<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class news extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/news_model');
        $this->load->library('image_lib');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index()
    {
        $category = 0;
        if ($_GET['cat'] > 0) {
            $category = $_GET['cat'];
        }
        $arr['msg'] = '';
        if ($_POST) {
            if (!empty($_POST['chk'])) {
                $arr = array();
                $delete_user = '0';
                if ($_POST['action'] == 'delete') {
                    $data['msg'] = 'delete';
                    $delete_user = '1';
                }

                foreach ($_POST['chk'] as $id) {
                    if ($delete_user == '1') {
                        $delete = deleteRecordById('latest_news', $id);
                        if ($delete) {
                            $this->session->set_flashdata('success', 'News deleted successfully.');
                        }
                    }
                }
            }
        }

        $data['news_list'] = $this->news_model->getRecords($category);
        $data['category'] = $this->news_model->getCategoriesRecords();
        $data['selected_category'] = $category;
        adminLoadView('news/list', $data);
    }

    public function add()
    {

        $postData = array();
        //
        if ($_POST) {
            $data['postData'] = $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

            // if(!filter_var($url, FILTER_VALIDATE_URL)) {
            // $data['error']='Enter Valid Link of Menu';
            // }else{

            $formValidation = $this->news_model->formValidations();

            if (!empty($_FILES['image'])) {

                $data['error'] = array();
                $file_name  = time() . $_FILES['image']['name'];
                $file_size  = $_FILES['image']['size'];
                $file_tmp   = $_FILES['image']['tmp_name'];
                $file_type  = $_FILES['image']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['image']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif");

                // if (in_array($file_ext, $expensions) === false) {
                //     $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                // }

                $insertData['image'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/news/' . $file_name;
                    $thumb['new_image']         = './upload/news/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();


                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/news/' . $file_name;
                    $thumb2['new_image']         = './upload/news/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/news/' . $file_name);
                }
            }

        
                // if (!empty($_FILES['news_audio'])) {
                //     $data['audio_error'] = array();
                //     $audio_file_name  = time() . $_FILES['news_audio']['name'];
                //     $audio_file_size  = $_FILES['news_audio']['size'];
                //     $audio_file_tmp   = $_FILES['news_audio']['tmp_name'];
                //     $audio_file_type  = $_FILES['news_audio']['type'];
                //     $audio_file_ext   = strtolower(end(explode('.', $_FILES['news_audio']['name'])));
                //     $audio_expensions = array("mp3");

                //     if (in_array($audio_file_ext, $audio_expensions) === false) {
                //         $data['audio_error'] = "extension not allowed, please choose a mp3 file.";
                //     }

                //     if ($audio_file_size > 2097152) {
                //         $data['audio_error'] = 'File size must be excately 5 MB';
                //     }

                //     // $insertData['news_audio'] = $audio_file_name;
                //     if (empty($data['audio_error']) == true) {
                //         move_uploaded_file($audio_file_tmp, "./upload/news/audio/" . $audio_file_name);
                //         //unlink("./upload/news/audio/" . $file_name);
                //     }
                // }
            

         
                // if (!empty($_FILES['news_video'])) {
                //     $data['video_error'] = array();
                //     $video_file_name  = time() . $_FILES['news_video']['name'];
                //     $video_file_size  = $_FILES['news_video']['size'];
                //     $video_file_tmp   = $_FILES['news_video']['tmp_name'];
                //     $video_file_type  = $_FILES['news_video']['type'];
                //     $video_file_ext   = strtolower(end(explode('.', $_FILES['news_video']['name'])));
                //     $video_expensions = array("mp4", "3gp", "avi");

                //     if (in_array($video_file_ext, $video_expensions) === false) {
                //         $data['news_video'] = "extension not allowed, please choose a mp4 or 3gp or avi file.";
                //     }

                //     if ($video_file_size > 2097152) {
                //         $data['news_video'] = 'File size must be excately 5 MB';
                //     }
                //     //$insertData['news_video'] = $video_file_name;

                //     if (empty($data['video_error']) == true) {
                //         move_uploaded_file($video_file_tmp, "./upload/news/video/" . $video_file_name);
                //         //unlink("./upload/news/video/" . $file_name);
                //     }
                // }
            

            //}
            if ($formValidation && empty($data['error'])) {

                //$newsdate =  date('Y-m-d h:i:s', strtotime($postData['date'] . ' ' . $postData['hour'] . ':' . $postData['minit'] . ':00'));
                $newsdate =  date('Y-m-d h:i:s');
                if ($postData['highlights']) {
                    $highlights = implode('#$#', $postData['highlights']);
                } else {
                    $highlights = '';
                }

                if ($postData['hide_name_on_news']) {
                    $hide_name_on_news = '1';
                } else {
                    $hide_name_on_news = '0';
                }

                if ($postData['hide_email_on_news']) {
                    $hide_email_on_news = '1';
                } else {
                    $hide_email_on_news = '0';
                }
                
                if ($postData['hide_image_on_news']) {
                    $hide_image_on_news = '1';
                } else {
                    $hide_image_on_news = '0';
                }

                $insertData = array(
                    'title'                 => $postData['title'],
                    'discription'           => $postData['discription'],
                    'link'                  => $postData['link'],
                    'date'                  => $newsdate,
                    'status'                => $postData['status'],
                    'country'               => $postData['country'],
                    'state'                 => $postData['state'],
                    'city'                  => $postData['city'],
                    'reporter'              => $postData['reporter'],
                    'categorise'            => $postData['categorise'],
                       'child_categorise'            => $postData['child_categorise'],
                    // 'short_discription'     => $postData['short_discription'],
                    'highlights'            => $highlights,
                    'image_capsion'         => $postData['image_capsion'],
                    'news_audio'          => $postData['news_audio'],
                    'news_video'          => $postData['news_video'],
                    'spceial_block'         => $postData['spceial_block'],
                    'youtube_code'          => $postData['youtube_code'],
                    'media_type'            => $postData['media_type'],
                    'hide_name_on_news'     => $hide_name_on_news,
                    'hide_image_on_news'     => $hide_image_on_news,
                    'hide_email_on_news'    => $hide_email_on_news
                );
                
                if (!empty($postData['image_capsion'])) {
                    $insertData['image_capsion'] = $postData['image_capsion'];
                } else {
                    $insertData['image_capsion'] = '';
                }
                
                if (!empty($_FILES['image'])) {
                    $insertData['image'] = $file_name;
                } else {
                    $insertData['image'] = '';
                }
                
                //$insertData['image'] = $file_name;
                $insertData['news_audio'] = $audio_file_name;
                $insertData['news_video'] = $video_file_name;

                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }

                $slug = create_slug('latest_news', $postData['title']);

                if (!empty($slug)) {
                    $insertData['slug'] = $slug;
                }

                //pr($insertData);
                //exit;

                $return = addUpdateRecord('latest_news', '', '', $insertData);


                 

                 if ($_FILES['mfile']['name'][0] !="") {
$count = count($_FILES['mfile']['name']);
                     for($i=0;$i<$count;$i++){

                $data['error'] = array();
                $file_name  = time() . $_FILES['mfile']['name'][$i];
                $file_size  = $_FILES['mfile']['size'][$i];
                $file_tmp   = $_FILES['mfile']['tmp_name'][$i];
                $file_type  = $_FILES['mfile']['type'][$i];
                $file_ext   = strtolower(end(explode('.', $_FILES['mfile']['name'][$i])));

                $expensions = array("jpeg", "jpg", "png", "gif");

                // if (in_array($file_ext, $expensions) === false) {
                //     $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                // }

              //  $insertData['mfile'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/news/' . $file_name;
                    $thumb['new_image']         = './upload/news/gorig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();


                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/news/' . $file_name;
                    $thumb2['new_image']         = './upload/news/gthumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/news/' . $file_name);
                }
                    if (!empty($file_name)) {
                        $data = array(
                        "name"=>$file_name,
                        "nid"=>$return
                        );
                    }
// $data = array(
// "name"=>$file_name,
// "nid"=>$return
// );
 $this->db->insert('news_gallery',$data);
}

            }


                if ($return) {
                    $this->session->set_flashdata('success', 'News added successfully.');
                    redirect('admin/news');
                }
            } else {

                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        

        $allcategory = $this->news_model->getCategoriesRecords11();
        $allcountry = $this->news_model->getAllCountry();
        //$allcountryState = $this->news_model->getAllCountrystate(101);
        $allReporter = $this->news_model->getallReporter();

        $data['allcategory'] = $allcategory;
        $data['allcountry'] = $allcountry;
        $data['allReporter'] = $allReporter;

        adminLoadView('news/create', $data);
    }

    public function edit($id = null, $user_id = 0)
    {


        if (empty($id)) {
            redirect('admin/news');
        }

        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /*
            if (!filter_var($url, FILTER_VALIDATE_URL)) {
				$data['error']='Enter Valid Link of Menu';
            }
            */
            $formValidation = $this->news_model->formValidations($id);
            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            $slug = create_slug('latest_news', $postData['title'], $id);
            if (!empty($slug)) {
                $updateData['slug'] = $slug;
            }

            /*
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {

                $data['error']  = array();
                $file_name      = $_FILES['image']['name'];
                $file_size      = $_FILES['image']['size'];
                $file_tmp       = $_FILES['image']['tmp_name'];
                $file_type      = $_FILES['image']['type'];
                $file_ext       = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions     = array("jpeg", "jpg", "png", "gif");

                if (in_array($file_ext, $expensions) === false) {
                    $data['error']  = "extension not allowed, please choose a JPEG or PNG file.";
                }

                if ($file_size > 2097152) {
                    $data['error']  = 'File size must be excately 2 MB';
                }

                $updateData['image'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                }

                $testsize = getimagesize("./upload/news/" . $file_name);
                $width = $testsize[0];
                $height = $testsize[1];

                if ($width < 450 || $height < 280) {
                    $data['error'] = 'Image Size is Small';
                    unlink("./upload/news/" . $file_name);
                }

                $updateData['image'] = $file_name;
            }
            */
            $myimg_fimename = $postData['oldimage'];
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {

                $data['error'] = array();
                $file_name  = time() . $_FILES['image']['name'];
                $file_size  = $_FILES['image']['size'];
                $file_tmp   = $_FILES['image']['tmp_name'];
                $file_type  = $_FILES['image']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['image']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif");

                // if (in_array($file_ext, $expensions) === false) {
                //     $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                // }


                $updateData['image'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                    $myimg_fimename = $file_name;
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/news/' . $file_name;
                    $thumb['new_image']         = './upload/news/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();

                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/news/' . $file_name;
                    $thumb2['new_image']         = './upload/news/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/news/' . $file_name);
                }
            }


        

                if (!empty($_FILES['news_audio'])) {

                    $data['audio_error'] = array();
                    $audio_file_name  = time() . $_FILES['news_audio']['name'];
                    $audio_file_size  = $_FILES['news_audio']['size'];
                    $audio_file_tmp   = $_FILES['news_audio']['tmp_name'];
                    $audio_file_type  = $_FILES['news_audio']['type'];
                    $audio_file_ext   = strtolower(end(explode('.', $_FILES['news_audio']['name'])));

                    $audio_expensions = array("mp3");

                    // if (in_array($audio_file_ext, $audio_expensions) === false) {
                    //     $data['audio_error'] = "extension not allowed, please choose a mp3 file.";
                    // }

                    // if ($audio_file_size > 2097152) {
                    //     $data['audio_error'] = 'File size must be excately 5 MB';
                    // }
                    // $updateData['news_audio'] = $audio_file_name;

                    if (empty($data['audio_error']) == true) {
                        move_uploaded_file($audio_file_tmp, "./upload/news/audio/" . $audio_file_name);
                        //unlink("./upload/news/audio/" . $file_name);
                    }
                }
            

         
                if (!empty($_FILES['news_video'])) {

                    $data['video_error'] = array();
                    $video_file_name  = time() . $_FILES['news_video']['name'];
                    $video_file_size  = $_FILES['news_video']['size'];
                    $video_file_tmp   = $_FILES['news_video']['tmp_name'];
                    $video_file_type  = $_FILES['news_video']['type'];
                    $video_file_ext   = strtolower(end(explode('.', $_FILES['news_video']['name'])));
                    $video_expensions = array("mp4", "3gp", "avi");
                    
                    
                    // if (in_array($video_file_ext, $video_expensions) === false) {
                    //     $data['news_video'] = "extension not allowed, please choose a mp4 or 3gp or avi file.";
                    // }
                    // if ($video_file_size > 2097152) {
                    //     $data['news_video'] = 'File size must be excately 5 MB';
                    // }
                    // $updateData['news_video'] = $video_file_name;

                    if (empty($data['video_error']) == true) {
                        move_uploaded_file($video_file_tmp, "./upload/news/video/" . $video_file_name);
                        //unlink("./upload/news/video/" . $file_name);
                    }
                }
            

            if ($formValidation &&  empty($data['error'])) {


                if ($postData['highlights']) {
                    $highlights = implode('#$#', $postData['highlights']);
                } else {
                    $highlights = '';
                }

                // $newsdate =  date('Y-m-d h:i:s', strtotime($postData['date'] . ' ' . $postData['hour'] . ':' . $postData['minit'] . ':00'));
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                $updateData['link'] = $postData['link'];
                // $updateData['date'] = $newsdate;
                $updateData['status'] = $postData['status'];
                // $updateData['short_discription'] = $postData['short_discription'];
                $updateData['media_type'] = $postData['media_type'];
                $updateData['country'] = $postData['country'];
                $updateData['state'] = $postData['state'];
                $updateData['city'] = $postData['city'];
                $updateData['reporter'] = $postData['reporter'];
                $updateData['categorise'] = $postData['categorise'];
                $updateData['child_categorise'] = $postData['child_categorise'];
                $updateData['youtube_code'] = $postData['youtube_code'];
                $updateData['spceial_block'] = $postData['spceial_block'];
                $updateData['highlights'] = $highlights;
                $updateData['image_capsion'] = $postData['image_capsion'];
                $updateData['image'] = $myimg_fimename;
                
                if (!empty($postData['image_capsion'])) {
                    $updateData['image_capsion'] = $postData['image_capsion'];
                } else {
                    $updateData['image_capsion'] = '';
                }
                
                // if (!empty($_FILES['image'])) {
                //     $updateData['image'] = $file_name;
                // } else {
                //     $updateData['image'] = $postData['oldimage'];
                // }
                
                

                if ($postData['hide_name_on_news']) {
                    $hide_name_on_news = '1';
                } else {
                    $hide_name_on_news = '0';
                }

                if ($postData['hide_email_on_news']) {
                    $hide_email_on_news = '1';
                } else {
                    $hide_email_on_news = '0';
                }
                
                if ($postData['hide_image_on_news']) {
                    $hide_image_on_news = '1';
                } else {
                    $hide_image_on_news = '0';
                }

                $updateData['hide_name_on_news'] = $hide_name_on_news;
                $updateData['hide_image_on_news'] = $hide_image_on_news;
                $updateData['hide_email_on_news'] = $hide_email_on_news;

                $return = addUpdateRecord('latest_news', 'id', $id, $updateData);

                   

                 if ($_FILES['mfile']['name'][0]!='') {
$count = count($_FILES['mfile']['name']);
                  
                     for($i=0;$i<$count;$i++){

                $data['error'] = array();
                $file_name  = time() . $_FILES['mfile']['name'][$i];
                $file_size  = $_FILES['mfile']['size'][$i];
                $file_tmp   = $_FILES['mfile']['tmp_name'][$i];
                $file_type  = $_FILES['mfile']['type'][$i];
                $file_ext   = strtolower(end(explode('.', $_FILES['mfile']['name'][$i])));

                $expensions = array("jpeg", "jpg", "png", "gif");

                // if (in_array($file_ext, $expensions) === false) {
                //     $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                // }

              //  $insertData['mfile'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/news/' . $file_name;
                    $thumb['new_image']         = './upload/news/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();


                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/news/' . $file_name;
                    $thumb2['new_image']         = './upload/news/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/news/' . $file_name);
                }
                
                 if (!empty($file_name)) {
                        $data = array(
                        "name"=>$file_name,
                        "nid"=>$id
                        );
                    }

// $data = array(
// "name"=>$file_name,
// "nid"=>$id
// );
 $this->db->insert('news_gallery',$data);
}

            }

                if ($return) {
                    $this->session->set_flashdata('success', 'News updated successfully.');
                    redirect('admin/news');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
            $data['postData'] = $postData;
        } else {
            $postData = $this->news_model->getRecordById($id);
             
            $postData['highlights'] = explode('#$#', $postData['highlights']);
            $data['postData'] = $postData;
            
        }


        $allcategory = $this->news_model->getCategoriesRecords11();
       
        $allcountry = $this->news_model->getAllCountry();
        
        //$allcountryState = $this->news_model->getAllCountrystate(101);
        $allReporter = $this->news_model->getallReporter();
           
        //pr($allcountry);
        $data['user_id'] = $user_id;
        $data['allcategory'] = $allcategory;
        $data['allcountry'] = $allcountry;
        $data['allReporter'] = $allReporter;

        adminLoadView('news/edit', $data);
    }

    public function delete($id = null)
    {

        if (empty($id)) {
            redirect('admin/news');
        }

        $deleteData = $this->news_model->getRecordById($id);
        $delete = deleteRecordById('latest_news', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'News deleted successfully.');
            redirect('admin/news');
        }
    }


    public function categories()
    {
        $data['blogs'] = $this->news_model->getCategoriesRecords();
        adminLoadView('news/list_category', $data);
    }
    public function categorie_add()
    {
        $postData = array();
        if ($_POST) {
            date_default_timezone_set('Asia/Kolkata');
        $dates= date('d-m-Y');
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->news_model->formCatValidations();
            // if (!empty($_FILES['image'])) {
            //     $data['error'] = array();
            //     $file_name = $_FILES['image']['name'];
            //     $file_size = $_FILES['image']['size'];
            //     $file_tmp = $_FILES['image']['tmp_name'];
            //     $file_type = $_FILES['image']['type'];
            //     $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
            //     $expensions = array("jpeg", "jpg", "png", "gif");
            //     if (in_array($file_ext, $expensions) === false) {
            //         $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
            //     }
            //     if ($file_size > 2097152) {
            //         $data['error'] = 'File size must be excately 2 MB';
            //     }
            //     $insertData['image'] = $file_name;
            //     if (empty($data['error']) == true) {
            //         move_uploaded_file($file_tmp, "./upload/news_categorie/" . $file_name);
            //         $testsize = getimagesize("./upload/news_categorie/" . $file_name);
            //         $width = $testsize[0];
            //         $height = $testsize[1];
                    
            //     }
            // }
            
            
            
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'title' => $postData['title'],
                    'discription' => $postData['discription'],
                    'link' => $postData['link'],
                    // 'image' => $postData['image'],
                    'categorie_type' => $postData['categorie_type'],
                    'categorie_colour' => $postData['categorie_colour'],
                    'order' => $postData['order'],
                    'created_date' => $dates,
                    'status' => $postData['status']
                );
                $insertData['image'] = $file_name;
                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }
                $slug = create_slug('news_categories', $postData['title']);
                if (!empty($slug)) {
                    $insertData['slug'] = $slug;
                }
                $return = addUpdateRecord('news_categories', '', '', $insertData);
                if ($return) {
                    if($_POST['parent_category']){
                    $parent_category=$_POST['parent_category'];
                    $data= array(
'parent_category'=>$parent_category,
'child_category'=>$return
                    );
                    $this->db->insert("category_map",$data);
                    }
                    $this->session->set_flashdata('success', 'news categorie added successfully.');
                    redirect('admin/news/categories');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('news/create_category', $data);
    }
    public function categorie_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/news/categories');
        }
        $postData = $this->news_model->getCategorieRecordById($id);
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

            $formValidation = $this->news_model->formCatValidations($id);
            $slug = create_slug('news_categories', $postData['title'], $id);
            if (!empty($slug)) {
                $updateData['slug'] = $slug;
            }

            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            // if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
            //     $data['error'] = array();
            //     $file_name = $_FILES['image']['name'];
            //     $file_size = $_FILES['image']['size'];
            //     $file_tmp = $_FILES['image']['tmp_name'];
            //     $file_type = $_FILES['image']['type'];
            //     $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
            //     $expensions = array("jpeg", "jpg", "png", "gif");
            //     if (in_array($file_ext, $expensions) === false) {
            //         $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
            //     }
            //     if ($file_size > 2097152) {
            //         $data['error'] = 'File size must be excately 2 MB';
            //     }
            //     $updateData['image'] = $file_name;
            //     if (empty($data['error']) == true) {
            //         move_uploaded_file($file_tmp, "./upload/news_categorie/" . $file_name);
            //     }
            //     $testsize = getimagesize("./upload/news_categorie/" . $file_name);
            //     $width = $testsize[0];
            //     $height = $testsize[1];
                
            //     $updateData['image'] = $file_name;
            // }
            if ($formValidation && empty($data['error'])) {
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                $updateData['link'] = $postData['link'];
                $updateData['categorie_type'] = $postData['categorie_type'];
                $updateData['status'] = $postData['status'];
                $updateData['categorie_colour'] = $postData['categorie_colour'];
                $updateData['order'] = $postData['order'];

                $return = addUpdateRecord('news_categories', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'news categorie updated successfully.');
                    redirect('admin/news/categories');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        adminLoadView('news/edit_category', $data);
    }
    public function categorie_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/news/categories');
        }
        $deleteData = $this->news_model->getCategorieRecordById($id);
        $delete = deleteRecordById('news_categories', $deleteData['id']);
        if ($delete) {
           $this->db->delete('category_map', array('child_category' =>  $deleteData['id'])); 
            $this->session->set_flashdata('success', 'news Categorie deleted successfully.');
            redirect('admin/news/categories');
        }
    }

    function getCountrySate()
    {
        $allcountryState = array();
        if ($_POST['country_id']) {
            $allcountryState = $this->news_model->getAllCountrystateByName($_POST['country_id']);
        }
        echo json_encode($allcountryState);
    }
    function ndelete()
    {
       $nid = $this->uri->segment(4);
       $id = $this->uri->segment(5);
           $delete = deleteRecordById('news_gallery', $id);
        if ($delete) {
            $this->session->set_flashdata('success', 'Deleted successfully.');
            redirect("admin/news/edit/$nid");
        }
    }
    
    public function categorie_manage()
    {
     
        $data['cate'] = $this->news_model->getManCategoriesRecords();
        
        adminLoadView('news/manage_category', $data);
    }
    
    public function add_categorie_manage(){
        
     $catid =    $_POST['manage_category'];
     $position = $_POST['position'];
   
    $sql = "SELECT * FROM `manage_category` where position = $position OR 	categoriesid = $catid";
    	$query = $this->db->query($sql);
        $result = $query->result();
        if($result){
          for($i=0;count($result)>$i;$i++){
              $sql1 = "DELETE FROM `manage_category` where position = $position OR 	categoriesid = $catid";
              $this->db->query($sql1);
          }
           $insertData = array(
                    'categoriesid' => $_POST['manage_category'],
                    'position' => $_POST['position']
                );
                
                $return = addUpdateRecord('manage_category', '', '', $insertData);
                $this->session->set_flashdata('success', 'news categorie Update successfully.');
                    redirect('admin/news/categorie_manage');
        }
        else{
           $insertData = array(
                    'categoriesid' => $_POST['manage_category'],
                    'position' => $_POST['position']
                );
                
                $return = addUpdateRecord('manage_category', '', '', $insertData);
                

                    $this->session->set_flashdata('success', 'news categorie added successfully.');
                    redirect('admin/news/categorie_manage');
        }
     
    }
    
    public function man_categorie_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/news/categorie_manage');
        }
        $deleteData = $this->news_model->getmanCategorieRecordById($id);
        $delete = deleteRecordById('manage_category', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'Manage news Categorie deleted successfully.');
            redirect('admin/news/categorie_manage');
        }
    }
    
    
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
