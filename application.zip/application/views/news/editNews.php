<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script>
<style>
	#imgdiv {
		width: 160px;
		float: left;
		margin-left: 20px
	}

	#reload {
		float: right;
		margin-right: 40px
	}

	section {
		background-color: #FFF;
	}

	span.error_message {
		color: #e45252;
	}
</style>
<section id="form">
	<!--form-->
	<div class="container">
		<div class="row">
			<div class="col-sm-1"></div>
			<div class="col-sm-10">
				<br />
				<br />
				<div class="categoryproduct " style="padding-left:0;">
					<div class="content-heading">
						<h2 class="title-head">Edit News</h2>
					</div>
				</div>
				<div class="signup-form">
					<?php
					if (!empty($postData)) {
						$name               = $postData['title'];
						$discription        = $postData['discription'];
						$link               = $postData['link'];
						$status 	    = $postData['status'];
						$image              = $postData['image'];
						$media_type         = $postData['media_type'];
						$youtube_code       = $postData['youtube_code'];
						$short_discription  = $postData['short_discription'];
						$news_countryname   = $postData['country'];
						$news_state         = $postData['state'];
						$news_city          = $postData['city'];
						$categorise         = $postData['categorise'];
						$image_capsion 	    = $postData['image_capsion'];
						$highlights_array   = $postData['highlights'];
						$hide_name_on_news  = $postData['hide_name_on_news'];
						$hide_email_on_news = $postData['hide_email_on_news'];
						$hide_image_on_news = $postData['hide_image_on_news'];
					}
					?>
					<div class="outter-wp">
						<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
						<!--/sub-heard-part-->
						<div class="graph-visual tables-main">
							<div class="graph-form">
								<?php if (!empty($error)) { ?>
									<div class="alert alert-danger message" style="display: block;">
										<?php echo $error; ?>
									</div>
								<?php } ?>
								<div class="form-body">
									<form action="<?php echo base_url('news/edit/' . $id); ?>" id="editnewsform" enctype="multipart/form-data" method="post">
										<div class="form-group">
											<label for="exampleInputEmail1">News Headline <span class="star-color">*</span></label>
											<input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>">
											<span class="error_message" id="title_error"></span>
										</div>
										<!-- <div class="form-group">
											<div class="row">
												<div class="col-lg-12">
													<label for="exampleInputPassword1">Short Description <span class="star-color"></span></label>
													<textarea name="short_discription" style="width: 100%;height: 70px" id="short_discription"><?php echo $short_discription; ?></textarea>
												</div>
											</div>
										</div> -->
										<div class="form-group">
											<div class="row">
												<div class="col-lg-12">
													<label for="exampleInputPassword1">Description <span class="star-color">*</span></label>
													<textarea name="discription" rows="3" cols="90" id="discription" name="discription"><?php echo $discription; ?></textarea>
													<span class="error_message" id="discription_error"></span>
												</div>
											</div>
										</div>
										<div class="form-group">
											<div class="row">
												<div class="col-lg-12">
													<label>News Highlights</label>
													<div id="add_highlights">
														<?php
														if (!empty($highlights_array)) {
															$i = 0;
															foreach ($highlights_array as $highlights) { ?>
																<P class="highlightsClass"><input type="text" class="form-control col-lg-11" name="highlights[]" value="<?php echo $highlights; ?>">&nbsp;&nbsp; <?php if ($i == 0) { ?><a onclick="add_highlights_point();">Add New</a><?php } else { ?><a onclick="removePoint(this);">Remove</a><?php } ?></p>
															<?php $i++;
															}
														} else { ?>
															<P class="highlightsClass"><input type="text" class="form-control col-lg-11" name="highlights[]" value="">&nbsp;&nbsp; <?php if ($i == 0) { ?><a onclick="add_highlights_point();">Add New</a><?php } else { ?><a onclick="removePoint(this);">Remove</a><?php } ?></p>
														<?php } ?>
													</div>
												</div>
											</div>
										</div>
										<div class="form-group">
											<label>Add Image </label>
											<input type="hidden" name='mimage' value="<?php echo $image; ?>">
											<input class="form-control" type="file" name="image" value="">
											
											<?php if ($image != '') { ?>
												<br>
												<br>
												<img src="<?php echo base_url('upload/news/thumb/' . $image); ?>" height="80px" width="200px">
											<?php } ?>
										</div>
										<div class="form-group">
											<label>Add Image description</label>
											<input type="text" name="image_capsion" class="form-control" value="<?php echo $image_capsion; ?>">
										</div>
										<!-- <div class="form-group">
											<label for="exampleInputPassword1">Link <span class="star-color">*</span></label>
											<input type="text" class="form-control" id="link" name="link" value="<?php echo $link; ?>">
										</div> -->


										<script type="text/javascript">
		function add_highlights_point11() {
		$('#add_highlights11').append('<p class="highlightsClass"><input type="file" class="form-control col-lg-10" name="mfile[]" value="">&nbsp;&nbsp;<a  style="cursor:pointer;color:red;" onclick="removePoint(this);" >Remove</a></p>');
	}
</script>
										<div class="form-group">
						<label>Add Multiple Image </label>
						<br>
						<?php foreach ($getmultipleimage as $key => $value) { ?>
						<!--<input type="hidden" name='mmfile[]' value="<?= $value['name']; ?>">-->
						<img src="<?= base_url(); ?>upload/news/orig/<?= $value['name']; ?>" style="width:100px;margin-left:20px;border:1px solid #444;padding:3px;"/> <span style="color:red;cursor:pointer;" onclick="deletemultipleimage(<?php echo $value['id']; ?>);">Delete</span>
                      <?php } ?>
						<div style="clear: both;"></div>
				<p class="highlightsClass"><input type="file" class="form-control col-lg-10" name="mfile[]" value="">&nbsp;&nbsp;<a  style="cursor:pointer;color:#008DE7;" onclick="add_highlights_point11(this);" >Add  More Image</a></p>
						<span id="add_highlights11"></span><br>
						<div style="clear: both;"></div>
					</div>
					<div></div>


										<div class="form-group">
											<label for="exampleInputPassword1">News Type</label>
											<div class="radio block">
												<label>
													<input type="radio" value="news" onclick="showTheUploadOption(this.value);" <?php echo ($media_type == 'news') ? 'checked="checked"' : ''; ?> name="media_type" checked="checked" />News
												</label>
												&nbsp;&nbsp;&nbsp;&nbsp;
												<label>
													<input type="radio" value="youtube" onclick="showTheUploadOption(this.value);" <?php echo ($media_type == 'youtube') ? 'checked="checked"' : ''; ?> name="media_type" />Youtube
												</label>
											</div>

											<!--<select class="form-control" onclick="showTheUploadOption(this.value);" id="media_type" name="media_type">
							<option <?php if ($media_type != 'youtube' && $media_type != 'video' && $media_type != 'audio') {
										echo ' selected="selected" ';
									} ?> selected="selected" value="news">News</option>
							 <option value="images">Image</option> 
							<option <?php if ($media_type == 'audio') {
										echo ' selected="selected" ';
									} ?> value="audio">Audio</option>
							<option <?php if ($media_type == 'video') {
										echo ' selected="selected" ';
									} ?> value="video">Video</option>
							<option <?php if ($media_type == 'youtube') {
										echo ' selected="selected" ';
									} ?> value="youtube">Youtube</option>
														
							<option value="facebook">FaceBook</option>
							<option value="twitter">Twitter</option>
							<option value="instagram">Instagram</option>
							 
						</select>
						 -->
										</div>
										<div class="form-group optionContaner" id="option_to_show_audio" style="display:none">
											<label for="exampleInputPassword1">News Audio</label>
											<input type="file" name="news_audio" value="<?php echo $news_audio; ?>"><small class="msg-upload">maximum 5mb File size allowed</small>
										</div>
										<div class="form-group optionContaner" id="option_to_show_video" style="display:none">
											<label for="exampleInputPassword1">News Video</label>
											<input type="file" name="news_video" value="<?php echo $news_video; ?>"><small class="msg-upload">maximum 5mb File size allowed</small>
										</div>
										<div class="form-group optionContaner" id="option_to_show_youtube" style="display:<?php if ($media_type == 'youtube') {
																																echo ' block ';
																															} else {
																																echo ' none ';
																															} ?>">
											<div class="row">
												<div class="col-lg-8">
													<label for="exampleInputPassword1">News YouTube Code</label>
													<textarea name="youtube_code" style="width: 100%;height: 70px" id="youtube_code"><?php echo $youtube_code; ?></textarea>
												</div>
											</div>
											<div class="row">
												<div class="col-lg-8">
													<label for="exampleInputPassword1">Note:</label>
													<ol>
														<li>On a computer, go to the YouTube video you want to embed.</li>
														<li>Under the video, click SHARE Share.</li>
														<li>Click Embed.</li>
														<li>From the box that appears, copy the HTML code.</li>
														<li>Paste the code into News YouTube Code.</li>
													</ol>
												</div>
											</div>
										</div>
										<div class="form-group">
											<label for="exampleInputPassword1">Location</label>
											<br>
											<select class="form-control" id="news_country" name="country" onchange="news_getcountrystate(this.value);">
												<?php foreach ($allcountry as $country) {
													$selected = '';
													if ($country->name == 'India') {
														$selected = ' selected="selected" ';
													}
												?>
													<option <?php echo $selected; ?> value="<?php echo $country->name; ?>"><?php echo $country->name; ?></option>
												<?php } ?>
											</select>
											<span class="error_message" id="news_country_error"></span>
											<br><br>
											<select class="form-control" id="news_state" name="state" onchange="news_setStateCity(this.value)">
												<option value=""></option>
											</select>
											<br>
											<br>

											<select class="form-control" id="news_city" name="city">
												<option value=""></option>
											</select>
										</div>
										<br>
										<br>
																		<div class="form-group">
						<label for="exampleInputPassword1">News Categorise*</label>
						<br>
						<select class="form-control pcategory" id="categorise" name="categorise">
							<option value=""></option>
							<?php foreach ($allcategory as $cat) { ?>
								<option <?php if ($categorise == $cat['id']) {
											echo ' selected ';
										} ?> value="<?php echo $cat['id']; ?>"><?php echo $cat['title']; ?></option>
							<?php } ?>
						</select>
					</div>

							<div class="form-group">
						<label for="exampleInputPassword1">News Sub Categorise</label>
						<br>
						<?php if(!empty($childcategoryname[0]['slug'])) { ?>
						<select class="form-control ccategory" id="categorise" name="child_categorise">
							<option value="<?php echo $childcategoryname[0]['id']; ?>"><?php echo $childcategoryname[0]['slug']; ?></option>
							
						</select>
					<?php } else { ?>
						<select class="form-control ccategory" id="categorise" name="child_categorise">
							<option value="">News Sub Categorise</option>
							
						</select>
					<?php } ?>
					</div>

							<script>
$(document).ready(function(){
    $("select.pcategory").change(function(){
        var pcategory = $(".pcategory option:selected").val();
        //alert(pcategory);
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>news/pcategory",
            data: { pcategory : pcategory } 
        }).done(function(data){
        //alert(data);
        	// alert(data);
           $(".ccategory").html(data);
        });
    });
});
</script>
										<div class="form-group">
											<br>
											<br>
											<label>
												<input type="checkbox" name="hide_email_on_news" <?php if ($hide_email_on_news == '1') {
																										echo ' checked="checked" ';
																									} ?> value="1">
												Hide email on news
											</label>
											&nbsp;&nbsp;&nbsp;&nbsp;
											<label>
												<input type="checkbox" name="hide_name_on_news" <?php if ($hide_name_on_news == '1') {
																									echo ' checked="checked" ';
																								} ?> value="1">
												Hide name on news
											</label>
											&nbsp;&nbsp;&nbsp;&nbsp;
											<label>
												<input type="checkbox" name="hide_image_on_news" <?php if ($hide_image_on_news == '1') {
																									echo ' checked="checked" ';
																								} ?> value="1">
												Hide Imge on news
											</label>
										</div>
										<div class="form-group">
											<label for="radio" class="col-sm-2 control-label">Status</label>
											<div class="radio block">
												<label>
													<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked" />Active
												</label>
												&nbsp;&nbsp;&nbsp;&nbsp;
												<label>
													<input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive
												</label>
											</div>
										</div>
										<div class="form-group">
											<label class="">
												<!-- <input <?php if ($check_for_terms == '1') {
																echo ' checked="checked" ';
															} ?> type="checkbox" name="check_for_terms" value="1" id="check_for_terms" /> -->
												<!--By clicking "Submit" ,You are agree to the <a data-toggle="modal" style="color: #980537;" data-target="#modal_terms_and_conditions">Terms and Conditions</a>.-->
											</label><br>
											<span class="error_message" id="check_for_terms_error"></span>
										</div>
										
										<input type="hidden" name="submit_action" id="submit_action" value="add" />
										
										<button type="button" id="submit_button" title="Active Your News" name="save" value="save" class="btn-sm btn-secondary">Update</button>
										<button id="submit_button_loader" style="display: none;" title="Create an Account" name="save" value="save" class="btn-sm btn-secondary">Update <i class="fa fa-circle-notch fa-spin" style="font-size:24px"></i></button>
										<!--<button id="submit_button" onclick="return validateForm('preview');" title="Create an Account" name="preview" value="preview" class="btn-sm btn-secondary">Preview</button>-->
										
										<!-- 
											<button type="submit" onclick="return validateForm();" class="btn btn-sm btn-secondary display-4" name="submit" value="submit">Update</button>
										 -->
										<a href="<?php echo base_url('news/my_news'); ?>"><button type="button" class="btn btn-sm btn-secondary display-4" name="Back" value="Back">Back</button></a>
									
									</form>
								</div>
							</div>
							<!--//graph-visual-->
						</div>
					</div>
					<br><br>
					<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
					<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
					<script>
						//Replace the <textarea id="editor1"> with a CKEditor
						//instance, using default configuration.
						CKEDITOR.env.isCompatible = true;
						CKEDITOR.replace('discription');

						function showTheUploadOption(val) {
							$('.optionContaner').hide();
							$('#option_to_show_' + val).show();
						}

						function add_highlights_point() {
							$('#add_highlights').append('<p class="highlightsClass"><input type="text" class="form-control col-lg-10" name="highlights[]" value="">&nbsp;&nbsp;<a onclick="removePoint(this);" >Remove</a></p>');
						}

						function removePoint(ele) {
							$(ele).parent('p').remove();
						}

						function news_getcountrystate(id, onload = '', set = '', city = '') {
							var postData = {
								country_id: id
							};
							$.ajax({
								url: "<?php echo base_url(); ?>home/getCountrySate",
								data: postData,
								dataType: 'json',
								type: 'POST',
								success: function(result) {
									$('#news_state').html('');
									var output = [];
									output.push('<option value=""></option>');
									$.each(result, function(key, value) {
										output.push('<option value="' + value.name + '">' + value.name + '</option>');
									});

									if (output.length > 0) {
										$('#news_state').html(output.join(''));
									} else {
										$('#news_state').html('<option value="">No state found</option>');
									}
									if (onload == 'load') {
										if (set != '') {
											$('#news_state').val(set);
										}
										if (city != '') {
											setTimeout(function() {
												news_setStateCity(set, 'load', city);
											}, 1000);
										}
									}
									$('#news_state').trigger('change');
								}
							});
						}

						function news_setStateCity(id, onload = '', set = '') {
							//alert(id);
							var postData = {
								country_id: id
							};

							$.ajax({
								url: "<?php echo base_url(); ?>home/getSateCity",
								data: postData,
								dataType: 'json',
								type: 'POST',
								success: function(result) {

									$('#news_city').html('');
									var output = [];
									output.push('<option value=""></option>');
									$.each(result, function(key, value) {
										output.push('<option value="' + value.name + '">' + value.name + '</option>');
									});
									if (output.length > 0) {
										$('#news_city').html(output.join(''));
									} else {
										$('#news_city').html('<option value="">No city found</option>');
									}
									if (onload == 'load') {
										if (set != '') {
											$('#news_city').val(set);
										}
									}
									$('#news_city').trigger('change');
								}
							});
						}

						$(document).ready(function() {
							$('#news_country').select2({
								placeholder: "Select country",
								allowClear: true
							});
							$('#news_state').select2({
								placeholder: "Select state",
								allowClear: true
							});
							$('#news_city').select2({
								placeholder: "Select city",
								allowClear: true
							});
							$('#categorise').select2({
								placeholder: "Select categorise",
								allowClear: true
							});
							$('#news_country').val('<?php echo $news_countryname ?>');
							$('#news_country').trigger('change');
							news_getcountrystate('<?php echo $news_countryname ?>', 'load', '<?php echo $news_state ?>', '<?php echo $news_city ?>');
							//setStateCity('<?php echo $news_state ?>', 'load', '<?php echo $news_city ?>');
						});


						function validateForm(act) {
							var error = 0;
				// 			$('#submit_button').hide();
				// 			$('#submit_button_loader').show();
							$('.error_message').html('');
							
							if ($('#title').val() == '') {
								$("#title_error").html('please enter new titel');
								error = 1;
							}
							var desc = CKEDITOR.instances['discription'].getData();
							if (desc == '') {
								$("#discription_error").html('please enter new discription');
								error = 1;
							}

							if ($('#news_country').val() == '') {
								$("#news_country_error").html('please enter country');
								error = 1;
							}

							var data = $('#news_country').select2('data');
							if (data == '') {
								$("#news_country_error").html('please select country');
								error = 1;
							}

							/*
							if($("#check_for_terms").prop('checked') != true){
								$("#check_for_terms_error").html('please agree to the Terms and Conditions and Privacy Policy');
								error = 1;
							}
							*/

							if (error == 1) {
								return false;
							} else {
								//$('#myModalPreview').modal('show');
								// $("#submit_action").val(act);
								// document.theForm.submit()
								return true;
							}
						}

						function callsubmit(act) {
				// 			$("#submit_action").val(act);
				// 			console.log('***********');
				// 			console.log(act);
							//$("#add_news_form").submit();
							//document.getElementById('add_news_form').submit();
				// 			document.theForm.submit()
						}
					</script>
				</div>
				<!--/sign up form-->
			</div>
		</div>
	</div>
</section>
<!--/form-->

<div class="modal fade" id="modal_terms_and_conditions" role="dialog">
	<div class="modal-dialog modal-lg" style="width:90%;">
		<div class="modal-content" style="width:92%;">
			<div class="modal-header">
				<h4 class="modal-title">Terms and Conditions and Privacy Policy</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body" style="overflow-x: hidden; overflow-y: scroll;">
				<?php echo  $terms_and_conditions_and_privacy_policy_html; ?>
				<p><input type="checkbox" id="myCheck" onclick="myFunction()" style="height:15px;width:15px;"> <label style="font-family: serif;font-size: 18px;font-weight: 600;">Agree Term & Condition</label></p>
			</div>
			<div class="modal-footer">
			    <button type="button" id="chk_agree_term_con" style="display:none;background-color: #260f51!important;" class="btn btn-sm btn-primary">Ok</button>
				<button type="button" class="btn-sm btn-info-outline close_term_con_modal" style="background-color: #b7b6ba!important;" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>




<style type="text/css">
	.form-control {
    display: block;
    width: 100%;
    height: 37px;
    padding: 8px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #777;
    background-color: #fff;
    background-image: none;
    border: 1px solid #ddd;
    border-radius: 0;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}
.glyphicon {
    position: relative;
    top: 1px;
    display: inline-block;
    font-family: 'Glyphicons Halflings';
    font-style: normal;
    font-weight: 400;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
</style>
<script>
function deletemultipleimage(id)
{
    var imageid = id;
    // alert(imageid);
    

    $.ajax({
        url: '<?php echo base_url(); ?>news/deleteimages',
        type: "post",
        data: {
           'imageid':imageid,
        },
        success: function(data) {
        alert('Image Deleted Successfully.');
        location.reload()
        },
   
});
}
</script>

<script>
function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("chk_agree_term_con");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}



    $(function(){
        $("button#submit_button").click(function(){
            if($("#chk_agree_term_con").is(":checked")){
                if(validateForm('active')){
                    $("form#editnewsform").submit();
                }
            }else{
                $("#modal_terms_and_conditions").modal('show');
            }
        });
        $("button#chk_agree_term_con").click(function(){
            if($(this).submit() && validateForm('active')){
                $("form#editnewsform").submit();
            }
            else if($(this).submit()){
                $("#modal_terms_and_conditions .close_term_con_modal").click();
            }
        });
    });
</script>