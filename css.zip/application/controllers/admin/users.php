<?php

//error_reporting(0);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Users extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
        $this->load->helper('custom_helper');
        $this->load->model('admin/users_model');
        $this->load->model('news_model');
    }

    public function index()
    {
        $arr['page'] = 'user';
        $arr['msg'] = '';
        if ($_POST) {
            if (!empty($_POST['chk'])) {
                $arr = array();
                $delete_user = '0';
                if ($_POST['action'] == 'active') {
                    $arr = array('user_status' => 'A');
                    $data['msg'] = 'active';
                } else if ($_POST['action'] == 'deactive') {
                    $arr = array('user_status' => 'D');
                    $data['msg'] = 'deactive';
                } else if ($_POST['action'] == 'suspend') {
                    $arr = array('user_status' => 'S');
                    $data['msg'] = 'suspend';
                } else if ($_POST['action'] == 'delete') {
                    $data['msg'] = 'delete';    
                    $delete_user = '1';
                }else if ($_POST['action'] == 'sendmail') {
                    $data['msg'] = 'sendmail';
                    $send_mail = 'sendmail';
                }
                
                foreach ($_POST['chk'] as $id) {
                    if($send_mail=='sendmail'){
                        //echo '****';
                    }else if($delete_user == '1'){
                        $delete = deleteRecordById('users', $id);
                        if ($delete) {
                            $this->session->set_flashdata('success', 'Users deleted successfully.');
                        }
                    }else{
                        if(!empty($arr)){
                            $this->db->where('id', $id);
                            $this->db->update('users', $arr);
                        }
                    }
                }
            }
        }
        
        $users = $this->users_model->getUsers();
        $data['users'] = $users;
        $this->load->view('admin/users/vwManageUser', $data);
    }

    /*
    public function add_newuser() {
        $arr['page'] = 'user';
        $this->load->view('admin/users/vwAddNewUser',$arr);
    }
	*/


    function add_newuser()
    {

        $this->load->model('regusers_model');
        $this->load->model('user_model');
        $user = array();
        
        date_default_timezone_set('Asia/Kolkata');
        $dates= date('d-m-Y');
        
        

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('first_name', 'first name', 'required');
            $this->form_validation->set_rules('last_name', 'last name', 'required');
            $this->form_validation->set_rules('email', 'email address', 'trim|required|valid_email');
            //$this->form_validation->set_rules('address_street', 'address', 'required');
            //$this->form_validation->set_rules('address_city', 'city', 'required');
            //$this->form_validation->set_rules('phone_mobile', 'phone no', 'required|max_length[15]|min_length[10]|numeric');
            //$this->form_validation->set_rules('address_state', 'state', 'required');
            //$this->form_validation->set_rules('address_country', 'country', 'required');
            //$this->form_validation->set_rules('phone_mobile', 'phone no', 'required');

            if ($this->input->post('password') != '' ) {
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
            }

            //$this->form_validation->set_error_delimiters('<div class="alert bg-danger"><a class="close" data-dismiss="alert">x</a><strong>', '</strong></div>');

            if ($this->form_validation->run()) {
                $profile_image = '';
                if (!empty($_FILES)) {
                    if ($_FILES['profile_image']['tmp_name'] != "") {
                        $tempFile      = $_FILES['profile_image']['tmp_name'];
                        $temp          = $_FILES["profile_image"]["name"];
                        $path_parts    = pathinfo($temp);
                        $t             = preg_replace('/\s+/', '', microtime());
                        $fileName      = time() . '_' . $path_parts['filename'] . $t . '.' . $path_parts['extension'];
                        $targetPath    =  "./upload/profile_image/";
                        $targetFile    = $targetPath . $fileName;
                        $profile_image = $fileName;
                        move_uploaded_file($tempFile, $targetFile);
                    } else {
                        $profile_image = $this->input->post('old_logo');
                    }
                } else {
                    $profile_image = $this->input->post('old_logo');
                }

                $data_to_store = array(
                    'first_name' => $this->input->post('first_name'),
                    'last_name' => $this->input->post('last_name'),
                    'email' => $this->input->post('email'),
                    'address_street' => $this->input->post('address_street'),
                    'address_city' => $this->input->post('address_city'),
                    'phone_mobile' => $this->input->post('phone_mobile'),
                    'address_state' => $this->input->post('address_state'),
                    'address_country' => $this->input->post('address_country'),
                    'signup_date' => $dates,
                    'gender' => $this->input->post('gender'),
                    'profile_image' => $profile_image
                );
                //var_dump($data_to_store);
// die;
                if ($this->input->post('password') != '') {
                    $data_to_store['password'] = $this->input->post('password');
                }

                $data_to_store['user_status'] = $this->input->post('user_status');


                if ($this->regusers_model->insert_users($data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/users');
            } else {
                $user = $_POST;
            }
        }

        $allcountry = getAllCountry();
        //$allcountryState = getAllCountrystate(101);

        $data['id'] = $id;
        $data['allcategory'] = $allcategory;
        $data['allcountry'] = $allcountry;
        $data['user']  = $user;
        $this->load->view('admin/users/vwAddNewUser', $data);
    }

    public function edit_user($id)
    {
        $this->load->model('regusers_model');
        $this->load->model('user_model');
        $user = $this->user_model->getRecordById($id);

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('first_name', 'first name', 'required');
            $this->form_validation->set_rules('last_name', 'last name', 'required');
            if ($user['email'] != $this->input->post('email')) {
                $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email|callback_validate_email');
                $this->form_validation->set_message('validate_email', 'This email address already register.please login!');
            } else {
                $this->form_validation->set_rules('email', 'email address', 'trim|required|valid_email');
            }
            //$this->form_validation->set_rules('address_street', 'address', 'required');
            //$this->form_validation->set_rules('address_city', 'city', 'required');
            //$this->form_validation->set_rules('phone_mobile', 'phone no', 'required|max_length[15]|min_length[10]|numeric');
            //$this->form_validation->set_rules('address_state', 'state', 'required');
            //$this->form_validation->set_rules('address_country', 'country', 'required');
            //$this->form_validation->set_rules('phone_mobile', 'phone no', 'required');

            if ($this->input->post('password') != '' ) {
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
            }

            //$this->form_validation->set_error_delimiters('<div class="alert bg-danger"><a class="close" data-dismiss="alert">x</a><strong>', '</strong></div>');

            if ($this->form_validation->run()) {
                $profile_image = '';
                if (!empty($_FILES)) {
                    if ($_FILES['profile_image']['tmp_name'] != "") {
                        $tempFile      = $_FILES['profile_image']['tmp_name'];
                        $temp          = $_FILES["profile_image"]["name"];
                        $path_parts    = pathinfo($temp);
                        $t             = preg_replace('/\s+/', '', microtime());
                        $fileName      = time() . '_' . $path_parts['filename'] . $t . '.' . $path_parts['extension'];
                        $targetPath    =  "./upload/profile_image/";
                        $targetFile    = $targetPath . $fileName;
                        $profile_image = $fileName;
                        move_uploaded_file($tempFile, $targetFile);
                    } else {
                        $profile_image = $this->input->post('old_logo');
                    }
                } else {
                    $profile_image = $this->input->post('old_logo');
                }

                $data_to_store = array(
                    'first_name' => $this->input->post('first_name'),
                    'last_name' => $this->input->post('last_name'),
                    'email' => $this->input->post('email'),
                    'address_street' => $this->input->post('address_street'),
                    'address_city' => $this->input->post('address_city'),
                    'phone_mobile' => $this->input->post('phone_mobile'),
                    'address_state' => $this->input->post('address_state'),
                    'address_country' => $this->input->post('address_country'),
                    'phone_mobile' => $this->input->post('phone_mobile'),
                    'gender' => $this->input->post('gender'),
                    'profile_image' => $profile_image
                );

                if ($this->input->post('password') != '') {
                    $data_to_store['password'] = $this->input->post('password');
                }

                $data_to_store['user_status'] = $this->input->post('user_status');


                if ($this->regusers_model->update_users($id, $data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/users');
            } else {
                $user = $_POST;
            }
        }

        $allcountry = getAllCountry();
        //$allcountryState = getAllCountrystate(101);

        $data['id'] = $id;
        $data['allcategory'] = $allcategory;
        $data['allcountry'] = $allcountry;
        $data['user']  = $user;
        $this->load->view('admin/users/vwEditUser', $data);
    }

    public function delete_user($user_id)
    {
        if (empty($user_id)) {
            redirect('users');
        }

        $delete = deleteRecordById('users', $user_id);
        if ($delete) {
            $this->session->set_flashdata('success', 'Users deleted successfully.');
        }
        redirect('admin/users');
    }

    function list_users_ajax($msg = '') {
        
        $sort = array('id', 'first_name', 'last_name', 'email', 'user_ip');
        if ($_POST['sSearch']) {
            $search = " WHERE first_name LIKE '%" . $_POST['sSearch'] . "%' OR last_name LIKE '%" . $_POST['sSearch'] . "%' OR email LIKE '%" . $_POST['sSearch'] . "%' OR user_ip LIKE '%" . $_POST['sSearch'] . "%'";
        } else {
            $search = '';
        }
        if ($sort[$_POST['iSortCol_0']]) {
            $order = " ORDER BY " . $sort[$_POST['iSortCol_0']] . " " . $_POST['sSortDir_0'];
        }
        $get['limit'] = $_POST['iDisplayLength'];
        $get['fields'] = '*';
        $get['offset'] = $_POST['iDisplayStart'];
        $get['search'] = $search;
        $get['order'] = $order;
        $row = $this->users_model->getUsers($get);
        $res = array();

        foreach ($row as $k => $r) {
            $res[$k]['checkbox'] = '<input type="checkbox" class="checkbox1" name="chk[]" value="' . $r['id'] . '" />';
            $res[$k]['first_name'] = $r['first_name'] .' '.$r['last_name'];
            
            /* $res[$k]['email'] =
              '<a href="' .base_url() .'admin/admin_user/event_user/?id='.$r['id'].'' . $r['id'] . '" onclick="fillModel(this)">'.$r['email'].'</a>'; */

            $res[$k]['email'] = $r['email'];

            /* $res[$k]['email'] = '<a href="#" onclick="setEmail(this);" email="' . $r['email'] . '"  id="m_window"  data-toggle="modal" data-target="#myModal">' . $r['email'] . '</a>'; */
            //$res[$k]['first_name'] = $r['first_name'];
            //$res[$k]['user_ip'] = $r['user_ip'];
            //$res[$k]['events'] = '<a href="' . base_url() . 'admin/users/event_user/' . $r['id'] . '"><img width=" " height=" " alt=" " src="' . base_url() . 'admin_images/event.png"></img></a>';
            //$res[$k]['purchase'] = '<a href="' . base_url() . 'admin/users/purchase_user/' . $r['id'] . ' "><img width=" " height=" " alt=" " src="' . base_url() . 'admin_images/ticketimg.png"></img></a>';
            //$res[$k]['multi_users'] = '<a href="' . base_url() . 'admin/users/list_multi_users/' . $r['id'] . '"><img width=" " height=" " alt=" " src="' . base_url() . 'admin_images/accountimg.png"></img></a>';
            
            if ($r['user_status'] == 'A')
                $res[$k]['user_status'] = '<div style="text-align:center"><img title="Active User" alt="Active User" src="' . base_url() . 'admin_images/active.jpg"></img></div>';
            else
                $res[$k]['user_status'] = '<div style="text-align:center"><img title="Disabled User" alt="Disabled User" src="' . base_url() . 'admin_images/deactive.jpg"></img></div>';
            
            //$res[$k]['active'] = ($r['active']==1)?'Active':'Inactive';

            /*
            $res[$k]['action'] = '<a href="' . base_url() . 'admin/users/earning/0/' . $r['id'] . '">Earnings</a> /
            <a href="' . base_url() . 'admin/users/view_user/' . $r['id'] . '">View</a> /
            <a href="' . base_url() . 'admin/users/edit_user/' . $r['id'] . '">Edit</a> /
            <a href="' . base_url() . 'admin/users/refferal_user/' . $r['id'] . '">User Referral</a>';
            */
            
            $res[$k]['action'] = '<a href="' . base_url() . 'admin/users/my_news/' . $r['id'] . '">News</a> / <a href="' . base_url() . 'admin/users/edit_user/' . $r['id'] . '">Edit</a>';
        }
        $data['data'] = $res;
        //$data['draw'] = 1;
        $data['recordsTotal'] = count($data['data']);
        $data['recordsFiltered'] = count($this->users_model->getAllData());
        echo json_encode($data);
    }

    public function logout()
    {
        $user_data = $this->session->all_userdata();
        $this->session->unset_userdata('ip_address');
        $this->session->unset_userdata('user_agent');
        $this->session->unset_userdata('last_activity');
        $this->session->unset_userdata('is_admin_login');
        $this->session->unset_userdata('id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('user_type');
        $this->session->sess_destroy();
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        redirect('admin/home', 'refresh');
    }

    public function newsdelete($user_id,$id = null)
    {

        if (empty($id)) {
            redirect('admin/users');
        }

        if (empty($user_id)) {
            redirect('admin/users');
        }

        $delete = deleteRecordById('latest_news', $id);
        if ($delete) {
            $this->session->set_flashdata('success', 'News deleted successfully.');
            redirect('admin/users/my_news/'.$user_id);
        }
    }
    
    function my_news($user_id){

        $data['user_id'] = $user_id;
        $category = 0;
        if($_GET['cat']>0){
            $category = $_GET['cat']; 
        }
       $data['category'] =$this->news_model->getCategoriesRecords();
       $data['news_list'] = $this->news_model->getRecords($user_id,$category);
       $data['selected_category'] = $category;  
       adminLoadView('users/news/list', $data);
    }

    function validate_email($email)
    {
        $this->load->model('user_model');
        $user_count = $this->user_model->validate_email($this->input->post('email'));
        if ($user_count > 0) {
            return false;
        } else {
            return true;
        }
    }

    function profile_view($id)
    {
        $this->load->model('user_model');
        //$data['user']         = $this->user_model->getRecordById($id);
        $data['id']         = $id;
        $data['total_news'] = $this->user_model->getTotalNews($id);
        $data['total_visiter'] = $this->user_model->getTotalVister($id);
        $data['cat_ount'] = $this->user_model->getcategoryNewsCount($id);
        $data['pending_news'] = $this->user_model->get_all_pending_news($id);
        $data['notShowCategory'] = '1';
        adminLoadView('users/profile_view', $data);
    }

}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
