<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class faq extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/faq_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index()
    {

        $data['faqs'] = $this->faq_model->getfaqsRecords();
        adminLoadView('faq/list', $data);
    }
    public function faq_add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->faq_model->formCatValidations();
      
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'title' => $postData['title'],
                    'discription' => $postData['discription'],
                    'link' => $postData['link'],
                    'created_date' => date('Y-m-d h:i:s'),
                    'order' => $postData['order']
                );

                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }
                $slug = create_slug('faqs', $postData['title']);
                if (!empty($slug)) {
                    $insertData['slug'] = $slug;
                }
                $return = addUpdateRecord('faqs', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'faq added successfully.');
                    redirect('admin/faq');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('faq/create', $data);
    }
    public function faq_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/faq');
        }
        $postData = $this->faq_model->getfaqRecordById($id);
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

            $formValidation = $this->faq_model->formCatValidations($id);
            $slug = create_slug('faqs', $postData['title'], $id);
            if (!empty($slug)) {
                $updateData['slug'] = $slug;
            }

            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
                $data['error'] = array();
                $file_name = $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png", "gif");
                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }
                if ($file_size > 2097152) {
                    $data['error'] = 'File size must be excately 2 MB';
                }
                $updateData['image'] = $file_name;
                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news_faq/" . $file_name);
                }
                $testsize = getimagesize("./upload/news_faq/" . $file_name);
                $width = $testsize[0];
                $height = $testsize[1];
                /*
                    if ($width < 450 || $height < 280) {
                        $data['error'] = 'Image Size is Small';
                        unlink("./upload/blogs_faq/" . $file_name);
                    }
                */
                $updateData['image'] = $file_name;
            }
            if ($formValidation && empty($data['error'])) {
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                $updateData['status'] = $postData['status'];
                $updateData['order'] = $postData['order'];

                $return = addUpdateRecord('faqs', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'news faq updated successfully.');
                    redirect('admin/faq');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        adminLoadView('faq/edit', $data);
    }
    public function faq_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/faq');
        }
        $deleteData = $this->faq_model->getfaqRecordById($id);
        $delete = deleteRecordById('faqs', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'news faq deleted successfully.');
            redirect('admin/faq');
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
