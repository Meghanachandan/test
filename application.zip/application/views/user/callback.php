<?php

require_once("Facebook/autoload.php");

$fb = new Facebook\Facebook([
  'app_id' => '386653662643024',
  'app_secret' => '81e141602e3ee0bf0714ea26b5423a73',
  'default_graph_version' => 'v2.10',
  ]);

$helper = $fb->getRedirectLoginHelper();
if (isset($_GET['state'])) {
    $helper->getPersistentDataHandler()->set('state', $_GET['state']);
}

try {
  $accessToken = $helper->getAccessToken();
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

if (! isset($accessToken)) {
  if ($helper->getError()) {
    header('HTTP/1.0 401 Unauthorized');
    echo "Error: " . $helper->getError() . "\n";
    echo "Error Code: " . $helper->getErrorCode() . "\n";
    echo "Error Reason: " . $helper->getErrorReason() . "\n";
    echo "Error Description: " . $helper->getErrorDescription() . "\n";
  } else {
    header('HTTP/1.0 400 Bad Request');
    echo 'Bad request';
  }
  exit;
}

// Logged in
//echo '<h3>Access Token</h3>';
//var_dump($accessToken->getValue());

// The OAuth 2.0 client handler helps us manage access tokens
$oAuth2Client = $fb->getOAuth2Client();

// Get the access token metadata from /debug_token
$tokenMetadata = $oAuth2Client->debugToken($accessToken);
//echo '<h3>Metadata</h3>';
//var_dump($tokenMetadata);

// Validation (these will throw FacebookSDKException's when they fail)
//$tokenMetadata->validateAppId($config['app_id']);
$tokenMetadata->validateAppId('720775435130200');
// If you know the user ID this access token belongs to, you can validate it here
//$tokenMetadata->validateUserId('123');
$tokenMetadata->validateExpiration();

if (! $accessToken->isLongLived()) {
  // Exchanges a short-lived access token for a long-lived one
  try {
    $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
  } catch (Facebook\Exceptions\FacebookSDKException $e) {
    echo "<p>Error getting long-lived access token: " . $e->getMessage() . "</p>\n\n";
    exit;
  }

  echo '<h3>Long-lived</h3>';
  //var_dump($accessToken->getValue());
}

$_SESSION['fb_access_token'] = (string) $accessToken;

// User is logged in with a long-lived access token.
// You can redirect them to a members-only page.
//header('Location: https://example.com/members.php');


try {
  // Returns a `Facebook\FacebookResponse` object
  $response = $fb->get('/me?fields=id,first_name,last_name,email', $_SESSION['fb_access_token']);
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  echo 'Graph returned an error: ' . $e->getMessage();
  exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  echo 'Facebook SDK returned an error: ' . $e->getMessage();
  exit;
}

$user = $response->getGraphUser();

//echo 'Name: ' . $user['name']. '<br>';
//echo 'Email: ' . $user['email'];


require_once("admin/sqlcon.php");
//Check if email already exists
/* Prepare an insert statement */
$query = "select count(1) from register where email = ?";
$stmt = mysqli_prepare($con,$query);

$res=mysqli_fetch_array(mysqli_query($con,"select count(1) as cnt from register  where email='".$user['email']."'"));

if($res['cnt'] == 1){
  //User already registered
  //set sessions and redirect to home page
  $_SESSION['user']=$user['email'];
  echo '<script>window.location="userhome.php";</script>';

}
else if($res['cnt'] == 0){
  //User Not registered; Create new user
  $stmt=mysqli_query($con,"insert into register (fname,lname,email,mob,gen,password,statuss1,allow) values('".$user['first_name']."','".$user['last_name']."','".$user['email']."','','','','0','0')");

  

  $stmt=mysqli_query($con,"INSERT INTO `fb_users` (`id`, `first_name`, `last_name`, `email`) VALUES (NULL, '".$user['first_name']."', '".$user['last_name']."', '".$user['email']."'); ");

  


  //set sessions and redirect to home page
  $_SESSION['user']=$user['email'];
  echo '<script>window.location="userhome.php";</script>';

}

die;


// OR
// echo 'Name: ' . $user->getName();

?>