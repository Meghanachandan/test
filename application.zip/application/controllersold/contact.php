<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Contact extends CI_Controller {

    var $ldata;
    var $sdata;
    public function __construct() {
        parent::__construct();
        $this->load->helper('custom_helper');
        //$this->load->model('User_model');
        $this->load->library('email');
        $this->load->helper('url');
		
    }

	public function send_mail()
    {
        $data = array();
        $postData = array();
        $data['page_active']  = 'Contact';
        if ($_POST) {

            $postData = $_POST;
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'Name', 'required|alpha_numeric');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('subject', 'Subject', 'required');
            $this->form_validation->set_rules('message', 'Message', 'required');

            if ($this->form_validation->run() == FALSE) {

                if (validation_errors()) {
                    $data["error"] = validation_errors();
                } else {
                    $data["error"] = "";
                }

            } else {
                $email = $postData['email'];
                $subject = $postData['subject'];
                $messages = array(
                    'name'      => $postData['name'],
                    'message'   => $postData['message'],
                    'email'     => $postData['email'],
                    'subject'   => $postData['subject'],
                );
                send_email_with_template($email, AUTHOR_EMAIL, $subject, 'welcome', $messages);
                $this->session->set_flashdata('success', 'Contact email send successfully.');
                redirect('contact', 'refresh');
            }
            $data['postData'] = $postData;
        }


        defaultLoadView('contact/index', $data);
    }
	

    public function welcome()
    {
        $this->load->view('user/welcome');
    }

    public function index()
    {
        $data['page_active']  = 'Contact';
		defaultLoadView('contact/index', $data);
		 
	}
 
     
		/*public function send_mail() { 
		
         $from_email = "your@example.com"; 
         $to_email = $this->input->post('email'); 
	
   
         //Load email library 
         $this->load->library('email'); 
         $this->email->from($from_email, 'Your Name'); 
         $this->email->to($to_email);
         $this->email->subject('Email Test'); 
         $this->email->message('Testing the email class.'); 
		 
   			
         //Send mail 
         if($this->email->send()) 
         $this->session->set_flashdata("email_sent","Email sent successfully."); 
         else 
         $this->session->set_flashdata("email_sent","Error in sending Email."); 
         $this->load->view('index'); 
		  
		 
      } 
*/
    
}
 
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */