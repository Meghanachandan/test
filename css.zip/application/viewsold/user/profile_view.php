<style>
	.mainbody {
		background: #f0f0f0;
	}

	/* Special class on .container surrounding .navbar, used for positioning it into place. */
	.navbar-wrapper {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		z-index: 20;
		margin-left: -15px;
		margin-right: -15px;
	}

	/* Flip around the padding for proper display in narrow viewports */
	.navbar-wrapper .container {
		padding-left: 0;
		padding-right: 0;
	}

	.navbar-wrapper .navbar {
		padding-left: 15px;
		padding-right: 15px;
	}

	.navbar-content {
		width: 320px;
		padding: 15px;
		padding-bottom: 0px;
	}

	.navbar-content:before,
	.navbar-content:after {
		display: table;
		content: "";
		line-height: 0;
	}

	.navbar-nav.navbar-right:last-child {
		margin-right: 15px !important;
	}

	.navbar-footer {
		background-color: #DDD;
	}

	.navbar-footer-content {
		padding: 15px 15px 15px 15px;
	}

	.dropdown-menu {
		padding: 0px;
		overflow: hidden;
	}

	.brand_network {
		color: #9D9D9D;
		float: left;
		position: absolute;
		left: 70px;
		top: 30px;
		font-size: smaller;
	}

	.post-content {
		margin-left: 58px;
	}

	.badge-important {
		margin-top: 3px;
		margin-left: 25px;
		position: absolute;
	}

	table td {
		border: 1px solid #ccc;
		padding: 5px;
	}

	#user_education_table {
		width: 100%;
	}

	.p {
		padding: 0px;
	}
</style>

<style>
	.col-1,
	.col-2,
	.col-3,
	.col-4,
	.col-5,
	.col-6,
	.col-7,
	.col-8,
	.col-9,
	.col-10,
	.col-11,
	.col-12,
	.col,
	.col-auto,
	.col-sm-1,
	.col-sm-2,
	.col-sm-3,
	.col-sm-4,
	.col-sm-5,
	.col-sm-6,
	.col-sm-7,
	.col-sm-8,
	.col-sm-9,
	.col-sm-10,
	.col-sm-11,
	.col-sm-12,
	.col-sm,
	.col-sm-auto,
	.col-md-1,
	.col-md-2,
	.col-md-3,
	.col-md-4,
	.col-md-5,
	.col-md-6,
	.col-md-7,
	.col-md-8,
	.col-md-9,
	.col-md-10,
	.col-md-11,
	.col-md-12,
	.col-md,
	.col-md-auto,
	.col-lg-1,
	.col-lg-2,
	.col-lg-3,
	.col-lg-4,
	.col-lg-5,
	.col-lg-6,
	.col-lg-7,
	.col-lg-8,
	.col-lg-9,
	.col-lg-10,
	.col-lg-11,
	.col-lg-12,
	.col-lg,
	.col-lg-auto,
	.col-xl-1,
	.col-xl-2,
	.col-xl-3,
	.col-xl-4,
	.col-xl-5,
	.col-xl-6,
	.col-xl-7,
	.col-xl-8,
	.col-xl-9,
	.col-xl-10,
	.col-xl-11,
	.col-xl-12,
	.col-xl,
	.col-xl-auto {
		position: relative;
		/* width: 100%; */
		padding-right: 10px;
		padding-left: 10px;
		float: left;
	}

	.page-title-box {
		padding: 25px 0;
	}

	.float-right {
		float: right !important;
	}

	.page-title-box .breadcrumb {
		font-size: 13px;
		margin-bottom: 0;
		padding: 2px 0;
		background-color: transparent;
	}

	.page-title-box .page-title {
		font-size: 18px;
		margin: 0;
		color: #303e67;
	}

	h4 {
		line-height: 22px;
	}

	.card {
		position: relative;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-ms-flex-direction: column;
		flex-direction: column;
		min-width: 0;
		word-wrap: break-word;
		background-color: #fff;
		background-clip: border-box;
		border: 0 solid rgba(0, 0, 0, 0.125);
		border-radius: .25rem;
	}

	.card {
		margin-bottom: 20px;
		background-color: #fff;
		border-radius: .25rem;
		border: 1px solid #eceff5;
	}



	.card-body {
		-webkit-box-flex: 1;
		-ms-flex: 1 1 auto;
		flex: 1 1 auto;
		min-height: 1px;
		padding: 1.25rem;
	}

	.header-title,
	.title-text {
		margin-bottom: 8px;
		text-transform: capitalize;
		letter-spacing: .02em;
		font-size: 15px;
		font-weight: 500;
		margin-top: 0;
		color: #303e67;
		text-shadow: 0 0 1px rgba(241, 245, 250, .1);
		font-family: Roboto, sans-serif;
	}

	.thumb-md {
		height: 48px;
		width: 48px;
		font-size: 14px;
		font-weight: 700;
	}

	.rounded-circle {
		border-radius: 50% !important;
	}

	.text-truncate {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.ml-3,
	.mx-3 {
		margin-left: 1rem !important;
	}

	.font-weight-semibold {
		font-weight: 500;
	}

	.font-24 {
		font-size: 24px !important;
	}

	.text-dark {
		color: #000444 !important;
	}

	.font-12 {
		font-size: 12px !important;
	}

	.text-muted {
		color: #a4abc5 !important;
	}

	.text-uppercase {
		text-transform: uppercase !important;
	}

	.nav-border.nav.nav-pills {
		background-color: transparent;
		border-bottom: 2px dashed #eceff5;
		line-height: 36px;
	}

	.text-center {
		text-align: center !important;
	}

	.align-self-center {
		-ms-flex-item-align: center !important;
		-ms-grid-row-align: center !important;
		align-self: center !important;
	}

	.icon-dual-pink {
		color: #fd3c97;
		fill: rgba(253, 60, 151, .25);
	}

	.icon-md {
		height: 24px;
		width: 24px;
	}

	.font-weight-semibold {
		font-weight: 500;
	}

	.font-24 {
		font-size: 24px !important;
	}

	.mb-1,
	.my-1 {
		margin-bottom: .25rem !important;
	}

	.font-weight-semibold-alt {
		font-weight: 500;
	}

	.font-12 {
		font-size: 12px !important;
	}

	.text-muted {
		color: #a4abc5 !important;
	}

	.text-uppercase {
		text-transform: uppercase !important;
	}

	.mb-0,
	.my-0 {
		margin-bottom: 0 !important;
	}

	.text-center {
		text-align: center !important;
	}

	.align-self-center {
		-ms-flex-item-align: center !important;
		-ms-grid-row-align: center !important;
		align-self: center !important;
	}

	.col-4 {
		-webkit-box-flex: 0;
		-ms-flex: 0 0 33.33333%;
		flex: 0 0 33.33333%;
		max-width: 33.33333%;
	}

	.col-8 {
		-webkit-box-flex: 0;
		-ms-flex: 0 0 66.66667%;
		flex: 0 0 66.66667%;
		max-width: 66.66667%;
	}

	.row {
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-ms-flex-wrap: wrap;
		flex-wrap: wrap;
		margin-right: -10px;
		margin-left: -10px;
	}

	.col-12 {
		-webkit-box-flex: 0;
		-ms-flex: 0 0 100%;
		flex: 0 0 100%;
		max-width: 100%;
	}

	.mb-3,
	.my-3 {
		margin-bottom: 1rem !important;
	}

	.table-responsive {
		display: block;
		width: 100%;
		overflow-x: auto;
		-webkit-overflow-scrolling: touch;
	}

	.table {
		width: 100%;
		margin-bottom: 1rem;
		color: #36374c;
	}

	.table thead th {
		vertical-align: bottom;
		border-bottom: 2px solid #eaf0f7;
	}

	.table .thead-light th {
		color: #303e67;
		background-color: #f1f5fa;
		border-color: #eaf0f7;
	}

	.icon-dual-warning {
		color: #fda354;
		fill: rgba(253, 163, 84, .25);
	}

	.icon-dual-purple {
		color: #7680ff;
		fill: rgba(118, 128, 255, .25);
	}

	.transaction-history li {
		border-bottom: 1px solid #f1f5fa;
		padding: 12px 0;
		/* width: 50%; */
		float: left;
	}

	.align-items-center {
		-webkit-box-align: center !important;
		-ms-flex-align: center !important;
		align-items: center !important;
	}

	.media {
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: start;
		-ms-flex-align: start;
		align-items: flex-start;
		width: 80%;
	}

	.transaction-history .transaction-icon {
		-ms-flex-item-align: center;
		-ms-grid-row-align: center;
		align-self: center;
		margin-right: 12px;
	}

	.transaction-history .transaction-icon i {
		font-size: 20px;
		width: 36px;
		height: 36px;
		display: inline-block;
		line-height: 36px;
		text-align: center;
		background-color: rgba(118, 128, 255, .15);
		color: #7680ff;
		border-radius: 50%;
	}

	.align-self-center {
		-ms-flex-item-align: center !important;
		-ms-grid-row-align: center !important;
		align-self: center !important;
	}

	.media-body {
		-webkit-box-flex: 1;
		-ms-flex: 1;
		flex: 1;
	}

	.transaction-history li {
		border-bottom: 1px solid #f1f5fa;
		padding: 12px 0;
	}

	.transaction-history .transaction-icon {
		-ms-flex-item-align: center;
		-ms-grid-row-align: center;
		align-self: center;
		margin-right: 12px;
	}

	.transaction-history .transaction-data h3 {
		font-size: 14px;
		color: #303e67;
		line-height: 26px;
	}

	ul {
		display: block;
		list-style-type: disc;
		margin-block-start: 1em;
		margin-block-end: 1em;
		margin-inline-start: 0px;
		margin-inline-end: 0px;
		padding-inline-start: 40px;
	}

	.d-flex {
		display: -webkit-box !important;
		display: -ms-flexbox !important;
		display: flex !important;
	}

	.pl-0,
	.px-0 {
		padding-left: 0 !important;
	}

	.m-0 {
		margin: 0 !important;
	}

	.thumb-sm {
		height: 36px !important;
		width: 36px !important;
		font-size: 12px;
		font-weight: 700;
	}

	.mr-2,
	.mx-2 {
		margin-right: .5rem !important;
	}

	.rounded-circle {
		border-radius: 50% !important;
	}

	img {
		vertical-align: middle;
		border-style: none;
	}

	.table td,
	.table>tbody>tr>td,
	.table>tbody>tr>th,
	.table>tfoot>tr>td,
	.table>tfoot>tr>th,
	.table>thead>tr>td,
	.table>thead>tr>th {
		padding: 5px !important;
		font-size: 0.85em;
		color: #999;
		border-left: none;
		border-top: none !important;
	}
</style>
<div class="mainbody">
	<div class="container">
		<div class="row pt-4">
			<div style="padding-top:20px;"></div>
			<div class="col-lg-3 col-md-3 col-sm-12">
				<div class="col-lg-12">
					<div align="center">
						<?php if ($user['profile_image'] != '') {
							echo '<img class="thumbnail img-responsive" src="' . base_url() . '/upload/profile_image/' . $user['profile_image'] . '"  width="100%" height="250px" />';
						} else { ?>
							<img class="thumbnail img-responsive" src="https://lut.im/7JCpw12uUT/mY0Mb78SvSIcjvkf.png" width="100%" height="250px">
						<?php } ?>
					</div>
				</div>
				<div class="col-lg-12 mt-4">
					<h6><strong>Name</strong> : <?php echo $user['first_name'] . " " . $user['last_name']; ?> </h6>
					<hr>
					<h6><strong>Email</strong> : <?php echo $user['email']; ?></h6>
					<hr>
					<h6><strong>Phone No</strong> : <?php echo $user['phone_mobile']; ?> </h6>
					<hr>
					<h6><strong>Location</strong></h6>
					<?php
					$address = array();
					if ($user['address_street'] != '') {
						$address[] = $user['address_street'];
					}
					if ($user['address_city'] != '') {
						$address[] = $user['address_city'];
					}
					if ($user['address_state'] != '') {
						$address[] = $user['address_state'];
					}
					if ($user['address_country'] != '') {
						$address[] = $user['address_country'];
					}
					$address = implode(', ', $address);
					?>
					<p><?php echo $address; ?> </p>
					<hr>
					<a style="float: right; margin-top: 15px;" class="btn btn-sm btn-secondary mb-4" href="<?= base_url('user/profile'); ?>">Edit</a>
				</div>
			</div>
			<div class="col-lg-9 col-md-9 col-sm-12 col-xl-9 ">
				<div class="col-sm-12">
					<div class="row">
						<div class="col-lg-9">
							<div class="col-lg-12 px-0">
								<div class="card">
									<div class="card-body">
										<!-- <a href="" class="float-right text-info">View All</a> -->
										<h4 class="header-title mt-0 mb-3">News Categorys</h4>
										<ul class="list-unsyled m-0 pl-0 transaction-history">
											<?php foreach ($cat_ount as $cat) { ?>
												<li class="col-sm-12 col-md-6 col-lg-6 col-xl-6 align-items-center d-flex justify-content-between">
													<div class="media">
														<div class="transaction-icon"><i class="fa fa-arrow-right" aria-hidden="true"></i></div>
														<div class="media-body align-self-center">
															<div class="transaction-data">
																<h3 class="m-0"><?php echo $cat['title']; ?></h3>
																<!-- <p class="text-muted mb-0">6 June 2019 10:25 AM</p> -->
															</div>
														</div>
														<!--end media body-->
													</div><span class="text-danger"><?php echo $cat['cnt']; ?></span>
												</li>
											<?php } ?>
										</ul>
									</div>
									<!--end card-body-->
								</div>
								<!--end card-->
							</div>
							<!--end card-->
						</div>
						<!--end col-->
						<div class="col-lg-3">
							<div class="card">
								<div class="card-body">
									<div class="row">
										<div class="col-4 align-self-center text-center">

											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-repeat align-self-center icon-md icon-dual-purple">
												<polyline points="17 1 21 5 17 9"></polyline>
												<path d="M3 11V9a4 4 0 0 1 4-4h14"></path>
												<polyline points="7 23 3 19 7 15"></polyline>
												<path d="M21 13v2a4 4 0 0 1-4 4H3"></path>
											</svg>
										</div>
										<!--end col-->
										<div class="col-8">
											<h3 class="mt-0 mb-1 font-24 font-weight-semibold"><?php echo $total_visiter; ?></h3>
											<p class="mb-0 font-12 text-muted text-uppercase font-weight-semibold-alt">Visits</p>
										</div>
										<!--end col-->
									</div>
									<!--end row-->
								</div>
								<!--end card-body-->
							</div>
							<!--end  card-->
							<div class="card">
								<div class="card-body justify-content-center">
									<div class="row">
										<div class="col-4 align-self-center text-center"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers align-self-center icon-md icon-dual-warning">
												<polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
												<polyline points="2 17 12 22 22 17"></polyline>
												<polyline points="2 12 12 17 22 12"></polyline>
											</svg></div>
										<!--end col-->
										<div class="col-8">
											<h3 class="mt-0 mb-1 font-weight-semibold"><?php echo $total_news; ?></h3>
											<p class="mb-0 font-12 text-muted text-uppercase font-weight-semibold-alt">News</p>
										</div>
										<!--end col-->
									</div>
									<!--end row-->
								</div>
								<!--end card-body-->
							</div>
							<!--end  card-->
							<!--
							<div class="card">
								<div class="card-body">
									<div class="row">
										<div class="col-4 align-self-center text-center">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users align-self-center icon-md icon-dual-pink">
												<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
												<circle cx="9" cy="7" r="4"></circle>
												<path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
												<path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
											</svg>
										</div>
										<div class="col-8">
											<h3 class="mt-0 mb-1 font-weight-semibold"><?php echo $total_users; ?></h3>
											<p class="mb-0 font-12 text-uppercase font-weight-semibold-alt text-muted">Users</p>
										</div>
									</div>
								</div>
							</div>
							-->
						</div>
					</div>
					<!--end row-->
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-body order-list">
									<a href="<?php echo base_url(); ?>news/my_news" class="float-right text-info">View All</a>
									<h4 class="header-title mt-0 mb-3">Latest News</h4>
									<div class="table-responsive">
										<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
										<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
										<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
										<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>


										<table class="display responsive" id="example-table">
											<thead class="thead-light">
												<tr>
													<th class="border-top-0">Id</th>
													<th class="border-top-0">Image</th>
													<th class="border-top-0">Title</th>
													<th class="border-top-0">Date</th>
													<th class="border-top-0">Status</th>
													<th class="border-top-0">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												$i = 0;
												foreach ($pending_news as $key => $news) {
													$status = (!empty($news['status']) && $news['status'] == '1') ? 'Active' : 'Deactive';
													$i++; ?>
													<tr>
														<th><?php echo $i; ?></th>
														<?php
														if (trim($news['image']) == '') {
															$news['image'] = 'no-image.png';
														} else {
															$news['image'] = 'thumb/' . $news['image'];
														}
														?>
														<th><?php echo "<img class='thumb-sm rounded-circle mr-2' src='" . base_url('upload/news/' . $news['image']) . "' />"; ?></th>
														<th><a href="<?php echo base_url() . cleanNewsUrl($news); ?>" target="_blank"><?php echo $news['title']; ?></a></th>
														<th><?php echo $news['date']; ?></th>
														<th><?php echo $status; ?></th>
														<th>
															<a target="_blank" href='<?php echo base_url('news/edit/' . $news['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp;
															<a target="_blank" onclick='return confirm("Are you sure? you want to delete this latest news!")' href='<?php echo base_url('admin/news/delete/' . $news['id']); ?>'><i class="fa fa-trash-o"></i></a>
														</th>
													</tr>
												<?php } ?>
											</tbody>
										</table>
										<!--end table-->
									</div>
									<!--end /div-->
								</div>
								<!--end card-body-->
							</div>
							<!--end card-->
						</div>
						<!--end col-->
					</div>
					<!--end row-->

				</div>


			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		$('#example-table').DataTable({
			"pagingType": "full_numbers",
			"lengthMenu": [
				[10, 25, 50, -1],
				[10, 25, 50, "All"]
			]
		});
	});
</script>