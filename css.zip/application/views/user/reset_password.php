<link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet">


<style>
    section {
        background-color: #FFF;
    }
</style>

<section id="form"><!--form-->
	<div class="container">
		<div class="row">
        	<div class="col-sm-12">
            	<div class="col-sm-4 col-sm-offset-4">
                <div class="categoryproduct " style="padding-left:0;">  
                    <div class="content-heading">
                          <h2 class="title-head">Reset Password</h2>
                    </div>
                </div>
                </div>                    
            </div>
			<div class="col-sm-4 col-sm-offset-4">
				<div class="login-form social-buttons"><!--login form-->
                    <?php if (!empty($error)) { ?>
						<div class="alert alert-danger"><?php echo $error; ?></div>
					<?php } ?>
					<?php if($this->session->flashdata('success')){ ?>
						<div class="alert alert-success message" style="display: block;">
							<?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<form action="<?php echo base_url('user/reset_password/'.$forgot_unique_code); ?>" method="post">
						<input type="password" placeholder="Password" name="password" />
						<input type="password" placeholder="Retype Password" name="cpassword" />
						<strong>Rules for Creating Password </strong><br>
						<span>1) Must be 8 characters or longer<!--  with 1 number -->.</span>
						<button type="submit" title="Submit" class="btn btn-default">Submit</button>
					</form>
					<h5 class="text-center" title="Return to Log in"><a href="<?php echo base_url('user/login'); ?>" style="color: #333;text-decoration:underline;">Return to Log in</a></h5>
      		 	</div><!--/login form-->
			</div>
		</div>
	</div>
</section><!--/form-->