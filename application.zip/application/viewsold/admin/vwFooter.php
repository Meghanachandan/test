</div>
</div>
<!--//content-inner-->
<!--/sidebar-menu-->
<div class="sidebar-menu">
    <header class="logo">
        <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="<?php echo base_url("admin/dashboard"); ?>"> <span id="logo">Agcnn.com</span>
            <!--<img id="logo" src="" alt="Logo"/>-->
        </a>
    </header>
    <div style="border-top:1px solid rgba(69, 74, 84, 0.7)"></div>
    <!--/down-->
    <!--/down-->
    <div class="menu">
        <ul id="menu">
            <li id="menu-academico">
                <?php if ($this->session->userdata('username')) { ?>
                    <a href="" class="dropdown-toggle user-label" data-toggle="dropdown" aria-expanded="false" style="color: #fff"><i class="fa fa-user"></i><span> &nbsp;Hello <?php echo ucwords($this->session->userdata('username')); ?></span></a>
                <?php } ?>
            </li>
            <li>
                <a href="<?php echo base_url("admin/dashboard"); ?>">
                    <i class="fa fa-tachometer"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li id="menu-academico">
                <a href="#">
                    <i class="fa fa-file-text-o"></i>
                    <span>Pages Settings</span>
                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>
                </a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes">
                        <a href="<?php echo base_url('admin/pages/add'); ?>">Add Pages</a>
                    </li>
                    <li id="menu-academico-boletim">
                        <a href="<?php echo base_url('admin/pages'); ?>">View/Edit Pages</a>
                    </li>
                </ul>
            </li>
            <li id="menu-academico"><a href="#"><i class="fa fa-bars"></i> <span>Menus Settings</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/menus/add'); ?>">Add Menus</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/menus'); ?>">View/Edit Menus</a></li>
                </ul>
            </li>
            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>News Categories</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/news/categorie_add'); ?>">Add News Categories</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/news/categories'); ?>">View/Edit News Categories</a></li>
                </ul>
            </li>
            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>News</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/news/add'); ?>">Add News</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/news'); ?>">View/Edit News</a></li>
                </ul>
            </li>
            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>Adds</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/adds/add'); ?>">Add adds</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/adds'); ?>">View/Edit adds</a></li>
                </ul>
            </li>
            <li id="menu-academico">
                <a href="#"><i class="fa fa-dribbble"></i>
                    <span>Users</span>
                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>
                </a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/users/add_newuser'); ?>">Add Users</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/users'); ?>">View/Edit Users</a></li>
                </ul>
            </li>

            <li id="menu-academico"><a href="#"><i class="fa fa-phone"></i> <span>Contact Address</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>
                <ul id="menu-academico-sub">
                    <!-- <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/contact_address/add'); ?>">Add Address</a></li> -->
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/contact_address'); ?>">View/Edit Address</a></li>
                </ul>
            </li>

            <li id="menu-academico">
                <a href="#"><i class="fa fa-dribbble"></i>
                    <span>Faq</span>
                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>
                </a>
                <ul id="menu-academico-sub">
                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/faq/faq_add'); ?>">Add Faq</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/faq'); ?>">View/Edit Faqs</a></li>
                </ul>
            </li>
            <li id="menu-academico"><a href="#"><i class="fa fa-cogs"></i> <span>Others Settings</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>
                <ul id="menu-academico-sub">
                    <!-- <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/social_network'); ?>">Manage Social Icons</a></li> -->
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/email_subscribers'); ?>">Email Subscriber</a></li>
                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/terms'); ?>">Terms and Conditions</a></li>
                    <!-- <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/payment/security_list'); ?>">Security Card</a></li> -->
                </ul>
            </li>
            <li id="menu-academico">
                <?php if ($this->session->userdata('username')) { ?>
                    <a href="<?php echo base_url('admin/users/logout') ?>" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" title="Logout"><i class="fa fa-sign-out"></i><span>Logout</span></a>
                <?php } ?>
            </li>
        </ul>
    </div>
</div>
<div class="clearfix"></div>
</div>
<script>
    var toggle = true;

    $(".sidebar-icon").click(function() {
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({
                "position": "absolute"
            });
        } else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({
                    "position": "relative"
                });
            }, 400);
        }
        toggle = !toggle;
    });
</script>

</body>

</html>