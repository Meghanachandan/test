<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">adds</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h3 class="inner-tittle two">adds </h3>
			<?php
				if($this->session->flashdata('success')){ 
				?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
			} ?>

			<?php
			$category_array = array();
			if($adds_categories){
				foreach($adds_categories as $cat){
					//pr($cat);
					$category_array[$cat['id']] = $cat['title'];  
				}
			}
			?>
		<div class="graph">
			<div class="tables">
				<table class="display responsive" id="example-table">
					<thead> 
						<tr> 
							<th>Id</th> 
							<th width="200" >Title</th>
							<th>Categorise</th>
							<th>Link</th>
							<th>Image</th> 
							<th>Created</th> 
							<th>Status</th> 
							<th>Action</th>  
						</tr> 
					</thead>
					<?php
					$i=0;
					foreach ($adds as $key => $blog) {
						
						$status = (!empty($blog['status']) && $blog['status'] == '1') ? 'Active' : 'Deactive';
						$i++; ?>
						<tr> 
							<th><?php echo $i; ?></th> 
							<th><?php echo $blog['title']; ?></th>
							<th><?php echo $category_array[$blog['categorie']]; ?></th>
							<th><?php echo $blog['link']; ?></th> 
							<th><?php echo "<img src='".base_url('upload/adds/'.$blog['image'])."' height='80px' width='90px'/>"; ?></th> 
							<th><?php echo $blog['created_date']; ?></th> 
							<th><?php echo $status; ?></th> 
							<th>
							<a href='<?php echo base_url('admin/adds/edit/'.$blog['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp; 
							<a onclick='return confirm("Are you sure? you want to delete this blog!")' href='<?php echo base_url('admin/adds/delete/'.$blog['id']); ?>'><i class="fa fa-trash-o"></i></a>
							</th>
						</tr>
					<?php }?>
				</table>
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script> 
$(document).ready(function() {
	$('#example-table').DataTable( {
		"pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ]

	});
});
</script>