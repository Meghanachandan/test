<section>
    <div class='container'>
        <div class="row">
            <div class='col-md-6'>
                <div class='form'>
                    <label>Department</label>
                    <strong><?php echo getDepartment($users['department_id']); ?></strong>
                </div>
            </div>
            <div class='col-md-6'></div>
            <div class='col-md-6'><div class='form'>
                    <label>Department</label>
                    <strong><?php echo getDesignation($users['designation']); ?></strong>
                </div></div>
            <div class='col-md-6'></div>
            <div class='col-md-12'>
                <?php 
                if($users['picture']==''){
                    $ims= 'http://newssyn.com/upload/adds/no-image.png';
                }else{
                    $ims= 'http://newssyn.com/upload/team_pic/'.$users['picture'];
                }
                ?>
                <img src="<?php echo $ims; ?>" alt="meber_details" style='height: 300px;width: 100%'>
            </div>
            <div class="col-md-6">
                <label><?php echo getDesignation($users['designation']); ?></label>
            </div>
            <div class="col-md-6">
                <strong><?php echo $users['name']; ?></strong>
            </div>
        </div>
    </div>
</section>