<?php
class dashboard_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function getTotalUsers(){
        $sql = "SELECT count(*) as cnt FROM `users`";
    	$query = $this->db->query($sql);
        //$result = $query->getArray();
		//return $result['cnt'];
		$row_users = $query->result_array();
			return $row_users[0]['cnt'];
	}

	function getTotalNews(){
        $sql = "SELECT count(*) as cnt FROM `latest_news`";
    	$query = $this->db->query($sql);
        //$result = $query->getArray();
		//return $result['cnt'];
		$row_users = $query->result_array();
			return $row_users[0]['cnt'];
	}

	function getTotalVister(){
        $sql = "SELECT count(*) as cnt FROM `site_vister`";
    	$query = $this->db->query($sql);
        //$result = $query->getArray();
		//return $result['cnt'];
		$row_users = $query->result_array();
			return $row_users[0]['cnt'];
	}

	function getcategoryNewsCount(){
        $sql = "SELECT let.categorise as cat,nc.`title`,COUNT(let.`categorise`) AS cnt FROM `latest_news` AS let LEFT JOIN `news_categories` AS nc ON nc.id =let.`categorise` WHERE let.`categorise` > 0 GROUP BY let.categorise";
    	$query = $this->db->query($sql);
        //$result = $query->getArray();
		//return $result['cnt'];
		$row_users = $query->result_array();
			return $row_users;
	}

	function get_all_pending_news()
	{
		$sql = "SELECT * FROM `latest_news` WHERE status = '0' ORDER BY `created_date` DESC LIMIT 20";
		$query = $this->db->query($sql);
		$row_users = $query->result_array();
		return $row_users;
	}
	
	public function formValidations($id = null)
	{
		/*$url = $_POST['link'];
			if (!filter_var($url, FILTER_VALIDATE_URL) == false) {
			return true; 
			} else {
			$this->form_validation->set_rules('link', 'Link', 'required');	
			?>
            <script>
			alert('Enter valid Link of News');
			</script>
            <?php
			
			return false; 
			}*/
		//$this->form_validation->set_rules('link', 'Link', 'required');
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('image', 'File', 'required');
		//$this->form_validation->set_rules('date', 'Date', 'required');
		/*$editImage = $this->getImage($id);
		if (empty($editImage)) {
			if (empty($_FILES['image']['name'])) {
				$this->form_validation->set_rules('image', 'Image', 'required');
			}
		}*/
		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}
	
	public function getNoticeRecords()
	{
		$this->db->order_by("id", "desc");
// 			$this->db->where("categorie_type", '0');
		$query = $this->db->get('notice');
		$ret = $query->result_array();
// 		echo $this->db->last_query();die;
		return $ret;
	}
	
	public function getNoticeRecords11($id)
	{
	$this->db->where('id', $id);
		$q = $this->db->get('notice');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}
	
		public function getRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('email_subscriber');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function allow_signup($data)
	{
		return $this->db->insert('allow_signup',$data);
	}

	public function select($db)
	{
		return $this->db->query($db);
	}

	public function update_allow_signup($data)
	{
		$this->db->where(array('pkid'=>1));
		$this->db->update('allow_signup',$data);
	}
	

}























