<style>
    #imgdiv {
        width: 160px;
        float: left;
        margin-left: 20px
    }

    #reload {
        float: right;
        margin-right: 40px
    }

    section {
        background-color: #FFF;
    }
</style>
<section id="form">
    <!--form-->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="categoryproduct " style="padding-left:0;">
                    <div class="content-heading">
                        <h2 class="title-head">Edit News</h2>
                    </div>
                </div>
            </div>
            <div class="col-sm-9 ">
                <div class="signup-form">
                    <?php
                    if (!empty($postData)) {
                        $name               = $postData['title'];
                        $discription        = $postData['discription'];
                        $link               = $postData['link'];
                        $image              = $postData['image'];
                        $date_part          = explode(' ', $postData['date']);
                        $date               = $date_part[0];
                        $time               = explode(':', $date_part[1]);
                        $hour               = $time[0];
                        $minit              = $time[1];
                        $media_type         = $postData['media_type'];
                        $short_discription  = $postData['short_discription'];
                        $country            = $postData['country'];
                        $state              = $postData['state'];
                        $city               = $postData['city'];
                        $categorise         = $postData['categorise'];
                    }
                    ?>
                    <div class="outter-wp">
                        <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
                        <!--/sub-heard-part-->
                        <div class="graph-visual tables-main">
                            <div class="graph-form">
                                <?php if (!empty($error)) { ?>
                                    <div class="alert alert-danger message" style="display: block;">
                                        <?php echo $error; ?>
                                    </div>
                                <?php } ?>
                                <div class="form-body">
                                    <form action="<?php echo base_url('admin/users/newsedit/' . $user_id . '/' . $id); ?>" enctype="multipart/form-data" method="post">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">News Headline <span class="star-color">*</span></label>
                                            <input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>">
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <label for="exampleInputPassword1">Short Description <span class="star-color"></span></label>
                                                    <textarea name="short_discription" style="width: 100%;height: 70px" id="short_discription"><?php echo $short_discription; ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <label for="exampleInputPassword1">Description <span class="star-color">*</span></label>
                                                    <textarea name="discription" rows="3" cols="90" id="discription" name="discription"><?php echo $discription; ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Add Image </label>
                                            <input type="file" name="image" value="<?php echo $image; ?>"><small class="msg-upload">Image Dimension must be Minimum 600px*400px</small>
                                            <?php if ($image != '') { ?>
                                                <br>
                                                <br>
                                                <img src="<?php echo base_url('upload/news/' . $image); ?>" height="80px" width="200px">
                                            <?php } ?>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <label>Publish Date</label>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="col-lg-5" style="padding-right: 10px;padding-left: 0px;float:left">
                                                        <input type="date" style="width: 100%" id="datepicker" class="form-control" name="date" value="<?php echo $date; ?>" required>
                                                    </div>
                                                    <div class="col-lg-3" style="padding-right: 10px;padding-left: 0px;float:left">
                                                        <!-- <input type="text" style="width: 100%" id="timepicker" class="form-control" name="time" value="<?php echo $date; ?>" required> -->
                                                        <select name="hour" class="form-control" style="width: 100%">
                                                            <?php for ($i = 0; $i < 24; $i++) { ?>
                                                                <option value="<?php if ($i < 10) {
                                                                                    echo '0' . $i;
                                                                                } else {
                                                                                    echo $i;
                                                                                } ?>">
                                                                    <?php echo $i . ' hr'; ?>
                                                                </option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-lg-3" style="padding-right: 10px;padding-left: 0px;float:left">
                                                        <!-- <input type="text" style="width: 100%" id="timepicker" class="form-control" name="time" value="<?php echo $date; ?>" required> -->
                                                        <select name="minit" class="form-control" style="width: 100%">
                                                            <?php for ($k = 0; $k < 60; $k++) { ?>
                                                                <option value="<?php if ($k < 10) {
                                                                                    echo '0' . $k;
                                                                                } else {
                                                                                    echo $k;
                                                                                } ?>">
                                                                    <?php echo $k; ?> minit </option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div class="form-group">
                                            <label for="exampleInputPassword1">Link <span class="star-color">*</span></label>
                                            <input type="text" class="form-control" id="link" name="link" value="<?php echo $link; ?>">
                                            </div> 
                                        -->
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">News Type</label>
                                            <select class="form-control" onclick="showTheUploadOption(this.value);" id="media_type" name="media_type">
                                                <option selected="selected" value="news">News</option>
                                                <!-- <option value="images">Image</option> -->
                                                <!-- <option value="audio">Audio</option>
                                                <option value="video">Video</option> -->
                                                <option value="youtube">Youtube</option>
                                                <!-- 							
                                                <option value="facebook">FaceBook</option>
                                                <option value="twitter">Twitter</option>
                                                <option value="instagram">Instagram</option>
                                                -->
                                            </select>
                                        </div>
                                        <div class="form-group optionContaner" id="option_to_show_audio" style="display:none">
                                            <label for="exampleInputPassword1">News Audio</label>
                                            <input type="file" name="news_audio" value="<?php echo $news_audio; ?>"><small class="msg-upload">maximum 5mb File size allowed</small>
                                        </div>
                                        <div class="form-group optionContaner" id="option_to_show_video" style="display:none">
                                            <label for="exampleInputPassword1">News Video</label>
                                            <input type="file" name="news_video" value="<?php echo $news_video; ?>"><small class="msg-upload">maximum 5mb File size allowed</small>
                                        </div>
                                        <div class="form-group optionContaner" id="option_to_show_youtube" style="display:none">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <label for="exampleInputPassword1">News YouTube Code</label>
                                                    <textarea name="youtube_code" style="width: 100%;height: 70px" id="youtube_code"><?php echo $news_youtube; ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Location</label>
                                            <select class="form-control" id="news_country" name="country" onchange="news_getcountrystate(this.value);">
                                                <?php foreach ($allcountry as $country) {
                                                    $selected = '';
                                                    if ($country->name == 'India') {
                                                        $selected = ' selected="selected" ';
                                                    }
                                                ?>
                                                    <option <?php echo $selected; ?> value="<?php echo $country->name; ?>"><?php echo $country->name; ?></option>
                                                <?php } ?>
                                            </select>
                                            <br>
                                            <select class="form-control" id="news_state" name="state">
                                                <?php foreach ($allcountryState as $state) { ?>
                                                    <option value="<?php echo $state->name; ?>"><?php echo $state->name; ?></option>
                                                <?php } ?>
                                            </select>
                                            <br>
                                            <input type="text" class="form-control" id="news_city" name="city" value="<?php echo $city; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">News Categorise</label>
                                            <select class="form-control" id="categorise" name="categorise">
                                                <?php foreach ($allcategory as $cat) { ?>
                                                    <option selected="selected" value="<?php echo $cat['id'] ?>"><?php echo $cat['title'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-default" name="submit" value="submit">Update</button>
                                    </form>
                                </div>
                            </div>
                            <!--//graph-visual-->
                        </div>
                    </div>
                    <br><br>

                    <script>
                        //Replace the <textarea id="editor1"> with a CKEditor
                        //instance, using default configuration.

                        CKEDITOR.replace('discription');

                        function showTheUploadOption(val) {
                            $('.optionContaner').hide();
                            $('#option_to_show_' + val).show();
                        }

                        function news_getcountrystate(id) {
                            //console.log(id);
                            var postData = {
                                country_id: id
                            };
                            $.ajax({
                                url: "<?php echo base_url(); ?>home/getCountrySate",
                                data: postData,
                                //cache: false,
                                //processData: false,
                                //contentType: false,
                                dataType: 'json',
                                type: 'POST',
                                success: function(result) {

                                    // do something with the result
                                    $('#news_state').html('');
                                    var output = [];
                                    $.each(result, function(key, value) {
                                        output.push('<option value="' + value.name + '">' + value.name + '</option>');
                                    });

                                    $('#news_state').html(output.join(''));


                                }
                            });
                        }
                    </script>

                    <!-- <form action="<?php echo base_url('user/signup'); ?>" method="post" novalidate>
                        <input type="text" name="first_name" placeholder="First Name" value="<?php echo $userData['first_name']; ?>" />
                        <input type="text" name="last_name" placeholder="Last Name" value="<?php echo $userData['last_name']; ?>" />
                        <input type="email" name="email" placeholder="Email Address" value="<?php echo $userData['email']; ?>" />
                        <input type="password" name="password" placeholder="Password" />
                        <div id="imgdiv" style="margin-left:0px; height:41px;">
                            <img id="img" src="<?php echo base_url(); ?>images/captcha/captcha.php">
                        </div>
                        <div style="margin-left:10px; float:left">
                            <img id="reload" src="<?php echo base_url(); ?>images/captcha/reload.png">
                        </div>

                        <div class="clearfix"></div>
                        <div>Enter Image Text:</div>
                        <div>
                            <input id="captcha1" name="captcha" type="text" placeholder="Enter Above Image Text Here">
                        </div>
                        <button type="submit" title="Create an Account" class="btn btn-default">Create an Account</button>
                    </form> -->
                </div>
                <!--/sign up form-->
            </div>
        </div>
    </div>
</section>
<!--/form-->