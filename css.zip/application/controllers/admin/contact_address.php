<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Contact_address extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/contact_address_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index() {
        
        $data['addresses'] = $this->contact_address_model->getRecords();
        adminLoadView('contact_address/list', $data);
    }

    public function add() {

        $postData = array();
        if ($_POST) {
            $postData = $_POST;

            $formValidation = $this->contact_address_model->formValidations();
            if ($formValidation) {
                $insertData = array(
                    'address'       => $postData['address'],
                    'email'         => $postData['email'],
                    'phone_number'  => $postData['phone_number'],
                );

                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }   

                $return = addUpdateRecord('contact_address', '', '', $insertData);

                if ($return) {
                    $this->session->set_flashdata('success', 'Address added successfully.');
                    redirect('admin/contact_address');
                } 
            } else {

                if(validation_errors()) {
                    if(validation_errors()){
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

       
        $data['postData'] = $postData;
        adminLoadView('contact_address/create', $data);
    }


    public function edit($id = null) {

        if (empty($id)) {
            redirect('admin/contact_address');
        }

        $postData = $this->contact_address_model->getRecordById($id);
        if ($_POST) {
            $postData = $_POST;

            $formValidation = $this->contact_address_model->formValidations();
            if ($formValidation) {
                $updateData = array(
                    'address'       => $postData['address'],
                    'email'         => $postData['email'],
                    'phone_number'  => $postData['phone_number'],
                );

                if (!empty($postData['status'])) {
                    $updateData['status'] = $postData['status'];
                } else {
                    $updateData['status'] = 1;
                }   
                
                $return = addUpdateRecord('contact_address', 'id', $id, $updateData);

                if ($return) {
                    $this->session->set_flashdata('success', 'Address updated successfully.');
                    redirect('admin/contact_address');
                } 
            } else {

                if(validation_errors()) {
                    if(validation_errors()){
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

       
        $data['postData'] = $postData;
        adminLoadView('contact_address/edit', $data);
    }

    public function delete($id = null) {

        if (empty($id)) {
            redirect('admin/contact_address');
        }

        $deleteData = $this->contact_address_model->getRecordById($id);
        $delete = deleteRecordById('contact_address', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'Address deleted successfully.');
            redirect('admin/contact_address');
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */