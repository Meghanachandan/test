<?php
$options_educations = array('' => "Select");
foreach ($educations as $row)
{
    $options_educations[$row['id']] = $row['name'];
}
?>

<style>
table td {
    border: 1px solid #ccc;
    padding: 5px;
}


#user_education_table tr td{
    padding:5px;
}

#singup_form{
 font-weight:normal;
}

#singup_form label{
    font-weight:normal;
}

#singup_form select,#singup_form password,#singup_form input{
    padding:5px;
}
.form-actions {
    padding: 26px 0;
}
.control-label {
    float: left;
    padding-right: 10px;
    width: 20%;
}
.form-horizontal .control-label {
    text-align: left;
}
.control-group
{
    padding: 10px;
    width: 100%;
    min-height:40px;
}
.controls > input[type="text"],.controls > input[type="password"] {
    border: 1px solid #ccc;
    width: 60%;
}

</style>
    <table style="display:none" >
        <tr id="user_education_row_0"  >
            <td>
                <?php echo form_dropdown('alleducation[education][]',$options_educations, '', 'class="span2 user_education_sel" id="user_education_sel_0" onchange="getSubEducation(this)" style="width:190px;" '); ?>
            </td>
            <td> 
                <?php  echo form_dropdown('alleducation[sub_education][]',  array(),'', 'class="span2" id="user_sub_edu_sel_0" style="width:190px;"'); ?>
            </td>
            <td>                
                <input style="width:200px;" placeholder="Please enter university" type="text" name="alleducation[university][]" value="">
            </td>
            <td>               
                <input style="width:80px;" type="text" name="alleducation[marks][]" placeholder="in %" value="">
            </td>
            <td>                
                <input style="width:80px;"  placeholder="Year" type="text" name="alleducation[passing][]" value="">
            </td>
            <td> 
                <a onclick="remove_row(this)" >Remove</a>
            </td>
        </tr>
    </table>
    <div class="content">
    <!--about-->
        <div class="about-setion" id="singup_form">
            <div class="container">
                <h2 class="tittle">Profile</h2>
    <?php
    //flash messages
    if($this->session->flashdata('flash_message')){
        if($this->session->flashdata('flash_message') == 'updated')
        {
            echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">x</a>';
            echo ' Profile successfully updated/ Details successfully submitted .';
            echo '</div>';       
        }else{
            echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">x</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
            echo '</div>';          
        }
    }
    
    //form data
    //$attributes = array('class' => 'form-horizontal', 'id' => '');
    $attributes = array('class' => 'form-horizontal', 'id' => '','enctype'=>'multipart/form-data');
      

    //form validation
    echo validation_errors();
    echo form_open('home/profile', $attributes);
    ?>
    <fieldset>
        <div class="control-group">
            <label for="inputError" class="control-label">Profile Image</label>
            <div class="controls">
                <?php if($user[0]['profile_image']!=''){ echo '<img src="'.SITE_URL.'upload/profile_image/'.$user[0]['profile_image'].'" width="100" height="100" /><br><br>'; } ?>
                <input type="hidden" name="old_logo" value="<?=$user[0]['profile_image']?>" id=""  />
              
            </div>
        </div>
            <div class="control-group">
            <label for="inputError" class="control-label"></label>
            <div class="controls">
                <input type="file" name="profile_image" id=""  />
            </div>
        </div>

        <div class="control-group">
            <label for="inputError" class="control-label">First Name</label>
            <div class="controls">
                <input type="text" id="" name="first_name" value="<?php echo $user[0]['first_name']; ?>" >
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">Last Name</label>
            <div class="controls">
                <input type="text" id="" name="last_name" value="<?php echo $user[0]['last_name']; ?>">
            </div>
        </div>          
        <div class="control-group">
            <label for="inputError" class="control-label">Email Address</label>
            <div class="controls">
                <input type="text" id="" name="email_addres" value="<?php echo $user[0]['email_addres']; ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">User Name</label>
            <div class="controls">
                <input type="text" name="user_name" value="<?php echo $user[0]['user_name']; ?>">
            </div>
        </div>
              
        <div class="control-group">
            <label for="inputError" class="control-label">Address</label>
            <div class="controls">
                <input type="text" name="address" value="<?php echo $user[0]['address']; ?>">
            </div>
        </div>
              
        <div class="control-group">
            <label for="inputError" class="control-label">City</label>
            <div class="controls">
                <input type="text" name="city" value="<?php echo $user[0]['city']; ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">State</label>
            <div class="controls">
                <input type="text" name="state" value="<?php echo $user[0]['state']; ?>">
            </div>
        </div>
        <div class="control-group">
            <label for="inputError" class="control-label">country</label>
            <div class="controls">
                <input type="text" name="country" value="<?php echo $user[0]['country']; ?>">
            </div>
        </div>
          <?php if($user[0]['user_type']=='1'){ ?>      
        <div class="control-group"  style="display:table" >
            <label for="inputError" class="control-label">Education</label>
            <div id="user_education" class="controls">
                <table id="user_education_table" >
                    <tr>
                        <td>Course</td>
                        <td>Sub Course</td>
                        <td>University</td>
                        <td>Mark Obtain</td>
                        <td>Passing</td>
                        <td></td>
                    </tr>
                    <?php $alleducation  = unserialize($user[0]['education']);
                    if($alleducation)
                    {
                        $i=0;
                        foreach($alleducation['education'] as $education)
                        {
                            if($education>0)
                            {
                                ?>
                                <tr id="user_education_row_0<?=$i?>"  >
                                    <td>
                                        <?php       
                                        echo form_dropdown('alleducation[education][]',$options_educations, $alleducation['education'][$i], 'class="span2 user_education_sel" id="user_education_sel_0'.$i.'" onchange="getSubEducation(this)" style="width:190px;" ');
                                        ?>
                                    </td>
                                    <td> 
                                        <?php   
                                            $cource = $this->subcource_model->get_subcource_by_edu_id($alleducation['education'][$i]);    

                                            $options_cource = array('' => "Select");
                                            foreach ($cource as $row)
                                            {
                                                $options_cource[$row['id']] = $row['name'];
                                            }
                                        echo form_dropdown('alleducation[sub_education][]',  $options_cource ,$alleducation['sub_education'][$i], 'class="span2" id="user_sub_edu_sel_0'.$i.'" style="width:190px;"');
                                        ?>
                                    </td>
                                    <td>                
                                      <input style="width:200px;" placeholder="Please enter university" type="text" name="alleducation[university][]" value="<?php echo $alleducation['university'][$i]; ?>">
                                    </td>
                                    <td>               
                                        <input style="width:80px;" type="text" name="alleducation[marks][]" placeholder="in %" value="<?php echo $alleducation['marks'][$i]; ?>">
                                    </td>
                                    <td>                
                                        <input style="width:80px;"  placeholder="Year" type="text" name="alleducation[passing][]" value="<?php echo $alleducation['passing'][$i]; ?>">
                                    </td>
                                    <td> 
                                        <a onclick="remove_row(this)" >Remove</a>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                            }
                        }
                    }
                ?>
                </table>
            </div>  
            </div>  
            <?php }else{ ?>            
            <div class="control-group"  style="display:table" >
                <label for="inputError" class="control-label">Students</label>
                <div id="user_education" class="controls">
                    <table id="user_education_table" width="70%" style="float:left" >
                        <tr>
                            <td style="width:60px;" >#</td>
                            <td>First Name</td>
                            <td>Last Name</td>
                            <td>Email</td>
                            <td>Action</td>
                        </tr>
                        
                        <?php 
                        if($user_child){
                            $i=0;
                            foreach($user_child as $userinfo)
                            {
                                ?>
                                <tr>
                                    <td>
                                        <?php if($userinfo['profile_image']!=''){ echo '<img src="'.SITE_URL.'upload/profile_image/'.$userinfo['profile_image'].'" width="50" height="50" />'; } ?>
                                    </td>
                                    <td><?=$userinfo['first_name']?></td>
                                    <td><?=$userinfo['last_name']?></td>
                                    <td><?=$userinfo['email_addres']?></td>
                                    <td> 
                                        <a href="<?=base_url('home/edit_student/'.$userinfo['id']);?>" >Edit</a>
                                        &nbsp;|&nbsp;
                                        <a onclick="return conformdelete()" href="<?=base_url('home/delete_student/'.$userinfo['id']);?>" >Delete</a>
                                    </td>
                                </tr>
                                <?php
                            $i++;
                            }
                        }
                        ?>
                    </table>
                </div>  
            </div>  
            <?php } ?>            
            <div class="control-group">
                <div class="form-actions">
                <br>

                    <button class="btn btn-primary" type="submit">Save changes</button>
                    <?php if($user[0]['user_type']=='1'){ ?>  
                    <button onclick="add_row()" class="btn btn-primary" type="button">Add Course</button>
                    <?php }else{ ?>  
                    <button onclick="add_student()" class="btn btn-primary" type="button">Add Student</button>
                    <?php } ?>  
                </div>
            </div>    
    </fieldset>
<?php echo form_close(); ?>
</div>
</div>
<script>
    function add_row()
    {
        var education = $('.user_education_sel');
        var count = education.length+1;
        var tr_data = $("#user_education_row_0").html();
        var tr_data = tr_data.replace('user_education_row_0','user_education_row_'+count) 
        var tr_data = tr_data.replace('user_education_sel_0','user_education_sel_'+count) 
        var tr_data = tr_data.replace('user_sub_edu_sel_0','user_sub_edu_sel_'+count) 
        
        var html = '<tr>'+tr_data+'</tr>';
        $("#user_education_table").append(html);
    } 
     
    function remove_row(ele){

            $(ele).parent().parent().remove(); 
            alert('sucessfully removed!');
        
        
    }
     
    function getSubEducation(ele)
    {
        var id = $(ele).val();
        var append_id = ele.id;
        var append_ele =  append_id.replace('user_education_sel_','user_sub_edu_sel_');
        var url ='<?=base_url().'home';?>/listdata/'+id;
        $.get(url,function(data,status){
            $("#"+append_ele).html(data);
        });
    } 
    
    function add_student(){
        location.href="<?=base_url().'home';?>/add_student";
    }
    
    function conformdelete()
    {
        if(confirm("Do You Want Delete This Student From Your Account!")){
            return true;
        }else{
            return false;
        }        
    }    
    
</script>
















