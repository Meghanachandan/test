<div class="blog-post-area" id="blog-post-area">
	<?php
	 if(!empty($getNews)) { ?>
		<?php 
			$i=1;
			foreach ($getNews as $news) {
				$css = "";
				if ($i > 1) {
					$css = "mt20";
				}
		?>
			<div class="single-blog-post <?php echo $css; ?>">
				<a title="<?php echo $news->title; ?>" href="<?php echo base_url('news/post/'.$news->slug); ?>">
                    <?php
                        if(trim($news->image)==''){
                            $news->image = 'no-image.png';
                        }                
                    ?>
					<img src="<?php echo base_url("upload/news/".$news->image) ?>" alt="" class="img-responsive">
				</a>
				<h3><?php echo $news->title; ?></h3>
				<div class="post-meta">
					<ul>
						<!-- <li><i class="fa fa-user"> &nbsp; Author </i>  dixit shah </li> -->
						<li><i class="fa fa-calendar"> &nbsp; Posted </i> <?php echo  date('M d, Y', strtotime($news->created_date)); ?></li>
					</ul>
				</div>
				<p class="blog-para">
					<?php 
						if (strlen($news->discription) > 100) {
					        $stringCut = substr($news->discription, 0, 100);
					        $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
					    } else {
					        $string = $news->discription;
					    } 
					    echo $string;
					?>
				</p>
				<a title="<?php echo $news->title; ?>" class="btn btn-primary" href="<?php echo base_url('news/post/'.$news->slug); ?>">Read More</a>
			</div>
			<?php 
				if($i != count($getNews)){
					echo '<hr>';
				}
			?>
    		<?php 	
    			$i++;
    		}
    	} else {
    		echo '<div class="alert alert-info">Record Not Found!</div>';
    		} ?>
    	<br>
	<?php echo $paginationCount; ?>
</div>
