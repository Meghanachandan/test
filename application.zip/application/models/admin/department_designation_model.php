<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Department_designation_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}
	
	function get_departments(){
	    return $this->db->select("id, department")->from("departments")->get();
	}
	
	function add_department($data){
	    $recdata = array(
	        "department" => $data["department"],
	        "updated_at" => date("Y-m-d H:i:s")
	        );
	   return $this->db->set($recdata)->insert("departments");
	}

	function update_department($data){
	    $recdata = array(
	        "department" => $data["department"],
	        "updated_at" => date("Y-m-d H:i:s")
	        );
	    return $this->db->set($recdata)->where("id",$data["id"])->update("departments");
	}
	
	function get_designations(){
	    return $this->db->select("id,depart_id, (select department from departments where id=designations.depart_id)as department, designation")->from("designations")->get();
	}
	
	function add_designation($data){
	    $recdata = array(
	        "depart_id" => $data["department"],
	        "designation" => $data["designation"],
	        "updated_at" => date("Y-m-d H:i:s")
	        );
	    return $this->db->set($recdata)->insert("designations");
	}

	function update_designation($data){
	    $recdata = array(
	        "depart_id" => $data["department"],
	        "designation" => $data["designation"],
	        "updated_at" => date("Y-m-d H:i:s")
	        );
	    return $this->db->set($recdata)->where("id",$data["id"])->update("designations");
	}
	
	
	
}


?>