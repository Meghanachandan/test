<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class terms extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/terms_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index()
    {

        $data['terms'] = $this->terms_model->gettermsRecords();
        adminLoadView('terms/list', $data);
    }
    public function terms_add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->terms_model->formCatValidations();
      
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'title' => $postData['title'],
                    'discription' => $postData['discription'],
                    'created_date' => date('Y-m-d h:i:s')
                );
                $return = addUpdateRecord('terms', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'terms added successfully.');
                    redirect('admin/terms');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('terms/create', $data);
    }
    public function terms_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/terms');
        }
        $postData = $this->terms_model->gettermsRecordById($id);
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $formValidation = $this->terms_model->formCatValidations($id);
            if ($formValidation && empty($data['error'])) {
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                  $return = addUpdateRecord('terms', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'news terms updated successfully.');
                    redirect('admin/terms');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        adminLoadView('terms/edit', $data);
    }
    public function terms_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/terms');
        }
        $deleteData = $this->terms_model->gettermsRecordById($id);
        $delete = deleteRecordById('terms', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'news terms deleted successfully.');
            redirect('admin/terms');
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
