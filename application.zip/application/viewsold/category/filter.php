<div class="col-md-9 col-sm-8" id="loadPriceFilter" style="height:0;">
	<div class="dynamic_loader" style="display: none;"></div>
</div>
<div id="dynamic_show_page">
	<div class="col-md-9 col-sm-8">
		<div class="features_items my-overlay">

	    <div class="col-sm-12 p0 clearfix">
	        <div class="col-sm-5 col-xs-3 ">
	              <ul class="color-box item-list clearfix hidden-xs">
	                  <li class="hidden-xs"><i class="fa fa-th"></i></li>
	                  <li style="line-height:22px">
	                  	<?php if(!empty($total_count) && $total_count > 0){
	                  		if ($total_count > 1) {
	                  			echo $total_count." Items";
	                  		} else {
	                  			echo $total_count." Item";
	                  		}
	                  	} else {
	                  		echo "0 Item";
	                  	} ?>
	                  </li>
	              </ul>
	        </div>
	        <div class="col-sm-7 col-xs-12 p0">
	            <ul class="color-box item-list pull-right clearfix">
	                <li style="line-height:22px">Sort By</li>
	                <li style="margin-top:0;">
	                	<?php
	                	$high = $low = "";
	                	if(!empty($filter['sortPrice']) && $filter['sortPrice'] == 'desc'){
	                		$high = 'selected';
	                	} else {
	                		$low = 'selected';
	                	} ?>
	                	<select id="sorter" data-role="sorter" onchange="sortByPrice(this.value)" class="sorter-options">
							<option value="asc" <?php echo $low; ?>>Low To High</option>
							<option value="desc" <?php echo $high; ?>> High To Low </option>
						</select>
	                </li>
				</ul>
	        </div>
		</div>

	    <?php 
	    	if (!empty($results)) {
	    		foreach ($results as $product) {
	    ?>
	    	<div class="col-sm-4 col-xs-6">
				<div class="product-image-wrapper">
	                <div class="single-products">
	                    <div class="productinfo">
	                        <a title="<?php echo $product->product_name; ?>" href="<?php echo base_url('product/'.$product->slug) ?>"><img src="<?php echo base_url($product->image); ?>" alt="" class="pro-img"/></a>
	                        <p></p>
	                        <p class="pn-ht"><?php echo $product->product_name; ?></p>
	                        
	                        <div class="col-sm-12 p0">
	                        <div class="col-sm-6 p0">
	                        	<h2 class=" ad-crt"><?php echo priceFormate($product->price); ?></h2>
	                        </div>
	                        <div class="col-sm-6 mobi-tc p0 ">
	                        	<a title="<?php echo $product->product_name; ?>" href="<?php echo base_url('product/'.$product->slug) ?>" class="btn btn-default pull-right add-to-cart ad-crt" style="text-align:left !important;"><i class="fa fa-eye"></i>View</a>
	                        </div>
                            </div>
	                    </div>
	                    
	                </div>
					<div class="choose">
						<ul class="nav nav-pills nav-justified">
							<li class="col-sm-8 col-sm-12 p0">
	                        	</li>
						</ul>
					</div>
				</div>
			</div>
	    <?php 
	    	}
	    } else { ?>
	    <div class="clearfix"></div>
	    	<div class="alert alert-info">Record Not Found!</div>
	    <?php } ?>
		</div><!--features_items-->

		<div class="row" style="margin-left: 25%;">
			<div class="col-sm-12">
				<?php echo $paginationCount; ?>
			</div>
		</div>
		<br><br>
	</div>
</div>