<?php
//error_reporting(E_ALL);
$actual_link = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
if (!defined('BASEPATH')) exit('No direct script access allowed');

class News extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->model('news_model');
        $this->load->library('form_validation');
        $this->session->unset_userdata('payment_status');
    }

    public function index()
    {
        $data['page_active']   = 'Latest News';
        $total_count    = $this->news_model->activeRecordCount();
        if ($this->input->post('pageId') > 0) {
            $page = $this->input->post('pageId');
        } else {
            $page = 0;
        }

        $pagination              = getPagination($total_count, $page);
        $data["getNews"]         = $this->news_model->getActiveRecords($pagination['per_page'], $pagination['start_from']);
        $data['total_count']     = $total_count;
        $data['latest_post']     = $this->news_model->getLatestPost(3);
        $data['paginationCount'] = $pagination['pagination'];
        defaultLoadView('news/index', $data);
    }

    public function filter()
    {
        $data['page_active']   = 'Latest News';
        $searchText     = $this->input->post('searchText');
        $total_count    = $this->news_model->activeRecordCount($searchText);

        if ($this->input->post('pageId') > 0) {
            $page = $this->input->post('pageId');
        } else {
            $page = 0;
        }
        $pagination                 = getPagination($total_count, $page);
        $data["getNews"]            = $this->news_model->getActiveRecords($pagination['per_page'], $pagination['start_from'], $searchText);
        $data['total_count']        = $total_count;
        $data['paginationCount']    = $pagination['pagination'];
        echo $this->load->view('news/filter', $data);
    }

    public function search($searchText = null)
    {
        $data['page_active']   = 'Latest News';
        $searchText  = $this->input->post('searchText');

        $total_count = $this->news_model->activeRecordCount($searchText);

        if ($this->input->post('pageId') > 0) {
            $page = $this->input->post('pageId');
        } else {
            $page = 0;
        }

        $pagination                 = getPagination($total_count, $page);
        $data["getNews"]            = $this->news_model->getActiveRecords($pagination['per_page'], $pagination['start_from'], $searchText);

        $data['total_count']        = $total_count;
        $data['paginationCount']    = $pagination['pagination'];

        $this->load->view('news/search', $data);
    }


    public function post($slug)
    {
        $data['page_active']   = 'Latest News';
        $getNews        = $this->news_model->getRecordBySlug($slug);
        if (empty($getNews)) {
            show_404();
        }
        $data['getNews']        = $getNews;
        $data['latest_post']    = $this->news_model->getLatestPost(3);
        defaultLoadView('news/news-post', $data);
    }

    public function addNews()
    {

        $postData = array();

        if (check_user_authentication() != true) {
            redirect('home');
        }

        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

            // if(!filter_var($url, FILTER_VALIDATE_URL)) {
            // $data['error']='Enter Valid Link of Menu';
            // }else{

            $formValidation = $this->news_model->formValidations();
            $data['error'] = array();

            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {

                //$data['error'] = array();
                $main_file_name  = time() . $_FILES['image']['name'];
                $file_size  = $_FILES['image']['size'];
                $file_tmp   = $_FILES['image']['tmp_name'];
                $file_type  = $_FILES['image']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png", "gif");

                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }

                $updateData['image'] = $main_file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $main_file_name);
                    $this->load->library('image_lib');

                    // Create thumnail or resize image
                    $thumb = array();
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/news/' . $main_file_name;
                    $thumb['new_image']         = './upload/news/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;

                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();

                    // Create thumnail or resize image
                    $thumb2 = array();
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/news/' . $main_file_name;
                    $thumb2['new_image']         = './upload/news/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;

                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/news/' . $main_file_name);
                }
            }
            

                    // echo "<pre>";print_r($_FILES['mfile']['name']);die;
              
                

            //      if ($_FILES['mfile']['name'][0] !="") {
                    
            //     $count = count($_FILES['mfile']['name']);
            //     //  echo "<pre>";var_dump($_FILES['mfile']['name']);print_r($count);die;
            //          for($i=0;$i<$count;$i++){
        
            //     $file_multiple  = time() . $_FILES['mfile']['name'][$i];
                
            //     $file_size  = $_FILES['mfile']['size'][$i];
            //     $file_tmp   = $_FILES['mfile']['tmp_name'][$i];
            //     $file_type  = $_FILES['mfile']['type'][$i];
            //     $file_ext   = strtolower(end(explode('.', $_FILES['mfile']['name'][$i])));
            //     $expensions = array("jpeg", "jpg", "png", "gif");

            //     if (in_array($file_ext, $expensions) === false) {
            //         $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
            //     }

            //     $updateData['image'] = $file_multiple;

            //     if (empty($data['error']) == true) {
            //         move_uploaded_file($file_tmp, "./upload/news/" . $file_multiple);
            //         $this->load->library('image_lib');

            //         // Create thumnail or resize image
            //         $thumb = array();
            //         $thumb['image_library']     = 'gd2';
            //         $thumb['source_image']      = './upload/news/' . $file_multiple;
            //         $thumb['new_image']         = './upload/news/orig/';
            //         $thumb['create_thumb']      = false;
            //         $thumb['maintain_ratio']    = false;
            //         $thumb['width']             = 635;
            //         $thumb['height']            = 400;

            //         $this->image_lib->clear();
            //         $this->image_lib->initialize($thumb);
            //         $this->image_lib->resize();

            //         // Create thumnail or resize image
            //         $thumb2 = array();
            //         $thumb2['image_library']     = 'gd2';
            //         $thumb2['source_image']      = './upload/news/' . $file_multiple;
            //         $thumb2['new_image']         = './upload/news/thumb/';
            //         $thumb2['create_thumb']      = false;
            //         $thumb2['maintain_ratio']    = false;
            //         $thumb2['width']             = 165;
            //         $thumb2['height']            = 120;

            //         $this->image_lib->clear();
            //         $this->image_lib->initialize($thumb2);
            //         $this->image_lib->resize();
            //         unlink('./upload/news/' . $file_multiple);
            //     }
               
            //         if ($_FILES['mfile']['name'] !="") {
            //             $data = array(
            //             "name"=>$file_multiple,
            //             "nid"=>$id
            //             );
            //         }
            //     $this->db->insert('news_gallery',$data);
            //     }

            // }

            if ($_POST['media_type'] == 'audio') {
                if (!empty($_FILES['news_audio'])) {
                    $data['audio_error'] = array();
                    $audio_file_name  = time() . $_FILES['news_audio']['name'];
                    $audio_file_size  = $_FILES['news_audio']['size'];
                    $audio_file_tmp   = $_FILES['news_audio']['tmp_name'];
                    $audio_file_type  = $_FILES['news_audio']['type'];
                    $audio_file_ext   = strtolower(end(explode('.', $_FILES['news_audio']['name'])));
                    $audio_expensions = array("mp3");

                    if (in_array($audio_file_ext, $audio_expensions) === false) {
                        $data['audio_error'] = "extension not allowed, please choose a mp3 file.";
                    }
                    if ($audio_file_size > 2097152) {
                        $data['audio_error'] = 'File size must be excately 5 MB';
                    }
                    // $insertData['news_audio'] = $audio_file_name;
                    if (empty($data['audio_error']) == true) {
                        move_uploaded_file($audio_file_tmp, "./upload/news/audio/" . $audio_file_name);
                        //unlink("./upload/news/audio/" . $file_name);
                    }
                }
            }

            if ($_POST['media_type'] == 'video') {
                if (!empty($_FILES['news_video'])) {
                    $data['video_error'] = array();
                    $video_file_name  = time() . $_FILES['news_video']['name'];
                    $video_file_size  = $_FILES['news_video']['size'];
                    $video_file_tmp   = $_FILES['news_video']['tmp_name'];
                    $video_file_type  = $_FILES['news_video']['type'];
                    $video_file_ext   = strtolower(end(explode('.', $_FILES['news_video']['name'])));
                    $video_expensions = array("mp4", "3gp", "avi");
                    if (in_array($video_file_ext, $video_expensions) === false) {
                        $data['news_video'] = "extension not allowed, please choose a mp4 or 3gp or avi file.";
                    }
                    if ($video_file_size > 2097152) {
                        $data['news_video'] = 'File size must be excately 5 MB';
                    }
                    //$insertData['news_video'] = $video_file_name;
                    if (empty($data['video_error']) == true) {
                        move_uploaded_file($video_file_tmp, "./upload/news/video/" . $video_file_name);
                        //unlink("./upload/news/video/" . $file_name);
                    }
                }
            }

            //}
            if ($formValidation && empty($data['error'])) {

                //$newsdate =  date('Y-m-d h:i:s', strtotime($postData['date'] . ' ' . $postData['hour'] . ':' . $postData['minit'] . ':00'));
                $newsdate =  date('Y-m-d h:i:s');
                if ($postData['highlights']) {
                    $highlights = implode('#$#', $postData['highlights']);
                } else {
                    $highlights = '';
                }

                if ($postData['hide_name_on_news']) {
                    $hide_name_on_news = '1';
                } else {
                    $hide_name_on_news = '0';
                }

                if ($postData['hide_email_on_news']) {
                    $hide_email_on_news = '1';
                } else {
                    $hide_email_on_news = '0';
                }
                
                if ($postData['hide_image_on_news']) {
                    $hide_image_on_news = '1';
                } else {
                    $hide_image_on_news = '0';
                }

                $insertData = array(
                    'title'                 => $postData['title'],
                    'discription'           => $postData['discription'],
                    'link'                  => $postData['link'],
                    'date'                  => $newsdate,
                    'country'               => $postData['country'],
                    'state'                 => $postData['state'],
                    'city'                  => $postData['city'],
                    'reporter'              => $this->session->userdata('user_id'),
                    'categorise'            => $postData['categorise'],
                    'child_categorise'            => $postData['child_categorise'],
                    'short_discription'     => $postData['short_discription'],
                    'highlights'            => $highlights,
                    'image_capsion'         => $postData['image_capsion'],
                    //'news_audio'          => $postData['news_audio'],
                    //'news_video'          => $postData['news_video'],
                    'youtube_code'          => $postData['youtube_code'],
                    'media_type'            => $postData['media_type'],
                    'hide_name_on_news'     => $hide_name_on_news,
                    'hide_email_on_news'    => $hide_email_on_news,
                    'hide_image_on_news'    => $hide_image_on_news
                );
                
                if (!empty($postData['image_capsion'])) {
                    $insertData['image_capsion'] = $postData['image_capsion'];
                } else {
                    $insertData['image_capsion'] = '';
                }
                
                if (!empty($_FILES['image'])) {
                    $insertData['image'] = $main_file_name;
                } else {
                    $insertData['image'] = '';
                }
                
                
                //$insertData['image'] = $main_file_name;
                $insertData['news_audio'] = $audio_file_name;
                $insertData['news_video'] = $video_file_name;
                if ($postData['submit_action'] == 'active') {
                    $insertData['status'] = '1';
                } else {
                    $insertData['status'] = '0';
                }
                $slug = create_slug('latest_news', $postData['title']);
                if (!empty($slug)) {
                    $insertData['slug'] = $slug;
                }
                $return = addUpdateRecord('latest_news', '', '', $insertData);
                $insert_id = $this->db->insert_id();
                if(!empty($insert_id))
                {
                    $updatemultipleimgID = array('nid' => $insert_id);
                    $this->db->where('nid', NULL);
                    $this->db->update('news_gallery', $updatemultipleimgID);


                }
                if ($return) {
                    $this->session->set_flashdata('success', 'News added successfully.');
                    if ($postData['submit_action'] == 'preview') {
                        $url = base_url() . 'home/news_view/' . $insert_id . '?preview=' . base64_encode($this->session->userdata('user_id'));
                        redirect($url);
                    }
                    redirect('news/my_news');
                }
            } else {
                $data['postData'] = $postData;
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

        $allcategory = $this->news_model->getCategoriesRecords();
        $allcountry = getAllCountry();
        $allcountryState = getAllCountrystate(101);

        $data['notShowCategory'] = '1';
        $data['allcategory'] = $allcategory;
        $data['allcountryState'] = $allcountryState;
        $data['allcountry'] = $allcountry;
        $terms_and_conditions_and_privacy_policy_html = $this->news_model->getTermsRecords('2');

        $data['terms_and_conditions_and_privacy_policy_html'] = $terms_and_conditions_and_privacy_policy_html[0]['discription'];

        defaultLoadView('news/addNews', $data);
    }

    public function edit($id = null)
    {
        if (empty($id)) {
            redirect('home');
        }
        if (check_user_authentication() != true) {
            redirect('home');
        }
        if ($this->news_model->getNewsOwner($id, $this->session->userdata('user_id')) > 0) {
        } else {
            redirect('home');
        }


        if ($_POST) {
            //var_dump($_POST);
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /*
            if (!filter_var($url, FILTER_VALIDATE_URL)) {
				$data['error']='Enter Valid Link of Menu';
            }
            */
            $formValidation = $this->news_model->formValidations($id);
            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            $slug = create_slug('latest_news', $postData['title'], $id);
            if (!empty($slug)) {
                $updateData['slug'] = $slug;
            }

            /*
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {

                $data['error']  = array();
                $file_name      = $_FILES['image']['name'];
                $file_size      = $_FILES['image']['size'];
                $file_tmp       = $_FILES['image']['tmp_name'];
                $file_type      = $_FILES['image']['type'];
                $file_ext       = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions     = array("jpeg", "jpg", "png", "gif");

                if (in_array($file_ext, $expensions) === false) {
                    $data['error']  = "extension not allowed, please choose a JPEG or PNG file.";
                }

                if ($file_size > 2097152) {
                    $data['error']  = 'File size must be excately 2 MB';
                }

                $updateData['image'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                }

                $testsize = getimagesize("./upload/news/" . $file_name);
                $width = $testsize[0];
                $height = $testsize[1];

                if ($width < 450 || $height < 280) {
                    $data['error'] = 'Image Size is Small';
                    unlink("./upload/news/" . $file_name);
                }

                $updateData['image'] = $file_name;
            }
            */
            $data['error'] = array();
            $myimg_fimename = $postData['mimage'];
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {



                //$data['error'] = array();
                $file_name  = time() . $_FILES['image']['name'];
                
                $file_size  = $_FILES['image']['size'];
                $file_tmp   = $_FILES['image']['tmp_name'];
                $file_type  = $_FILES['image']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['image']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif");

                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }
                // var_dump($file_name);
                // die;
                $updateData['image'] = $file_name;
                

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                    $myimg_fimename = $file_name;
                    $this->load->library('image_lib');

                    // Create thumnail or resize image
                    $thumb = array();
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/news/' . $file_name;
                    $thumb['new_image']         = './upload/news/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;

                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();

                    // Create thumnail or resize image
                    $thumb2 = array();
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/news/' . $file_name;
                    $thumb2['new_image']         = './upload/news/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;

                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/news/' . $file_name);
                }
            }
            
            
           
           
              


            //     if ($_FILES['mfile']['name'][0]!='') {
            //         $count = count($_FILES['mfile']['name']);
            //         //var_dump($count);
            //         for($i=0;$i<$count;$i++){
            //         // var_dump($i);
            //         $file_multiple  = time() . $_FILES['mfile']['name'][$i];
            //         //                 var_dump($file_multiple);
            //         // die;
            //         $file_size  = $_FILES['mfile']['size'][$i];
            //         $file_tmp   = $_FILES['mfile']['tmp_name'][$i];
            //         $file_type  = $_FILES['mfile']['type'][$i];
            //         $file_ext   = strtolower(end(explode('.', $_FILES['mfile']['name'][$i])));
            //         $expensions = array("jpeg", "jpg", "png", "gif");

            //         if (in_array($file_ext, $expensions) === false) {
            //             $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
            //         }

            //         $updateData['image'] = $file_multiple;

            //         if (empty($data['error']) == true) {
            //             move_uploaded_file($file_tmp, "./upload/news/" . $file_multiple);
            //             $this->load->library('image_lib');

            //             // Create thumnail or resize image
            //             $thumb = array();
            //             $thumb['image_library']     = 'gd2';
            //             $thumb['source_image']      = './upload/news/' . $file_multiple;
            //             $thumb['new_image']         = './upload/news/orig/';
            //             $thumb['create_thumb']      = false;
            //             $thumb['maintain_ratio']    = false;
            //             $thumb['width']             = 635;
            //             $thumb['height']            = 400;

            //             $this->image_lib->clear();
            //             $this->image_lib->initialize($thumb);
            //             $this->image_lib->resize();

            //             // Create thumnail or resize image
            //             $thumb2 = array();
            //             $thumb2['image_library']     = 'gd2';
            //             $thumb2['source_image']      = './upload/news/' . $file_multiple;
            //             $thumb2['new_image']         = './upload/news/thumb/';
            //             $thumb2['create_thumb']      = false;
            //             $thumb2['maintain_ratio']    = false;
            //             $thumb2['width']             = 165;
            //             $thumb2['height']            = 120;

            //             $this->image_lib->clear();
            //             $this->image_lib->initialize($thumb2);
            //             $this->image_lib->resize();
            //             unlink('./upload/news/' . $file_multiple);
            //         }

            //         $data = array(
            //         "name"=>$file_multiple,
            //         "nid"=>$id
            //         );
            //         $this->db->insert('news_gallery',$data);
            //     }

            // }



            if ($_POST['media_type'] == 'audio') {

                if (!empty($_FILES['news_audio'])) {

                    $data['audio_error'] = array();
                    $audio_file_name  = time() . $_FILES['news_audio']['name'];
                    $audio_file_size  = $_FILES['news_audio']['size'];
                    $audio_file_tmp   = $_FILES['news_audio']['tmp_name'];
                    $audio_file_type  = $_FILES['news_audio']['type'];
                    $audio_file_ext   = strtolower(end(explode('.', $_FILES['news_audio']['name'])));

                    $audio_expensions = array("mp3");

                    if (in_array($audio_file_ext, $audio_expensions) === false) {
                        $data['audio_error'] = "extension not allowed, please choose a mp3 file.";
                    }

                    if ($audio_file_size > 2097152) {
                        $data['audio_error'] = 'File size must be excately 5 MB';
                    }
                    $updateData['news_audio'] = $audio_file_name;

                    if (empty($data['audio_error']) == true) {
                        move_uploaded_file($audio_file_tmp, "./upload/news/audio/" . $audio_file_name);
                        //unlink("./upload/news/audio/" . $file_name);
                    }
                }
            }

            if ($_POST['media_type'] == 'video') {
                if (!empty($_FILES['news_video'])) {

                    $data['video_error'] = array();
                    $video_file_name  = time() . $_FILES['news_video']['name'];
                    $video_file_size  = $_FILES['news_video']['size'];
                    $video_file_tmp   = $_FILES['news_video']['tmp_name'];
                    $video_file_type  = $_FILES['news_video']['type'];
                    $video_file_ext   = strtolower(end(explode('.', $_FILES['news_video']['name'])));
                    $video_expensions = array("mp4", "3gp", "avi");
                    if (in_array($video_file_ext, $video_expensions) === false) {
                        $data['news_video'] = "extension not allowed, please choose a mp4 or 3gp or avi file.";
                    }
                    if ($video_file_size > 2097152) {
                        $data['news_video'] = 'File size must be excately 5 MB';
                    }
                    $updateData['news_video'] = $video_file_name;
                    if (empty($data['video_error']) == true) {
                        move_uploaded_file($video_file_tmp, "./upload/news/video/" . $video_file_name);
                        //unlink("./upload/news/video/" . $file_name);
                    }
                }
            }

            if ($formValidation &&  empty($data['error'])) {


                if ($postData['highlights']) {
                    $highlights = implode('#$#', $postData['highlights']);
                } else {
                    $highlights = '';
                }

                // $newsdate =  date('Y-m-d h:i:s', strtotime($postData['date'] . ' ' . $postData['hour'] . ':' . $postData['minit'] . ':00'));
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                $updateData['link'] = $postData['link'];
                //$updateData['date'] = $newsdate;
                $updateData['status'] = $postData['status'];
                $updateData['short_discription'] = $postData['short_discription'];
                $updateData['media_type'] = $postData['media_type'];
                $updateData['country'] = $postData['country'];
                $updateData['state'] = $postData['state'];
                $updateData['city'] = $postData['city'];
                $updateData['categorise'] = $postData['categorise'];
                $updateData['child_categorise'] = $postData['child_categorise'];
                $updateData['youtube_code'] = $postData['youtube_code'];
                $updateData['spceial_block'] = $postData['spceial_block'];
                $updateData['highlights'] = $highlights;
                $updateData['image_capsion'] = $postData['image_capsion'];

                if ($postData['hide_name_on_news']) {
                    $hide_name_on_news = '1';
                } else {
                    $hide_name_on_news = '0';
                }

                if ($postData['hide_email_on_news']) {
                    $hide_email_on_news = '1';
                } else {
                    $hide_email_on_news = '0';
                }
                
                if ($postData['hide_image_on_news']) {
                    $hide_image_on_news = '1';
                } else {
                    $hide_image_on_news = '0';
                }

                $updateData['hide_name_on_news'] = $hide_name_on_news;
                $updateData['hide_email_on_news'] = $hide_email_on_news;
                $updateData['hide_image_on_news'] = $hide_image_on_news;
                
                
                
                $updateData['image'] = $myimg_fimename;

                $return = addUpdateRecord('latest_news', 'id', $id, $updateData);

                if ($return) {
                    $this->session->set_flashdata('success', 'News updated successfully.');
                    if ($postData['submit_action'] == 'preview') {
                        $url = base_url() . 'home/news_view/' . $id . '?preview=' . base64_encode($this->session->userdata('user_id'));
                        redirect($url);
                    }
                    redirect('news/my_news');
                }
            } else {

                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
            $data['postData'] = $postData;
        } else {
            $postData = $this->news_model->getRecordById($id);
            $postData['highlights'] = explode('#$#', $postData['highlights']);
            $data['postData'] = $postData;
        }

        $allcategory = $this->news_model->getCategoriesRecords();
        $allcountry = getAllCountry();
        $allcountryState = getAllCountrystate(101);


        //pr($allcountry);
        $this->db->select('*');
        $this->db->from('news_gallery');
        $this->db->where('nid', $id);
        $getdata = $this->db->get();
        $data['getmultipleimage'] = $getdata->result_array();
        $data['id'] = $id;
        $data['allcategory'] = $allcategory;
        $data['allcountry'] = $allcountry;
        $data['notShowCategory'] = '1';
        // get chide category 
        $child_categoryid = $postData['child_categorise'];
        $this->db->select('*');
        $this->db->from('news_categories');
        $this->db->where('id', $child_categoryid);
        $getchildcat = $this->db->get();
        $data['childcategoryname'] = $getchildcat->result_array();
        //echo "<pre>";
        //print_r($data);die;
        
        $terms_and_conditions_and_privacy_policy_html = $this->news_model->getTermsRecords('2');

        $data['terms_and_conditions_and_privacy_policy_html'] = $terms_and_conditions_and_privacy_policy_html[0]['discription'];
        
        
        defaultLoadView('news/editNews', $data);
    }

    public function delete($id = null)
    {

        if (empty($id)) {
            redirect('home');
        }

        if (check_user_authentication() != true) {
            redirect('home');
        }



        if ($this->news_model->getNewsOwner($id, $this->session->userdata('user_id')) > 0) {
        } else {
            redirect('home');
        }

        $delete = deleteRecordById('latest_news', $id);
        if ($delete) {
            $this->session->set_flashdata('success', 'News deleted successfully.');
            redirect('news/my_news');
        }
    }


    function my_news()
    {
        if (check_user_authentication() != true) {
            redirect('home');
        }

        if ($_GET['cat'] > 0) {
            $category = $_GET['cat'];
        }

        $data['news_list'] = $this->news_model->getRecords($this->session->userdata('user_id'), $category);
        $data['category'] = $this->news_model->getCategoriesRecords();
        $data['notShowCategory'] = '1';
        defaultLoadView('news/list', $data);
    }

    function activate_news($id)
    {
        if (check_user_authentication() != true) {
            $this->session->set_flashdata('success', 'Not having access this page.');
            redirect('home');
        }

        $updateData['status'] = '1';
        addUpdateRecord('latest_news', 'id', $id, $updateData);
        $this->session->set_flashdata('success', 'News active successfully.');
        redirect('news/my_news');
    }
     public function pcategory()
    {

       
        $pcategory = $_POST['pcategory'];
        $this->db->select('*');
        $this->db->from('category_map');
        $this->db->where("parent_category",$pcategory);
        $query = $this->db->get();
        $result = $query->result_array();
        //print_r($result);die;
        echo "<option value=''>Select Child Category</option>";
        foreach($result as $value)
        {
        $child_category = $value['child_category'];
        $this->db->select('id,title');
        $this->db->from('news_categories');
        $this->db->where("id",$child_category);
        $query11 = $this->db->get();
        // echo $this->db->last_query();die;
        $result11 = $query11->result_array();
      
        echo "<option value='".$result11[0]['id']."'>".$result11[0]['title']."</option>";
        }


    }
    public function deleteimages()
    {
        $id = $this->input->post('imageid');
        $this->db->where('id', $id);
        $this->db->delete('news_gallery');


    }
     function subscribe()
    {
        
    //var_dump($_POST);
       
        if ($_POST) {
            $postData = $_POST;
            
            
            $newsdate =  date('Y-m-d h:i:s');
                

                $insertData = array(
                    'email'                 => $postData['subscribe_email'],
                    'created'           => $newsdate,
                    'status'                  => '1'
                    
                );
                
               
                
                $return = addUpdateRecord('email_subscriber', '', '', $insertData);
                
                if ($return) {
                    
                   // $this->session->set_flashdata('success', 'News added successfully.');
                    redirect($actual_link);
                }
            
        }

        
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
