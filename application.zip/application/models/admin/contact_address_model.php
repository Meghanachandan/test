<?php
	class Contact_address_model extends CI_Model {
 
	    function __construct()
	    {
	        parent::__construct();
	    }

	    public function getRecords()
	    {
	    	$this->db->order_by("id","desc");
            $query  = $this->db->get('contact_address');
            $ret    = $query->result_array();
            return $ret;
	    }

	    public function getRecordById($id)
	    {
			$this->db->where('id', $id);
			$q = $this->db->get('contact_address');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }

	    public function formValidations()
	    {
           	$this->form_validation->set_rules('address', 'Address', 'required');
            $this->form_validation->set_rules('email', 'Email', 'valid_email');
            $this->form_validation->set_rules('phone_number', 'Phone Number', 'required');

            if ($this->form_validation->run() == FALSE) {
				return false; 
		    } else {
		       return TRUE; 
		    }
	    }

	    
	}
?>