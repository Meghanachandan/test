<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Menus extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/menu_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index() {

        $data['menus'] = $this->menu_model->getRecords();
        adminLoadView('menus/list', $data);
    }

    public function add() {

        $postData = array();

        $data['menusType'] = $this->menu_model->getMenuType();
        // $data['postData'] = $postData;

        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /*if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            }*/

            $formValidation = $this->menu_model->formValidations();
            $this->db->from('menus');
            $this->db->where('menu_type', 'mainmenu');
            $query = $this->db->get();
            $rowcount = $query->num_rows();


            /*if ($rowcount > 6) {
                $data['error'] = 'Main menu Limit is 6 your menu is not added';
            } else {*/

                if ($formValidation && $data['error'] == "") {
                    $insertData = array(
                        'title' => $postData['name'],
                        'menu_type' => $postData['menu_type'],
                        'parent_id' => $postData['parent_id'],
                        'link' => $postData['link'],
                        'status' => $postData['status']
                    );

                    $slug = create_slug('menus', $postData['name']);
                    if (!empty($slug)) {
                        $insertData['slug'] = $slug;
                    }
					
                    $return = addUpdateRecord('menus', '', '', $insertData);

                    if ($return) {
                        $this->session->set_flashdata('success', 'Menu added successfully.');
                        redirect('admin/menus');
                    }
                } else {

                    if (validation_errors()) {
                        if (validation_errors()) {
                            $data['error'] = validation_errors();
                        }
                    }
                }
           // }
        }

        $data['postData'] = $postData;
        adminLoadView('menus/create', $data);
    }

    public function edit($id = null) {

        if (empty($id)) {
            redirect('admin/menus');
        }

        $postData = $this->menu_model->getRecordById($id);
        $data['postData'] = $postData;
        $data['menusType'] = $this->menu_model->getMenuType();
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /*if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            }*/

            $formValidation = $this->menu_model->formValidations();
            if ($formValidation && $data['error'] == "") {
                $updateData = array(
                    'title' => $postData['name'],
                    'menu_type' => $postData['menu_type'],
                    'parent_id' => $postData['parent_id'],
                    'link' => $postData['link'],
                    'status' => $postData['status']
                );

                $slug = create_slug('menus', $postData['name'], $id);
                if (!empty($slug)) {
                    $updateData['slug'] = $slug;
                }

                if ($postData['menu_type'] == 'submenu') {
                    $updateData['parent_id'] = $postData['parent_id'];
                } else {
                    $updateData['parent_id'] = 0;
                }

                $return = addUpdateRecord('menus', 'id', $id, $updateData);

                if ($return) {
                    $this->session->set_flashdata('success', 'Menu updated successfully.');
                    redirect('admin/menus');
                }
            } else {

                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }



        adminLoadView('menus/edit', $data);
    }

    public function delete($id = null) {

        if (empty($id)) {
            redirect('admin/menus');
        }

        $deleteData = $this->menu_model->getRecordById($id);
        $delete = deleteRecordById('menus', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'Menu deleted successfully.');
            redirect('admin/menus');
        }
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */