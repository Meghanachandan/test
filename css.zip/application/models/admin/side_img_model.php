<?php
class Side_img_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}
	

	public function getSideImgRecords()
	{
		$this->db->order_by("id", "desc");
// 			$this->db->where("categorie_type", '0');
		$query = $this->db->get('side_img');
		$ret = $query->result_array();
// 		echo $this->db->last_query();die;
		return $ret;
	}
	
	public function getSideImgRecords11($id)
	{
	$this->db->where('id', $id);
		$q = $this->db->get('side_img');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}
	public function getRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('side_img');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}
	
}
?>