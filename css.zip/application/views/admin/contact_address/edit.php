<?php
	if (!empty($postData)) {
		$address 		= $postData['address'];
		$email 			= $postData['email'];
		$phone_number 	= $postData['phone_number'];
		$status 		= $postData['status'];
	}
?>
<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li><a href="<?php echo base_url('admin/contact_address'); ?>">CONTACT ADDRESS</a></li>
			<li class="active">Edit ADDRESS</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">Edit ADDRESS</h2>
		<div class="graph-form">
			<?php
				if(!empty($error)){ 
				?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
			} ?>
			<div class="form-body">
				<?php 
				$editId = "";
				if(!empty($postData['id'])) {
					$editId = $postData['id'];
				} ?>
				<form action="<?php echo base_url('admin/contact_address/edit/'.$editId); ?>" method="post">
					<input type="hidden" value=""/>
					<div class="form-group">
						<label for="exampleInputEmail1">Email <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
					</div>
					<div class="form-group">
						<div class="row">
                            <div class="col-lg-8">
                                <label for="exampleInputPassword1">Address <span class="star-color">*</span></label> 
                                <textarea name="address" rows="10" cols="80" id="address"  name="address" required><?php echo $address; ?></textarea>
                            </div>
                        </div>
					</div> 
					<div class="form-group">
						<label for="exampleInputPassword1">Phone Number</label> 
						<input type="text" class="form-control" id="phone_number"  name="phone_number"  value="<?php echo $phone_number; ?>">
					</div>
					<div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Status</label>
						<div class="radio block"><label>
						<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked"  />Active</label></div>
						<div class="radio block">
						<label><input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive</label></div>
					</div>
					<button type="submit" class="btn btn-default" name="submit" value="submit">Update</button> 
				</form> 
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( 'address' );
</script>