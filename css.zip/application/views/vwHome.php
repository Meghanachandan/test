<!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <?php $url1 = current_url();
  $parse = parse_url($url1);
       $strig = $parse['host'];
  $ad="SELECT * FROM `side_img` WHERE page_host ='".$strig."' and status='1'  ORDER BY id DESC LIMIT 1";
$q = $this->db->query($ad);
        $data = $q->result_array();
// echo $this->db->last_query();die;
// echo "<pre>";print_r($data);die;
  ?>

  <style>
      @media(max-width: 600px){
          #display{
              display: none;
          }
      }
      @media(min-width: 1200px){
    .megamenu-li {
    position: static;
    z-index:1;
        }
        }
  </style>          
          
<?php if ($latest_news[0]) { ?>
    <section class="tabs4 cid-rUEF7euy93" id="tabs4-r" >
        <div class="container-fluid">
            <div class="row">
               
 <div class="col-sm-12 col-md-2 col-lg-2 col-xl-2 mb-3 main-contaner-for-home p-1" style="margin-top: -5px;
    box-shadow: none;">
     
     <?php if($strig==$data[0]['page_host']){
        if($data[0]['media_type']=='img'){ 
         ?>
         
             <img src="<?php echo 'http://newssyn.com/upload/side_img/left_img/orig/'.$data[0]['left_img']; ?>" id="display" style="height: 734.5px;width:275.06px;">
      <?php  } else{ ?>
                    <span style="height: 734.5px;width:275.06px;" id="display"><?php echo $data[0]['l_sence_code']; ?></span>
    <?php } }else{ ?>
     <img src="<?php echo base_url(); ?>images/ads.gif" style="width:100%;">
     <?php } ?>
 </div>
    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 "  style="float:left;padding-left:0px !important;padding-right:0px !important;">

                <div  class="col-md-12" >
              
<?php $this->load->view('fslider'); ?>

                </div>


                <div style="clear:both"></div>
<div  class="col-md-12" >
               

<?php $this->load->view('fcrausal'); ?>


                </div>
            </div>
                <div class="col-sm-12 col-md-2 col-lg-2 col-xl-2 mb-3 main-contaner-for-home p-1" style="margin-top: -5px;
    box-shadow: none;">
                        <?php if($strig==$data[0]['page_host']){
          if($data[0]['media_type']=='img'){  ?>
             <img src="<?php echo 'http://newssyn.com/upload/side_img/right_img/orig/'.$data[0]['right_img']; ?>" id="display" style="height: 734.5px;width:275.06px;">
       <?php  } else { ?>
     <span style="height: 734.5px;width:275.06px;" id="display"><?php echo $data[0]['r_sence_code']; ?></span>
     
    <?php } }else{ ?>
     <img src="<?php echo base_url(); ?>images/ads.gif" id="display" style="width:100%;">
     <?php } ?>
 </div>
            </div>
        </div>
    </section>
<?php } ?>
<style>
    @media(min-width: 1200px){
        .sssssss{
            margin-top:-55px;
        }
    }
     @media(max-width: 600px){
        .sssssss{
            margin-top:-35px;
        }
    }
</style>
<style>
    @media(max-width: 600px){
        .slick-current {
         width: 210px!important;   
        }
        .slick-track{
            margin-left: 60px!important;
        }
    }
</style>
<?php if ($latest_news) { ?>
    <section class="features17 cid-rUEOBxXWse sssssss" id="features17-y" style="">
        <div class="container-fluid">
            <div cl ass="media-container-row">
                <h1 class="classForHeadercategory">
                    Latest News
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php
                unset($latest_news[0]);
                if ($latest_news) {
                    $news = array();
                    foreach ($latest_news as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'ln';
                        //  if($news['news_video']){
                        // $this->load->view('home/home_news_block_video', $news_data);
                        // }
                        $this->load->view('home/home_news_block', $news_data);
                    }
                }
                ?>
            </div>
        </div>
    </section>
<?php } ?>




<?php if ($populer_news) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    papular story
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php if ($populer_news) {
               
                    
                    $news = array();
                    foreach ($populer_news as $news) {
                     
                        $news_data['news'] = $news;
                          
                        $news_data['list'] = 'pn';
                        // if($news['news_video']){
                        // $this->load->view('home/home_news_block_video', $news_data);
                        // }
                        $this->load->view('home/home_news_block', $news_data);
                    }
                ?>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } ?>

<?php
$add_array = array();
foreach ($addOnPage as $key => $value) {
    $add_array[]  = $key;
}
//pr($add_array);
?>

<section class="features17 cid-rUEHsxB8TC" id="features17-s">
    <div class="container-fluid">
        <!--<div class="media-container-row center2 slider">-->
            <?php $addCount = 0;
            foreach ($addOnPage[$add_array[0]] as $add) { ?>
                <?php if ($addCount < 4) { ?>
                    <!--<div class="card p-3">-->
                    <!--    <div class="card-wrapper">-->
                    <!--        <div class="card-img">-->
                    <?php if($add['image'] == ''){
                            $img='http://newssyn.com/upload/adds/no-image.png';
                    }else{
                       $img=base_url() . 'upload/adds/' . $add['image']; 
                    }
                    ?>
                                <img src="<?php echo $img; ?>" alt="FifthNews.com" style="height:180px;width: 100%;" title="<?php echo $add['title']; ?>">
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                <?php }
                $addCount++; ?>
            <?php } ?>
        <!--</div>-->
    </div>
</section>

<?php
$cat_count = 0;
$adds_counter_count = 1;

     
          $query = "SELECT news_categories.id,news_categories.title,news_categories.slug,news_categories.categorie_type,news_categories.categorie_colour,manage_category.position,manage_category.categoriesid FROM `news_categories` INNER JOIN manage_category ON news_categories.id = manage_category.categoriesid where news_categories.status = '1' AND news_categories.order > 0 ORDER BY manage_category.position ASC";
        $query = $this->db->query($query);
        $rowsasdasd = $query->result_array();
  


   
      //  echo "<pre>";print_r($rowsasdasd);die;
$allcategories = $rowsasdasd;
//echo "<pre>";print_r($allcategories);die;
if ($allcategories) {
    foreach ($allcategories as $category) {
        $categories_news = $this->home_model->get_latest_news_by_id($category['id']);
        if ($categories_news) { ?>
            <section class="features17 cid-rUEOBxXWse" id="features17-y" >
                <div class="container-fluid">
                    <div class="media-container-row">
                        <h1 class="classForHeadercategory">
                            <div style="width: calc(100% - 55px);"><?php echo '<a  href="http://' . $category['slug']. '.newssyn.com"> ' . $category['title'] . ' </a>'; ?></div>
                            <div><?php echo '<a style="font-size: 15px;" href="http://' . $category['slug']. '.newssyn.com"> More... </a>'; ?></div>
                        </h1>
                    </div>
                    <div class="media-container-row center slider" style="text-align: -webkit-center;">
                        <?php
                        $news = array();
                        foreach ($categories_news as $news) {
                            $news_data['news'] = $news;
                            $news_data['list'] = 'cat';
                        //      if($news['news_video']){
                        // $this->load->view('home/home_news_block_video', $news_data);
                        // }
                       // echo "<pre>";print_r($news_data);die;
                            $this->load->view('home/home_news_block', $news_data);
                        }
                        ?>
                    </div>
                </div>
            </section>
        <?php } ?>
        <?php
        if ($cat_count % 10 == 0 && $cat_count > 0) {
            //pr($adds_counter_count);
        ?>
            <section class="features17 cid-rUEHsxB8TC" id="features17-s">
                <div class="container-fluid">
                    <!--<div class="media-container-row center2 slider">-->
                        <?php $addCount = 0;
                        foreach ($addOnPage[$add_array[$adds_counter_count]] as $add) { ?>
                            <?php if ($addCount < 4) { ?>
                                <!--<div class="card p-3">-->
                                <!--    <div class="card-wrapper">-->
                                <!--        <div class="card-img">-->
                                <?php if($add['image'] == ''){
                            $img2='http://newssyn.com/upload/adds/no-image.png';
                    }else{
                       $img2=base_url() . 'upload/adds/' . $add['image']; 
                    }
                    ?>
                                            <img src="<?php echo $img2; ?>" alt="FifthNews.com" style="height:180px;width: 100%;" title="<?php echo $add['title']; ?>">
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                            <?php }
                            $addCount++; ?>
                        <?php } ?>
                    <!--</div>-->
                </div>
            </section>
<?php
            $adds_counter_count++;
        }
        $cat_count++;
    }
}
?>
<?php
if ($recientView) { ?>
    <section style="overflow: hidden;" class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    Recent View
                </h1>
            </div>
            <div class="media-container-row center slider" style="">
                <?php
                $news = array();
                foreach ($recientView as $news) {
                    $news_data['news'] = $news;
                    $news_data['list'] = 'rv';
                    //  if($news['news_video']){
                    //     $this->load->view('home/home_news_block_video', $news_data);
                    //     }
                    $this->load->view('home/home_news_block', $news_data);
                } ?>
            </div>
        </div> <br />
    </section>

<?php } ?>


<script src="http://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
 
 
    $(document).ready(function(){
    

        $(".likebtn").click(function(){
            pid = $(this).data('id');
            btn = $(this);
            // alert(pid);
            $.post("<?php echo base_url('Home/like'); ?>", {news_id: pid}, function(result){
                // alert(result);
                if(result==0) alert("Please Login First!!");
                if(result==1)
                {
                    btn.removeClass('fa-heart-o');
                    btn.addClass('fa-heart');
                    // btn.html('<i class="fa fa-heart"></i>');
                    alert('you liked');
                    btn.removeClass('likebtn');
                    btn.addClass('unlikebtn');
                    location.reload();
                } 
            });
        });

        $(".unlikebtn").click(function(){
            unlikeid = $(this).data('id');
            btnunlike = $(this);
            // alert(pid);
            // alert('hi');

            $.post("<?php echo base_url('Home/unlike'); ?>", {news_id: unlikeid}, function(result){
                // alert(result);
                if(result==0) alert("Please Login First!!");
                if(result==1)
                {
                    btnunlike.removeClass('fa-heart');
                    btnunlike.addClass('fa-heart-o');
                    // btn.html('<i class="fa fa-heart"></i>');
                    alert('you unliked');
                    btnunlike.removeClass('unlikebtn');
                    btnunlike.addClass('likebtn');
                    location.reload();
                } 
            });
        });
    });
 

    $(document).on('ready', function() {
        $(".center").slick({
            dots: false,
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 6,
                        slidesToScroll: 1,
                       // centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                       // centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        //centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        $(".center2").slick({
            dots: false,
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        $(".center3").slick({
            dots: false,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    });
</script>