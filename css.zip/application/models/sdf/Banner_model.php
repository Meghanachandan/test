<?php
	class Banner_model extends CI_Model {
 
	    function __construct()
	    {
	        parent::__construct();
	    }

	    public function getRecords()
	    {
	    	$query  = $this->db->get('banner_images');
            $ret    = $query->result_array();
            return $ret;
	    }

	    public function getRecordById($id)
	    {

			$this->db->where('id', $id);
			$q = $this->db->get('banner_images');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }

	     public function getMenuType()
	    {

			$this->db->where('menu_type', 'mainmenu');
			$q = $this->db->get('banner_images');
			//if id is unique we want just one row to be returned
			$data = $q->result_array();
			return $data;
	    }

	    public function formValidations()
	    {
           	$this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('link', 'Link', 'required');
            if ($this->form_validation->run() == FALSE) {
				return false; 
		    } else {
		       return TRUE; 
		    }
	    }

	    
	}
?>