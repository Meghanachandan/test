<script>
	function validateForm() {
		var x = document.forms["contact-form"]["email"].value;
		var atpos = x.indexOf("@");
		var dotpos = x.lastIndexOf(".");
		if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
			alert("Not a valid e-mail address");
			return false;
		}
	}
</script>

<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script>
<style>
	#imgdiv {
		width: 160px;
		float: left;
		margin-left: 20px
	}

	#reload {
		float: right;
		margin-right: 40px
	}

	section {
		background-color: #FFF;
	}
</style>
<section id="form">
	<!--form-->
	<div class="container">
		<div class="row" style="margin-top: 50px;margin-bottom: 10px;">
			<br>
			<br>
			<div class="col-md-7 col-sm-6 mb-4">
				<div class="contact-form">

					<?php if (!empty($error)) { ?>
						<div class="alert alert-danger"><?php echo $error; ?></div>
					<?php } ?>

					<div class="status alert alert-success" style="display: none"></div>

					<div class="col-lg-12">
						<?php if ($this->session->flashdata('success')) { ?>
							<div class="alert alert-success">
								<a href="#" class="close" data-dismiss="alert">&times;</a>
								<?php echo $this->session->flashdata('success'); ?></div>
						<?php } ?>
					</div>
					<?php
					echo $this->session->flashdata('email_sent');
					echo form_open('contact/send_mail');
					?>
					<h4 class="icon-block__title align-left mbr-fonts-style display-5">
						Contact Us
					</h4>
					<form class="block mbr-form" action="http://mobirise.com/" method="post" data-form-title="Mobirise Form"><input type="hidden" data-form-email="true" value="VyfBhjXY/U/Zmt1Pt1h8AUq3OZw8hzMN2LHhS02AKmRlJXOXYztQHFLe4ZtOqtsGZcolY6Zc/k02XjN6+grxxBoiXlO8zOY2aPEWv+XteZzFKh7BTcuG/y+UuTZ6thxI">
						<div class="row">
							<div class="form-group col-md-6 multi-horizontal" data-for="name">
								<input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo $postData['name']; ?>">
							</div>
							<div class="form-group col-md-6 multi-horizontal" data-for="phone">
								<input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo $postData['email']; ?>">
							</div>
							<div class="form-group col-md-12" data-for="email">
								<input type="text" name="subject" class="form-control" placeholder="Subject" value="<?php echo $postData['subject']; ?>">
							</div>
							<div class="form-group col-md-12" data-for="message">
								<textarea name="message" maxlength="500" id="message" class="form-control" rows="2" placeholder="Your Message Here"><?php echo $postData['message']; ?></textarea>
								<div style="font-size: 11px;color:#ccc;margin-top:5px;"><span id="remain_char">500</span> Character(s) Remaining</div>
							</div>
							<div class="input-group-btn col-md-12">
								<!-- <button href="" type="submit" class="btn btn-primary btn-form display-4">SEND MESSAGE</button> -->
								<input type="submit" name="submit" title="Submit" class="btn-sm btn-secondary" value="Submit">
							</div>
						</div>
					</form>
				</div>
			</div>

			<div class="col-md-5 col-sm-6 mb-4">
				<div class="contact-info">
					<div class="categoryproduct" style="padding-left:0;">
						<div class="content-heading">
							<h4 class="icon-block__title align-left mbr-fonts-style display-5">
								Contact Info
							</h4>
						</div>
					</div>
					<address>
						<?php $getCAddress = getFirstRecord('contact_address'); ?>
						<?php if (!empty($getCAddress['address'])) { ?>
							<br>
							<h5><?php echo $getCAddress['address']; ?></h5>
						<?php } ?>

						<?php if (!empty($getCAddress['phone_number'])) { ?>
							<br>
							<h5><STRONG>Mobile</STRONG> : <?php echo $getCAddress['phone_number']; ?></h5>
						<?php } ?>

						<?php if (!empty($getCAddress['email'])) { ?>
							<br>
							<h5><strong>Email </strong>: <a title="<?php echo $getCAddress['email']; ?>" href="mailto:<?php echo $getCAddress['email']; ?>"><?php echo $getCAddress['email']; ?></a></h5>
						<?php } ?>

					</address>


				</div>
			</div>

		</div>
	</div>
</section>
<!--/#contact-page-->

<section>
	<div class="gap nogap">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 p-0">
					<div class="contact-map">
						<iframe src="http://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3667.274457210247!2d79.93342711444542!3d23.19666641562105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3981afebb72a114d%3A0xc3cb018135967991!2sAVIS!5e0!3m2!1sen!2sin!4v1553935248000!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><!-- google map -->

<script>
	$('#message').keyup(function(e) {
		var tval = $('#message').val(),
			tlength = tval.length,
			set = 500,
			remain = parseInt(set - tlength);
		$('#remain_char').text(remain);
		if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
			$('#message').val((tval).substring(0, tlength - 1))
		}
	})
</script>