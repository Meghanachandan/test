<link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet">
<style>
    #imgdiv {
        width: 160px;
        float: left;
        margin-left: 20px
    }

    #reload {
        float: right;
        margin-right: 40px
    }

    section {
        background-color: #FFF;
    }
</style>
<section >
    <!--form-->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="categoryproduct " style="padding-left:0;">
                    <div class="content-heading">
                        <h2 class="title-head"><?php  echo $terms['title']; ?></h2>
                    </div>
                </div>
                <div >
                <?php  echo  $terms['discription']; ?>
                </div>
            </div>
        </div>
    </div>
</section>
