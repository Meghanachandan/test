<?php
if (!empty($postData)) {
    // echo "<pre>";print_r($postData);die;
   	$categorise 		= $postData['category_id']; 
   	$left_img 		= $postData['left_img']; 
   	$right_img 		= $postData['right_img']; 
   	$sub_category_id 		= $postData['sub_category_id']; 
   	$page_host 		= $postData['page_host']; 
   	$media_type 		= $postData['media_type']; 
   	$l_sence_code 		= $postData['l_sence_code']; 
   	$r_sence_code 		= $postData['r_sence_code'];
   	
   	$l_discription 		= $postData['l_discription']; 
   	$r_discription 		= $postData['r_discription']; 
   	$valid_date 		= $postData['valid_date']; 
   	$link 		= $postData['link']; 
   	$status 		= $postData['status']; 
   	$id 		= $postData['id']; 
   
}
$allcategories = get_blog_categories();
//var_dump($allcategories);
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/news/categories'); ?>">NEWS CATEGORISES</a></li>
            <li class="active">ADDS SIDE IMAGE</li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">EDIT SIDE IMAGE</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <form action="<?php echo base_url('admin/side_img/edit').'/'.$id; ?>" enctype="multipart/form-data" method="post">
                    <input type="hidden" value=""/>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select Category <span class="star-color">*</span></label>
                        <select class='form-control' name="host" id="manage_category">
                            <option value="">Select Category...</option>
                            <option <?php if ($page_host == 'newssyn.com') {
											echo ' selected ';
										} ?> value="newssyn.com">Home</option>
                            <option <?php if ($page_host == 'news_view') {
											echo ' selected ';
										} ?> value="news_view">News View</option>
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select Category <span class="star-color">*</span></label>
                        <select class='form-control pcategory' name="manage_category" id="manage_category">
                            <option value="">Select Category...</option>
                            <?php
                            foreach($allcategories as $category){
                                ?>
                                <option <?php if ($categorise == $category['id']) {	echo ' selected="selected" '; } ?> value="<?php echo $category['id']; ?>"><?php echo $category['title']; ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select Category <span class="star-color">*</span></label>
                        <?php if(!empty($childcategoryname[0]['slug'])) { ?>
						<select class="form-control ccategory" id="categorise" name="sub_category">
							<option value="<?php echo $childcategoryname[0]['id']; ?>"><?php echo $childcategoryname[0]['slug']; ?></option>
							
						</select>
					<?php } else { ?>
                        <select class='form-control ccategory' name="sub_category" id="categorise">
                            <option value="">Select Sub Category...</option>
                            ?>
                        </select>
                        <?php } ?>
                        <script>
$(document).ready(function(){
    $("select.pcategory").change(function(){
        var pcategory = $(".pcategory option:selected").val();
        // alert(pcategory);
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>news/pcategory",
            data: { pcategory : pcategory } 
        }).done(function(data){
        // 	 alert(data);
        	// alert(data);
           $(".ccategory").html(data);
        });
    });
});
</script>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Link <span class="star-color">*</span></label>
                        <input type="text" class="form-control" value="<?php echo $link; ?>" name="link" placeholder='Link'>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Valid Date<span class="star-color">*</span></label>
                        <input type="date" class="form-control" value="<?php echo $valid_date; ?>" name="valid_date">
                    </div>
                    <div class="form-group">
						<label for="exampleInputPassword1">Side Adds Type</label>
						<div class="radio block">
							<label>
								<input type="radio" value="img" onclick="showTheUploadOption(this.value);" <?php echo ($media_type == 'img') ? 'checked="checked"' : ''; ?> name="media_type" checked="checked" />Image
							</label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label>
								<input type="radio" value="code" onclick="showTheUploadOption(this.value);" <?php echo ($media_type == 'code') ? 'checked="checked"' : ''; ?> name="media_type" />Sence Code
							</label>
						</div>
						<div class="form-group optionContaner" id="option_to_show_code" style="display:<?php if ($media_type == 'code') {
																											echo ' block ';
																										} else {
																											echo ' none ';
																										} ?>">
						<div class="row">
							<div class="col-lg-4">
								<label for="exampleInputPassword1">Left Sence Code</label>
								<textarea name="l_sence_code" style="width: 100%;height: 70px" id="youtube_code"><?php echo $l_sence_code; ?></textarea>
							</div>
							<div class="col-lg-4">
								<label for="exampleInputPassword1">Right Sence Code</label>
								<textarea name="r_sence_code" style="width: 100%;height: 70px" id="youtube_code"><?php echo $r_sence_code; ?></textarea>
							</div>
						</div>
					</div>
                    
                    <div class="optionContaner" id="option_to_show_img" style="display:<?php if ($media_type == 'code') {
																											echo ' none ';
																										} else {
																											echo ' blcok ';
																										} ?>">
                    <div class="form-group">
                        <label>Left Image</label>
                        <input type="hidden" name="oldimage_l" value="<?php echo $left_img; ?>">
                        <input type='file' name='left_img'>
                        <?php if ($left_img != '') { ?>
							<br>
							<br>
							<img src="<?php echo base_url('upload/side_img/left_img/orig/' . $left_img); ?>" style="width:100px;margin-left:20px;border:1px solid #444;padding:3px;">
						<?php } ?>
                    </div>
                    <div class="form-group">
                        <label>Left Description</label>
                        <textarea rows="3" cols="90" id="discription" name="l_discription"><?php echo $l_discription; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Right Image</label>
                        <input type="hidden" name="oldimage_r" value="<?php echo $right_img; ?>">
                        <input type='file' name='right_img'>
                        <?php if ($right_img != '') { ?>
							<br>
							<br>
							<img src="<?php echo base_url('upload/side_img/right_img/orig/' . $right_img); ?>" style="width:100px;margin-left:20px;border:1px solid #444;padding:3px;">
						<?php } ?>
                    </div>
                    <div class="form-group">
                        <label>Right Description</label>
                        <textarea rows="3" cols="90" id="discription1" name="r_discription"><?php echo $r_discription; ?></textarea>
                    </div>
                    <div class="form-group">
						<label for="exampleInputPassword1">Status</label>
						<div class="radio block">
							<label>
								<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked" />Active
							</label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label>
								<input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive
							</label>
						</div>
						</div>
                    </div>
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
    
</div>
</div>
<script type="text/javascript" > 
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
    CKEDITOR.replace('discription1');
    function showTheUploadOption(val) {
		$('.optionContaner').hide();
		$('#option_to_show_' + val).show();
	}
   
</script>