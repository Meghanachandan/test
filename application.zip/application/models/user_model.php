<?php
	class User_model extends CI_Model {
 
	    function __construct()
	    {
	        parent::__construct();
	    }

	    public function getRecordById($id)
	    {

			$this->db->where('id', $id);
			$q = $this->db->get('users');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }

	    public function check_user($email = "", $password = null)
	    {
	    	$query 			= "SELECT * FROM users WHERE email = '".$email."' AND password = '".$password."' AND user_status = 'A'";		
			$users_query 	= $this->db->query($query);
			$row_users 		= $users_query->result_array();
			return array_shift($row_users);
	    }

	    public function check_email($email = "", $status = "")
	    {
	    	$query 			= "SELECT * FROM users WHERE email = '".$email."'";		
			$users_query 	= $this->db->query($query);
			$row_users 		= $users_query->result_array();
			if (!empty($row_users) && count($row_users) > 0) {
				if ($status) {
					return array_shift($row_users);
				} else {
					return true;
				}
				
			}
			return false;
	    }

	    public function check_exist_address($email = "", $first_name = "", $last_name = "", $address1 = "", $address2 = "", $city = "", $state = "", $zip_code = "", $country = "", $phone_number = "", $company = "")
	    {
	    	
	    	$companyName = "";
	    	if (!empty($company)) {
	    		$companyName = "AND company = '".$company."'";
	    	}

	    	$addressName = "";
	    	if (!empty($address2)) {
	    		$addressName = "AND address_second = '".$address2."'";
	    	}

	    	$query 	= "SELECT * FROM user_addresses WHERE email = '".$email."' AND  first_name = '".$first_name."' AND  last_name = '".$last_name."' AND  address_first = '".$address1."' AND  city = '".$city."' AND  state = '".$state."' AND  zip_code = '".$zip_code."' AND  country = '".$country."' AND phone_number = '".$phone_number."' ".$companyName." ".$addressName;		
			$users_query 	= $this->db->query($query);
			$row_users 		= $users_query->result_array();
			if (!empty($row_users) && count($row_users) > 0) {
				return true;
			}
			return false;
	    }

	    function user_mail($id, $case='', $i=0){
			$signup_user 	= $this->getRecordById($id);
			$users_name 	= '';
			if($signup_user['first_name'] != '') {
				$users_name 	.= $signup_user['first_name'];
			}

			if($signup_user['last_name'] != '') {

				if($signup_user['first_name'] != ''){
					$users_name .= " ";
				}
				$users_name		.= $signup_user['last_name'];
			}

			if($users_name==''){
				$users_name 	.= $signup_user['email'];
			}

			$data['users_name'] 	= $users_name;
			$data['users_email'] 	= $signup_user['email'];
			$data['users'] 			= $signup_user;
			$data['day'] 			= $i;
			$verification_link 		= base_url() . 'user/confirm_account/' . $signup_user['id'] . '/' . $signup_user['confirm_key'];
			$verification_link 		= '<a href="' . $verification_link . '" target="_blank">Click Here for Confirm Account</a>';
			$data['activate_link'] = $verification_link;
			$limit 			= 3;		

			$login_link 	= base_url('user/reset_password/' . $signup_user['forgot_unique_code']);
			$login_link 	= '<a href="' . $login_link . '" style="padding:7px 15px; background:#75a809; color:#ffffff;text-decoration:none; border-radius:5px; font:15px Calibri, Arial, Helvetica, sans-serif; text-transform:uppercase;"  target="_blank">Set a New Password</a>';
			$data['forget_login_link'] = $login_link;
			$invite_link 	= base_url('user/login');						
			$data['invite_link_a'] = $invite_link_a = '<a href="'.$invite_link.'" target="_blank">Click Here</a>';
			return $string 	= $this->load->view('email_templates/'.$case, $data, true);	
		}

		/*
		Function name :checkForgetUniqueCode()
		Parameter :forgot_unique_code
		Return : return expire or not_sent or user_id
		Use : Check the unique forget code is exist or not.
		*/
		function checkForgetUniqueCode($forgot_unique_code=null)
		{
			$query 			= "SELECT * FROM users WHERE forgot_unique_code = '".$forgot_unique_code."'";		
			$users_query 	= $this->db->query($query);
			$row 			= array_shift($users_query->result_array());
			
			//$query = $this->db->get_where('users',array('forgot_unique_code'=>$forgot_unique_code));
			if($row)
			{
				if(strtotime(date("Y-m-d H:i:s")) <= strtotime(date("Y-m-d H:i:s",strtotime($row['request_date'] . ' + '.FORGOT_TIME_LIMIT.' hours'))))
				{
					return $row['id'];
				}
				else
				{	
					return 'expire';
				}
			}
			else
			{
				return 'not_sent';
			}
		}

	
		function getTotalNews($id){
			$sql = "SELECT COUNT(*) AS cnt FROM `latest_news` WHERE `reporter` = '".$id."'";
			$query = $this->db->query($sql);
			//$result = $query->getArray();
			//return $result['cnt'];
			$row_users = $query->result_array();
				return $row_users[0]['cnt'];
		}
	
		function getTotalVister($id){
			$sql = "SELECT COUNT(*) AS cnt FROM `populer_news` WHERE news_id IN (SELECT id FROM `latest_news` WHERE `reporter` = '".$id."'); ";
			$query = $this->db->query($sql);
			//$result = $query->getArray();
			//return $result['cnt'];
			$row_users = $query->result_array();
				return $row_users[0]['cnt'];
		}
	
		function getcategoryNewsCount($id){
			$sql = "SELECT let.categorise as cat,nc.`title`,COUNT(let.`categorise`) AS cnt FROM `latest_news` AS let LEFT JOIN `news_categories` AS nc ON nc.id =let.`categorise` WHERE let.`categorise` > 0 AND  let.`reporter` = '".$id."' AND nc.`title`!='' GROUP BY let.categorise";
			$query = $this->db->query($sql);
			//$result = $query->getArray();
			//return $result['cnt'];
			$row_users = $query->result_array();
				return $row_users;
		}
	
		function get_all_pending_news($id)
		{
			$sql = "SELECT * FROM `latest_news` WHERE `reporter` = '".$id."' ORDER BY `created_date` DESC LIMIT 10";
			$query = $this->db->query($sql);
			$row_users = $query->result_array();
			return $row_users;
		}

		function validate_email($email)
		{
			$this->db->where('email', $email);
			$query = $this->db->get('users');
			return $query->num_rows;
		}

		

		public function check_email_social_account($id , $type)
	    {
			if($type=='google'){
				$query 			= "SELECT * FROM users WHERE google_id = '".$id."'";		
			}
			
			if($type=='facebook'){
				$query 			= "SELECT * FROM users WHERE facebook_id = '".$id."'";		
			}
			
			$users_query 	= $this->db->query($query);
			$row_users 		= $users_query->result_array();
			if (!empty($row_users) && count($row_users) > 0) {
				return array_shift($row_users);
			}
			return false;
	    }
	    
	    function getTotalNotice(){
			$sql = "SELECT COUNT(*) AS cnt FROM `notice`";
			$query = $this->db->query($sql);
			//$result = $query->getArray();
			//return $result['cnt'];
			$row_users = $query->result_array();
				return $row_users[0]['cnt'];
		}
		
	}
?>