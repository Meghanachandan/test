<?php
if (!empty($postData)) {
    $name = $postData['title'];
    $discription = $postData['discription'];
    $link = $postData['link'];
    $status = $postData['status'];
    $image = $postData['image'];
    $faq_type = $postData['faq_type'];
    $order = $postData['order'];
}
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/faq'); ?>">City</a></li>
            <li class="active">ADD City</li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">ADD New City</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <form action="<?php echo base_url('admin/location/city_add'); ?>" enctype="multipart/form-data" method="post">
                    <input type="hidden" value=""/>
                    
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select Country<span class="star-color">*</span></label>
                        
                        <select class="form-control" name="country_id" onchange="getcountrystate(this.value);" required>
                            <option value="">Select Country</option>
                        <?php

                    $this->db->select('*');
                    $this->db->from('countries');
                    
                    $query= $this->db->get();
                    
                            $data = $query->result_array();
                    
                    foreach ($data as $key => $value) {
                       ?>
                    <option value="<?= $value['id']; ?>"><?= $value['name']; ?></option>
                    <!---->
                       <?php
                    }
        ?>
    </select>
                    </div>
                    
                    
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select State<span class="star-color">*</span></label>
                        
                        <select class="form-control" id="state" name="state_id"   required>
                            <option value="">Select State</option>
                        <?php

                // $this->db->select('*');
                // $this->db->from('states');
                // $query= $this->db->get();
                
                //         $data = $query->result_array();
                
                // foreach ($data as $key => $value) {
                   ?>
                <!--<option value="<?= $value['id']; ?>"><?= $value['name']; ?></option>-->
                
                   <?php
                // }
        ?>
    </select>
                    </div>
                    
                    
                    
                    
                    <div class="form-group">
                        <label for="exampleInputEmail1">City<span class="star-color">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>" required>
                    </div>
                      
                
                      
                
                   

                    

                  
                 
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script type="text/javascript" > 
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
    
    
    function getcountrystate(id, onload = '', set = '', city = '') {
		var postData = {
			country_id: id
		};
		$.ajax({
			url: "<?php echo base_url(); ?>home/getCountrySate1",
			data: postData,
			dataType: 'json',
			type: 'POST',
			success: function(result) {
				$('#state').html('');
				var output = [];
				output.push('<option value="">Select State</option>');
				$.each(result, function(key, value) {
					output.push('<option value="' + value.id + '">' + value.name + '</option>');
				});

				if (output.length > 0) {
					$('#state').html(output.join(''));
				} else {
					$('#state').html('<option value="">No state found</option>');
				}
				if (onload == 'load') {

					if (set != '') {
						$('#state').val(set);
					}

					if (city != '') {
						setTimeout(function() {
							setStateCity(set, 'load', city);
						}, 1000);
					}
				}
				$('#state').trigger('change');


			}
		});
	}
   
</script>