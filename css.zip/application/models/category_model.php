<?php
	class Category_model extends CI_Model {
 
	    function __construct()
	    {
	        parent::__construct();
	    }

	    public function activeRecordCount() {
	    	$this->db->where('status', '1');
	        $count = $this->db->count_all("product_category");
	        return $count;
	    }

	    public function getActiveRecords()
	    {
           	$this->db->order_by("created_date", "asc");
	        $this->db->where('status', '1');
			$query = $this->db->get('product_category');

	        if ($query->num_rows() > 0) {
	            foreach ($query->result() as $row) {
	                $data[] = $row;
	            }
	            return $data;
	        }
	        return false;
	    }

	    public function getRecordById($id)
	    {
			$this->db->where('id', $id);
			$q = $this->db->get('product_category');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }

	    public function getRecordBySlug($slug)
	    {
			$this->db->where('slug', $slug);
			$q = $this->db->get('product_category');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }
	}
?>