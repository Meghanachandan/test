<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class notice extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/notice_model');
        $this->load->library('image_lib');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }
    
    public function index()
    {
        $data['notice'] = $this->notice_model->getNoticeRecords();
        adminLoadView('notice/notice_list', $data);
    }
    
    public function add_notice()
    {

        $postData = array();
        //
        if ($_POST) {
            
            $data['postData'] = $postData = $_POST;
            $data['error'] = "";
            //$url = $_POST['link'];

            // if(!filter_var($url, FILTER_VALIDATE_URL)) {
            // $data['error']='Enter Valid Link of Menu';
            // }else{

            $formValidation = $this->notice_model->formValidations();
            //var_dump($formValidation);
            
            

// echo 'helo';
//         die;
            //}
            // if ($formValidation && empty($data['error'])) {
                    
             
                //$newsdate =  date('Y-m-d h:i:s', strtotime($postData['date'] . ' ' . $postData['hour'] . ':' . $postData['minit'] . ':00'));
                $newsdate =  date('Y-m-d');
               

                $insertData = array(
                    'title'                 => $postData['title'],
                    'description'           => $postData['discription'],
                    'create_date'                  => $newsdate
                    
                    
                );
                if($_FILES["image"]["name"]!="" && in_array(pathinfo($_FILES["image"]["name"],PATHINFO_EXTENSION), array("jpg", "jpeg", "png", "wevp", "pdf"))){
                    $img_name = substr($_FILES["image"]["name"], 0, -6).date("YmdHis").mt_rand(10000,99999).".".pathinfo($_FILES["image"]["name"],PATHINFO_EXTENSION);
                    $imgfile = "upload/notice/thumb/".$img_name;
                    if(move_uploaded_file($_FILES["image"]["tmp_name"],$imgfile)){
                        $insertData['image'] = $img_name;
                    }
                }
                
                // if (!empty($_FILES['image'])) {
                //     $insertData['image'] = $file_name;
                // } else {
                //     $insertData['image'] = '';
                // }
                
                

                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }

                

                $return = addUpdateRecord('notice', '', '', $insertData);


                
                if ($return) {
                    $this->session->set_flashdata('success', 'News added successfully.');
                    redirect('admin/notice');
                }
            // } else {

            //     if (validation_errors()) {
            //         if (validation_errors()) {
            //             $data['error'] = validation_errors();
            //         }
            //     }
            // }
        }
        

        adminLoadView('notice/add_notice');
    }
    
    public function edit($id = null, $user_id = 0)
    {


        if (empty($id)) {
            redirect('admin/notice');
        }

        if ($_POST) {
            
            $postData = $_POST;
            $data['error'] = "";
            
            // $formValidation = $this->notice_model->formValidations($id);
            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            

          $myimg_fimename = $postData['oldimage'];
            


        



            // if ($formValidation &&  empty($data['error'])) {


                
              
             

                // $newsdate =  date('Y-m-d h:i:s', strtotime($postData['date'] . ' ' . $postData['hour'] . ':' . $postData['minit'] . ':00'));
                $updateData['title'] = $postData['title'];
                $updateData['description'] = $postData['discription'];
                $updateData['status'] = $postData['status'];
                
                
                
               
                if($_FILES["image"]["name"]!="" && in_array(pathinfo($_FILES["image"]["name"],PATHINFO_EXTENSION), array("jpg", "jpeg", "png", "wevp", "pdf"))){
                    $img_name = substr($_FILES["image"]["name"], 0, -6).date("YmdHis").mt_rand(10000,99999).".".pathinfo($_FILES["image"]["name"],PATHINFO_EXTENSION);
                    $imgfile = "upload/notice/thumb/".$img_name;
                    if(move_uploaded_file($_FILES["image"]["tmp_name"],$imgfile)){
                        $updateData["image"] = $img_name;
                    }
                    
                }else{
                    $updateData['image'] = $myimg_fimename;
                }


                $return = addUpdateRecord('notice', 'id', $id, $updateData);

                   

                if ($return) {
                    $this->session->set_flashdata('success', 'News updated successfully.');
                    redirect('admin/notice');
                }
            // } else {
            //     if (validation_errors()) {
            //         if (validation_errors()) {
            //             $data['error'] = validation_errors();
            //         }
            //     }
            // }
            $data['postData'] = $postData;
        } else {
           
            $postData = $this->notice_model->getNoticeRecords11($id);
            // echo $this->db->last_query();
            //echo $this->$db->last_query();
            //  echo "<pre>";print_r($postData);die;
          //  $postData['highlights'] = explode('#$#', $postData['highlights']);
            $data['postData'] = $postData;
        }


        //$allcategory = $this->dashboard_model->getNoticeRecords11();
        

        //pr($allcountry);
        $data['user_id'] = $user_id;
        //$data['allcategory'] = $allcategory;
        

        adminLoadView('notice/edit', $data);
    }
    
    public function delete($id = null)
    {

        if (empty($id)) {
            redirect('admin/notice');
        }

        $deleteData = $this->notice_model->getRecordById($id);
        $delete = deleteRecordById('notice', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'News deleted successfully.');
            redirect('admin/notice');
        }
    }
    
}
?>