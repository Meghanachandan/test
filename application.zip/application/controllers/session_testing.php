<?php
echo "<pre>";
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//error_reporting(E_ALL);
class Session_testing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    
    
    function index(){
        $udata = array(
            'tuser_id'   => "456",
            'tuser_name' => "twinkle",
            'tlast_name' => "khanna",
            'temail'     => "email",
        );
        
        
        $this->session->sess_destroy();
        
        $this->session->set_userdata($udata);
        var_dump($this->session->userdata("tuser_id"));
		echo session_save_path();
    }
}