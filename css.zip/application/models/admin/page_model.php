<?php
	class Page_model extends CI_Model {
 
	    function __construct()
	    {
	        parent::__construct();
	    }

	    public function getRecords()
	    {
	    	$this->db->order_by("id","desc");
            $query  = $this->db->get('pages');
            $ret    = $query->result_array();
            return $ret;
	    }

	    public function getRecordById($id)
	    {
			$this->db->where('id', $id);
			$q = $this->db->get('pages');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }

	    public function formValidations()
	    {
			
           	$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('link', 'Link', 'required');
            $this->form_validation->set_rules('discription', 'Description', 'required');

            if ($this->form_validation->run() == FALSE) {
				return false; 
		    } else {
		       return TRUE; 
		    }
	    }

	    
	}
?>