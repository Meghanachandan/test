<?php
if ($getCatInfo) {
?>
    <section class="tabs4 cid-rUEF7euy93" id="tabs4-r">
        <div class="container">
            <h1>News In <?php echo $getCatInfo['title']; ?></h1>
        </div>
    </section>
<?php
}

?>

<section class="tabs4 cid-rUEF7euy93" id="tabs4-r">
    <div class="container">
        <div class="col-md-9">

            <?php

            $news_count = 0;
            foreach ($filter_data as $news) {
                if ($news_count < 5) {
            ?>

                    <div class="media-container-row mt-5 pt-3">
                        <div class="mbr-figure" style="width: 60%;">
                            <!-- <img src="<?php echo base_url(); ?>assets/images/background6.jpg" style="max-height:320px;" alt="FifthNews.com"> -->
                            <img src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>" style="height:320px;" alt="<?php echo $news['title'] ?>">
                            <div class="date_box" style="font-size: 14px;margin-top: -25px;">
                                <?php echo $news['date'] ?> - &nbsp;&nbsp;&nbsp;
                                <span><i class="fas fa-pencil-alt"></i></span> Nilima Pathak
                            </div>
                        </div>
                        <div class="tabs-container">
                            <div class="tab-content">
                                <!-- <div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="mbr-text py-5 mbr-fonts-style display-7">
                                        Sites made with FifthNews.com are 100% mobile-friendly according the latest Google Test and Google loves those websites (officially)!
                                    </p>
                                </div>
                            </div>
                        </div> -->
                                <div class="card-box">
                                    <h4>
                                        <?php echo $news['title'] ?>
                                    </h4>
                                    <p class="mbr-text mbr-fonts-style display-7">
                                        <?php echo strip_tags($news['discription']) ?>
                                    </p>
                                </div>

                                <a href="<?php echo base_url() . 'home/news_view/' . $news['id']; ?>" class="btn btn-secondary btn-form display-4">
                                    Read More
                                </a>
                            </div>
                        </div>
                    </div>

                <?php
                } else {
                ?>

                    <a href="<?php echo base_url() . 'home/news_view/' . $news['id']; ?>" style="color: #000;">
                        <div class="media-container-row mt-5 pt-3">
                            <div class="mbr-figure" style="width: 130px;">
                                <!-- <img src="<?php echo base_url(); ?>assets/images/background6.jpg" style="max-height:320px;" alt="FifthNews.com"> -->
                                <img src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>" style="height:100px;width: 100px;" alt="<?php echo $news['title'] ?>">
                            </div>
                            <div class="tabs-container" style="width: 80%;">
                                <div class="tab-content">
                                    <h4>
                                        <?php echo $news['title'] ?>
                                    </h4>
                                    <p class="mbr-text mbr-fonts-style display-7">
                                        <?php echo strip_tags($news['discription']) ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>

            <?php
                }
                $news_count++;
            }

            ?>
        </div>
        <div class="col-md-3">
            <div class="col-md-12">
                <h1 class="classForHeadercategory">
                    Latest News
                </h1>
            </div>
            <div class="col-md-12">
                <?php
                if ($latest_news) {
                    foreach ($latest_news as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'ln';
                        $this->load->view('home/home_news_block', $news_data);
                    }
                }
                ?>
            </div>
            <div class="col-md-12">
                <h1 class="classForHeadercategory">
                    papular story
                </h1>
            </div>
            <div class="col-md-12">
                <?php
                if ($populer_news) {
                    foreach ($populer_news as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'pn';
                        $this->load->view('home/home_news_block', $news_data);
                    }
                }
                ?>
            </div>
        </div>
    </div>
</section>

<?php

//if ($news_count > 23) {
if ($news_count > 2) {
?>
    <section class="tabs4 cid-rUEF7euy93" id="tabs4-r">
        <div class="container">
            <div class="media-container-row mt-5 pt-3">
                <a onclick="gotoViewAllPage();" class="btn btn-secondary btn-form display-4">
                    View All News
                </a>
            </div>
        </div>
    </section>
<?php
}
?>


<?php if ($recientView) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    Recent View
                </h1>
            </div>
            <div class="media-container-row">
                <?php

                foreach ($recientView as $news) {
                    $news_data['news'] = $news;
                    $news_data['list'] = 're';
                    $this->load->view('home/home_news_block', $news_data);
                }

                ?>
            </div>
        </div>
    </section>
<?php } ?>

<script>
    function gotoViewAllPage() {
        method = "post";

        var form = document.createElement("form");
        form.setAttribute("method", method);
        form.setAttribute("action", "<?php echo base_url() . 'home/news_all_view/' . $cat_id; ?>");

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "country");
        hiddenField.setAttribute("value", '<?php echo $country; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "state");
        hiddenField.setAttribute("value", '<?php echo $state; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "city");
        hiddenField.setAttribute("value", '<?php echo $city; ?>');
        form.appendChild(hiddenField);


        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "key");
        hiddenField.setAttribute("value", '<?php echo $key; ?>');
        form.appendChild(hiddenField);

        document.body.appendChild(form);
        form.submit();
    }

    //href=""
</script>