<?php
class News_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	public function activeRecordCount($searchtext = null)
	{

		/*	$search = "";
	    	if (!empty($searchtext)) {
	    		$search = "AND title LIKE '%".$searchtext."%' OR discription LIKE '%".$searchtext."%'";
	    	}

	        $query = "SELECT * FROM latest_news WHERE status = '1' ".$search;	
			$count = $this->db->query($query);

	        return $count->num_rows();*/

		$this->db->limit($limit, $start);
		if (!empty($searchtext)) {
			$this->db->like('title', $searchtext);
			$this->db->or_like('discription', $searchtext);
		}

		$this->db->where('status', '1');
		$count = $this->db->get('latest_news');
		return $count->num_rows();
	}

	public function getActiveRecords($limit, $start, $searchtext = null)
	{
		$this->db->limit($limit, $start);

		if (!empty($searchtext)) {
			$this->db->like('title', $searchtext);
			$this->db->or_like('discription', $searchtext);
		}

		$this->db->where('status', '1');
		$query = $this->db->get('latest_news');

		if ($query->num_rows() > 0) {

			foreach ($query->result() as $row) {
				$data[] = $row;
			}
			return $data;
		}
		return false;
	}

	public function getRecordById($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getRecordBySlug($slug)
	{
		$this->db->where('slug', $slug);
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getLatestPost()
	{
		$this->db->order_by("id", "asc");
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getNewsOwner($id,$user_id)
	{
		$this->db->where('id', $id);
		$this->db->where('reporter', $user_id);
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = $q->result_array();
		return $data[0];
	}

	public function getImage($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data['image'];
	}

	public function formValidations($id = null)
	{
		/*$url = $_POST['link'];
			if (!filter_var($url, FILTER_VALIDATE_URL) == false) {
			return true; 
			} else {
			$this->form_validation->set_rules('link', 'Link', 'required');	
			?>
            <script>
			alert('Enter valid Link of News');
			</script>
            <?php
			
			return false; 
			}*/
		//$this->form_validation->set_rules('link', 'Link', 'required');

		$this->form_validation->set_rules('title', 'Title', 'required');
		//$this->form_validation->set_rules('discription', 'discription', 'required');
		$this->form_validation->set_rules('country', 'country', 'required');
		
		/*
		$editImage = $this->getImage($id);
		if (empty($editImage)) {
			if (empty($_FILES['image']['name'])) {
				$this->form_validation->set_rules('image', 'Image', 'required');
			}
		}*/

		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}

	public function getCategoriesRecords()
	{
		$this->db->order_by("id", "desc");
		$this->db->where("categorie_type", '0');
		$query = $this->db->get('news_categories');
		$ret = $query->result_array();
		return $ret;
	}

	public function getRecords($user_id,$cat_id =0)
	{
		$this->db->where('reporter', $user_id);
		if($cat_id>0){
			$this->db->where('categorise', $cat_id);
		}
		$this->db->order_by("id", "desc");
		$query = $this->db->get('latest_news');
		$ret = $query->result_array();
		return $ret;
	}

	public function getTermsRecords($id)
	{
		$this->db->where('id', '2');
		$query = $this->db->get('terms');
		$ret = $query->result_array();
		return $ret;
	}

    
    public function getAllCountrystateByName($country_id)
	{
		
    $countrysql = "SELECT `id`,`name` FROM `countries` WHERE `name` = '" . $country_id . "' ;";
    $countryquery = $this->db->query($countrysql);
    $countryresult = $countryquery->result_array();

    $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
    $query = $CI->db->query($sql, array($countryresult[0]['id']));
    // $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
	}
	
	public function getAllCountrystateByName1($country_id)
	{
		
    $countrysql = "SELECT `id`,`name` FROM `countries` WHERE `id` = '" . $country_id . "' ;";
    $countryquery = $this->db->query($countrysql);
    $countryresult = $countryquery->result_array();

    $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
    $query = $CI->db->query($sql, array($countryresult[0]['id']));
    // $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
	}
	
	
    
}
