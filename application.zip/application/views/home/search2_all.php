<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Ideabox main theme css file. you have to add all pages -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/search/main-style.css">

<!-- Ideabox responsive css file -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/search/responsive-style.css">

<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css"/> -->
<script type="text/javascript" src="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.js"></script>

<!--Main container start -->
<main class="container">
    <section class="main-content">
        <div class="main-content-wrapper">
            <div class="content-body">
                <div class="content-timeline">
                    <!--Timeline header area start -->
                    <div class="post-list-header">
                        <span class="post-list-title">
                            <?php
                            if ($getCatInfo['title']) {
                                echo $getCatInfo['title'];
                            } else {
                                echo 'News';
                            }
                            ?>
                        </span>
                    </div>
                    <div class="loder_contaner">
                        <div class="loader">Loading...</div>
                    </div>
                    <!--Timeline header area end -->
                    <?php if ($filter_data) { ?>
                        <!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" /> -->
                        <!--Timeline items start -->
                        <div style="display: none" class="timeline-items">
                            <table id="example" class="display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Office</th>
                                        <th>Age</th>
                                        <th>Start date</th>
                                        <th>Salary</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    foreach ($filter_data as $news) {
                                    ?>
                                        <tr>
                                            <td>
                                                <div class="timeline-item">
                                                    <div class="timeline-right">
                                                        <div class="timeline-post-image">
                                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="color: #000;">
                                                                <?php
                                                                if (trim($news['image']) == '') {
                                                                    $news['image'] = 'no-image.png';
                                                                } else {
                                                                    $news['image'] = 'thumb/' . $news['image'];
                                                                }
                                                                ?>
                                                                <img src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>">
                                                            </a>
                                                        </div>
                                                        <div class="timeline-post-content">
                                                        <?php
                                                $full_description = '';
                                                $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                                $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                                $full_description_text = limit_text($news['discription'], 400);
                                                $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                                ?>
                                                            <!-- <a href="#" class="timeline-category-name">Technology</a> -->
                                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="color: #000;" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                                <h3 class="timeline-post-title"><span class="new_slug" style="color: #004d38;">
                                                                        <?php echo limit_text($news['title'], 30); ?> / </span>
                                                                    <?php echo limit_text(strip_tags($news['discription']), 100); ?>
                                                                </h3>
                                                            </a>
                                                            <div style="float: right;position: absolute;right: 0;top: 0;width: 40px;height: 40px;z-index: 9999;" onmouseover="showSocialButtonBox('social_box_cate_<?php echo $news['id']; ?>');" onmouseout="hideSocialButtonBox()">
                                                                <span class="share_box">
                                                                    ...
                                                                </span>

                                                                <div class="social_share_button" id="social_box_cate<?php echo '_' . $news['id'] ?>">

                                                                    <!-- Sharingbutton Facebook -->
                                                                    <a class="resp-sharing-button__link" href="http://facebook.com/sharer/sharer.php?u=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" aria-label="">
                                                                        <div class="resp-sharing-button resp-sharing-button--facebook resp-sharing-button--small">
                                                                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                                                    <path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z" />
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                    <!-- Sharingbutton Twitter -->
                                                                    <a class="resp-sharing-button__link" href="http://twitter.com/intent/tweet/?text=<?php echo urlencode($news['short_discription']); ?>&amp;url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" aria-label="">
                                                                        <div class="resp-sharing-button resp-sharing-button--twitter resp-sharing-button--small">
                                                                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                                                    <path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z" />
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                    <!-- Sharingbutton WhatsApp -->
                                                                    <a class="resp-sharing-button__link" href="whatsapp://send?text=<?php echo urlencode($news['short_discription'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" rel="noopener" aria-label="">
                                                                        <div class="resp-sharing-button resp-sharing-button--whatsapp resp-sharing-button--small">
                                                                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                                                                    <path d="M20.1 3.9C17.9 1.7 15 .5 12 .5 5.8.5.7 5.6.7 11.9c0 2 .5 3.9 1.5 5.6L.6 23.4l6-1.6c1.6.9 3.5 1.3 5.4 1.3 6.3 0 11.4-5.1 11.4-11.4-.1-2.8-1.2-5.7-3.3-7.8zM12 21.4c-1.7 0-3.3-.5-4.8-1.3l-.4-.2-3.5 1 1-3.4L4 17c-1-1.5-1.4-3.2-1.4-5.1 0-5.2 4.2-9.4 9.4-9.4 2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7-.1 5.2-4.3 9.4-9.5 9.4zm5.1-7.1c-.3-.1-1.7-.9-1.9-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1s-1.2-.5-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6s.3-.3.4-.5c.2-.1.3-.3.4-.5.1-.2 0-.4 0-.5C10 9 9.3 7.6 9 7c-.1-.4-.4-.3-.5-.3h-.6s-.4.1-.7.3c-.3.3-1 1-1 2.4s1 2.8 1.1 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.3.2-.7.2-1.2.2-1.3-.1-.3-.3-.4-.6-.5z" />
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <div class="timeline-post-info">
                                                                <a href="#" class="author">
                                                                    <?php echo getReporterName($news['reporter']); ?>
                                                                </a>
                                                                <span class="dot"></span>
                                                                <span class="comment">
                                                                <?php echo date('D/M d, Y, h:i A', strtotime($news['date'])) . ' - ' . date('T'); ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo limit_text($news['title'], 30); ?></td>
                                            <td><?php echo limit_text(strip_tags($news['discription']), 100); ?></td>
                                            <td><?php echo getReporterName($news['reporter']); ?></td>
                                            <td><?php echo date('D, d M Y', strtotime($news['date'])); ?></td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!--Timeline items end -->
                    <?php } else { ?>
                        <div class="load-more " style="min-height: 700px">
                            <h5>Sorry, No Result found</h5>
                            <a href="<?php echo base_url(); ?>">
                                <button class="load-more-button material-button" type="button">
                                    Back
                                </button>
                            </a>
                        </div>
                    <?php } ?>
                </div>

            </div>
            <div class="content-sidebar">
                <div class="sidebar_inner">

                    <?php
                    $side_bar_conter = 0;
                    if ($populer_news) {
                        // unset($populer_news[0]);
                    ?>

                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Top News</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($populer_news as $news) {
                                    ?>
                                        <li>
                                        <?php
                                                $full_description = '';
                                                $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                                $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                                $full_description_text = limit_text($news['discription'], 400);
                                                $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                                ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?> </h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                    <?php
                    if ($latest_news) {
                    ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Latest News</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($latest_news as $news) {
                                    ?>
                                        <li>
                                        <?php
                                                $full_description = '';
                                                $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                                $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                                $full_description_text = limit_text($news['discription'], 400);
                                                $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                                ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                    <?php if ($recientView) { ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Recent View</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($recientView as $news) {
                                    ?>
                                        <li>
                                        <?php
                                                $full_description = '';
                                                $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                                $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                                $full_description_text = limit_text($news['discription'], 400);
                                                $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                                ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>




                    <div class="seperator"></div>


                </div>
            </div>
            <div style="clear: both;"></div>
        </div>
    </section>

</main>

<script>
    function gotoViewAllPage() {
        method = "post";

        var form = document.createElement("form");
        form.setAttribute("method", method);
        form.setAttribute("action", "<?php echo base_url() . 'home/news_all_view/' . $cat_id; ?>");

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "country");
        hiddenField.setAttribute("value", '<?php echo $country; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "state");
        hiddenField.setAttribute("value", '<?php echo $state; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "city");
        hiddenField.setAttribute("value", '<?php echo $city; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "key");
        hiddenField.setAttribute("value", '<?php echo $key; ?>');
        form.appendChild(hiddenField);

        document.body.appendChild(form);
        form.submit();
    }
</script>
<!-- <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script> -->
<script>
    $(document).ready(function() {
        $('#example').DataTable({
            "columnDefs": [{
                    "targets": [1],
                    "visible": false,
                },
                {
                    "targets": [2],
                    "visible": false
                },
                {
                    "targets": [3],
                    "visible": false
                },
                {
                    "targets": [4],
                    "visible": false
                }

            ],
            language: {
                search: "",
                sLengthMenu: "Show _MENU_",
                searchPlaceholder: "Search"
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ]
        });
    });
    $(document).ready(function() {
        $('.loder_contaner').hide();
        $('.timeline-items').show();
        var hieght = 95 * <?php echo $side_bar_conter; ?>;
        hieght = hieght + 100;
        $('.main-content-wrapper').css('min-height', hieght);
    });
</script>