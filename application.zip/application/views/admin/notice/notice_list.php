<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
 
<div class="outter-wp">
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li class="active">NOTICE </li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h3 class="inner-tittle two">List Notice</h3>
        <?php
        if ($this->session->flashdata('success')) {
            ?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php }
        ?>
        <div class="graph">
            <div class="tables">
                <table class="display responsive" id="example-table">
                    <thead> 
                        <tr> 
                            <th>Id</th> 
                            <th width="250px">Title</th>
                            <th width="250px">Image/PDF</th>
                            <th width="250px">Discription</th>
                            <th>Created</th> 
                            <th>Status</th> 
                            <th>Action</th>  
                        </tr> 
                    </thead>
                    <?php
                    $i = 0;
                    foreach ($notice as $key => $blog) {
                        $status = (!empty($blog['status']) && $blog['status'] == '1') ? 'Active' : 'Deactive';
                        $i++;
                        ?>
                        <tr> 
                            <th><?php echo $i; ?></th> 
                            <th><?php echo $blog['title']; ?></th>
                            <th><?php
										$sdfgh=$blog['image'];
										$explode=explode('.',$sdfgh);
										if($explode[1] == 'pdf'){
										?>
										    <a target="_blank" href='<?php echo base_url('upload/notice/thumb/' . $blog['image']); ?>'>View PDF</a>
										    <?php }else{ ?>
										    <a data-toggle="modal" data-target="#myModal1<?php echo $blog['id']; ?>" ><?php echo "<img src='" . base_url('upload/notice/thumb/' . $blog['image']) . "' height='80px' width='90px'/>"; ?></a>
										    <?php } ?></th>
                            <th><a class="btn btn-info" style="padding: 5px;" data-toggle="modal" data-target="#myModal<?php echo $blog['id']; ?>">Notice</a></th>
                            <!--<th><?php echo "<img src='" . base_url('upload/news_categorie/' . $blog['image']) . "' height='80px' width='90px'/>"; ?></th> -->
                            <th><?php echo $blog['create_date']; ?></th> 
                            <th><?php echo $status; ?></th> 
                            <th>
                                <a href='<?php echo base_url('admin/notice/edit/' . $blog['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp; 
                                <a onclick='return confirm("Are you sure? you want to delete this news categorie!")' href='<?php echo base_url('admin/notice/delete/' . $blog['id']); ?>'><i class="fa fa-trash-o"></i></a>
                            </th>
                        </tr>
                        <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $blog['id']; ?>" style="height: auto;" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Notice - <?php echo $blog['title']; ?></h4>
        </div>
        <div class="modal-body">
          <?php echo $blog['description']; ?>
        </div>
        <div class="modal-footer" style="padding: 0px;">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <div class="modal fade" id="myModal1<?php echo $blog['id']; ?>" style="height: auto;" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body">
          <?php echo "<img src='" . base_url('upload/notice/thumb/' . $blog['image']) . "' height='auto' width='100%'/>"; ?>
        </div>
        <div class="modal-footer" style="padding: 0px;">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
                    <?php } ?>
                </table>
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script>
function toggleCheckbox(id,status)
 {

 $.ajax({
            type: "POST",
            url: "http://newssyn.com/admin/pages/topstatus",
            data: { id : id,status: status} 
        }).done(function(data){
            alert("Success");
            // alert(data);
            // alert(data);
           //$(".ccategory").html(data);
        });
 }
</script>
<script>
    $(document).ready(function () {
        $('#example-table').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ]

        });
    });
</script>