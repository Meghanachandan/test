<?php
	if (!empty($postData)) {
		$name 		= $postData['title'];
		$menu_type  = $postData['menu_type'];
		$link 		= $postData['link'];
		$status 	= $postData['status'];
		$parent_id 	= $postData['parent_id'];
	}
	//print_r($postData);exit;
?>
<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li><a href="<?php echo base_url('admin/menus'); ?>">MENUS</a></li>
			<li class="active">Edit MENU</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">Edit MENU</h2>
		<div class="graph-form">
			<?php
				if(!empty($error)){ 
				?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
			} ?>
			<div class="form-body">
				<?php 
				$editId = "";
				if(!empty($postData['id'])) {
					$editId = $postData['id'];
				} 
				?>

				<form action="<?php echo base_url('admin/menus/edit/'.$editId); ?>" method="post">
					<input type="hidden" value=""/>
					<div class="form-group">
						<label for="exampleInputEmail1">Name <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" >
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Link</label> 
						<input type="text" class="form-control" id="link"  name="link"  value="<?php echo $link; ?>" >
					</div>
					<?php if($menu_type=='mainmenu'){
							$mainmenu='selected="selcted"';
						}

						if($menu_type=='submenu'){
							$submenu='selected="selcted"';
						}

						if($menu_type=='footermenu'){
							$footermenu='selected="selcted"';
						} ?>
					<div class="form-group">
						<label for="exampleInputPassword1">Menu Type <span class="star-color">*</span></label> 
						<select name="menu_type" class="form-control" onchange="displayparent(this.value);">
						<option value="">Select</option>
						<option value="mainmenu" <?php echo $mainmenu;?>>Main Menu</option>
						<option value="submenu" <?php echo $submenu;?>>Sub Menu</option>
						<option value="footermenu" <?php echo $footermenu;?>>Footer Menu</option>
						</select>
					</div>
					<?php


					 $style =($menu_type == 'submenu') ? 'block' : 'none';

					 	?>
						<?php if (!empty($menusType)) { ?> 
							<div class="form-group" id="parentmenulist" style="display:<?php echo $style; ?>">
								<label for="exampleInputPassword1">Parent</label> 
							<select name="parent_id" class="form-control" >

							<?php

							echo '<option value="0">select</option>'; 

							 foreach($menusType as $type){
									$rest='';
									if($type['id']==$parent_id){
										$rest='selected="selected"';
									}
								  	echo '<option value="'.$type['id'].'" '.$rest.'>'.$type['title'].'</option>'; 
									
									}?>
							</select>
							</div>
						<?php } ?>
					
					
					<div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Status</label>
						<div class="radio block"><label>
						<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" />Active</label></div>
						<div class="radio block">
						<label><input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive</label></div>
					</div>
					<button type="submit" class="btn btn-default" name="submit" value="submit">Update</button> 
				</form> 
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script>
function displayparent(value)
{
	
	if(value=="submenu"){
		
		$("#parentmenulist").show();
		
	}else
	{
		$("#parentmenulist").hide();
	}
}
</script>