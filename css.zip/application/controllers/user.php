<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//error_reporting(E_ALL);
class User extends CI_Controller
{

    var $ldata;
    var $sdata;
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->model('user_model');
        $this->load->helper('url');
        $this->load->library('email');
    }

    public function welcome()
    {
        $this->load->view('user/welcome');
    }

    public function index()
    {

        if (check_user_authentication() == true) {
            $_SESSION["abc"] = "abc";
            //$_SESSION['login']="login";
            redirect('home');
        }
        $data['notShowCategory'] = '1';
        defaultLoadView('user/index', $data);
    }

    public function login()
    {
        if (check_user_authentication() == true) {
            $_SESSION["abc"] = "abc";
            //$_SESSION['login']="login";
            redirect('home');
        }

        $page = "";
        if ($this->input->get('page')) {
            $page = $this->input->get('page');
        }


        $data = array();
        $data['page'] = $page;
        if ($_POST) {

            $this->load->library('form_validation');
            $data['username'] = $this->input->post('loginEmail');
            $this->form_validation->set_rules('loginEmail', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('loginPassword', 'Password', 'required');
            $returndata = array();
            $returndata['url'] = '';
            $returndata["error"] = "";
            $returndata["success"] = "";
            if ($this->form_validation->run() == FALSE) {
                if (validation_errors()) {
                    $returndata["error"] = validation_errors();
                }
            } else {
                $email      = $this->input->post('loginEmail');
                $password   = $this->input->post('loginPassword');
                $newsl      = $this->input->post('loginNewl');

                $logindata = array(
                    'email'     => $email,
                    'password'  => $password
                );
                $login = $this->user_model->check_user($email, $password); // $login = $this->user_model->check_user($email, $password); 
                if (!empty($login)) {
                    $udata = array(
                        'user_id'   => $login['id'],
                        'user_name' => $login['first_name'],
                        'last_name' => $login['last_name'],
                        'email'     => $login['email'],
                    );

                    if ($newsl == 'on') {
                        $udata['newsletter'] =  true;
                    }
                    $this->session->set_userdata($udata);
                    if (!empty($page)) {
                        $pageDecode = base64_decode($page);
                        if ($pageDecode == 'addNews') {
                            $returndata['url'] = '/news/addNews';
                            //redirect('/news/addNews', 'refresh');
                        }
                    }
                    $_SESSION["abc"] = "abc";
                    //redirect('/', 'refresh');
                    $returndata["success"] = "Login Successful....";
                } else {
                    $returndata["error"] = "Incorrect Email And Password.";
                }
            }
            echo json_encode($returndata);
            exit;
        }
        $_SESSION["abc"] = "abc";
        $data['page_active'] = 'login';
        $data['notShowCategory'] = '1';
        defaultLoadView('user/index', $data);
    }


    public function login_ajax()
    {
        $data = array();
        $data['page']       = $page;
        $data["error"]      = "";
        $data["success"]    = "";
        if ($_POST) {

            $this->load->library('form_validation');
            $data['username'] = $this->input->post('loginEmail');
            $this->form_validation->set_rules('loginEmail', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('loginPassword', 'Password', 'required');
            if ($this->form_validation->run() == FALSE) {

                if (validation_errors()) {
                    $data["error"] = validation_errors();
                } else {
                    $data["error"] = "";
                }
            } else {
                $email      = $this->input->post('loginEmail');
                $password   = $this->input->post('loginPassword');
                $newsl      = $this->input->post('loginNewl');

                $logindata = array(
                    'email'     => $email,
                    'password'  => md5($password)
                );
                $login = $this->user_model->check_user($email, md5($password));
                if (!empty($login)) {

                    $udata = array(
                        'user_id'   => $login['id'],
                        'user_name' => $login['first_name'],
                        'last_name' => $login['last_name'],
                        'email'     => $login['email']
                    );

                    if ($newsl == 'on') {
                        $udata['newsletter'] =  true;
                    }
                    $this->session->set_userdata($udata);
                    $_SESSION["abc"] = "abc";
                    $data["success"]        = "success";
                } else {
                    $data["error"] = "Incorrect Email And Password.";
                }
            }
        }
        $_SESSION["abc"] = "abc";
        echo json_encode($data);
    }

    public function signup()
    {
        date_default_timezone_set('Asia/Kolkata');
        $dates= date('d-m-Y');
       //var_dump($_POST);
           
        if (check_user_authentication() == true) {

            //redirect('home');
        }

        //CAPTCHA Matching code
        session_start();

        if ($_SESSION["code"] != $_POST["captcha"]) {
            //redirect('user', 'refresh');
        } else {
            //echo "Form Submitted successfully....!";
        }

        $data = array();
        if ($_POST) {
             //die();

            $userData = $_POST;
            $this->load->library('form_validation');
            $data['username'] = $this->input->post('loginEmail');
            $this->form_validation->set_rules('first_name', 'First Name', 'required');
            $this->form_validation->set_rules('last_name', 'Last Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]|max_length[50]|trim');
            $this->form_validation->set_rules('phone_mobile', 'Phone No', 'required|min_length[10]|max_length[20]|trim');
            // $this->form_validation->set_rules('cpaasword', 'Confirm Password', 'required|min_length[8]|max_length[50]|matches[password]|trim');

            $first_name     = $this->input->post('first_name');
            $last_name      = $this->input->post('last_name');
            $email          = $this->input->post('email');
            $password       = $this->input->post('password');
            $phone_mobile   = $this->input->post('phone_mobile');
            $gender         = $this->input->post('gender');

            $checkEmail = $this->user_model->check_email($email);
            $emailError = "";
            if ($checkEmail) {
                $emailError = "<p>The email address already exist.</p>";
            }

            if ($this->form_validation->run() == FALSE  || $emailError) {

                if (validation_errors() || $emailError) {
                    $data["serror"] = validation_errors() . $emailError;
                } else {
                    $data["serror"] = "";
                }
            } else {

                $insertData = array(
                    'first_name'    => $first_name,
                    'last_name'     => $last_name,
                    'email'         => $email,
                    'gender'        => $gender,
                    'phone_mobile'  => $phone_mobile,
                    'signup_date' => $dates,
                    'password'      => $password
                );

                $result = addUpdateRecord('users', '', '', $insertData);

                if ($result) {
                    $alldata['data'] = $insertData;
                    $this->email->set_mailtype("html");
$this->email->set_newline("\r\n");
$this->email->set_crlf("\r\n");

                  //  send_email_with_template($email, "noreply@newssyn.com", 'Newssyn Account Verification', 'verify', $alldata);
                  
                    $config = Array(    

                          'protocol' => 'smtp',
                          'smtp_host' => 'ssl://smtp.googlemail.com',
                          'smtp_port' => 465,
                          'smtp_user' => 'newsagcnn@gmail.com',
                          'smtp_pass' => 'masscomm',
                          'mailtype' => 'html',
                          'charset' => 'utf-8'
                        );
                        $this->load->library('email', $config);
                        $this->email->set_newline("\r\n");
                        $this->email->from('noreply@newssyn.com', 'AUTHOR_EMAIL');
                        $data = array(
                           'first_name'=> $this->input->post('first_name'),
                           'email'=> $this->input->post('email')
                             );
                            
                         $this->email->to($email); 
                          $this->email->subject('Newssyn Account Verification');
                     
                            $body = $this->load->view('email_templates/verify',$data,TRUE);
                            
                           
                          $this->email->message($body);
                            $this->email->send();
                        
                        
                  
                  
                  
                  
                  
                  // send_email_with_template($email, "noreply@newssyn.com", 'Welcome To NEWSSYN', 'welcome', $insertData);
                    //$this->session->set_flashdata('success', 'User created successfully, Please login');
                    echo 'User created successfully, Verify Your Mail ID';
                    exit;
                    //redirect('user/signup', 'refresh');
                }
                
                // echo "<pre>";print_r($insertData);die;
            }
            $data['userData'] = $userData;
        }

        $data['page_active'] = 'new_account';
        $data['notShowCategory'] = '1';
        defaultLoadView('user/signup', $data);
    }


    public function signup_ajax()
    {

        $data = array();
        if ($_POST) {
            $first_name     = $this->input->post('first_name');
            $last_name      = $this->input->post('last_name');
            $email          = $this->input->post('email');
            $password       = $this->input->post('password');
            $checkEmail     = $this->user_model->check_email($email);
            $data['emailError'] = "";
            if ($checkEmail) {
                $data['emailError'] = "<p>The email address already exist.</p>";
            }

            $insertData = array(
                'first_name'    => $first_name,
                'last_name'     => $last_name,
                'email'         => $email,
                'password'      => md5($password)
            );

            $result = addUpdateRecord('users', '', '', $insertData);
            $data['success'] = false;
            if ($result) {

                send_email_with_template($email, AUTHOR_EMAIL, 'Welcome To Agcnn', 'welcome', $insertData);
                $data['success'] = true;
            }
        }

        echo json_encode($data);
    }

    function add_newuser()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', EMAIL, 'required|valid_email|valid_emails');
        $this->form_validation->set_rules('password', PASSWORD, 'required');
        $this->form_validation->set_rules('home_phone', HOME_PHONE, 'required|numeric');
        $this->form_validation->set_rules('cell_phone', CELL_PHONE, 'required|numeric');

        $email_check = '';
        $password_range = '';

        if ($_POST) {
            $password = $this->input->post('password');
            if ($this->check_email(SecurePostData($this->input->post('email'))) == 1) {
                $email_check = EMAIL_IS_ALREADY_EXIST;
            }
            if (strlen($password) > 16 or strlen($password) <= 7) {
                $password_range = "<br/>Password range must be from 8 to 16 characters.";
            }
        }

        if ($this->form_validation->run() == FALSE || $email_check != '' || $password_range != '') {
            if (validation_errors() || $email_check != '' || $password_range != '') {
                $arr["error"] = validation_errors() . $email_check . $password_range;
            } else {
                $arr["error"] = "";
            }

            $arr['email'] = $this->input->post('email');
            $arr['password'] = $this->input->post('password');
            $arr['home_phone'] = $this->input->post('home_phone');
            $arr['cell_phone'] = $this->input->post('cell_phone');
            $arr['allow_costume_access'] = $this->input->post('allow_costume_access');
        } else {

            $arr = array(
                'prefix'        => SecurePostData($this->input->post('prefix')),
                'first_name'    => SecurePostData($this->input->post('first_name')),
                'last_name'     => SecurePostData($this->input->post('last_name')),
                'suffix'        => SecurePostData($this->input->post('suffix')),
                'email'         => SecurePostData($this->input->post('email')),
                'password'      => SecurePostData($this->input->post('password')),
                'home_phone'    => SecurePostData($this->input->post('home_phone')),
                'active'        => 1,
                'cell_phone'    => SecurePostData($this->input->post('cell_phone')),
                'allow_costume_access' => SecurePostData($this->input->post('allow_costume_access')),
                'user_ip'       => $_SERVER['SERVER_ADDR'],
                'created_at'    => date('Y-m-d H:i:s')
            );
            $success = AddUpdateTable('users', '', '', $arr);
            $this->session->set_flashdata('item', NEW_RECORD_HAS_BEEN_ADDED_SUCCESSFULLY);
            redirect('admin/admin_user/list_users/add');
        }
        // $arr['site_setting'] = site_setting();
        $arr['page'] = 'user';
        $this->load->view('admin/users/vwAddNewUser', $arr);
    }

    public function forgot_password()
    {
         
        defaultLoadView('user/forgot_password');
    }
    public function forgetsave()
    {
        $email = $this->input->post('email');
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $email);
        $result = $this->db->get();
        $countrow = $result->num_rows();
        if($countrow > 0)
        {
            $link = base_url().'user/setforgetpassword?email='.$email;
            $to= $email;
            $subject = 'Forget Password';
            $MESSAGE_BODY= '<div style="padding: 24px;font-size: 18px;line-height: 37px;width:600px;">
                <div align="center" style="padding-bottom: 10px;font-size: 30px;">
                 <span style="color:#B32018; font-size:25px; font-weight: bold;">
                 Forget Password - Newssyn</span> 
                </div>';
            $MESSAGE_BODY.= '<div>Hello <b>'.$email.'</b><br/>';
            $MESSAGE_BODY.= '<br/>This is Password Reset Link Please Click Now:- <a href="'.$link.'">Forget Password</a>.
                    <br/>Thanks! <span style="color:#B32018; font-size:20px; font-weight:
                  bold;"></span> 
                    <br/> <span style="color:#B32018; font-size:20px; font-weight: bold;">
                 Newssyn</span></div></div>';
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'From: NEWSSYN ' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

            if(mail($to, $subject, $MESSAGE_BODY, $headers))
            {
              
            } 
            $this->session->set_flashdata('success', 'Forget Password Link Send Your MailID.');
            redirect('user/forgot_password');     
        } else
        {
            $this->session->set_flashdata('invalid', 'This EmailID is not Exits Please Enter Vaild EmailID.');
            redirect('user/forgot_password');
        }

    }

    public function setforgetpassword()

    {
         $getemail = $this->input->get('email');
        //$getemail ='nilswap786@gmail.com';
         $result['data'] = array('email' => $getemail);
         defaultLoadView('user/setforgetpassword', $result);
    }
     public function updatepassword()

    {
         $email = $this->input->post('email');
         $password = $this->input->post('password');
         $cpassword = $this->input->post('cpassword');
         $updatedata = array('password' => $password);
         if($password != $cpassword)
         {
         $this->session->set_flashdata('invalid', 'Password And Confirm Password Not Match.');
        redirect('user/setforgetpassword?email='.$email.'');
         } else
         {
        $this->db->where('email', $email);
        $this->db->update('users', $updatedata);
        $this->session->set_flashdata('success', 'Password Upadted Successfully.');
        redirect('user/setforgetpassword?email='.$email.'');
         }
    }


    public function reset_password($forgot_unique_code = null)
    {
        if (empty($forgot_unique_code)) {
            $this->session->set_flashdata('msg_exipired', 'Your verification link has been expired');
            redirect('/');
        }

        $chk_forget_code = $this->user_model->checkForgetUniqueCode($forgot_unique_code);
        if ($chk_forget_code == 'expire') {
            $this->session->set_flashdata('msg_exipired', 'Your verification link has been expired');
            redirect('/');
        }
        if ($chk_forget_code == 'not_sent') {
            $this->session->set_flashdata('msg_exipired', 'Your verification link has been expired');
            redirect('/');
        }

        $data['forgot_unique_code'] = $forgot_unique_code;
        if ($_POST) {

            $user_id = $chk_forget_code;
            $this->load->library('form_validation');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]|max_length[50]|trim');
            $this->form_validation->set_rules('cpassword', 'Retype Password', 'required|min_length[8]|max_length[50]|matches[password]|trim');

            if ($this->form_validation->run() == FALSE) {
                $data['error'] = "";
                if (validation_errors()) {
                    $data['error'] = validation_errors();
                } else {
                    $data['error'] = '';
                }

                if ($this->input->post('user_id')) {

                    $data['user_id'] = $this->input->post('user_id');
                    $data['forgot_unique_code'] = $this->input->post('forget_unique_code');
                } else {
                    $data['user_id'] = $user_id;
                    $data['forgot_unique_code'] = $forgot_unique_code;
                }
                $data['password'] = '';
                $data['cpassword'] = '';
            } else {
                $spass      = array('password' => md5($this->input->post('password')));
                $set        = addUpdateRecord('users', 'id', $user_id, $spass);
                $user_data  = $this->user_model->getRecordById($user_id);
                if ($set != '') {
                    $chk = $this->user_model->check_user($user_data['email'], $spass['password']);
                    if ($chk) {
                        if ($chk['user_status'] == 'A') {

                            //update last_login date field by priyanka on 30-06-2015
                            $lastlogindata = array('last_login_date' => date('Y-m-d h:i:s'));
                            addUpdateRecord('users', 'id', $chk['id'], $lastlogindata);

                            $udata = array(
                                'user_id'   => $chk['id'],
                                'user_name' => $chk['first_name'],
                                'last_name' => $chk['last_name'],
                                'email'     => $chk['email'],
                            );

                            $this->session->set_userdata($udata);
                        }
                    }
                    $this->session->set_flashdata('reset_success', 'Your password has been reset successfully.');
                    redirect('home');
                } else {
                    $data['error'] = 'Your link has been expired.';
                }
            }
        }

        defaultLoadView('user/reset_password', $data);
    }

    public function logout()
    {
        $user_data = $this->session->all_userdata();

        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('user_name');
        $this->session->unset_userdata('last_name');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('newsletter');
        $this->session->sess_destroy();
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        redirect('/', 'refresh');
    }

    public function add_address()
    {
        $userId = check_user_authentication();
        if (!$userId) {
            redirect('home');
        }
        if ($_POST) {

            $postData   = $_POST;
            $checkAdress = $this->user_model->check_exist_address($postData['email'], $postData['first_name'], $postData['last_name'], $postData['street_address1'], $postData['street_address2'], $postData['city'], $postData['slt_states'], $postData['zip_code'], $postData['slt_country'], $postData['phone_number'], $postData['company']);
            $insertData = array(
                'email'         => $postData['email'],
                'first_name'    => $postData['first_name'],
                'last_name'     => $postData['last_name'],
                'address_first' => $postData['street_address1'],
                'address_second' => $postData['street_address2'],
                'company'       => $postData['company'],
                'country'       => $postData['slt_country'],
                'state'         => $postData['slt_states'],
                'city'          => $postData['city'],
                'zip_code'      => $postData['zip_code'],
                'phone_number'  => $postData['phone_number'],
                'user_id'       => $userId
            );
            $this->load->library('cart');
            $items =  $this->cart->contents();
            if (!empty($items)) {

                if ($checkAdress) {
                    $result = addUpdateRecord('user_addresses', 'id', $postData['address_id'], $insertData);
                } else {
                    $result = addUpdateRecord('user_addresses', '', '', $insertData);
                }
                if ($result) {
                    $this->session->set_userdata('payment_status', '1');
                    echo 'success';
                } else {
                    echo 'error';
                }
            } else {
                echo 'cart_empty';
            }
        }
    }

    function profile()
    {

        if (check_user_authentication() != true) {
            $this->session->set_flashdata('success', 'Not having access this page.');
            redirect('home');
        }

        $this->load->model('regusers_model');
        $id = $this->session->userdata('user_id');
        $user = $this->user_model->getRecordById($id);

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('first_name', 'first name', 'required');
            $this->form_validation->set_rules('last_name', 'last name', 'required');
            if ($user['email'] != $this->input->post('email')) {
                $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email|callback_validate_email');
                $this->form_validation->set_message('validate_email', 'This email address already register.please login!');
            } else {
                $this->form_validation->set_rules('email', 'email address', 'trim|required|valid_email');
            }
            //$this->form_validation->set_rules('email_addres', 'email address', 'trim|required|valid_email');
            $this->form_validation->set_rules('address_street', 'address', 'required');
            $this->form_validation->set_rules('address_city', 'city', 'required');
            $this->form_validation->set_rules('phone_mobile', 'phone no', 'required|max_length[15]|min_length[10]|numeric');
            $this->form_validation->set_rules('address_state', 'state', 'required');
            $this->form_validation->set_rules('address_country', 'country', 'required');
            $this->form_validation->set_rules('phone_mobile', 'phone no', 'required');

            if ($this->input->post('password') != '' && $this->input->post('new_password') != '') {
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');
                $this->form_validation->set_rules('new_password', 'Password', 'trim|required|min_length[4]|max_length[32]');
                $this->form_validation->set_rules('new_com_password', 'Password Confirmation', 'trim|required|matches[new_password]');
            }

            $this->form_validation->set_error_delimiters('<div class="alert bg-danger"><a class="close" data-dismiss="alert">x</a><strong>', '</strong></div>');

            if ($this->form_validation->run()) {
                $profile_image = '';
                if (!empty($_FILES)) {
                    if ($_FILES['profile_image']['tmp_name'] != "") {
                        $tempFile      = $_FILES['profile_image']['tmp_name'];
                        $temp          = $_FILES["profile_image"]["name"];
                        $path_parts    = pathinfo($temp);
                        $t             = preg_replace('/\s+/', '', microtime());
                        $fileName      = time() . '_' . $path_parts['filename'] . $t . '.' . $path_parts['extension'];
                        $targetPath    =  "./upload/profile_image/";
                        $targetFile    = $targetPath . $fileName;
                        $profile_image = $fileName;
                        move_uploaded_file($tempFile, $targetFile);
                    } else {
                        $profile_image = $this->input->post('old_logo');
                    }
                } else {
                    $profile_image = $this->input->post('old_logo');
                }

                $data_to_store = array(
                    'first_name' => $this->input->post('first_name'),
                    'last_name' => $this->input->post('last_name'),
                    'address_street' => $this->input->post('address_street'),
                    'address_city' => $this->input->post('address_city'),
                    'phone_mobile' => $this->input->post('phone_mobile'),
                    'address_state' => $this->input->post('address_state'),
                    'address_country' => $this->input->post('address_country'),
                    'phone_mobile' => $this->input->post('phone_mobile'),
                    'gender' => $this->input->post('gender'),
                    'profile_image' => $profile_image
                );

                if ($this->input->post('password') != '' && $this->input->post('new_password') != '') {
                    $data_to_store['password'] = md5($this->input->post('new_password'));
                }


                if ($this->regusers_model->update_users($id, $data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('user/profile');
            } else {
                $user = $_POST;
            }
        }

        $allcountry = getAllCountry();
        //      $allcountryState = getAllCountrystate(101);

        $data['id'] = $id;
        $data['allcategory'] = $allcategory;
        $data['allcountry'] = $allcountry;
        $data['user']  = $user;
        $data['notShowCategory'] = '1';
        defaultLoadView('user/profile', $data);
    }

    function profile_view()
    {
        if (check_user_authentication() != true) {
            $this->session->set_flashdata('success', 'Not having access this page.');
            redirect('home');
        }

        $id                   = $this->session->userdata('user_id');
        //$this->load->model('regusers_model');
        $data['user']         = $this->user_model->getRecordById($id);
        //$this->load->model('admin/dashboard_model');
        //$data['total_users'] = $this->user_model->getTotalUsers($id);
        $data['total_news'] = $this->user_model->getTotalNews($id);
        $data['total_visiter'] = $this->user_model->getTotalVister($id);
        $data['total_notice'] = $this->user_model->getTotalNotice();
        $data['cat_ount'] = $this->user_model->getcategoryNewsCount($id);
        $data['pending_news'] = $this->user_model->get_all_pending_news($id);
        $data['notShowCategory'] = '1';

        defaultLoadView('user/profile_view', $data);
    }

    function validate_email($email)
    {
        $user_count = $this->user_model->validate_email($this->input->post('email'));
        if ($user_count > 0) {
            return false;
        } else {
            return true;
        }
    }

    public function social_login()
    {
        
        
        

        if (check_user_authentication() == true) {
            return '1';
        }

        $data = array();
        $returndata = array();
        $returndata['url'] = '';
        $returndata["error"] = "";
        $returndata["success"] = "";
        date_default_timezone_set('Asia/Kolkata');
        $dates= date('d-m-Y');

        if ($_POST) {
            
            if ($_POST['social'] != '') {
// var_dump($_POST);
//             die;
 
                $login_type = $_POST['social'];

                if ($_POST['social'] == 'facebook') {
                    $facebook_id = $social_id =  $this->input->post('id');
                }

                if ($_POST['social'] == 'google') {
                    $google_id = $social_id =  $this->input->post('id');
                }


                $email          = $this->input->post('email');
                if($email!=''){
                    $checkEmail = $this->user_model->check_email($email, TRUE);
                }
                
                if (!$checkEmail) {
                    
                    $checkEmail = $this->user_model->check_email_social_account($social_id, $login_type);
                }
               
// echo "<pre>";print_r($checkEmail['id']);die;
                if ($checkEmail) {
                    $user_id = $checkEmail['id'];
                } else {
                    $first_name     = $this->input->post('first_name');
                    $last_name      = $this->input->post('last_name');
                    $password       = rand();
                    //$phone_mobile   = $this->input->post('phone_mobile');
                    $gender         = $this->input->post('');
                    $insertData = array(
                        'first_name'    => $first_name,
                        'last_name'     => $last_name,
                        'email'         => $email,
                        'gender'        => $gender,
                        'signup_date'  => $dates,
                        'password'      => $password
                    );
                       
                    $result = addUpdateRecord('users', '', '', $insertData);
                    $user_id = $result;
                    
                    if ($result) {
                        $this->email->set_mailtype("html");
$this->email->set_newline("\r\n");
$this->email->set_crlf("\r\n");
                        // send_email_with_template($email, AUTHOR_EMAIL, 'Welcome To Agcnn', 'welcome', $insertData);
                        
                        $config = Array(    

                          'protocol' => 'smtp',
                    
                          'smtp_host' => 'ssl://smtp.googlemail.com',
                    
                          'smtp_port' => 465,
                    
                          'smtp_user' => 'newsagcnn@gmail.com',
                    
                          'smtp_pass' => 'masscomm',
                    
                          'mailtype' => 'html',
                    
                          'charset' => 'utf-8'
                    
                        );
                    
                        $this->load->library('email', $config);
                        
                        $this->email->set_newline("\r\n");

  

                        $this->email->from('noreply@newssyn.com', 'AUTHOR_EMAIL');
                    
                        $data = array(
                    
                           'first_name'=> $this->input->post('first_name'),
                           'email'=> $this->input->post('email')
                    
                             );
                        
                        
                         $this->email->to($email);

                          $this->email->subject('Welcome To Agcnn'); 
                        
                          
                        
                            $body = $this->load->view('email_templates/welcome',$data,TRUE);
                        
                          $this->email->message($body); 
                        
                            $this->email->send();
                        
                        
                        
                        
                    }
                }
                 
                $update_dat = array();
                if ($_POST['social'] == 'facebook') {
                   
                    $update_dat['facebook_id'] = $facebook_id;
                }

                if ($_POST['social'] == 'google') {
                    $update_dat['google_id'] =  $google_id;
                }
                
                
                $result = addUpdateRecord('users', 'id', $user_id, $update_dat);

                $login = $this->user_model->getRecordById($user_id);
           
                if ($login) {
                    $udata = array(
                        'user_id'   => $login['id'],
                        'user_name' => $login['first_name'],
                        'last_name' => $login['last_name'],
                        'email'     => $login['email'],
                    );
                    $this->session->set_userdata($udata);
                    $returndata["success"] = "Login Successful....";
                } else {
                    $returndata["error"] = "Error occurred! user not associated with us please contact administrator.";
                }
            } else {
                $returndata["error"] = "Error occurred! Please try again.";
            }
        }
        echo json_encode($returndata);
        exit;
    }
    public function active()
    {
            $email = base64_decode($_GET['em']);
            
            $this->db->select('*');
$this->db->from('users');
$this->db->where("email",$email);
$query23= $this->db->get();
$result23 = $query23->result_array();


             
        $this->db->where('email', $email);
          $this->db->where('user_status', 'A');
$num_rows = $this->db->count_all_results('users');
if($num_rows>0)
{
     ?>
      <script>alert("Link Expeire");
      window.location.replace('https://newssyn.com/user/login');
      </script>
      
      <?php  
}
else
{
 
   
       $this->db->where("email",$email);
       $this->db->update('users',["user_status"=>'A']);
       

$alldata['data']= array(
    "first_name"=>$result23[0]['first_name'],
      "email"=>$result23[0]['email']
    );

     $this->email->set_mailtype("html");
$this->email->set_newline("\r\n");
$this->email->set_crlf("\r\n");
            
             send_email_with_template($email, "noreply@newssyn.com", 'Welcome To Newssyn', 'welcome', $alldata);
       
      ?>
      <script>alert("Account Active Successfully");
      window.location.replace('https://newssyn.com/user/login');
      </script>
      <?php
}

    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
