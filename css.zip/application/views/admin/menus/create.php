<?php
//echo $error;
	if (!empty($postData)) {
		$name 		= $postData['name'];
		$discription= $postData['discription'];
		$link 		= $postData['link'];
		$status 	= $postData['status'];
	}
?>
<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li><a href="<?php echo base_url('admin/menus'); ?>">MENUS</a></li>
			<li class="active">ADD MENU</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">ADD NEW MENU</h2>
		<div class="graph-form">
			<?php
				if(!empty($error)){ 
				?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
			} ?>
			<div class="form-body">
				<form action="<?php echo base_url('admin/menus/add'); ?>" method="post">
					<input type="hidden" value=""/>
					<div class="form-group">
						<label for="exampleInputEmail1">Name <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
					</div>
					
					<div class="form-group">
						<label for="exampleInputPassword1">Link <span class="star-color">*</span></label> 
						<input type="text" class="form-control" id="link"  name="link"  value="<?php echo $link; ?>" >
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Menu Type <span class="star-color">*</span></label> 
						<select name="menu_type" class="form-control" onchange="displayparent(this.value);" required="">
						<option value="">Select</option>
						<option value="mainmenu">Main Menu</option>
						<option value="submenu">Sub Menu</option>
						<option value="footermenu">Footer Menu</option>
						</select>
					</div>
					<?php 
					if (!empty($menusType)) { ?> 
						<div class="form-group" id="parentmenulist" style="display: none;">
							<label for="exampleInputPassword1">Parent</label> 
						<select name="parent_id" class="form-control" >

						<?php

						echo '<option value="0">select</option>'; 

						 foreach($menusType as $type){
								$rest='';
								if($type['id']==$parent_id){
									$rest='selected="selected"';
								}
							  	echo '<option value="'.$type['id'].'" '.$rest.'>'.$type['title'].'</option>'; 
								
								}?>
						</select>
						</div>
					<?php } ?>
					<div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Status</label>
						<div class="radio block"><label>
						<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked"  />Active</label></div>
						<div class="radio block">
						<label><input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive</label></div>
					</div>
					<button type="submit" class="btn btn-default" name="submit" value="submit" onclick="return valid_url_format();">Submit</button> 
				</form> 
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>

<script>
function displayparent(value)
{
	
	if(value=="submenu"){
		
		$("#parentmenulist").show();
		
	}else
	{
		$("#parentmenulist").hide();
	}
}
</script>
