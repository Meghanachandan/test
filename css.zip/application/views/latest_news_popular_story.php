<!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
<?php $url1 = current_url();
  $parse = parse_url($url1);
       $strig = $parse['host'];
  $ad="SELECT * FROM `side_img` WHERE page_host ='".$strig."' and status='1'  ORDER BY id DESC LIMIT 1";
$q = $this->db->query($ad);
        $data = $q->result_array();
// echo $this->db->last_query();die;
// echo "<pre>";print_r($data);die;
  ?>

  <style>
      @media(max-width: 600px){
          #display{
              display: none;
          }
      }
      @media(min-width: 1200px){
    .megamenu-li {
    position: static;
    z-index:1;
        }
        }
  </style>          

<style>
    @media(min-width: 1200px){
        .sssssss{
            margin-top:-55px;
        }
    }
     @media(max-width: 600px){
        .sssssss{
            margin-top:-35px;
        }
    }
</style>
<style>
    @media(max-width: 600px){
        .slick-current {
         width: 210px!important;   
        }
        .slick-track{
            margin-left: 60px!important;
        }
    }
</style>
<?php if ($latest_news) { ?>
    <section class="features17 cid-rUEOBxXWse sssssss" id="features17-y" style="">
        <div class="container-fluid">
            <div cl ass="media-container-row">
                <h1 class="classForHeadercategory">
                    Latest News
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php
                unset($latest_news[0]);
                if ($latest_news) {
                    $news = array();
                    foreach ($latest_news as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'ln';
                        //  if($news['news_video']){
                        // $this->load->view('home/home_news_block_video', $news_data);
                        // }
                        $this->load->view('home/home_news_block', $news_data);
                    }
                }
                ?>
            </div>
        </div>
    </section>
<?php } ?>




<?php if ($populer_news) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    papular story
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php if ($populer_news) {
               
                    
                    $news = array();
                    foreach ($populer_news as $news) {
                     
                        $news_data['news'] = $news;
                          
                        $news_data['list'] = 'pn';
                        // if($news['news_video']){
                        // $this->load->view('home/home_news_block_video', $news_data);
                        // }
                        $this->load->view('home/home_news_block', $news_data);
                    }
                ?>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } ?>

<?php
$add_array = array();
foreach ($addOnPage as $key => $value) {
    $add_array[]  = $key;
}
//pr($add_array);
?>




<script src="http://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
    $(document).ready(function(){
        
        $(".likebtn").click(function(){
            pid = $(this).data('id');
            btn = $(this);
            // alert(pid);
            $.post("<?php echo base_url('Home/like'); ?>", {news_id: pid}, function(result){
                // alert(result);
                if(result==0) alert("Please Login First!!");
                if(result==1)
                {
                    btn.removeClass('fa-heart-o');
                    btn.addClass('fa-heart');
                    // btn.html('<i class="fa fa-heart"></i>');
                    alert('you liked');
                    btn.removeClass('likebtn');
                    btn.addClass('unlikebtn');
                    location.reload();
                } 
            });
        });

        $(".unlikebtn").click(function(){
            unlikeid = $(this).data('id');
            btnunlike = $(this);
            // alert(pid);
            // alert('hi');

            $.post("<?php echo base_url('Home/unlike'); ?>", {news_id: unlikeid}, function(result){
                // alert(result);
                if(result==0) alert("Please Login First!!");
                if(result==1)
                {
                    btnunlike.removeClass('fa-heart');
                    btnunlike.addClass('fa-heart-o');
                    // btn.html('<i class="fa fa-heart"></i>');
                    alert('you unliked');
                    btnunlike.removeClass('unlikebtn');
                    btnunlike.addClass('likebtn');
                    location.reload();
                } 
            });
        });
    });
 

    $(document).on('ready', function() {
        $(".center").slick({
            dots: false,
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 6,
                        slidesToScroll: 1,
                       // centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                       // centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        //centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        $(".center2").slick({
            dots: false,
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        $(".center3").slick({
            dots: false,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    });
</script>