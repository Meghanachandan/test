
<style>
    section {
        background-color: #FFF;
    }
</style>
<section id="form"><!--form-->
	<div class="container">
		<div class="row">
		<div style="width:95%;max-width: 550px;margin:20px auto;">
        	<div class="col-sm-12">
            	
                <div class="categoryproduct text-center" style="padding-top:40;">  
                    <div class="content-heading">
						  <h2 class="title-head">Forgot Password</h2>
						  <BR>
						<BR>
                    </div>
                </div>
                                   
			</div>
			<div class="col-sm-12 text-center">
			
				<div class="login-form social-buttons"><!--login form-->
					<h5>Enter your email address and we'll send you a link to reset your password.</h5>
				
						<BR>
                    <?php if (!empty($error)) { ?>
						<div class="alert alert-danger"><?php echo $error; ?></div>
					<?php } ?>
					<?php if($this->session->flashdata('success')){ ?>
						<div class="alert alert-success message" style="display: block;">
							<?php echo $this->session->flashdata('success'); ?>
						</div>
					<?php } ?>
					<form action="<?php echo base_url('user/forgot_password'); ?>" method="post">
						<div class="form-group">
							<input type="text" class="form-control m-0" placeholder="Email Address" name="femail" />
						</div>
						<p>
						<span>Please check your spam/junk mail folder if you do not see the password reset email within 24 hours.</span>
						</p>
						<button type="submit" title="Submit" class="btn-sm btn-secondary" >Submit</button>
					</form>
						<BR>
						<BR>
					<h5 class="text-center" ><a title="Return to Log in" href="<?php echo base_url('user/login'); ?>" style="color: #333;text-decoration:underline;">Return to Log in</a></h5>
      		 	</div><!--/login form-->
		
			</div>
		</div>
		</div>
	</div>
</section><!--/form-->