</div>
</div>

<?php  
$actual_link = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];  
$explode=explode('/',$actual_link);
// print_r($explode[6]);die;
?>

<!--//content-inner-->
<!--/sidebar-menu-->


<!--<div class="sidebar-menu">-->
<!--    <header class="logo" id="sidenav">-->
<!--        <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="<?php echo base_url("admin/dashboard"); ?>"> <span id="logo">Agcnn.com</span>-->
<!--        </a>-->
<!--    </header>-->
<!--    <div style="border-top:1px solid rgba(69, 74, 84, 0.7)"></div>-->
    
<!--    <style>-->
<!--    #sidenav {-->
 
<!--}-->

<!--#sidenav a {-->
  
<!--}-->
<!--.abc {-->
<!--  z-index: 1;-->
<!--  top: 0;-->
<!--  left: 0;-->
<!--  overflow-x: hidden;-->
<!--}-->
<!--    </style>-->
<!--    <div class="menu">-->
<!--        <ul id="menu" class="" style="margin-top: 55px;">-->
<!--            <li id="menu-academico">-->
<!--                <?php if ($this->session->userdata('username')) { ?>-->
<!--                    <a href="" class="dropdown-toggle user-label" data-toggle="dropdown" aria-expanded="false" style="color: #fff"><i class="fa fa-user"></i><span> &nbsp;Hello <?php echo ucwords($this->session->userdata('username')); ?></span></a>-->
<!--                <?php } ?>-->
<!--            </li>-->
<!--            <li>-->
<!--                <a href="<?php echo base_url("admin/dashboard"); ?>">-->
<!--                    <i class="fa fa-tachometer"></i>-->
<!--                    <span>Dashboard</span>-->
<!--                </a>-->
<!--            </li>-->
<!--            <li id="menu-academico">-->
<!--                <a href="#">-->
<!--                    <i class="fa fa-file-text-o"></i>-->
<!--                    <span>Pages Settings</span>-->
<!--                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>-->
<!--                </a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes">-->
<!--                        <a href="<?php echo base_url('admin/pages/add'); ?>">Add Pages</a>-->
<!--                    </li>-->
<!--                    <li id="menu-academico-boletim">-->
<!--                        <a href="<?php echo base_url('admin/pages'); ?>">View/Edit Pages</a>-->
<!--                    </li>-->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico"><a href="#"><i class="fa fa-bars"></i> <span>Menus Settings</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/menus/add'); ?>">Add Menus</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/menus'); ?>">View/Edit Menus</a></li>-->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>News Categories</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/news/categorie_add'); ?>">Add News Categories</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/news/categories'); ?>">View/Edit News Categories</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/news/categorie_manage'); ?>">Manage News Categories</a></li>-->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>News</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/news/add'); ?>">Add News</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/news'); ?>">View/Edit News</a></li>-->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>Notice</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/notice/add_notice'); ?>">Add Notice</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/notice'); ?>">View/Edit Notice</a></li>-->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico"><a href="#"><i class="fa fa-dribbble"></i> <span>Adds</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/adds/add'); ?>">Add adds</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/adds'); ?>">View/Edit adds</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/side_img/add_side_img'); ?>">Add Side Adds</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/side_img'); ?>">View/Side Side Adds</a></li>-->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico">-->
<!--                <a href="#"><i class="fa fa-dribbble"></i>-->
<!--                    <span>Users</span>-->
<!--                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>-->
<!--                </a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/users/add_newuser'); ?>">Add Users</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/users'); ?>">View/Edit Users</a></li>-->
<!--                </ul>-->
<!--            </li>-->
            
<!--            <li id="menu-academico">-->
<!--                <a href="#"><i class="fa fa-dribbble"></i>-->
<!--                    <span>Team Members</span>-->
<!--                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>-->
<!--                </a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/department'); ?>">Manage Department</a></li>-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/department/designations'); ?>">Manage Designation</a></li>-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/team/add_newmember'); ?>">Add Team</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/team'); ?>">View/Edit Team</a></li>-->
<!--                </ul>-->
<!--            </li>-->

<!--            <li id="menu-academico"><a href="#"><i class="fa fa-phone"></i> <span>Contact Address</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
                    <!-- <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/contact_address/add'); ?>">Add Address</a></li> -->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/contact_address'); ?>">View/Edit Address</a></li>-->
<!--                </ul>-->
<!--            </li>-->

<!--            <li id="menu-academico">-->
<!--                <a href="#"><i class="fa fa-dribbble"></i>-->
<!--                    <span>Faq</span>-->
<!--                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>-->
<!--                </a>-->
<!--                <ul id="menu-academico-sub">-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/faq/faq_add'); ?>">Add Faq</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/faq'); ?>">View/Edit Faqs</a></li>-->
<!--                </ul>-->
<!--            </li>-->
<!--             <li id="menu-academico">-->
<!--                <a href="#"><i class="fa fa-dribbble"></i>-->
<!--                    <span>Location</span>-->
<!--                    <span class="fa fa-angle-right icon-mtm" style="float: right"></span>-->
<!--                </a>-->
<!--                <ul id="menu-academico-sub" style='margin-top: -77px;'>-->
<!--                    <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/location/country_add'); ?>">Add Country</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/location/country_view'); ?>">View/Edit Country</a></li>-->
<!--                     <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/location/state_add'); ?>">Add State</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/location/state_view'); ?>">View/Edit State</a></li>-->
<!--                     <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/location/city_add'); ?>">Add City</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/location/city_view'); ?>">View/Edit City</a></li>-->
<!--                </ul>-->
                
<!--            </li>-->

<!--            <li id="menu-academico"><a href="#"><i class="fa fa-cogs"></i> <span>Others Settings</span> <span class="fa fa-angle-right icon-mtm" style="float: right"></span></a>-->
<!--                <ul id="menu-academico-sub">-->
                    <!-- <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/social_network'); ?>">Manage Social Icons</a></li> -->
                    
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/home/changepassword'); ?>">Change Password</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/email_subscribers'); ?>">Email Subscriber</a></li>-->
<!--                    <li id="menu-academico-boletim"><a href="<?php echo base_url('admin/terms'); ?>">Terms and Conditions</a></li>-->
                    <!-- <li id="menu-academico-avaliacoes"><a href="<?php echo base_url('admin/payment/security_list'); ?>">Security Card</a></li> -->
<!--                </ul>-->
<!--            </li>-->
<!--            <li id="menu-academico">-->
<!--                <?php if ($this->session->userdata('username')) { ?>-->
<!--                    <a href="<?php echo base_url('admin/users/logout') ?>" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" title="Logout"><i class="fa fa-sign-out"></i><span>Logout</span></a>-->
<!--                <?php } ?><br>-->
<!--            </li>-->
        
             
           <!--  <li id="menu-academico">-->
           <!--   <a href="#">demo2</a>-->
           <!-- </li>-->
           <!-- <li id="menu-academico">-->
           <!--   <a href="#">demo3</a>-->
           <!-- </li>-->
           <!-- <li id="menu-academico">-->
           <!--   <a href="#">demo4</a>-->
           <!-- </li>-->
           <!-- <li id="menu-academico">-->
           <!--   <a href="#">demo5</a>-->
           <!-- </li>-->
           <!-- <li id="menu-academico">-->
           <!--   <a href="#">demo6</a>-->
           <!-- </li>-->
<!--        </ul>-->
<!--    </div>-->
<!--</div>-->


<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!--<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>-->
<!------ Include the above in your HEAD tag ---------->


<!--<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">-->

<style>
    .nav-side-menu {
  overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #2e353d;
  position: fixed;
  top: 0px;
  width: 200px;
  height: 100%;
  color: #e1ffff;
}
.nav-side-menu .brand {
  background-color: #23282e;
  line-height: 50px;
  display: block;
  text-align: center;
  font-size: 14px;
}
.nav-side-menu .toggle-btn {
  display: none;
}
.nav-side-menu ul,
.nav-side-menu li {
  list-style: none;
  padding: 0px;
  margin: 0px;
  line-height: 35px;
  cursor: pointer;
  /*    
    .collapsed{
       .arrow:before{
                 font-family: FontAwesome;
                 content: "\f053";
                 display: inline-block;
                 padding-left:10px;
                 padding-right: 10px;
                 vertical-align: middle;
                 float:right;
            }
     }
*/
}
.nav-side-menu ul :not(collapsed) .arrow:before,
.nav-side-menu li :not(collapsed) .arrow:before {
  font-family: FontAwesome;
  content: "\f078";
  display: inline-block;
  padding-left: 10px;
  padding-right: 10px;
  vertical-align: middle;
  float: right;
}
.nav-side-menu ul .active,
.nav-side-menu li .active {
  border-left: 3px solid #d19b3d;
  background-color: #4f5b69;
}
.nav-side-menu ul .sub-menu li.active,
.nav-side-menu li .sub-menu li.active {
  color: #d19b3d;
}
.nav-side-menu ul .sub-menu li.active a,
.nav-side-menu li .sub-menu li.active a {
  color: #d19b3d;
}
.nav-side-menu ul .sub-menu li,
.nav-side-menu li .sub-menu li {
  background-color: #181c20;
  border: none;
  line-height: 28px;
  border-bottom: 1px solid #23282e;
  margin-left: 0px;
}
.nav-side-menu ul .sub-menu li:hover,
.nav-side-menu li .sub-menu li:hover {
  background-color: #020203;
}
.nav-side-menu ul .sub-menu li:before,
.nav-side-menu li .sub-menu li:before {
  font-family: FontAwesome;
  content: "\f105";
  display: inline-block;
  padding-left: 10px;
  padding-right: 10px;
  vertical-align: middle;
}
.nav-side-menu li {
  padding-left: 0px;
  border-left: 3px solid #2e353d;
  border-bottom: 1px solid #23282e;
}
.nav-side-menu li a {
  text-decoration: none;
  color: #e1ffff;
}
.nav-side-menu li a i {
  padding-left: 10px;
  width: 20px;
  padding-right: 20px;
}
.nav-side-menu li:hover {
  border-left: 3px solid #d19b3d;
  background-color: #4f5b69;
  -webkit-transition: all 1s ease;
  -moz-transition: all 1s ease;
  -o-transition: all 1s ease;
  -ms-transition: all 1s ease;
  transition: all 1s ease;
}
@media (max-width: 767px) {
  .nav-side-menu {
    position: relative;
    width: 100%;
    margin-bottom: 10px;
  }
  .nav-side-menu .toggle-btn {
    display: block;
    cursor: pointer;
    position: absolute;
    right: 10px;
    top: 10px;
    z-index: 10 !important;
    padding: 3px;
    background-color: #ffffff;
    color: #000;
    width: 40px;
    text-align: center;
  }
  .brand {
    text-align: left !important;
    font-size: 22px;
    padding-left: 20px;
    line-height: 50px !important;
  }
}
@media (min-width: 767px) {
  .nav-side-menu .menu-list .menu-content {
    display: block;
  }
}
body {
  margin: 0px;
  padding: 0px;
}

</style>
<div class="nav-side-menu">
    <div class="brand"><a href="<?php echo base_url("admin/dashboard"); ?>"> <span id="logo">Agcnn.com</span></div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                <li>
                  <?php if ($this->session->userdata('username')) { ?>
                    <a onclick='savesubcat()' href="" class="dropdown-toggle user-label" data-toggle="dropdown" aria-expanded="false" style="color: #fff"><i class="fa fa-user"></i><span> &nbsp;Hello <?php echo ucwords($this->session->userdata('username')); ?></span></a>
                <?php } ?>
                </li>

                <li class="collapsed <?php if ($explode[5] == 'dashboard') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="<?php echo base_url("admin/dashboard"); ?>"> 
                  <i class="fa fa-dashboard fa-lg"></i> Dashboard
                  </a>
                </li>

                <li  data-toggle="collapse" data-target="#products" class="collapsed <?php if ($explode[5] == 'pages') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-file-text-o"></i> Pages Settings <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="products">
                    <li class="active"><a onclick='savesubcat()' href="<?php echo base_url('admin/pages/add'); ?>">Add Pages</a></li>
                    <li><a onclick='savesubcat()' href="<?php echo base_url('admin/pages'); ?>">View/Edit Pages</a></li>
                </ul>
                </li>


                <li data-toggle="collapse" data-target="#service1" class="collapsed <?php if ($explode[5] == 'menus') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-bars"></i> Menus Settings <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="service1">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/menus/add'); ?>">Add Menus</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/menus'); ?>">View/Edit Menus</a></li>
                </ul>
                </li>  

                <li data-toggle="collapse" data-target="#service2" class="collapsed <?php if ($explode[5] == 'news' && $explode[6] == 'categorie_add'  or $explode[6] == 'categories' or $explode[6] == 'categorie_manage') {echo 'active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> News Categories <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="service2">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/news/categorie_add'); ?>">Add News Categories</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/news/categories'); ?>">View/Edit News Categories</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/news/categorie_manage'); ?>">Manage News Categories</a></li>
                </ul>
                </li>  

                <li data-toggle="collapse" data-target="#service3" class="collapsed <?php if ($explode[5] == 'news') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> News <span class="arrow"></span></a>
                 
                <ul class="sub-menu collapse" id="service3">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/news/add'); ?>">Add News</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/news'); ?>">View/Edit News</a></li>
                </ul>
                </li> 


                <li data-toggle="collapse" data-target="#new" class="collapsed <?php if ($explode[5] == 'notice') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> Notice <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/notice/add_notice'); ?>">Add Notice</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/notice'); ?>">View/Edit Notice</a></li>
                </ul>
                </li>
                
                <li data-toggle="collapse" data-target="#new1" class="collapsed <?php if ($explode[5] == 'adds' or $explode[5] == 'side_img') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> Adds <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new1">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/adds/add'); ?>">Add adds</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/adds'); ?>">View/Edit adds</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/side_img/add_side_img'); ?>">Add Side Adds</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/side_img'); ?>">View/Side Side Adds</a></li>
                </ul>
                </li>
                
                <li data-toggle="collapse" data-target="#new2" class="collapsed <?php if ($explode[5] == 'users') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> Users <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new2">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/users/add_newuser'); ?>">Add Users</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/users'); ?>">View/Edit Users</a></li>
                </ul>
                </li>
                
                <li data-toggle="collapse" data-target="#new3" class="collapsed <?php if ($explode[5] == 'department' or $explode[5] == 'team') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> Team Members <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new3">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/department'); ?>">Manage Department</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/department/designations'); ?>">Manage Designation</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/team/add_newmember'); ?>">Add Team</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/team'); ?>">View/Edit Team</a></li>
                </ul>
                </li>
                
                <li data-toggle="collapse" data-target="#new4" class="collapsed <?php if ($explode[5] == 'contact_address') {echo ' active';} ?>">
                  <a href="#"><i class="fa fa-phone"></i> Contact Address <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new4">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/contact_address'); ?>">View/Edit Address</a></li>
                </ul>
                </li>
                
                <li data-toggle="collapse" data-target="#new5" class="collapsed <?php if ($explode[5] == 'faq') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> Faq <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new5">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/faq/faq_add'); ?>">Add Faq</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/faq'); ?>">View/Edit Faqs</a></li>
                </ul>
                </li>
                
                <li data-toggle="collapse" data-target="#new6" class="collapsed <?php if ($explode[5] == 'location') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-dribbble"></i> Location <span class="arrow"></span></a>
               
                <ul class="sub-menu collapse" id="new6">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/location/country_add'); ?>">Add Country</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/location/country_view'); ?>">View/Edit Country</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/location/state_add'); ?>">Add State</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/location/state_view'); ?>">View/Edit State</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/location/city_add'); ?>">Add City</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/location/city_view'); ?>">View/Edit City</a></li>
                </ul>
                 </li>
                
                <li data-toggle="collapse" data-target="#new7" class="collapsed <?php if ($explode[5] == 'home' or $explode[5] == 'email_subscribers' or $explode[5] == 'terms') {echo ' active';} ?>">
                  <a onclick='savesubcat()' href="#"><i class="fa fa-cogs"></i> Others Settings <span class="arrow"></span></a>
                
                <ul class="sub-menu collapse" id="new7">
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/home/changepassword'); ?>">Change Password</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/email_subscribers'); ?>">Email Subscriber</a></li>
                  <li><a onclick='savesubcat()' href="<?php echo base_url('admin/terms'); ?>">Terms and Conditions</a></li>
                  <!--<li><a href="<?php echo base_url('admin/email_subscribers'); ?>">Email Subscriber</a></li>-->
                </ul>
                </li>
                


                 <li>
                     <?php if ($this->session->userdata('username')) { ?>
                  <a onclick='savesubcat()' href="<?php echo base_url('admin/users/logout') ?>">
                  <i class="fa fa-sign-out"></i> Logout
                  </a><?php } ?>
                  </li>

                <!-- <li>-->
                <!--  <a href="#">-->
                <!--  <i class="fa fa-users fa-lg"></i> Users-->
                <!--  </a>-->
                <!--</li>-->
            </ul>
     </div>
</div>

<div class="clearfix"></div>
</div>
<script>
// $(".collapsed > a").click(function() {
//   $(".sub-menu").slideUp(200);
//   if (
//     $(this)
//       .parent()
//       .hasClass("active")
//   ) {
//     $(".collapsed").removeClass("active");
//     $(this)
//       .parent()
//       .removeClass("active");
//   } else {
//     $(".collapsed").removeClass("active");
//     $(this)
//       .next(".sub-menu")
//       .slideDown(200);
//     $(this)
//       .parent()
//       .addClass("active");
//   }
// });

$(".menu-content li").click(function () {
    $('ul.sub-menu').not( $(this).children() ).slideUp();
    $(this).children("ul.sub-menu").slideToggle();
});

// var header = document.getElementById("myDIV");
// var btns = header.getElementsByClassName("collapsed");
// for (var i = 0; i < btns.length; i++) {
//   btns[i].addEventListener("click", function() {
//   var current = document.getElementsByClassName("active");
//   current[0].className = current[0].className.replace(" active", "");
//   this.className += " active";
//   });
// }
</script>
<script>
    var toggle = true;

    $(".sidebar-icon").click(function() {
        if (toggle) {
            $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
            $("#menu span").css({
                "position": "absolute"
            });
        } else {
            $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
            setTimeout(function() {
                $("#menu span").css({
                    "position": "relative"
                });
            }, 400);
        }
        toggle = !toggle;
    });
</script>

</body>

</html>