<?php
// print_r($postData);die;
if (!empty($postData)) {
    $name = $postData[0]['name'];
    $country_id = $postData[0]['country_id'];
    $state_id = $postData[0]['state_id'];
    // $discription = $postData['discription'];
    // $link = $postData['link'];
    // $status = $postData['status'];
    // $image = $postData['image'];
    // $categorie_type = $postData['categorie_type'];
    // $order = $postData['order'];
    //$categorie_colour = $postData['categorie_colour'];
}
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/news/categories'); ?>">City</a></li>
            <li class="active">EDIT City</li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">Edit City</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <?php
                $editId = "";
                if (!empty($postData[0]['id'])) {
                    $editId = $postData[0]['id'];
                }
                ?>
                <form action="<?php echo base_url('admin/location/city_edit/' . $editId); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" value=""/>
                    
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select Country<span class="star-color">*</span></label>
                        <select class="form-control" name="country_id" required>
                            <option value="">Select Country</option>
                        <?php

$this->db->select('*');
$this->db->from('countries');
// $this->db->where('id',$blog['country_id']);
$query= $this->db->get();

        $data = $query->result_array();

foreach ($data as $key => $value) {
   ?>
<option value="<?= $value['id']; ?>" <?php if($value['id']==$country_id) { echo "selected"; } ?>><?= $value['name']; ?></option>

   <?php
}
        ?>
    </select>
                    </div>

                     <div class="form-group">
                        <label for="exampleInputEmail1">Select State<span class="star-color">*</span></label>
                        <select class="form-control" name="state_id" required>
                            <option value="">Select State</option>
                        <?php

$this->db->select('*');
$this->db->from('states');
// $this->db->where('id',$blog['country_id']);
$query= $this->db->get();

        $data = $query->result_array();

foreach ($data as $key => $value) {
   ?>
<option value="<?= $value['id']; ?>" <?php if($value['id']==$state_id) { echo "selected"; } ?>><?= $value['name']; ?></option>

   <?php
}
        ?>
    </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="exampleInputEmail1">City <span class="star-color">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>" required>
                    </div>
                   
               
                    
					
                 
					
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Update</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
	
</script>