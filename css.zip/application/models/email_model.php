<?php
	class Email_model extends CI_Model {
 
	    
        function __construct(){
            parent :: __construct();
            $this->load->model('home_model');
           
            //$this->load->library('parser');
            
        }
        
        public function send_mail($data){
           $data['data']=$data;
            
            return $string = $this->parser->parse('email_templates/order_stat', $data, TRUE);	
        }
        
    }
    
    

	
?>
    
    
    
