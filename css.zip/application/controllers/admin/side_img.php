<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class side_img extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/side_img_model');
        $this->load->library('image_lib');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }
    
    // public function index()
    // {
    //     $data['notice'] = $this->notice_model->getNoticeRecords();
    //     adminLoadView('notice/notice_list', $data);
    // }
    
    public function index()
    {

        
         $data['side_img'] = $this->side_img_model->getSideImgRecords();
        //  echo  $this->db->last_query();die;
        adminLoadView('side_img/list', $data);
    }
    
    public function add_side_img()
    {

        $postData = array();
        //
        if ($_POST) {
           
            
            $data['postData'] = $postData = $_POST;
            $data['error'] = "";
              
              
              if($_POST['media_type']=='img'){
              
            if (!empty($_FILES['left_img'])) {
                
                $data['error'] = array();
                $file_name_l  = time() . $_FILES['left_img']['name'];
                $file_size  = $_FILES['left_img']['size'];
                $file_tmp   = $_FILES['left_img']['tmp_name'];
                $file_type  = $_FILES['left_img']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['left_img']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif", "pdf");

                // if (in_array($file_ext, $expensions) === false) {
                //     $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                // }

                // $insertData['left_img'] = $file_name_l;

                if (empty($data['error']) == true) {
                    
                    move_uploaded_file($file_tmp, "./upload/side_img/left_img/" . $file_name_l);
                    // var_dump($file_name_l);
            
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/side_img/left_img/' . $file_name_l;
                    $thumb['new_image']         = './upload/side_img/left_img/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();


                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/side_img/left_img/' . $file_name_l;
                    $thumb2['new_image']         = './upload/side_img/left_img/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/side_img/left_img/' . $file_name_l);
                    
                }
                
            }
            
            if (!empty($_FILES['right_img'])) {

                $data['error'] = array();
                $file_name_r  = time() . $_FILES['right_img']['name'];
                $file_size  = $_FILES['right_img']['size'];
                $file_tmp   = $_FILES['right_img']['tmp_name'];
                $file_type  = $_FILES['right_img']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['right_img']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif", "pdf");

                // if (in_array($file_ext, $expensions) === false) {
                //     $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                // }

                // $insertData['right_img'] = $file_name_r;

                if (empty($data['error']) == true) {
                    
                    move_uploaded_file($file_tmp, "./upload/side_img/right_img/" . $file_name_r);
            //         var_dump($_FILES);
            
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/side_img/right_img/' . $file_name_r;
                    $thumb['new_image']         = './upload/side_img/right_img/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();


                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/side_img/right_img/' . $file_name_r;
                    $thumb2['new_image']         = './upload/side_img/right_img/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/side_img/right_img/' . $file_name_r);
                    
                }
                
            }
            
              }
            
            //}
            // if ($formValidation && empty($data['error'])) {
                    
             
                $newsdate1 =  date('Y-m-d', strtotime($postData['valid_date']));
                $newsdate =  date('Y-m-d');
            //   var_dump($file_name_l);
//  echo "<pre>";print_r($file_name_l);die;
                $insertData = array(
                    'category_id'                 => $postData['manage_category'],
                    'sub_category_id'                 => $postData['sub_category'],
                    'page_host'                 => $postData['host'],
                    'media_type'                 => $postData['media_type'],
                    'l_sence_code'                 => $postData['l_sence_code'],
                    'r_sence_code'                 => $postData['r_sence_code'],
                    'l_discription'                 => $postData['l_discription'],
                    'r_discription'                 => $postData['r_discription'],
                    'valid_date'                 => $newsdate1,
                    'link'                 => $postData['link'],
                    'status'                 => $postData['status'],
                    'created_date'                  => $newsdate
                    
                    
                );
                
                
                if (!empty($_FILES['left_img'])) {
                    $insertData['left_img'] = $file_name_l;
                } else {
                    $insertData['left_img'] = '';
                }
                
                if (!empty($_FILES['right_img'])) {
                    $insertData['right_img'] = $file_name_r;
                } else {
                    $insertData['right_img'] = '';
                }
                
                // if (!empty($_POST['l_discription'])) {
                //     $insertData['l_discription'] = $postData['l_discription'];
                // } else {
                //     $insertData['l_discription'] = '';
                // }
                
                // if (!empty($_POST['r_discription'])) {
                //     $insertData['r_discription'] = $postData['r_discription'];
                // } else {
                //     $insertData['r_discription'] = '';
                // }
                
                // echo "<pre>";print_r($insertData);die;
                $return = addUpdateRecord('side_img', '', '', $insertData);


                
                if ($return) {
                    $this->session->set_flashdata('success', 'News added successfully.');
                    redirect('admin/side_img');
                }
            // } else {

            //     if (validation_errors()) {
            //         if (validation_errors()) {
            //             $data['error'] = validation_errors();
            //         }
            //     }
            // }
        }
        
        
        adminLoadView('side_img/add_img');
    }
        
    public function edit($id = null, $user_id = 0)
    {


        if (empty($id)) {
            redirect('admin/side_img');
        }

        if ($_POST) {
            
            $postData = $_POST;
            $data['error'] = "";
        
            
          $myimg_fimename_l = $postData['oldimage_l'];
            if (isset($_FILES['left_img']) && !empty($_FILES['left_img']['name'])) {

                $data['error'] = array();
                $file_name_l  = time() . $_FILES['left_img']['name'];
                $file_size  = $_FILES['left_img']['size'];
                $file_tmp   = $_FILES['left_img']['tmp_name'];
                $file_type  = $_FILES['left_img']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['left_img']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif","pdf");

                

                // $updateData['left_img'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/side_img/left_img/" . $file_name_l);
                     $myimg_fimename_l = $file_name_l;
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/side_img/left_img/' . $file_name_l;
                    $thumb['new_image']         = './upload/side_img/left_img/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();

                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/side_img/left_img/' . $file_name_l;
                    $thumb2['new_image']         = './upload/side_img/left_img/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/side_img/left_img/' . $file_name_l);
                }
            }
            
            
            $myimg_fimename_r = $postData['oldimage_r'];
            if (isset($_FILES['right_img']) && !empty($_FILES['right_img']['name'])) {

                $data['error'] = array();
                $file_name_r  = time() . $_FILES['right_img']['name'];
                $file_size  = $_FILES['right_img']['size'];
                $file_tmp   = $_FILES['right_img']['tmp_name'];
                $file_type  = $_FILES['right_img']['type'];
                $file_ext   = strtolower(end(explode('.', $_FILES['right_img']['name'])));

                $expensions = array("jpeg", "jpg", "png", "gif","pdf");

                

                // $updateData['image'] = $file_name;

                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/side_img/right_img/" . $file_name_r);
                     $myimg_fimename_r = $file_name_r;
                    // Create thumnail or resize image
                    $thumb['image_library']     = 'gd2';
                    $thumb['source_image']      = './upload/side_img/right_img/' . $file_name_r;
                    $thumb['new_image']         = './upload/side_img/right_img/orig/';
                    $thumb['create_thumb']      = false;
                    $thumb['maintain_ratio']    = false;
                    $thumb['width']             = 635;
                    $thumb['height']            = 400;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb);
                    $this->image_lib->resize();

                    // Create thumnail or resize image
                    $thumb2['image_library']     = 'gd2';
                    $thumb2['source_image']      = './upload/side_img/right_img/' . $file_name_r;
                    $thumb2['new_image']         = './upload/side_img/right_img/thumb/';
                    $thumb2['create_thumb']      = false;
                    $thumb2['maintain_ratio']    = false;
                    $thumb2['width']             = 165;
                    $thumb2['height']            = 120;
                    $this->image_lib->clear();
                    $this->image_lib->initialize($thumb2);
                    $this->image_lib->resize();
                    unlink('./upload/side_img/right_img/' . $file_name_r);
                }
            }
    // echo "<pre>";print_r($myimg_fimename_l);
    // echo "<pre>";print_r($myimg_fimename_r);die;
$newsdate1 =  date('Y-m-d', strtotime($postData['valid_date']));
                $updateData['category_id'] = $postData['manage_category'];
                $updateData['sub_category_id'] = $postData['sub_category'];
                $updateData['page_host'] = $postData['host'];
                $updateData['media_type'] = $postData['media_type'];
                $updateData['l_sence_code'] = $postData['l_sence_code'];
                $updateData['r_sence_code'] = $postData['r_sence_code'];
                
                $updateData['link'] = $postData['link'];
                $updateData['valid_date'] = $newsdate1;
                $updateData['l_discription'] = $postData['l_discription'];
                $updateData['r_discription'] = $postData['r_discription'];
                $updateData['status'] = $postData['status'];
                
             $updateData['left_img'] = $myimg_fimename_l;
             $updateData['right_img'] = $myimg_fimename_r;

                $return = addUpdateRecord('side_img', 'id', $id, $updateData);

                   

                if ($return) {
                    $this->session->set_flashdata('success', 'News updated successfully.');
                    redirect('admin/side_img');
                }
            // } else {
            //     if (validation_errors()) {
            //         if (validation_errors()) {
            //             $data['error'] = validation_errors();
            //         }
            //     }
            // }
            $data['postData'] = $postData;
        } else {
           
            $postData = $this->side_img_model->getSideImgRecords11($id);
            $child_categoryid = $postData['sub_category_id'];
        $this->db->select('*');
        $this->db->from('news_categories');
        $this->db->where('id', $child_categoryid);
        $getchildcat = $this->db->get();
        $data['childcategoryname'] = $getchildcat->result_array();
            $data['postData'] = $postData;
        }


        //$allcategory = $this->dashboard_model->getNoticeRecords11();
        

        //pr($allcountry);
        $data['user_id'] = $user_id;
        //$data['allcategory'] = $allcategory;
        

        adminLoadView('side_img/edit', $data);
    }
    
    public function delete($id = null)
    {

        if (empty($id)) {
            redirect('admin/notice');
        }

        $deleteData = $this->side_img_model->getRecordById($id);
        $delete = deleteRecordById('side_img', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'News deleted successfully.');
            redirect('admin/side_img');
        }
    }
    
}
?>