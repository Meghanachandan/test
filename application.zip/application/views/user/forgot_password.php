
<style>
    section {
        background-color: #FFF;
    }
</style>
<section id="form"><!--form-->
	<div class="container">
		<div class="row">
		<div style="width:95%;max-width: 550px;margin:20px auto;">
        	<div class="col-sm-12">
            	
                <div class="categoryproduct text-center" style="padding-top:40;">  
                    <div class="content-heading">
						  <h2 class="title-head">Forgot Password</h2>
						  <BR>
						<BR>
                    </div>
                </div>
                                   
			</div>
			<div class="col-sm-12 text-center">
			
				<div class="login-form social-buttons"><!--login form-->
				
				    <BR>
                    <?php if(!empty($this->session->flashdata('success')))
                    { ?>
                    <div class="alert alert-success" role="alert">
                    <?php echo $this->session->flashdata('success'); ?>
                    </div>
                    <?php }
                    
                    else { ?>
                        
					<h5>Enter your email address and we'll send you a link to reset your password.</h5>
				
						
                        
                        <?php if(!empty($this->session->flashdata('invalid')))
                        { ?>
                        <div class="alert alert-danger" role="alert">
                        <?php echo $this->session->flashdata('invalid'); ?>
                        </div>
                        <?php } ?>
                        
					<form action="<?php echo base_url('user/forgetsave'); ?>" method="post">
						<div class="form-group">
							<input type="email" class="form-control m-0" placeholder="Email Address" name="email" required="required">
						</div>
						<!--within 24 hours-->
						<p>
						<span>Please check your spam/junk mail folder if you do not see the password reset email.</span>
						</p>
						<button type="submit" title="Submit" class="btn-sm btn-secondary" >Submit</button>
					</form>
						<BR>
					<?php
                    }
                    ?>
						<BR>
						    
					<h5 class="text-center" ><a title="Return to Log in" href="<?php echo base_url('user/login'); ?>" style="color: #333;text-decoration:underline;">Return to Log in</a></h5>
      		 	</div><!--/login form-->
		
			</div>
		</div>
		</div>
	</div>
</section><!--/form-->