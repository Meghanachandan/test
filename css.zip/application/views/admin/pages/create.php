<?php
	if (!empty($postData)) {
		$name 		= $postData['name'];
		$discription= $postData['discription'];
		$link 		= $postData['link'];
		$status 	= $postData['status'];
	}
?>
<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li><a href="<?php echo base_url('admin/pages'); ?>">PAGES</a></li>
			<li class="active">ADD PAGE</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">ADD NEW PAGE</h2>
		<div class="graph-form">
			<?php
				if(!empty($error)){ 
				?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
			} ?>
			<div class="form-body">
				<form action="<?php echo base_url('admin/pages/add'); ?>" method="post">
					<input type="hidden" value=""/>
					<div class="form-group">
						<label for="exampleInputEmail1">Name <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
					</div>
					<div class="form-group">
						<div class="row">
                            <div class="col-lg-8">
                                <label for="exampleInputPassword1">Description <span class="star-color">*</span></label> 
                                <textarea name="discription" rows="10" cols="80" id="discription"  name="discription" required><?php echo $discription; ?></textarea>
                            </div>
                        </div>
					</div> 
					<div class="form-group">
						<label for="exampleInputPassword1">Link<span class="star-color">*</span></label> 
						<input type="text" class="form-control" id="link"  name="link"  value="<?php echo $link; ?>">
					</div>
					<div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Status</label>
						<div class="radio block"><label>
						<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked"  />Active</label></div>
						<div class="radio block">
						<label><input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive</label></div>
					</div>
					<button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button> 
				</form> 
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( 'discription' );
</script>