<style>
    #imgdiv {
        width: 160px;
        float: left;
        margin-left: 0px;
    }

    #reload {
        float: left;
        width: 23px;
        margin-top: 12px;
    }

    section {
        background-color: #FFF;
    }

    .error {
        color: #84022e;
    }
</style>
<section id="form">
    <!--form-->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div style="width:95%;max-width: 350px;margin:20px auto;">
                    <?php if (!empty($serror)) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo $serror; ?>
                        </div>
                    <?php } ?>
                    <?php //if ($this->session->flashdata('success')) { 
                    ?>
                    <div style="display: none;" id="alert_success" class="alert alert-success"></div>
                    <?php //} 
                    ?>
                    <div class="signup-form">
                        <!--sign up form-->
                        <h3 class="omb_authTitle mb-4">Signup or <a href="<?php echo base_url('user/login' . $page); ?>">Login</a></h3>
                        <!-- <form autocomplete="off" action="<?php echo base_url('user/signup'); ?>" method="post" novalidate> -->

                        <div class="form-group">
                            <input type="text" id="first_name" name="first_name" class="form-control m-0" placeholder="First Name" value="<?php echo $userData['first_name']; ?>" />
                        </div>
                        <div class="form-group">
                            <input type="text" id="last_name" name="last_name" class="form-control m-0" placeholder="Last Name" value="<?php echo $userData['last_name']; ?>" />
                        </div>
                        <div class="form-group">
                            <input type="email" id="email" name="email" class="form-control m-0" placeholder="Email Address" value="<?php echo $userData['email']; ?>" />
                        </div>
                        <div class="form-group">
                            <input type="text" id="phone_mobile" name="phone_mobile" class="form-control m-0" placeholder="phone no" value="<?php echo $userData['phone_mobile']; ?>" />
                        </div>

                        <div class="form-group row">
                            <!-- Default unchecked -->
                            <div class="col-12">
                                <label>Gender</label>
                            </div>
                            <div class="col-3">
                                <div class="custom-control custom-radio">
                                    <input type="radio" value="Male" class="custom-control-input" id="defaultUnchecked" name="gender" checked>
                                    <label class="custom-control-label" for="defaultUnchecked">Male</label>
                                </div>
                            </div>
                            <div class="col-3">
                                <!-- Default checked -->
                                <div class="custom-control custom-radio">
                                    <input type="radio" value="Female" class="custom-control-input" id="defaultChecked2" name="gender">
                                    <label class="custom-control-label" for="defaultChecked2">Female</label>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="custom-control custom-radio">
                                    <input type="radio" value="Other" class="custom-control-input" id="defaultChecked3" name="gender">
                                    <label class="custom-control-label" for="defaultChecked3">Other</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" id="password" value="" class="form-control m-0" placeholder="Password" />
                            <span toggle="#password" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                        </div>
                        <div class="form-group row mx-0">
                            <div class="col-7  p-0 ">
                                <div class="row mx-0">
                                    <div id="imgdiv" class="col-10 p-0">
                                        <img id="img" src="<?php echo base_url(); ?>images/captcha/captcha.php">
                                    </div>
                                    <div class="col-2 p-0">
                                        <img id="reload" src="<?php echo base_url(); ?>images/captcha/reload.png">
                                    </div>
                                </div>
                            </div>
                            <div class="col-5 p-0">
                                <input id="captcha1" name="captcha" class="form-control m-0" type="text" placeholder="Enter Above Image Text Here">
                            </div>
                        </div>
                        <button id="submit_button" onclick="return validateSignForm();" title="Create an Account" class="btn-sm btn-secondary">Create an Account</button>
                        <button id="submit_button_loader" style="display: none;" title="Create an Account" class="btn-sm btn-secondary">Create an Account <i class="fa fa-circle-notch fa-spin" style="font-size:24px"></i></button>
                        <!-- </form> -->
                    </div>
                    <!--/sign up form-->
                </div>
            </div>
        </div>
    </div>
</section>
<!--/form-->
<!-- <script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script> -->
<script>
    function validateSignForm() {
        var captcha = $("#captcha1").val();
        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        var email = $('#email').val();
        var password = $('#password').val();
        var phone_mobile = $('#phone_mobile').val();
        var gender= $("[name='gender']:checked").val();
        $('#submit_button').hide();
        $('#submit_button_loader').show();

        $(".error").remove();
        var error = 0;
        if (first_name.length < 1) {
            $('#first_name').after('<span class="error">This field is required</span>');
            error = 1;
        }
        if (last_name.length < 1) {
            $('#last_name').after('<span class="error">This field is required</span>');
            error = 1;
        }
        if (email.length < 1) {
            $('#email').after('<span class="error">This field is required</span>');
            error = 1;
        } else {
            //var regEx = /^[A-Z0-9][A-Z0-9._%+-]{0,63}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/;
            var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            var validEmail = reg.test(email);
            if (validEmail == false) {
                $('#email').after('<span class="error">Enter a valid email</span>');
                error = 1;
            }
        }

        if (password.length < 8) {
            $('#password').after('<span class="error">Password must be at least 8 characters long</span>');
            error = 1;
        }
        

        if (phone_mobile.length < 10) {
            $('#phone_mobile').after('<span class="error">This field is required</span>');
            error = 1;
        } else {
            if (/^\d{10}$/.test(phone_mobile)) {
                // value is ok, use it
            } else {
                //alert("Invalid number; must be ten digits")
                $('#phone_mobile').after('<span class="error">Invalid number. must be ten digits</span>');
                error = 1;
            }

        }



        if (captcha.length < 1) {
            $('#captcha1').after('<span class="error">This field is required</span>');
            error = 1;
        }
        
        

        if (error == 1) {
            //alert("Fill All Fields");
            $('#submit_button').show();
            $('#submit_button_loader').hide();
            return false
        } else {
            //validating CAPTCHA with user input text
            //var dataString = 'captcha=' + captcha;
            var dataString = {
                'captcha': captcha,
                'first_name': first_name,
                'last_name': last_name,
                'email': email,
                'password': password,
                'gender': gender,
                'phone_mobile': phone_mobile
            };
            $.ajax({
                type: "POST",
                dataType: "text",
                url: "<?php echo base_url('user/signup'); ?>",
                data: dataString,
                success: function(html) {
                    //alert(html);
                    $("#captcha1").val('');
                    $('#first_name').val('');
                    $('#last_name').val('');
                    $('#email').val('');
                    $('#password').val('');
                    $('#phone_mobile').val('');
                    $("[name='gender']").val('');
                    $("#alert_success").scrollTop(0);
                    $("#alert_success").html(html);
                    $("#alert_success").show();
alert("Account Created Successfully.Please Check Your Mail ID and Active Your Account")
                    setTimeout(location.href = '<?php  echo base_url(); ?>user/login', 4000);
                }
            });
            return true;
        }
    }

    $(document).ready(function() {

        $("#reload").click(function() {
            $("img#img").remove();
            var id = Math.random();
            $('<img id="img" src="<?php echo base_url(); ?>images/captcha/captcha.php?id=' + id + '"/>').appendTo("#imgdiv");
            id = '';
        });



        //validation function
        //$('#button').click(function() {

        //});
    });

    $('.toggle-password').on('click', function() {
        $(this).toggleClass('fa-eye fa-eye-slash');
        let input = $($(this).attr('toggle'));
        if (input.attr('type') == 'password') {
            input.attr('type', 'text');
        } else {
            input.attr('type', 'password');
        }
    });

    $('.form-control').keypress(function (e) {
        if (e.which == 13) {
            validateSignForm();
        }
    });
</script>