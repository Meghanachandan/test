<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->database();
        $this->load->model('Admin_Model');
        $this->load->library('session');
        $this->load->library('upload');
        if(isset($_SESSION['reg_pkid']))
        {
          
        } else{
          redirect("AdminLogin/login");
        }
    }


    public function latest_news()
    {
        $sql = "SELECT * FROM `news` WHERE `news_isactive`=1 ORDER BY `news_date` DESC";
        $data['news'] = $this->Admin_Model->select($sql);
        $this->load->view('latest_news',$data);
    }

    public function logout()
	{
		$this->session->sess_destroy();
		redirect("AdminLogin/login");
	}

}