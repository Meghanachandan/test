<div class="blog-post-area my-overlay" id="blog-post-area">
	<?php if(!empty($getBlogs)) { ?>
		<?php 
			$i=1;
			foreach ($getBlogs as $blog) {
				$css = "";
				if ($i > 1) {
					$css = "mt20";
				}
		?>
			<div class="single-blog-post <?php echo $css; ?>">
				<a title="<?php echo $blog->title; ?>" href="<?php echo base_url('blogs/post/'.$blog->slug); ?>">
					<img src="<?php echo base_url("upload/blogs/".$blog->image) ?>" alt="" class="img-responsive">
				</a>
				<h3><?php echo $blog->title; ?> </h3>
				<div class="post-meta">
					<ul>
						<!-- <li><i class="fa fa-user"> &nbsp; Author </i>  dixit shah </li> -->
						<li><i class="fa fa-calendar"> &nbsp; Posted </i> <?php echo  date('M d, Y', strtotime($blog->created_date)); ?></li>
					</ul>
				</div>
				<p class="blog-para">
					<?php 
						if (strlen($blog->discription) > 100) {
	                        $stringCut = substr($blog->discription, 0, 100);
	                        $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
	                    } else {
	                        $string = $blog->discription;
	                    } 
	                    echo $string;
					?>
				</p>
				<a title="<?php echo $blog->title; ?>" class="btn btn-primary" href="<?php echo base_url('blogs/post/'.$blog->slug); ?>">Read More</a>
			</div>
			<?php 
				if($i != count($getBlogs)){
					echo '<hr>';
				}
			?>
    <?php 	
    			$i++;
    		}
    	} ?>
    	<br>
	<?php echo $paginationCount; ?>
</div>