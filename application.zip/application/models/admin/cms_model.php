<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cms_model extends CI_Model {
	
	public function __construct(){
		$this->load->database();
	}
	
	//insert Page Data
	public function insert_page()
	{	
	 
	$data = array(
			'label' => $this->input->post('page_title'),
			'content' => $this->input->post('tst_content')
		);

		return $this->db->insert('tbl_cms', $data);
	}
	
	//delete Page Data
	public function delete_page($id)
	{	
				$this->db->where('id', $id);
		return 	$this->db->delete('tbl_cms');
		
	}	
	
}
?>