 
 
 


<style>
    #imgdiv {
        width: 160px;
        float: left;
        margin-left: 20px
    }

    #reload {
        float: right;
        margin-right: 40px
    }

    section {
        background-color: #FFF;
    }

   /*******************************
* ACCORDION WITH TOGGLE ICONS
* Does not work properly if "in" is added after "collapse".
*******************************/
	.panel-group .panel {
		border-radius: 0;
		box-shadow: none;
		border-color: #EEEEEE;
	}

	.panel-default > .panel-heading {
		padding: 0;
		border-radius: 0;
		color: #212121;
		background-color: #FAFAFA;
		border-color: #EEEEEE;
	}

	.panel-title {
		font-size: 14px;
	}

	.panel-title > a {
		display: block;
		padding: 15px;
		text-decoration: none;
	}

	.more-less {
		float: right;
		color: #212121;
	}

	.panel-default > .panel-heading + .panel-collapse > .panel-body {
		border-top-color: #EEEEEE;
	}

/* ----- v CAN BE DELETED v ----- */

.demo-footer {
	position: fixed;
	bottom: 0;
	width: 100%;
	padding: 15px;
	background-color: #212121;
	text-align: center;
}

.demo-footer > a {
	text-decoration: none;
	font-weight: bold;
	font-size: 14px;
	color: #fff;
}
</style>
<section id="form">
    <!--form-->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="categoryproduct " style="padding-left:0;">
                    <div class="content-heading">
                        <h2 class="title-head">FAQ</h2>
                    </div>
                </div>
                <div class="panel-group" id="accordion">

                    <?php foreach ($faqs as $faq) { ?>
                        <div style="clear:both;"></div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo $faq['id']; ?>">
                                        <?php echo $faq['title']; ?>
                                    </a>
                                </h4>
                            </div>
                            <div id="collapse_<?php echo $faq['id']; ?>" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <?php echo $faq['discription']; ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>



