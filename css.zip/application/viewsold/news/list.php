<!--<link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet">-->
<!-- <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet"> -->


<style>
	#imgdiv {
		width: 160px;
		float: left;
		margin-left: 20px
	}

	#reload {
		float: right;
		margin-right: 40px
	}

	section {
		background-color: #FFF;
	}

	.table-bordered a {
		color: #000;
	}

	.table-bordered a:hover {
		color: #CCC;
	}
</style>
<section id="form">
	<!--form-->
	<div class="container">
		<div class="row">
			<div class="col-sm-12 mt-4 mb-5">
				<!--
				<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
				<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
                -->
				<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
				<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
				<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
				<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>



				<div class="graph-visual tables-main">
					<h3 class="inner-tittle two">MY NEWS</h3>
					<div class="col-sm-12 text-right" style="margin-top:-30px;margin-bottom:15px;padding: 0;">
						<a style="cursor: pointer;" onclick="loadcategorynrws(0);">All News &nbsp;&nbsp;</a>
						<select name="cate" onchange="loadcategorynrws(this.value);">
							<option value="">Select category</option>
							<?php foreach ($category as $cat) { ?>
								<option value="<?php echo $cat['id']; ?>" <?php if ($cat['id'] == $selected_category) {
																				echo ' selected="selected" ';
																			} ?>><?php echo $cat['title']; ?></option>
							<?php } ?>
						</select>

					</div>
					<?php
					if ($this->session->flashdata('success')) {
					?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
																																			} ?>
					<div class="graph">
						<div class="tables">
							<table class="display responsive" id="example-table">
								<thead>
									<tr>
										<th>Id</th>
										<th width="180px">Title</th>
										<th>Image</th>
										<!-- <th>Slug</th> -->
										<th>Date</th>
										<th>Status</th>
										<th style="width: 15%;">Action</th>
									</tr>
								</thead>
								<?php
								$i = 0;
								foreach ($news_list as $key => $news) {
									$status = (!empty($news['status']) && $news['status'] == '1') ? 'Active' : 'Deactive';
									$i++; ?>
									<tr>
										<td><?php echo $i; ?></td>
										<td width="180px">
											<?php if ($status == 'Deactive') { ?>
												<?php echo $news['title']; ?>
												&nbsp; - &nbsp;
												<a style="font-size: 12px;color: #06a9da;" href="<?php echo base_url() . 'home/news_view/' . $news['id']; ?>?preview=<?php echo base64_encode($news['reporter']); ?>" target="_blank">
													Preview
												</a>
												&nbsp;/&nbsp;
												<a style="font-size: 12px;color: #06a9da;" href="<?php echo base_url() . 'news/activate_news/' . $news['id']; ?>">
													Active
												</a>
											<?php } else { ?>
												<a href="<?php echo base_url() . cleanNewsUrl($news); ?>" target="_blank">
													<?php echo $news['title']; ?>
												</a>
											<?php	} ?>
											<br>
											<i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo $news['city']; ?>, <?php echo $news['state']; ?>, <?php echo $news['country']; ?>
											<br>
											<i class="fa fa-list" aria-hidden="true"></i> <?php echo getNewscategory($news['categorise']); ?>
										</td>
										<?php
										if (trim($news['image']) == '') {
											$news['image'] = 'no-image.png';
										}
										?>
										<td><?php echo "<img src='" . base_url('upload/news/thumb/' . $news['image']) . "' height='80px' width='90px'/>"; ?></th>

											<!-- <th><?php echo $news['slug']; ?></th> -->
										<td> <?php echo date('D/M d, Y, h:i A', strtotime($news['date'])); ?></td>
										<td><?php echo $status; ?></td>
										<td>
											<a href='<?php echo base_url('news/edit/' . $news['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp;
											<a onclick='return confirm("Are you sure? you want to delete this news!")' href='<?php echo base_url('news/delete/' . $news['id']); ?>'><i class="fa fa-trash-o"></i></a>
										</td>
									</tr>
								<?php } ?>
							</table>
						</div>
					</div>
					<!--//graph-visual-->
				</div>
			</div>
			<script>
				$(document).ready(function() {
					$('#example-table').DataTable({
						"pagingType": "full_numbers",
						"lengthMenu": [
							[10, 25, 50, -1],
							[10, 25, 50, "All"]
						]
					});
				});

				function loadcategorynrws(val) {
					location.href = "<?php echo base_url(); ?>news/my_news?cat=" + val;
				}
			</script>
		</div>
	</div>
	</div>
</section>