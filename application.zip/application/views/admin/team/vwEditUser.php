<?php //echo "<pre>";print_r($alldepartments);die; ?>
<?php $this->load->view('admin/vwHeader'); ?>
<link href="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<style>
    /*** General styles ***/
    /*
    .panel {
        box-shadow: none;
    }

    .panel-heading {
        border-bottom: 0;
    }

    .panel-title {
        font-size: 17px;
    }

    .panel-title>small {
        font-size: .75em;
        color: #999999;
    }

    .panel-body *:first-child {
        margin-top: 0;
    }

    .panel-footer {
        border-top: 0;
    }

    .panel-default>.panel-heading {
        color: #333333;
        background-color: transparent;
        border-color: rgba(0, 0, 0, 0.07);
    }

    form label {
        color: #999999;
        font-weight: 400;
    }

    .form-group input {
        margin: 0px;
    }

    .form-horizontal .form-group {
        margin-left: 0px;
        margin-right: 15px;
    }

    @media (min-width: 768px) {
        .form-horizontal .control-label {
            text-align: right;
            margin-bottom: 0;
            padding-top: 7px;
        }
    }
*/
    .profile__contact-info-icon {
        float: left;
        font-size: 18px;
        color: #999999;
    }

    .profile__contact-info-body {
        overflow: hidden;
        padding-left: 20px;
        color: #999999;
    }

    .profile-avatar {
        width: 200px;
        position: relative;
        margin: 0px auto;
        margin-top: 196px;
        border: 4px solid #f3f3f3;
    }

    .circle {
        border-radius: 1000px !important;
        overflow: hidden;
        width: 128px;
        height: 128px;
        border: 8px solid rgba(255, 255, 255, 0.7);
        position: absolute;
        top: 72px;
    }

    .border_with_shadow {
        border: 1px solid #f2f2f2;
        box-shadow: 2px 2px 8px #ccc;
    }
</style>
<?php
define("NEW_USER", "Edit Team Member");
define("ERRORS", "Errors");
define("BASIC_INFORMATION", "Basic Information");
define("PREFIX", "Prefix");
define("FIRST_NAME", "First Name");
define("LAST_NAME", "Last Name");
define("SUFFIX", "Suffix");
define("OTHER_INFORMATION", "Account Setting");
define("EMAIL", "Email");
define("PASSWORD", "Password");
define("HOME_PHONE", "Home Phone");
define("CELL_PHONE", "Cell Phone");
define("ALLOW_COSTUME", "Allow Costume");
define("ADD_USER", "Add User");
define("NO", "No");
define("YES", "Yes");
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1><?php echo NEW_USER; ?></h1>
            <ol class="breadcrumb">
                <li><a href="Users"><i class="icon-dashboard"></i> Users</a></li>
                <li class="active"><i class="icon-file-alt"></i> <?php echo NEW_USER; ?></li>
                <a href="<?php echo base_url(); ?>admin/team"> <button class="btn btn-primary" type="button" style="float:right;">Back</button></a>
                <div style="clear: both;"></div>
            </ol>
        </div>
    </div><!-- /.row -->
    <?php
    if (validation_errors() != '') { ?>

        <div class="alert alert-danger" role="alert">
            <!-- <button class="close" data-dismiss="alert">x</button> -->
            <strong><?php echo ERRORS; ?>!</strong> <?php echo validation_errors(); ?>
        </div>
    <?php } ?>
    <?php
    if ($this->session->flashdata('flash_message')) {
        echo '<div class="alert bg-success"><a class="close" data-dismiss="alert">x</a><strong>' . $this->session->flashdata('flash_message') . '</strong></div>';
    }
    ?>
    <?php
    $attributes = array('name' => 'frm_listadmin', 'class' => 'site-setting', 'autocomplete' => 'off', 'enctype' => 'multipart/form-data');
    echo form_open('admin/team/edit_member/' . $id, $attributes);
    ?>
    <div class="row">
        <div class="col-lg-12 clearfix">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo BASIC_INFORMATION; ?>
                </div>

                <div class="panel-body">
                    
                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Photo</label>
                        </div>
                        <div class="col-sm-2">
                            <div class=" d-flex justify-content-center align-items-center rounded" style="height: 140px; background-color: rgb(233, 236, 239);padding: 2px;">
                                <?php if ($user['picture']) {
                                    echo '<img class="profile-pic" src="' . base_url($user['picture']).'" width="100%" height="100%" />';
                                } else { ?>
                                    <img class="profile-pic" src="<?php echo base_url(); ?>upload/team_pic/default.png" width="100%" height="100%" />
                                <?php } ?>
                            </div>
                            <input type="hidden" name="old_dp_pic" value="<?= $user['picture'] ?>" id="" />
                            <div class="mt-2 p-0">
                                <div style="display: none;">
                                    <input type="file" name="dp_pic" id="profile_image" />
                                </div>
                                <button class="btn btn-sm btn-secondary mx-0 upload-button" type="button">
                                    <i class="fa fa-fw fa-camera"></i>
                                    <span>Change Photo</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Name</label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="name" value="<?php echo $user['name']; ?>">
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Email</label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="email" value="<?php echo $user['email']; ?>">
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Mobile No</label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="phone" value="<?php echo $user['phone']; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Department</label>
                        </div>
                        <div class="col-sm-9">
                            <select class="form-control pcategory" name="department">
                                <option value="">Select Department</option>
                                <?php foreach ($alldepartments as $desi) {
                                ?>
                                    <option <?php if ($user['department_id'] == $desi->id) {
											echo ' selected="selected" ';
										} ?> value="<?php echo $desi->id; ?>"><?php echo $desi->department; ?></option>
                                <?php } ?>
                            </select>
                            <span class="error_message" id="news_country_error"></span>
                        </div>
                    </div>
                    
                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Designation</label>
                        </div>
                        <div class="col-sm-9">
                            <select class="form-control ccategory" name="designation">
                              <?php
$pcategory = $user['department_id'];
// echo $pcategory;
        $this->db->select('*');
        $this->db->from('designations');
        $this->db->where("depart_id",$pcategory);
        $query = $this->db->get();
        $result = $query->result_array();
        echo "<option value=''>Select Designation</option>";
        foreach($result as $value)
        {
        $child_category = $value['depart_id'];
        $this->db->select('id,designation');
        $this->db->from('designations');
        $this->db->where("depart_id",$child_category);
        $query11 = $this->db->get();
        // echo $this->db->last_query();die;
        $result11 = $query11->result_array();
      ?>
     <option  <?php if ($user['designation'] == $result11[0]['id']) {
											echo ' selected="selected" ';
										} ?> value="<?= $result11[0]['id']; ?>"><?= $result11[0]['designation']; ?></option>;
<?php
        }
							?>  
                            </select>
                            <script>
$(document).ready(function(){
    $("select.pcategory").change(function(){
        var pcategory = $(".pcategory option:selected").val();
        // alert(pcategory);
        $.ajax({
            type: "POST",
            url: "http://newssyn.com/admin/pages/desgination",
            data: { pcategory : pcategory } 
        }).done(function(data){
        	// alert(data);
        	// alert(data);
           $(".ccategory").html(data);
        });
    });
});
</script>
                            <span class="error_message" id="news_country_error"></span>
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Short Description</label>
                        </div>
                        <div class="col-sm-9">
                            <textarea class="form-control" type="text" rows="3" name="description" value="<?= $user['description']; ?>"><?= $user['description']; ?></textarea>
                        </div>
                    </div>


                </div>

            </div>
        </div>

    </div>
    <!-- /row -->
    <div class="text-center">
        <button type="submit" class="btn btn-default btn-lg"><?php echo "Update User"; ?></button>
    </div>
    </form>
</div>
<!-- /#page-wrapper -->
<br />
<br />
<br />

</body>

</html>
<?php $this->load->view('admin/vwFooter'); ?>
<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        var readURL = function(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('.profile-pic').attr('src', e.target.result);
                    console.log(e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#profile_image").on('change', function() {
            readURL(this);
        });

        $(".upload-button").on('click', function() {
            $("#profile_image").click();
        });
    });

    $(document).ready(function() {
        $('#news_country').select2({
            placeholder: "Select country",
            allowClear: true
        });
        $('#news_state').select2({
            placeholder: "Select state",
            allowClear: true
        });
        $('#news_city').select2({
            placeholder: "Select city",
            allowClear: true
        });
        $('#categorise').select2({
            placeholder: "Select categorise",
            allowClear: true
        });
        $('#news_country').val('<?php echo $user['address_country']; ?>');
        $('#news_country').trigger('change');
        news_getcountrystate('<?php echo $user['address_country']; ?>', 'load', '<?php echo $user['address_state']; ?>', '<?php echo $user['address_city']; ?>');
        //setStateCity('<?php echo $news_state ?>', 'load', '<?php echo $news_city ?>');
    });

    function news_getcountrystate(id, onload = '', set = '', city = '') {
        var postData = {
            country_id: id
        };
        $.ajax({
            url: "<?php echo base_url(); ?>home/getCountrySate",
            data: postData,
            dataType: 'json',
            type: 'POST',
            success: function(result) {
                $('#news_state').html('');
                var output = [];
                output.push('<option value=""></option>');
                $.each(result, function(key, value) {
                    output.push('<option value="' + value.name + '">' + value.name + '</option>');
                });

                if (output.length > 0) {
                    $('#news_state').html(output.join(''));
                } else {
                    $('#news_state').html('<option value="">No state found</option>');
                }
                if (onload == 'load') {

                    if (set != '') {
                        $('#news_state').val(set);
                    }

                    if (city != '') {
                        setTimeout(function() {
                            news_setStateCity(set, 'load', city);
                        }, 1000);
                    }
                }
                $('#news_state').trigger('change');


            }
        });
    }

    function news_setStateCity(id, onload = '', set = '') {
        //alert(id);
        var postData = {
            country_id: id
        };

        $.ajax({
            url: "<?php echo base_url(); ?>home/getSateCity",
            data: postData,
            dataType: 'json',
            type: 'POST',
            success: function(result) {

                $('#news_city').html('');
                var output = [];
                output.push('<option value=""></option>');

                $.each(result, function(key, value) {
                    output.push('<option value="' + value.name + '">' + value.name + '</option>');
                });

                if (output.length > 0) {
                    $('#news_city').html(output.join(''));
                } else {
                    $('#news_city').html('<option value="">No city found</option>');
                }

                if (onload == 'load') {
                    if (set != '') {
                        $('#news_city').val(set);
                    }
                }
                $('#news_city').trigger('change');
            }
        });
    }

    /*
        function validateForm() {
            var error = 0;
            $('.error_message').html('');
            if ($('#title').val() == '') {
                $("#title_error").html('please enter new titel');
                error = 1;
            }
            var desc = CKEDITOR.instances['discription'].getData();
            if (desc == '') {
                $("#discription_error").html('please enter new discription');
                error = 1;
            }

            if ($('#news_country').val() == '') {
                $("#news_country_error").html('please enter country');
                error = 1;
            }

            var data = $('#news_country').select2('data');
            if (data == '') {
                $("#news_country_error").html('please select country');
                error = 1;
            }
            if (error == 1) {
                return false;
            }

        }
        */
</script>