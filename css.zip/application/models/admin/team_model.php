<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Team_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}

	/* 	function getUsers()
	{	
		$users_query = $this->db->query('SELECT * FROM `users`');
		$row_users = $users_query->result_array();
		return $row_users;
	}
	*/
	
	function insert_member($data){
	    $ins_rec = array(
	        "name" => $data["name"],
	        "email" => $data["email"],
	        "phone" => $data["phone"],
	        "designation" => $data["designation"],
	        "department_id" => $data["department_id"],
	        "description" => $data["description"],
	        "status" => $data["status"]
	        );
	   if($data["profile_image"]){
	       $ins_rec["picture"] = $data["profile_image"];
	   }
	   return $this->db->set($ins_rec)->insert("team");
	}
	
	function update_member($id, $data){
	    $ins_rec = array(
	        "name" => $data["name"],
	        "email" => $data["email"],
	        "phone" => $data["phone"],
	        "designation" => $data["designation"],
	        "description" => $data["description"],
	        "department_id" => $data["department_id"],
	        "picture" => $data["uploaded_file"]
	        );
	   if($data["dp_pic"]){
	       $ins_rec["picture"] = $data["dp_pic"];
	   }
	   return $this->db->set($ins_rec)->where(array("id"=>$id))->update("team");
	}

	function getUsers($data = ''){
		$query = "SELECT * FROM `team` ORDER BY `id` DESC ";
		$users_query = $this->db->query($query);
		$row_users = $users_query->result_array();

		if ($row_users) {
			return $row_users;
		}

		return 0;
	}

	function getAllData(){
		$users_query = $this->db->query('SELECT * FROM `team`');
		$row_users = $users_query->result_array();
		return $row_users;
	}

	//delete Page Data
	public function delete_record($id){
		$this->db->where('id', $id);
		return 	$this->db->delete('team');
	}

	public function getRecordById($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('team');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function check_email($email = "", $status = "", $id='')
	{
		$condition ="";
		if($id>0){
			$condition =" AND id !='".$id."' ";
		}
		$query 			= "SELECT * FROM team WHERE email = '".$email."' ".$condition;		
		$users_query 	= $this->db->query($query);
		$row_users 		= $users_query->result_array();
		if (!empty($row_users) && count($row_users) > 0) {
			if ($status) {
				return array_shift($row_users);
			} else {
				return true;
			}
			
		}
		return false;
	}
}
