<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Team_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}
	
	function all_members(){
	    $query = "SELECT * FROM `team` ORDER BY `id` DESC ";
		$users_query = $this->db->select("*")->from("team")->where("status",1 and 'department_id',$users)->get();
		$row_users = $users_query->result_array();

		if ($row_users) {
			return $row_users;
		}else{
		    return 0;
		}
	}
	
	function all_members2($users){
	    
	     $query = "SELECT * FROM `team` WHERE department_id LIKE '".$users."' and status ='1'  ORDER BY `id` DESC ";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
	}
	
	function all_department(){
	    $query = "SELECT * FROM `departments` ORDER BY `id` DESC ";
		$users_query = $this->db->select("*")->from("departments")->get();
		$row_users = $users_query->result_array();

		if ($row_users) {
			return $row_users;
		}else{
		    return 0;
		}
	}
	
	function member_detail($id , $preview=''){
	   // echo "<pre>";print_r($id);die;
	    $query = "SELECT * FROM `team` ORDER BY `id` DESC ";
		$qry = $this->db->select("*")->from("team");
		if($preview!='') {
		    $qry->where("status",1);
		}
		$qry->get();
		$row_users = $users_query->result_array();

		if ($row_users) {
			return $row_users[0];
		}else{
		    return 0;
		}
	}
	
	function member_detail2($id , $preview=''){
	  $this->db->where('id', $id);
		$q = $this->db->get('team');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}


}
