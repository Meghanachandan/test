<?php
class AdminLogin extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Admin_Model');
    }

    public function login(){
        $this->load->view('login');
    }

    public function register()
    {
        if($_SERVER['REQUEST_METHOD']=='POST')
        {
            $fname = $this->input->post('fname');
            $email = $this->input->post('email');
            $phone = $this->input->post('phone');
            $password = $this->input->post('password');

            $sql = "SELECT `email` FROM `register` WHERE `email`='$email' and `isactive`=1";
            $query = $this->Admin_Model->select($sql)->result();
            if(count($query)==null)
            {
                $data = array(
                    'fname' => $fname,
                    'email' => $email,
                    'phone' => $phone,
                    'password' => $password
                );
                $this->Admin_Model->register($data);
                $this->session->set_flashdata("success","  Register Successfully");
                redirect('AdminLogin/register');
            }else{
                $this->session->set_flashdata("error","Emailid Already Exists");
                redirect('AdminLogin/register');
            }
        }else{
            $this->load->view('register');
        }
    }

}