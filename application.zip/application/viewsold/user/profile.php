<style>
    /*** General styles ***/
    .panel {
        box-shadow: none;
    }

    .panel-heading {
        border-bottom: 0;
    }

    .panel-title {
        font-size: 17px;
    }

    .panel-title>small {
        font-size: .75em;
        color: #999999;
    }

    .panel-body *:first-child {
        margin-top: 0;
    }

    .panel-footer {
        border-top: 0;
    }

    .panel-default>.panel-heading {
        color: #333333;
        background-color: transparent;
        border-color: rgba(0, 0, 0, 0.07);
    }

    form label {
        color: #999999;
        font-weight: 400;
    }

    .form-group input {
        margin: 0px;
    }

    .form-horizontal .form-group {
        margin-left: 0px;
        margin-right: 15px;
    }

    @media (min-width: 768px) {
        .form-horizontal .control-label {
            text-align: right;
            margin-bottom: 0;
            padding-top: 7px;
        }
    }

    .profile__contact-info-icon {
        float: left;
        font-size: 18px;
        color: #999999;
    }

    .profile__contact-info-body {
        overflow: hidden;
        padding-left: 20px;
        color: #999999;
    }

    .profile-avatar {
        width: 200px;
        position: relative;
        margin: 0px auto;
        margin-top: 196px;
        border: 4px solid #f3f3f3;
    }

    .circle {
        border-radius: 1000px !important;
        overflow: hidden;
        width: 128px;
        height: 128px;
        border: 8px solid rgba(255, 255, 255, 0.7);
        position: absolute;
        top: 72px;
    }

    .border_with_shadow {
        border: 1px solid #f2f2f2;
        box-shadow: 2px 2px 8px #ccc;
    }
</style>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<?php

//form data
//$attributes = array('class' => 'form-horizontal', 'id' => '');
$attributes = array('class' => 'form-horizontal', 'id' => '', 'enctype' => 'multipart/form-data');
//form validation

echo form_open('user/profile', $attributes);
?>
<div class="container">
    <div class="row flex-lg-nowrap mt-5 ">
        <div class="offset-lg-2 offset-xl-2 col-lg-8 col-sm-12 col-md-12 col-xl-8 mb-3 pt-4 bg-white border_with_shadow">
            <?php
            //pr($user);
            ?>
            <div class="col">
                <div class="row">
                    <div class="col mb-3">
                        <div class="card">
                            <div class="card-body">
                                <?php
                                if ($this->session->flashdata('flash_message')) {
                                    echo '<div class="alert bg-success"><a class="close" data-dismiss="alert">x</a><strong>' . $this->session->flashdata('flash_message') . '</strong></div>';
                                }

                                echo validation_errors();
                                ?>
                                <div class="e-profile">
                                    <div class="row">
                                        <div class="col-12 col-sm-auto mb-3">
                                            <div class="mx-auto" style="width: 140px;">
                                                <div class=" d-flex justify-content-center align-items-center rounded" style="height: 140px; background-color: rgb(233, 236, 239);padding: 2px;">
                                                    <?php if ($user['profile_image'] != '') {
                                                        echo '<img class="profile-pic" src="' . base_url() . 'upload/profile_image/' . $user['profile_image'] . '" width="100%" height="100%" />';
                                                        /*
                                                    echo '<a href="' . site_url() . 'home/rmove_profile_image/' . $user['id'] . '" onclick="return confirm(\'Are you sure you want to delete this profile picture?\');" >
                                                    <img src="' . SITE_URL . 'assets/img/delete.png' . '" class="delete_icon" />
                                                    </a>
                                                    ';
                                                    */
                                                    } else { ?>
                                                        <img class="profile-pic" src="<?php echo base_url(); ?>upload/profile-images.png" width="100%" height="100%" />
                                                        <!-- <span >140x140</span> -->
                                                    <?php } ?>
                                                </div>
                                                <input type="hidden" name="old_logo" value="<?= $user['profile_image'] ?>" id="" />
                                            </div>
                                        </div>
                                        <div class="col d-flex flex-column flex-sm-row justify-content-between mb-3">
                                            <div class="text-center text-sm-left mb-2 mb-sm-0">
                                                <h4 class="pt-sm-2 pb-1 mb-0 text-nowrap"><?= $user['first_name'] . ' ' . $user['last_name']; ?></h4>
                                                <p class="mb-0"><?= $user['email']; ?></p>
                                                <!-- <div class="text-muted"><small>Last seen 2 hours ago</small></div> -->
                                                <div class="mt-2 p-0">
                                                    <div style="display: none;">
                                                        <input type="file" name="profile_image" id="profile_image" />
                                                    </div>
                                                    <button class="btn btn-sm btn-secondary mx-0 upload-button" type="button">
                                                        <i class="fa fa-fw fa-camera"></i>
                                                        <span>Change Photo</span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="text-center text-sm-right">
                                                <span class="badge badge-secondary">User</span>
                                                <div class="text-muted"><small>Joined <?php echo date('d M Y', strtotime($user['signup_date'])) ?></small></div>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="nav nav-tabs">
                                        <li class="nav-item"><a href="" class="active nav-link">Settings</a></li>
                                    </ul>
                                    <div class="tab-content pt-3">
                                        <div class="tab-pane active">
                                            <form class="form" novalidate="">
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>First Name</label>
                                                                    <input class="form-control" type="text" name="first_name" value="<?php echo $user['first_name']; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Last Name</label>
                                                                    <input class="form-control" type="text" name="last_name" value="<?php echo $user['last_name']; ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Email</label>
                                                                    <input class="form-control" type="text" name="email" value="<?php echo $user['email']; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="form-group col">
                                                                <!-- Default unchecked -->
                                                                <div class="col-12">
                                                                    <label>Gender</label>
                                                                </div>
                                                                <div class="row mx-0">
                                                                    <div class="col-3">
                                                                        <div class="custom-control custom-radio">
                                                                            <input type="radio" class="custom-control-input"   id="defaultUnchecked" name="gender" value="Male" <?php if($user['gender']=='Male' || $user['gender']=='' ){ echo 'checked'; }; ?> >
                                                                            <label class="custom-control-label" for="defaultUnchecked">Male</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-3">
                                                                        <!-- Default checked -->
                                                                        <div class="custom-control custom-radio">
                                                                            <input type="radio" class="custom-control-input" id="defaultChecked2" name="gender"  value="Female" <?php if($user['gender']=='Female'){ echo 'checked'; }; ?> >
                                                                            <label class="custom-control-label" for="defaultChecked2">Female</label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-3">
                                                                        <div class="custom-control custom-radio">
                                                                            <input type="radio" class="custom-control-input" id="defaultChecked3" name="gender"  value="Other" <?php if($user['gender']=='Other'){ echo 'checked'; }; ?> >
                                                                            <label class="custom-control-label" for="defaultChecked3">Other</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col mb-3">
                                                                <div class="form-group">
                                                                    <label>Address</label>
                                                                    <textarea class="form-control" rows="1" name="address_street"><?php echo $user['address_street']; ?></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-12 col-sm-6">
                                                                <div class="form-group">
                                                                    <label>Country</label><br>
                                                                    <!-- <input class="form-control" type="text" name="address_country" value="<?php echo $user['address_country']; ?>"> -->
                                                                    <select class="form-control" id="news_country" name="address_country" onchange="news_getcountrystate(this.value);">
                                                                        <?php foreach ($allcountry as $country) {
                                                                            $selected = '';
                                                                            if ($country->name == 'India') {
                                                                                $selected = ' selected="selected" ';
                                                                            }
                                                                        ?>
                                                                            <option <?php echo $selected; ?> value="<?php echo $country->name; ?>"><?php echo $country->name; ?></option>
                                                                        <?php } ?>
                                                                    </select>
                                                                    <span class="error_message" id="news_country_error"></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-12 col-sm-6">
                                                                <div class="form-group">
                                                                    <label>State</label><br>
                                                                    <!-- <input class="form-control" type="text" name="address_state" value="<?php echo $user['address_state']; ?>"> -->
                                                                    <select class="form-control" id="news_state" name="address_state" onchange="news_setStateCity(this.value)">
                                                                        <option value=""></option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-12 col-sm-6">
                                                                <div class="form-group">
                                                                    <label>City</label><br>
                                                                    <!-- <input class="form-control" type="text" name="address_city" value="<?php echo $user['address_city']; ?>"> -->
                                                                    <select class="form-control" id="news_city" name="address_city">
                                                                        <option value=""></option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-6 col-sm-12">
                                                                <div class="form-group">
                                                                    <label>Phone No</label>
                                                                    <input class="form-control" type="text" name="phone_mobile" value="<?php echo $user['phone_mobile']; ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12 col-sm-6 mb-3">
                                                        <div class="mb-2"><b>Change Password</b></div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Current Password</label>
                                                                    <input class="form-control" name="password" id="password" type="password" placeholder="Please Enter Current Password">
                                                                    <span toggle="#password" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>New Password</label>
                                                                    <input class="form-control" id="new_password" name="new_password" type="password" placeholder="Please Enter New Password">
                                                                    <span toggle="#new_password" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="form-group">
                                                                    <label>Confirm Password</label>
                                                                    <input class="form-control" id="new_com_password" name="new_com_password" type="password" placeholder="Please Enter Confirm Password">
                                                                    <span toggle="#new_com_password" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--
                                                    <div class="col-12 col-sm-5 offset-sm-1 mb-3">
                                                        <div class="mb-2"><b>Keeping in Touch</b></div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <label>Email Notifications</label>
                                                                <div class="custom-controls-stacked px-2">
                                                                    <div class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" id="notifications-blog" checked="">
                                                                        <label class="custom-control-label" for="notifications-blog">Blog posts</label>
                                                                    </div>
                                                                    <div class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" id="notifications-news" checked="">
                                                                        <label class="custom-control-label" for="notifications-news">Newsletter</label>
                                                                    </div>
                                                                    <div class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" id="notifications-offers" checked="">
                                                                        <label class="custom-control-label" for="notifications-offers">Personal Offers</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    -->
                                                </div>
                                                <div class="row">
                                                    <div class="col d-flex justify-content-end">
                                                        <a class="btn btn-sm btn-secondary" href="<?php echo base_url(); ?>user/profile_view">Back</a>
                                                        <button class="btn btn-sm btn-secondary" type="submit">Save Changes</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo form_close(); ?>
<script>
    $(document).ready(function() {
        var readURL = function(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('.profile-pic').attr('src', e.target.result);
                    console.log(e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#profile_image").on('change', function() {
            readURL(this);
        });

        $(".upload-button").on('click', function() {
            $("#profile_image").click();
        });
    });

    $(document).ready(function() {
        $('#news_country').select2({
            placeholder: "Select country",
            allowClear: true
        });
        $('#news_state').select2({
            placeholder: "Select state",
            allowClear: true
        });
        $('#news_city').select2({
            placeholder: "Select city",
            allowClear: true
        });
        $('#categorise').select2({
            placeholder: "Select categorise",
            allowClear: true
        });
        $('#news_country').val('<?php echo $user['address_country']; ?>');
        $('#news_country').trigger('change');
        news_getcountrystate('<?php echo $user['address_country']; ?>', 'load', '<?php echo $user['address_state']; ?>', '<?php echo $user['address_city']; ?>');
        //setStateCity('<?php echo $news_state ?>', 'load', '<?php echo $news_city ?>');
    });

    function news_getcountrystate(id, onload = '', set = '', city = '') {
        var postData = {
            country_id: id
        };
        $.ajax({
            url: "<?php echo base_url(); ?>home/getCountrySate",
            data: postData,
            dataType: 'json',
            type: 'POST',
            success: function(result) {
                $('#news_state').html('');
                var output = [];
                output.push('<option value=""></option>');
                $.each(result, function(key, value) {
                    output.push('<option value="' + value.name + '">' + value.name + '</option>');
                });

                if (output.length > 0) {
                    $('#news_state').html(output.join(''));
                } else {
                    $('#news_state').html('<option value="">No state found</option>');
                }
                if (onload == 'load') {

                    if (set != '') {
                        $('#news_state').val(set);
                    }

                    if (city != '') {
                        setTimeout(function() {
                            news_setStateCity(set, 'load', city);
                        }, 1000);
                    }
                }
                $('#news_state').trigger('change');


            }
        });
    }

    function news_setStateCity(id, onload = '', set = '') {
        //alert(id);
        var postData = {
            country_id: id
        };

        $.ajax({
            url: "<?php echo base_url(); ?>home/getSateCity",
            data: postData,
            dataType: 'json',
            type: 'POST',
            success: function(result) {

                $('#news_city').html('');
                var output = [];
                output.push('<option value=""></option>');

                $.each(result, function(key, value) {
                    output.push('<option value="' + value.name + '">' + value.name + '</option>');
                });

                if (output.length > 0) {
                    $('#news_city').html(output.join(''));
                } else {
                    $('#news_city').html('<option value="">No city found</option>');
                }

                if (onload == 'load') {
                    if (set != '') {
                        $('#news_city').val(set);
                    }
                }
                $('#news_city').trigger('change');
            }
        });
    }

    /*
        function validateForm() {
            var error = 0;
            $('.error_message').html('');
            if ($('#title').val() == '') {
                $("#title_error").html('please enter new titel');
                error = 1;
            }
            var desc = CKEDITOR.instances['discription'].getData();
            if (desc == '') {
                $("#discription_error").html('please enter new discription');
                error = 1;
            }

            if ($('#news_country').val() == '') {
                $("#news_country_error").html('please enter country');
                error = 1;
            }

            var data = $('#news_country').select2('data');
            if (data == '') {
                $("#news_country_error").html('please select country');
                error = 1;
            }
            if (error == 1) {
                return false;
            }

        }
        */

    $('.toggle-password').on('click', function() {
        $(this).toggleClass('fa-eye fa-eye-slash');
        let input = $($(this).attr('toggle'));
        if (input.attr('type') == 'password') {
            input.attr('type', 'text');
        } else {
            input.attr('type', 'password');
        }
    });
</script>