<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>

<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">CONTACT ADDRESS</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h3 class="inner-tittle two">CONTACT ADDRESS </h3>
			<?php
				if($this->session->flashdata('success')){ 
				?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
			} ?>
		<div class="graph">
			<div class="tables">
				<table class="display responsive" id="example-table">
				<thead> 
					<tr> 
						<th>Id</th> 
						<th width="200px" >Address</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Status</th> 
						<th>Action</th>  
					</tr> 
				</thead>
					<?php
						$i=0;
						foreach ($addresses as $key => $address) {
							$status = (!empty($address['status']) && $address['status'] == '1') ? 'Active' : 'Deactive';
						$i++; ?>
						<tr> 
							<th><?php echo $i; ?></th> 
							<th><?php echo $address['address']; ?></th>
							<th><?php echo $address['email']; ?></th> 
							<th><?php echo $address['phone_number']; ?></th> 
							<th><?php echo $status; ?></th> 
							<th>
							<a href='<?php echo base_url('admin/contact_address/edit/'.$address['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp; 
							<!-- <a onclick='return confirm("Are you sure? you want to delete this address!")' href='<?php echo base_url('admin/contact_address/delete/'.$address['id']); ?>'><i class="fa fa-trash-o"></i></a> -->
							</th>
						</tr>
					<?php }?>
				</table>
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script> 
$(document).ready(function() {
	$('#example-table').DataTable( {
		"pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ]

	});
});
</script>