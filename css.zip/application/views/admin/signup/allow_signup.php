<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
 
<div class="outter-wp">
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li class="active">NOTICE </li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h3 class="inner-tittle two">List Notice</h3>
        
        <div class="graph">
          

        <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <!-- <h5 class="card-header">Horizontal Form</h5> -->
                            <div class="card-body">
                                <?php echo form_open('admin/Allow_signup/index'); ?>
                               
                                
                                    <div class="form-group row">
                                        <label>Allow Signup</label>&nbsp;&nbsp;
                                        <div class="col-md-3">
                                            <label class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" value="on" name="allowsignup" class="custom-control-input"><span class="custom-control-label">On</span>
                                            </label>
                                        </div>
                                       
                                        <div class="col-md-3">
                                            <label class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" value="off" name="allowsignup" class="custom-control-input"><span class="custom-control-label">Off</span>
                                            </label>
                                        </div>
                                      
                                    </div>
                                    <hr>
                                    

                                  
                                    <div class="row pt-2 pt-sm-5 mt-1">
                                        
                                        <div class="col-sm-6 pl-0">
                                            <p class="text-right">
                                                <button type="submit" onclick="return myfun();" class="btn btn-space btn-primary">Submit</button>
                                                <!-- <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button> -->
                                            </p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>  
                </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script>
function toggleCheckbox(id,status)
 {

 $.ajax({
            type: "POST",
            url: "http://newssyn.com/admin/pages/topstatus",
            data: { id : id,status: status} 
        }).done(function(data){
            alert("Success");
            // alert(data);
            // alert(data);
           //$(".ccategory").html(data);
        });
 }
</script>
<script>
    $(document).ready(function () {
        $('#example-table').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ]

        });
    });
</script>