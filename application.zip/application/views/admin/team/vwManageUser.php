<?php
$this->load->view('admin/vwHeader');

define("NAME", "Name");
define("EMAIL", "Email");
define("ACTION", "Action");
define("PLEASE_SELECT_A_RECORD", "Please Select a Record");
define("USERS_Title", "Team Members");
define("ADMIN_PANEL", "Admin Panel");
define("NEW_USER", "New Member");
define("SUCCESS", "Success");
define("RECORD_HAS_BEEN_SUCCESSFULLY_ADDED", "Record has been successfully added");
define("RECORD_HAS_BEEN_SUCCESSFULLY_UPDATED", "Record has been successfully updated");
define("RECORD_HAS_BEEN_SUCCESSFULLY_DELETED", "Record has been successfully deleted");
define("RECORD_HAS_BEEN_SUCCESSFULLY_ACTIVE", "Record has been successfully active");
define("RECORD_HAS_BEEN_SUCCESSFULLY_DEACTIVE", "Record has been successfully deactive");
define("MAIL_HAS_BEEN_SUCCESSFULLY_SEND", "Mail has been successfully send");
define("SENDMAIL", "Sendmail");
define("ACTIVE", "Active");
define("DEACTIVE", "Deactive");
define("ARE_YOU_SURE_YOU_WANT_TO_ACTIVE_SELECTED_USER", "Are you sure you want to active selected user");
define("ARE_YOU_SURE_YOU_WANT_TO_DEACTIVE_SELECTED_USER", "Are you sure you want to deactive selected user");
define("ARE_YOU_SURE_YOU_WANT_TO_SEND_MAIL_SELECTED_USER", "Are you sure you want to send mail selected user");
define("ARE_YOU_SURE_YOU_WANT_TO_DELETE_SELECTED_USER", "Are you sure you want to delete selected user");
?>
<!--
<link href="<?php echo base_url(); ?>js/datatable/dataTables.bootstrap.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>js/datatable/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>js/datatable/dataTables.bootstrap.js"></script>
-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>


<div id="page-wrapper">

  <div class="row">
    <div class="col-lg-12">
      <h1>Users <small>Manage Team Members</small></h1>
      <ol class="breadcrumb">
        <li><a href="<? base_url("admin/team"); ?>"><i class="icon-dashboard"></i> Team</a></li>
        <li class="active"><i class="icon-file-alt"></i> Team Members</li>
        <a href="<?php echo base_url(); ?>index.php/admin/team/add_newmember"> <button class=" btn btn-primary btn-sm" type="button" style="float:right;">Add New Team Member</button></a>
        <div style="clear: both;"></div>
      </ol>
    </div>
  </div>

  <script>
    function setaction(elename, actionval, actionmsg, formname) {

      vchkcnt = 0;
      elem = document.getElementsByName(elename);

      for (i = 0; i < elem.length; i++) {

        if (elem[i].checked) vchkcnt++;

      }

      if (vchkcnt == 0) {

        alert('<?php echo PLEASE_SELECT_A_RECORD; ?>')

      } else {

        if (confirm(actionmsg))

        {
          document.getElementById('action').value = actionval;

          document.getElementById(formname).submit();
        }

      }


    }

    function setactionemail(elename, actionval, actionmsg, formname) {

      echkcnt = 0;
      elem = document.getElementsByName(elename);

      for (i = 0; i < elem.length; i++) {

        if (elem[i].checked) echkcnt++;

      }


      if (echkcnt == 0) {
        alert('<?php echo PLEASE_SELECT_A_RECORD; ?>');
        return false;
      } else {
        if (confirm(actionmsg)) {
          $('#myModal').modal('show');
          return true;
        }
      }
    }
  </script>
  <script type="text/javascript" language="javascript">
    function delete_rec(id, offset) {
      var ans = confirm("<?php echo ARE_YOU_SURE_TO_DELETE_USER; ?>");
      if (ans) {
        location.href = "<?php echo site_url('admin/team/delete_member/'); ?>" + "/" + id + "/";

      } else {

        return false;

      }
    }
  </script>




  <?php
  if ($msg == 'add') {  ?>

    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo RECORD_HAS_BEEN_SUCCESSFULLY_ADDED; ?>
    </div>

  <?php
  }
  if ($msg == 'update') {  ?>

    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo RECORD_HAS_BEEN_SUCCESSFULLY_UPDATED; ?>
    </div>

  <?php }
  if ($msg == 'delete') {  ?>

    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo RECORD_HAS_BEEN_SUCCESSFULLY_DELETED; ?>
    </div>
  <?php }
  if ($msg == 'active') {  ?>

    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo RECORD_HAS_BEEN_SUCCESSFULLY_ACTIVE; ?>
    </div>
  <?php }
  if ($msg == 'suspend') {   ?>

    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo RECORD_HAS_BEEN_SUCCESSFULLY_SUSPEND; ?>
    </div>
  <?php }
  if ($msg == 'deactive') {  ?>

    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo RECORD_HAS_BEEN_SUCCESSFULLY_DEACTIVE; ?>
    </div>

  <?php }

  if ($msg == 'sendmail') {  ?>
    <div class="alert alert-success" role="alert">
      <button class="close" data-dismiss="alert">x</button>
      <strong><?php echo SUCCESS; ?>!</strong> <?php echo MAIL_HAS_BEEN_SUCCESSFULLY_SEND; ?>
    </div>
  <?php } ?>



  <?php
  $attributes = array('name' => 'frm_listpage', 'id' => 'frm_listpage');
  echo form_open('admin/team/', $attributes);
  ?>

  <input type="hidden" name="action" id="action" />

  <div class="row">
    <div class="col-lg-12 clearfix">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h4 class="panel-title text-right">
            <button type="button" class="btn btn-success btn-sm" onclick="setaction('chk[]','active', '<?php echo ARE_YOU_SURE_YOU_WANT_TO_ACTIVE_SELECTED_USER; ?>', 'frm_listpage')"><?php echo ACTIVE; ?></button>
            <button type="button" class="btn btn-danger btn-sm" onclick="setaction('chk[]','deactive', '<?php echo ARE_YOU_SURE_YOU_WANT_TO_DEACTIVE_SELECTED_USER; ?>', 'frm_listpage')"><?php echo DEACTIVE; ?></button>
            <button type="button" class="btn btn-danger btn-sm" onclick="setaction('chk[]','delete', '<?php echo ARE_YOU_SURE_YOU_WANT_TO_DELETE_SELECTED_USER; ?>', 'frm_listpage')"><?php echo 'Delete'; ?></button>
            <!-- <button type="button" class="btn btn-warning btn-sm" onclick="return setactionemail('chk[]','sendmail', '<?php echo ARE_YOU_SURE_YOU_WANT_TO_SEND_MAIL_SELECTED_USER; ?>', 'frm_listpage')"><?php echo SENDMAIL; ?></button> -->
            <!-- <div style="display: none;">
              <?php
              $attributesmail = array('name' => 'frm_listpage', 'id' => 'frm_listpages', 'value' => '');
              echo $attributesmail['id'];
              ?>
              <input type="hidden" name="emails_to" id="emails_to" value="" />
              <a href="<?php echo site_url('admin/users/contact_email/' . $attributesmail['id']); ?>" class="btn-eventgrey marL10 mfPopup" id="mfPopup" value="">
                <?php echo SENDMAIL; ?>
              </a>
            </div> -->
          </h4>
        </div>
        <div class="panel-body">
          <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid">
            <div class="table-responsive">
              <table class="display responsive" id="dataTables-example4">
                <thead>
                  <tr>
                    <th class="sorting_disabled"><input type="checkbox" id="selecctall"></th>
                    <th>Id</th>
                    <th>Name</th>
                    <th><?php echo EMAIL; ?></th>
                    <th>Phone</th>
                    
                    <th>Departments/Designation</th>
                    <th>Status</th>
                    <th class="sorting_disabled"><?php echo ACTION; ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $i = 1;
                  foreach ($users as $k => $r) {
                    echo '<tr>';
                    echo '<td><input type="checkbox" class="checkbox1" name="chk[]" value="' . $r['id'] . '" /></td>';
                    echo '<td>' . $i++ . '</td>';
                    echo '<td>' . $r['name'] . '</td>';
                    echo '<td>' . $r['email'] . '</td>';
                    echo '<td>' . $r['phone'] . '</td>';
                    echo '<td>' . getDepartment($r['department_id']) .'/'.getDesignation($r['designation']). '</td>';
                    
                    if ($r['status'] == 1) {
                      echo '<td><div style="text-align:center"><img title="Active User" alt="Active User" src="' . base_url() . 'admin_images/active.jpg"></img></div></td>';
                    } else {
                      echo '<td><div style="text-align:center"><img title="Disabled User" alt="Disabled User" src="' . base_url() . 'admin_images/deactive.jpg"></img></div></td>';
                    }
                    echo '<td style="width: 115px;" >';
                    // echo '  &nbsp;&nbsp;&nbsp; <a  title="View Users Category" alt="View Users Category"  href="' . base_url() . 'admin/team/profile_view/' . $r['id'] . '"><i class="fa fa-user" aria-hidden="true"></i></a>';
                    echo '  &nbsp;&nbsp;&nbsp; <a  title="View/Edit" alt="View/Edit"  href="' . base_url() . 'admin/team/edit_member/' . $r['id'] . '"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                    echo '  &nbsp;&nbsp;&nbsp; <a onclick=\'return confirm("Are you sure? you want to delete this user!")\' title="Delete" alt="Delete"  href="' . base_url() . 'admin/team/delete_member/' . $r['id'] . '"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                    echo '</td>';
                    echo '</tr>';
                  }
                  ?>
                </tbody>
              </table>

            </div>
          </div>
        </div>

      </div>
    </div><!-- col-lg-8  -->
  </div>

  </form>
  <!-- /.row -->
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Contact User</h4>
      </div>
      <div class="modal-body">
        <form accept-charset="UTF-8" action="<?php echo site_url('admin/users/contact_email/' . $id) ?>" id="newguestForm" method="post" name="newguestForm" class="event-title" enctype="multipart/form-data">
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Email</label>
                <span>*</span> </div>
              <div class="col-sm-8 col-xs-12">
                <input type="text" name="email" readonly="readonly" class="form-control" id="email" value="<?php echo $email; ?>">
              </div>
            </div>
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Subject</label>
                <span>*</span> </div>
              <div class="col-sm-8 col-xs-12">
                <input type="text" name="subject" class="form-control" id="subject">
              </div>
            </div>
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Message</label>
                <span>*</span> </div>
              <div class="col-sm-8 col-xs-12">
                <textarea name="message" id="message" class="form-control"></textarea>
              </div>
            </div>

          </div>
          <div class="clearfix"></div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="btntemail_send">Send Email</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</body>

<script>
  function fnCallback() {
    if (this.checked) { // check select status
      $('.checkbox1').each(function() { //loop through each checkbox
        this.checked = true; //select all checkboxes with class "checkbox1"               
      });
    } else {
      $('.checkbox1').each(function() { //loop through each checkbox
        this.checked = false; //deselect all checkboxes with class "checkbox1"               

      });
    }
  }
  $(document).ready(function() {

    dTable = $('#dataTables-example4').dataTable({
      "iDisplayLength": 10,
      "bProcessing": true,
      "bServerSide": false,
      "lengthMenu": [
        [10, 25, 50, -1],
        [10, 25, 50, "All"]
      ],
      "order": [
        [1, "asc"]
      ],
      "aoColumnDefs": [{
          "bSortable": false,
          "aTargets": [0]
        }, {
          "bSortable": false,
          "aTargets": [-1]
        }

      ]
    });
  });

  function setEmail(id) {
    $("#email").val($(id).attr('email'));
  }
</script>
<script>
  $(document).ready(function() {

    $('#selecctall').click(function(event) { //on click 
      if (this.checked) { // check select status
        $('.checkbox1').each(function() { //loop through each checkbox
          this.checked = true; //select all checkboxes with class "checkbox1"               
        });
      } else {
        $('.checkbox1').each(function() { //loop through each checkbox
          this.checked = false; //deselect all checkboxes with class "checkbox1"           
        });
      }
    });


    $("#btntemail_send").bind('click', function() {

      var subject = $("#subject").val();
      var message = $("#message").val();

      if (subject == '') {
        alert("Subject is required field");
        $("#subject").focus();
        return false;
      } else if (message == '') {
        alert("Message is required field");
        $("#message").focus();
        return false;
      } else {
        $("#newguestForm").submit();
      }
    });


  });
</script>

</html>
<?php $this->load->view('admin/vwFooter'); ?>