<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/style.css">
       
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <!-- <div class="panel panel-default">
                    <div class="panel-body"> -->
                        <div class="row" style="padding: 26px 50px;">
                            <div class="col-md-4 col-md-offset-3 signup_form_grid">
                                <p class="signup_name">
                                    Sign Up /<a href="<?php echo base_url('AdminLogin/login'); ?>"> Login</a>
                                </p>

                                <?php if($this->session->flashdata('error')){ ?>
                                    <p style="color: white;background: red;text-align: center;padding: 5px;">
                                        <?php echo $this->session->flashdata('error'); ?>
                                    </p>
                                <?php } ?>
                                <?php if($this->session->flashdata('success')){ ?>
                                    <p style="color: white;background: green;text-align: center;padding: 5px;">
                                        <?php echo $this->session->flashdata('success'); ?>
                                    </p>
                                <?php } ?>
                                <div class="col-md-12 signup_form">
                                    <?php echo form_open('AdminLogin/register'); ?>
                                        <div class="form-group">
                                            <label class="signup_form_label">Name</label>
                                            <input type="text" pattern="[A-Za-z]" class="form-control signup_form_input" name="fname" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="signup_form_label">Email </label>
                                            <input type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" class="form-control signup_form_input" name="email">
                                        </div>
                                        <div class="form-group">
                                            <label class="signup_form_label">Phone Number</label>
                                            <input type="number" id="mobile" class="form-control signup_form_input" name="phone">
                                            <span id="message" style="color:red"></span>
                                        </div>
                                        <div class="form-group">
                                            <label class="signup_form_label">Password</label>
                                            <input type="password" class="password form-control signup_form_input pwd" name="password">
                                            <div>
                                                <span id="pass" style="display:none;color:red;">Password must be greater than 6 character</span>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="signup_form_label">Confirm Password</label>
                                            <input type="password" class="cpassword form-control signup_form_input" name="cpassword">
                                        </div>
                                        <button type="submit" onclick="return myfun();" class="btnSubmit btn btn-default signup_button_signup">Sign Up</button>
                                    </form>
                                </div>
                            <!-- </div>
                        </div> -->
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.pwd').on('blur',function(){
                if(this.value.length<6){ 
                    $("#pass").show();
                }
			    else{
				    $("#pass").hide();
			    }
		    });

            $('.btnSubmit').click(function(){
                var password = $('.cpassword').val();
                var cpassword = $('.password').val();
                if(password != cpassword)
                {
                    alert("password doesn't match");
                    return false;
                }
                return true;
            });
        });

        function myfun(){
            var a = document.getElementById("mobile").value;
            if(a==""){
                document.getElementById("message").innerHTML="**pls fill mobile number";
                return false;
            }
            if(isNaN(a)){
                document.getElementById("message").innerHTML="**enter only numeric values";
                return false;
            }
            if(a.length<10) {
                document.getElementById("message").innerHTML="**mobile number must be 10 digit";
                return false;
            }
            if(a.length>10){
                document.getElementById("message").innerHTML="**mobile number must be 10 digit";
                return false;
            }
        }
    </script>

</body>
</html>