        
     <?php
    
        session_start();
        $captcha_num = rand(1000,9999);
        $_SESSION['captcha_code'] = $captcha_num;
        $font_size = 30;
        $img_width = 150;
        $img_height = 40;
        header('Content-type','image/jpeg');
        $image = imagecreate($img_width,$img_height);
        imagecolorallocate($image,255,255,255);
        $textColor = imagecolorallocate($image,0,0,0);
        imagettftext($image,$font_size,0,15,30,$textColor,'font.tff',$captcha_num);
        imagejpeg($image);
       
 /*
session_start(); // Staring Session
$captchanumber = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz'; // Initializing PHP variable with string
$captchanumber = substr(str_shuffle($captchanumber), 0, 6); // Getting first 6 word after shuffle.
$_SESSION["code"] = $captchanumber; // Initializing session variable with above generated sub-string
$image = imagecreatefromjpeg(base_url().'images/home/BG17630login.jpg'); // Generating CAPTCHA
$foreground = imagecolorallocate($image, 175, 199, 200); // Font Color
imagestring($image, 5, 45, 8, $captchanumber, $foreground);
header('Content-type: image/png');
imagepng($image);   */    
        ?>