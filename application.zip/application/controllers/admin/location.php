<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class location extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/faq_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function country_view()
    {
$this->db->select('*');
$this->db->from('countries');
$query= $this->db->get();

        $data['faqs'] = $query->result_array();
        adminLoadView('country/list', $data);
    }
     public function state_view()
    {

  $this->db->select('*');
$this->db->from('states');
$query= $this->db->get();

        $data['faqs'] = $query->result_array();
        adminLoadView('state/list', $data);
    }
     public function city_view()
    {

//      $this->db->select('*');
// $this->db->from('cities');
// $this->db->limit(141851, 141855);
$cc="SELECT * FROM `cities` limit 141851, 141855";
$query= $this->db->query($cc);

        $data['faqs'] = $query->result_array();
        adminLoadView('city/list', $data);
    }
    public function country_add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->faq_model->formCatValidations();
      
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'name' => $postData['title']
                );

               
                $return = addUpdateRecord('countries', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'Country added successfully.');
                    redirect('admin/location/country_view');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('country/create', $data);
    }
    public function country_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/location/country_view');
        }
        $this->db->select('*');
$this->db->from('countries');
$this->db->where('id',$id);
$query= $this->db->get();

    

        $postData = $query->result_array();;
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

                $updateData['name'] = $postData['title'];
                // $updateData['discription'] = $postData['discription'];
                // $updateData['status'] = $postData['status'];
                // $updateData['order'] = $postData['order'];

                $return = addUpdateRecord('countries', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'Country updated successfully.');
                    redirect('admin/location/country_view');
                }
           
        }
        adminLoadView('country/edit', $data);
    }
    public function country_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/location/country_view');
        }
    $this->db->where('id', $id);
$this->db->delete('countries'); 
            $this->session->set_flashdata('success', 'Country deleted successfully.');
            redirect('admin/location/country_view');
        
    }

     public function state_add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            
            
          $hgfffghfg =  $postData['country_id'];
            
            
		$countrysql = "SELECT * FROM `countries` WHERE `id` = '".$hgfffghfg."' ;";
        $countryquery = $this->db->query($countrysql);
		$countryresult = $countryquery->result_array();
		
	//	echo "<pre>";print_r($countryresult[0]['iso2']);die;
            
            
            
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->faq_model->formCatValidations();
      
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'country_code' => $countryresult[0]['iso2'],
                    'name' => $postData['title'],
                      'country_id' => $postData['country_id']
                );

               
                $return = addUpdateRecord('states', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'State added successfully.');
                    redirect('admin/location/state_view');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('state/create', $data);
    }
    public function state_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/location/state_view');
        }
        $this->db->select('*');
$this->db->from('states');
$this->db->where('id',$id);
$query= $this->db->get();

    

        $postData = $query->result_array();;
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

                $updateData['name'] = $postData['title'];
                   $updateData['country_id']  = $postData['country_id'];
                // $updateData['discription'] = $postData['discription'];
                // $updateData['status'] = $postData['status'];
                // $updateData['order'] = $postData['order'];

                $return = addUpdateRecord('states', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'State updated successfully.');
                    redirect('admin/location/state_view');
                }
           
        }
        adminLoadView('state/edit', $data);
    }
    public function state_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/location/state_view');
        }
    $this->db->where('id', $id);
$this->db->delete('states'); 
            $this->session->set_flashdata('success', 'State deleted successfully.');
            redirect('admin/location/state_view');
        
    }
      public function city_add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            
            $hgf =  $postData['state_id'];
            
            
		$co = "SELECT * FROM `states` WHERE `id` = '".$hgf."' ;";
        $co = $this->db->query($co);
		$cot = $co->result_array();
		
		$hgf1 =  $postData['country_id'];
            
            
		$co1 = "SELECT * FROM `countries` WHERE `id` = '".$hgf1."' ;";
        $co1 = $this->db->query($co1);
		$cot1 = $co1->result_array();
		
// 		echo "<pre>";print_r($cot1[0]['iso2']);die;
            
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->faq_model->formCatValidations();
      
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'name' => $postData['title'],
                     'country_id' => $postData['country_id'],
                     'state_code' => $cot[0]['iso2'],
                     'country_code' => $cot1[0]['iso2'],
                      'state_id' => $postData['state_id']
                );

               
                $return = addUpdateRecord('cities', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'City added successfully.');
                    redirect('admin/location/city_view');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('city/create', $data);
    }
    public function city_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/location/city_view');
        }
        $this->db->select('*');
$this->db->from('cities');
$this->db->where('id',$id);
$query= $this->db->get();

    

        $postData = $query->result_array();;
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];

                $updateData['name'] = $postData['title'];
                $updateData['country_id'] = $postData['country_id'];
                $updateData['state_id'] = $postData['state_id'];
                // $updateData['discription'] = $postData['discription'];
                // $updateData['status'] = $postData['status'];
                // $updateData['order'] = $postData['order'];

                $return = addUpdateRecord('cities', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'City updated successfully.');
                    redirect('admin/location/city_view');
                }
           
        }
        adminLoadView('city/edit', $data);
    }
    public function city_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/location/city_view');
        }
    $this->db->where('id', $id);
$this->db->delete('cities'); 
            $this->session->set_flashdata('success', 'City deleted successfully.');
            redirect('admin/location/city_view');
        
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
