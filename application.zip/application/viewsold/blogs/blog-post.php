<section>
	<div class="container">
		<div class="row">
            <div class="page-title-wrapper product">
            	<div class="col-md-6 col-sm-6 col-xs-12"><h1 class="page-title">
                    <span class="base" data-ui-id="page-title-wrapper" itemprop="name"><?php echo $getBlog['title']; ?> </span></h1>
                 </div>
            	<div class="col-sm-6 hidden-xs"><div class="pull-right mt-5">
                    <ul class="page-list">
                        <li class="item home"><a href="<?php echo base_url('/'); ?>" title="Go to Home Page"> Home </a>  </li>
                        <li> > </li>
                        <li class="item home"><a href="<?php echo base_url('blogs'); ?>" title="Go to Blog"> Blog </a>  </li>
                        <li> > </li>
                        <li class="item product"><?php echo $getBlog['title']; ?></li>
                    </ul>
                </div>
                </div>

                <div class="clearfix"></div>
            </div>    
        </div>
    </div>
</section>
<section>
	<div class="container">
		<div class="row ">
			<div class="col-sm-8 col-md-9 ">
				<div class="blog-post-area">
					<div class="single-blog-post">
						<a href="#">
							<img src="<?php echo base_url('upload/blogs/'.$getBlog['image']); ?>" alt="" class="img-responsive">
						</a>
						<h3><?php echo $getBlog['title']; ?></h3>
						<div class="post-meta">
							<ul>
								<!-- <li><i class="fa fa-user"> &nbsp; Author </i>  dixit shah </li> -->
								<li><i class="fa fa-calendar"> &nbsp; Posted </i> <?php echo  date('M d, Y', strtotime($getBlog['created_date'])); ?></li>
							</ul>
						</div>
						<p class="blog-para"><?php echo $getBlog['discription']; ?></p>
					</div>
						<!-- <div class="col-sm-12 mb100">
							<div class="text-area">
								<div class="blank-arrow">
									<label>Your Name</label>
								</div>
								<textarea name="message" rows="11"></textarea>
								<a class="btn btn-primary" href="">post comment</a>
							</div>
						</div> -->
                    
				</div>
			</div>
            
			<div class="col-sm-4 col-md-3">
				<div class="left-sidebar">
					<div class="mt20 mb100"><!--shipping-->
                       <?php if (!empty($latest_post)) { ?>
							 <h2>Recent Posts</h2>
	                    	<p><?php echo  date('F Y', strtotime($latest_post['created_date'])); ?></p>
							<a title="<?php echo $latest_post['title']; ?>" href="<?php echo base_url("blogs/post/".$latest_post['slug']); ?>">
								<img src="<?php echo base_url("upload/blogs/".$latest_post['image']); ?>" alt="" class="img-responsive"/>
							</a>
						<?php } ?>
					</div><!--/shipping-->
                        
				</div>
			</div>
		</div>
	</div>
</section>