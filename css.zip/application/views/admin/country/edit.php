<?php
// print_r($postData);die;
if (!empty($postData)) {
    $name = $postData[0]['name'];
    // $discription = $postData['discription'];
    // $link = $postData['link'];
    // $status = $postData['status'];
    // $image = $postData['image'];
    // $categorie_type = $postData['categorie_type'];
    // $order = $postData['order'];
    //$categorie_colour = $postData['categorie_colour'];
}
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/news/categories'); ?>">Country</a></li>
            <li class="active">EDIT Country</li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">Edit Country</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <?php
                $editId = "";
                if (!empty($postData[0]['id'])) {
                    $editId = $postData[0]['id'];
                }
                ?>
                <form action="<?php echo base_url('admin/location/country_edit/' . $editId); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" value=""/>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Country <span class="star-color">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>" required>
                    </div>
                  
               
                    
					
                 
					
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Update</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
	
</script>