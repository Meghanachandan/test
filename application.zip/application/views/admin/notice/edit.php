<?php
if (!empty($postData)) {
	$name 			= $postData['title'];
	$discription 		= $postData['description'];

	$status 		= $postData['status'];
	$image 			= $postData['image'];

}
?>
<link href="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li><a href="<?php echo base_url('admin/notice'); ?>">NOTICE</a></li>
			<li class="active">Edit NOTICE</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">EDIT NOTICE</h2>
		<div class="graph-form">
			<?php if (!empty($error)) { ?>
				<div class="alert alert-danger message" style="display: block;">
					<?php echo $error; ?>
				</div>
			<?php } ?>
			<div class="form-body">
			    <?php
				$editId = "";
				if (!empty($postData['id'])) {
					$editId = $postData['id'];
				} ?>
				<form action="<?php echo base_url('admin/notice/edit/' . $editId); ?>" enctype="multipart/form-data" method="post">
					<input type="hidden" value="" />
					<div class="form-group">
						<label for="exampleInputEmail1">Notice Headline <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>">
					</div>
					<div class="form-group" id="">
						<label>Add Image </label>
						<input type="file" id='image' name="image" value="<?php //echo $image; ?>">
						<input type="hidden" name="oldimage" value="<?php echo $image; ?>">
						<!-- <small class="msg-upload">Image Dimension must be Minimum 600px*400px</small> -->
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-lg-12 ">
								<label for="exampleInputPassword1">Description <span class="star-color">*</span></label>
								<textarea name="discription" rows="3" cols="90" id="discription" name="discription"><?php echo $discription; ?></textarea>
							</div>
						</div>
					</div>
				
					<div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Status</label>
						<div class="radio block">
							<label>
								<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked" />Active
							</label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label>
								<input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive
							</label>
						</div>
					</div>
					
					<button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button>
				</form>
			</div>
		</div>
		<!--//graph-visual-->
	</div>
</div>
<br><br>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script>
	$(document).ready(function() {
		$('#datepicker').datepicker();
	});

	//Replace the <textarea id="editor1"> with a CKEditor
	//instance, using default configuration.
	CKEDITOR.replace('discription');

	
	


	
</script>