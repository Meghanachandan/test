<div id="priceFilterContainer">
	<section>
		<div class="container">
			<div class="row">
	            <div class="page-title-wrapper product">
	            	<div class="col-sm-6 col-xs-12">
	            		<h1 class="page-title ">
		                    <span class="base" data-ui-id="page-title-wrapper" itemprop="name">
			                    <?php if (!empty($get_category['category_name'])) { ?>
			                    	<?php echo $get_category['category_name']; ?>
			                    <?php } else { ?>
			                    	All Categories
			                    <?php } ?>
		                    </span>    
	                    </h1>
	                 </div>
	            	<div class="col-sm-6 hidden-xs"><div class="pull-right mt-5">
	                    <ul class="page-list">
                            <li class="item home"><a href="<?php echo base_url('/'); ?>" title="Go to Home Page"> Home </a>  </li>
                            <li> > </li>
                            <?php if (!empty($get_category)) { ?>
                            	<li class="item home"><a href="<?php echo base_url('category/'); ?>" title="Go to All Categories"> All Categories </a>  </li>
	                            <li> > </li>
	                            <li class="item product"><?php echo $get_category['category_name']; ?></li>
                            <?php } else { ?>
	                            <li class="item product">All Categories</li>
                            <?php } ?>
	                    </ul>
	                </div>
	                </div>
	                <div class="clearfix"></div>
	            </div>    
	        </div>
	    </div>
	</section>
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-4 hidden-xs">
					<div class="left-sidebar">
						<h2><a href="<?php echo base_url("category"); ?>" title="Go to All Categories">Categories</a></h2>
						<?php if (!empty($categories)) { ?>
							<div class="panel-group category-products" id="accordian">
								<?php foreach ($categories as $category) { ?>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
												<?php if ($category->id == $category_id) { ?>
													<a href="<?php echo base_url('category/products/'.$category->slug); ?>" class="active-cate" title="<?php echo $category->category_name; ?>">
														<div>
															<?php echo $category->category_name; ?>
														</div>
													</a>
												<?php } else { ?>
													<a href="<?php echo base_url('category/products/'.$category->slug); ?>" title="<?php echo $category->category_name; ?>"><?php echo $category->category_name; ?></a>
												<?php } ?>
												
											</h4>
										</div>
									</div>
								<?php } ?>
							</div><!--/category-productsr-->
						<?php } ?>
						
						<?php if (!empty($results)) { ?>
						<div class="brands_products">
							<h2>Filter</h2>
	                        <div class="block-subtitle"><strong>Shopping Options</strong></div>
	                        <div class="accordion" id="accordion1">
	                           
	                            <div class="accordion-group">
	                                <div class="accordion-heading bdr-none">
	                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo"><strong>Price</strong> </a>
	                                </div>
	                            <div id="collapseTwo" class="accordion-body collapse">
	                                <div class="accordion-inner">
	                               		<ul class=" clearfix price-filter" >
	                               			<?php if ($filter['price_count']['lowPriceCount'] > 0) { ?>
	                               				<li><a href="javascript:void(0);" class="price_1" onclick="filterPrice('1_99', 'price_1')">
	                                    			<?php echo priceFormate(0).' - '.priceFormate(99); ?>
	                                    			(<?php echo $filter['price_count']['lowPriceCount']; ?>)</a></li>
	                               			<?php } ?>

	                               			<?php if ($filter['price_count']['midPriceCount'] > 0) { ?>
	                               				<li><a href="javascript:void(0);" class="price_2" onclick="filterPrice('100_199', 'price_2')">
	                                    	<?php echo priceFormate(100).' - '.priceFormate(199); ?>
	                                    	 (<?php echo $filter['price_count']['midPriceCount']; ?>)</a></li>
	                               			<?php } ?>

	                               			<?php if ($filter['price_count']['highPriceCount'] > 0) { ?>
	                               				<li><a href="javascript:void(0);" class="price_3" onclick="filterPrice('200_above', 'price_3')">
	                                    	<?php echo priceFormate(200); ?> and above (<?php echo $filter['price_count']['highPriceCount']; ?>)</a></li>
	                               			<?php } ?>
	                                    </ul>
	                                </div>
	                            </div>
	                            </div>
	                            <br>
	                        </div>
						</div>
						<?php } ?>
					</div>
				</div>
				
				<div class="col-md-9 col-sm-8" id="loadPriceFilter" style="height:0;">
					<div class="dynamic_loader" style="display: none;"></div>
				</div>
				<div id="dynamic_show_page">
					<div class="col-md-9 col-sm-8 padding-right">
						<div class="features_items my-overlay">
						
		                 <div class="hiddenloader">
		                	<div class="col-sm-12 p0 clearfix">
		                    <div class="col-sm-5 col-xs-3 ">
		                          <ul class="color-box item-list clearfix hidden-xs">
		                              <li class="hidden-xs"><i class="fa fa-th"></i></li>
		                              <li style="line-height:22px">
		                              	<?php if(!empty($total_count) && $total_count > 0){
		                              		if ($total_count > 1) {
		                              			echo $total_count." Items";
		                              		} else {
		                              			echo $total_count." Item";
		                              		}
		                              	} else {
		                              		echo "0 Item";
		                              	} ?>
		                              </li>
		                          </ul>
		                    </div>
		                    <div class="col-sm-7 col-xs-12 p0">
		                        <ul class="color-box item-list pull-right clearfix">
		                            <li style="line-height:22px">Sort By</li>
		                            <li style="margin-top:0;">
		                            	<?php 
		                            	$high = $low = "";
		                            	if(!empty($filter['sortPrice']) && $filter['sortPrice'] == 'desc'){
		                            		$high = 'selected';
		                            	} else {
		                            		$low = 'selected';
		                            	} ?>
		                            	<select id="sorter" data-role="sorter" onchange="sortByPrice(this.value)" class="sorter-options">
											<option value="asc" <?php echo $low; ?>>Low To High</option>
											<option value="desc" <?php echo $high; ?>> High To Low </option>
										</select>
		                            </li>
								</ul>
		                    </div>
		            	</div>
		                
		               
		                	<div class="clearfix"></div>
		                	<?php 
			                	if (!empty($results)) {
			                		foreach ($results as $product) {
			                ?>
			                	<div class="col-sm-4 col-xs-6">
									<div class="product-image-wrapper">
			                            <div class="single-products">
			                                <div class="productinfo ">
			                                    <a title="<?php echo $product->product_name; ?>" href="<?php echo base_url('product/'.$product->slug) ?>"><img src="<?php echo base_url($product->image); ?>" alt="" class="pro-img" /></a>
			                                    <p></p>
			                                    <p class="pn-ht"><?php echo $product->product_name; ?></p>
			                                    <div class="col-sm-6  p0">
			                                    	<h2 class="ad-crt"><?php echo priceFormate($product->price); ?></h2>
			                                    </div>
			                                    <div class="col-sm-6 mobi-tc p0">
			                                    	<a title="<?php echo $product->product_name; ?>" href="<?php echo base_url('product/'.$product->slug) ?>" class="btn btn-default add-to-cart ad-crt pull-right" style="text-align:right !important;"><i class="fa fa-eye"></i>View</a>
			                                    </div>
			                                </div>
			                                
			                            </div>
										<div class="choose">
											<ul class="nav nav-pills nav-justified">
												<li class="col-sm-8 col-sm-12 p0">
			                                    </li>
											</ul>
										</div>
									</div>
								</div>
			                <?php 
			                	}
			                } else { ?>
			                	<div class="alert alert-info">Record Not Found!</div>
			                <?php } ?>
							</div><!--features_items-->

							<div class="row">
								<div class="col-xs-12">
									<?php echo $paginationCount; ?>
								</div>
							</div>
							<br><br>
							<div class="clearfix"></div>
		                </div>
		                <div class="clearfix"></div>
					</div>
				</div>
	            

				<div class="col-md-3 col-sm-4 hidden-lg hidden-sm hidden-md mb20">
				 <div class="left-sidebar">
					<!--	<h2>Categories</h2>
						<div class="panel-group category-products" id="accordian">
							<?php foreach ($categories as $category) { ?>
								<div class="panel panel-default">
									<div class="panel-heading">
										<h4 class="panel-title">
											<?php if ($category->id == $category_id) { ?>
												<a href="<?php echo base_url('category/products/'.$category->slug); ?>" class="active-cate">
													<div>
														<?php echo $category->category_name; ?>
													</div>
												</a>
											<?php } else { ?>
												<a href="<?php echo base_url('category/products/'.$category->slug); ?>"><?php echo $category->category_name; ?></a>
											<?php } ?>

										</h4>
									</div>
								</div>
							<?php } ?>
						</div>

						<div class="brands_products">
							<h2>Filter</h2>
	                        <div class="block-subtitle"><strong>Shopping Options</strong></div>
	                        <div class="accordion" id="accordion1">

	                            <div class="accordion-group">
	                                <div class="accordion-heading bdr-none">
	                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo1">Price </a>
	                                </div>
	                            <div id="collapseTwo1" class="accordion-body collapse">
	                                <div class="accordion-inner">
	                                   		<ul class="price-filter clearfix">
	                                        	<?php if ($filter['price_count']['lowPriceCount'] > 0) { ?>
		                               				<li><a href="javascript:void(0);" class="price_1" onclick="filterPrice('1_99', 'price_1')">
		                                    			<?php echo priceFormate(0).' - '.priceFormate(99); ?>
		                                    			(<?php echo $filter['price_count']['lowPriceCount']; ?>)</a></li>
		                               			<?php } ?>

		                               			<?php if ($filter['price_count']['midPriceCount'] > 0) { ?>
		                               				<li><a href="javascript:void(0);" class="price_2" onclick="filterPrice('100_199', 'price_2')">
		                                    	<?php echo priceFormate(100).' - '.priceFormate(199); ?>
		                                    	 (<?php echo $filter['price_count']['midPriceCount']; ?>)</a></li>
		                               			<?php } ?>

		                               			<?php if ($filter['price_count']['highPriceCount'] > 0) { ?>
		                               				<li><a href="javascript:void(0);" class="price_3" onclick="filterPrice('200_above', 'price_3')">
		                                    	<?php echo priceFormate(200); ?> and above (<?php echo $filter['price_count']['highPriceCount']; ?>)</a></li>
		                               			<?php } ?>
	                                        </ul>
	                                </div>
	                            </div>
	                            </div>
	                        </div>
						</div>



					</div> -->
                   
				</div>

			</div>
		</div>
		<input type="hidden" name="sort_price" id="sort_price" value="asc">
		<input type="hidden" name="hdn_category_id" id="hdn_category_id" value="<?php echo $get_category['id']; ?>">
		<input type="hidden" id="hdn_min_price" value="">
		<input type="hidden" id="hdn_max_price" value="">
	</section>
	<script type="text/javascript">
		function sortByPrice(sortText) {

			$(".my-overlay").addClass('overlay-bg');
			$(".dynamic_loader").show();

			var maxPrice = "";
			if ($("#hdn_max_price").val() != "") {
				maxPrice 	= $("#hdn_max_price").val();
			}

			var minPrice = "";
			if ($("#hdn_min_price").val() != "") {
				minPrice 	= $("#hdn_min_price").val();
			}

	        var category_id = "";
			if ($("#hdn_category_id").val() != "") {
				category_id = '/'+$("#hdn_category_id").val();
			}
			var page_path  = "<?php echo base_url(); ?>category/filter";
			$.ajax({
		           type: "POST",
		           url: page_path+category_id,
		           data: ({
	                    minPrice  		: minPrice,
	                    newMxPrice      : maxPrice,
	                    category_id 	: category_id,
	                    sortPrice 		: sortText
	                }),
		           cache: false,
		           success: function(result){
		                $("#dynamic_show_page").html(result);
	                	$("#hdn_max_price").val(maxPrice);
	           			$("#hdn_min_price").val(minPrice);
	           			$("#sorter").val(sortText);
	           			$("#sort_price").val(sortText);
	           			var explode = function(){
	           				$(".my-overlay").removeClass('overlay-bg');
	           				$(".dynamic_loader").hide();
                        };
                        setTimeout(explode, 100);
		           }
		      });
		}

		function filterPrice(price, clsName) {

			$(".my-overlay").addClass('overlay-bg');
			$(".dynamic_loader").show();
			var page_path  = "<?php echo base_url(); ?>category/filter";
			if (price != "") {

				var sortPrice = "";
				if ($("#sort_price").val() != "") {
					sortPrice 	= $("#sort_price").val();
				}


				var priceSpt = price.split("_");
				if (priceSpt[0] != "") {
					minPrice = priceSpt[0];
				}

				if (priceSpt[1] != "") {
					maxPrice = priceSpt[1];
				}
				
				if (maxPrice != "above") {
					newMxPrice = maxPrice;
				} else {
					newMxPrice = "";
				}

				var category_id = "";
				if ($("#hdn_category_id").val() != "") {
					category_id = '/'+$("#hdn_category_id").val();
				}

				$.ajax({
	                url: page_path+category_id,
	                type: "POST",
	                data: ({
	                    minPrice  		: minPrice,
	                    newMxPrice      : newMxPrice,
	                    category_id 	: category_id,
	                    sortPrice 		: sortPrice
	                }),
	                success: function (data) {

	                	if (clsName == 'price_1') {

	                		$(".price_1").addClass('active-price');
	                		$(".price_2").removeClass('active-price');
	                		$(".price_3").removeClass('active-price');
	                	} else if(clsName == 'price_2') {
	                		$(".price_1").removeClass('active-price');
	                		$(".price_2").addClass('active-price');
	                		$(".price_3").removeClass('active-price');
	                	} else {
	                		$(".price_1").removeClass('active-price');
	                		$(".price_2").removeClass('active-price');
	                		$(".price_3").addClass('active-price');
	                	}

	                	$("#dynamic_show_page").html(data);
	                	$("#hdn_max_price").val(newMxPrice);
	           			$("#hdn_min_price").val(minPrice);
	           			$(this).addClass('active-price')
	           			console.log($(this).addClass('active-price'));
	           			
	           			var explode = function(){
	           				$(".my-overlay").removeClass('overlay-bg');
	           				$(".dynamic_loader").hide();
                        };
                        setTimeout(explode, 100);
	                },
	                error: function (data) {
	                    designSaved = false;
	                }
	            })

			}
		}

		function changePagination(pageId, liId) {
			$("#loadPriceFilter_p").show();
			$(".my-overlay").addClass('overlay-bg');

			var maxPrice = "";
			if ($("#hdn_max_price").val() != "") {
				maxPrice 	= $("#hdn_max_price").val();
			}	

			var minPrice = "";
			if ($("#hdn_min_price").val() != "") {
				minPrice 	= $("#hdn_min_price").val();
			}
	        
	        var sortPrice = "";
			if ($("#sort_price").val() != "") {
				sortPrice 	= $("#sort_price").val();
			}

	        var category_id = "";
			if ($("#hdn_category_id").val() != "") {
				category_id = '/'+$("#hdn_category_id").val();
			}
			var page_path  = "<?php echo base_url(); ?>category/filter";
		     
		   	$.ajax({
	           type: "POST",
	           url: page_path+category_id,
	           data: ({
                    minPrice  		: minPrice,
                    newMxPrice      : maxPrice,
                    category_id 	: category_id,
                    sortPrice 		: sortPrice,
                    pageId 			: pageId
                }),
	           cache: false,
	           success: function(result){
	                $("#dynamic_show_page").html(result);
                	$("#hdn_max_price").val(maxPrice);
           			$("#hdn_min_price").val(minPrice);
           			$("#sorter").val(sortPrice);
           			$(".link").removeClass("active") ;
             		$("#"+liId).addClass( "active" );
             		var explode = function(){
           				$("#loadPriceFilter_p").hide();
           				$(".my-overlay").removeClass('overlay-bg');
                    };
                    setTimeout(explode, 100);
	           }
	      	});
		}

	</script>

</div>
