<?php
	if (!empty($postData)) {
		$name 		= $postData['name'];
		$discription= $postData['discription'];
		$link 		= $postData['link'];
		$status 	= $postData['status'];
	}
?>
<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">Social Networking Icons</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h3 class="inner-tittle two">PAGES </h3>
			<?php
				if($this->session->flashdata('success')){ 
				?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
			} ?>
		<div class="graph">
			<div class="tables">
				<table class="table table-bordered" id="example-table">
				<thead> 
					<tr> 
						<th>Id</th> 
						<th>Email</th>
						<th>Status</th>
						<th>Action</th>  
					</tr> 
				</thead>
					<?php
						$i=0;
						foreach ($email_subscribers as $key => $sub) {
							$status = (!empty($sub['status']) && $sub['status'] == '1') ? 'Active' : 'Deactive';
						$i++; ?>
						<tr> 
							<th><?php echo $i; ?></th> 
							<th><?php echo $sub['email']; ?></th>
							<th><?php echo $status; ?></th> 
							<th>
							<?php if ($status == '1') { ?>
								<a href='<?php echo base_url('admin/pages/edit/'.$page['id']); ?>'>Deactive</a>
							<?php } else { ?>
									<a href='<?php echo base_url('admin/pages/edit/'.$page['id']); ?>'>Active</a>
							<?php } ?>
							
							
							</th>
						</tr>
					<?php }?>
				</table>
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( 'discription' );
</script>