<?php

// error_reporting(0);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Team extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->model('team_model');
        $this->load->model('news_model');
    }

    public function index()
    {
        // $users = $this->team_model->all_members();
        $users = $this->team_model->all_department();
        
        // $userss = $this->team_model->all_members2($users);
        // echo "<pre>";print_r($userss);die;
        $data['users'] = $users;
        defaultLoadView('team/our_team', $data);
    }
    
    public function details($id)
    {
        // echo "<pre>";print_r($id);die;
        $users = $this->team_model->member_detail2($id);
        // echo $this->db->last_query();die;
        $data['users'] = $users;
        defaultLoadView('team/details', $data);
    }
    
}