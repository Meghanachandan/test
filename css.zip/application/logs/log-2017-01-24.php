<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-01-24 06:25:47 --> Severity: Notice  --> Undefined variable: arr E:\wamp\www\cms\application\controllers\admin\product.php 38
ERROR - 2017-01-24 11:05:04 --> Severity: Notice  --> Array to string conversion E:\wamp\www\cms\application\controllers\admin\pages.php 61
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> assets
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> assets
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> assets
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/css
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> assets
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> assets
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> assets
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/css
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:04 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:05 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:05 --> 404 Page Not Found --> pages/js
ERROR - 2017-01-24 11:05:05 --> 404 Page Not Found --> pages/js
