<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AdminAuthenticate extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Admin_Model','',TRUE);
        $this->load->library('session');
        $this->load->database();
	}

	public function login(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $query = $this->Admin_Model->get_user(array("email"=>$email,"password"=>$password,"isactive"=>1))->row();
        // print_r($query);
        // die();
        if($query){
            $userdata = array(
                "reg_pkid"=>$query->reg_pkid,
                "fname"=>$query->fname,
                "email"=>$query->email,
                "phone"=>$query->phone,
                "password"=>$query->password

            );
            // print_r ($userdata);
            // die();
            $this->session->set_userdata($userdata);
            redirect("Admin/latest_news");
      
        }else{
            $this->session->set_flashdata('error','invalid username and password');
           
            redirect("AdminLogin/login");
        }
    }


   
    
    
   
}