<?php
//$this->load->view('admin/vwHeader');

?>
<!--<link href="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />-->
<!--  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
<!--  <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
<!--  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>


<div id="page-wrapper">
    
    <div class="row">
        <div class="col-lg-12">
            <h1>Users <small>Manage Designations</small></h1>
            <ol class="breadcrumb">
                <li><a href="<?= base_url("admin/department"); ?>"><i class="icon-dashboard"></i> Department</a></li>
                <li class="active"><i class="icon-file-alt"></i> Designation</li>
                <a href="#add_rec_modal" data-toggle="modal"> <button class=" btn btn-primary btn-sm" type="button" style="float:right;">Add Designation</button></a>
                <div style="clear: both;"></div>
            </ol>
        </div>
    </div>
  
    <?php
    if (validation_errors() != '') { ?>

        <div class="alert alert-danger" role="alert">
            <!-- <button class="close" data-dismiss="alert">x</button> -->
            <strong><?php echo ERRORS; ?>!</strong> <?php echo validation_errors(); ?>
        </div>
    <?php } ?>
    <?php
    if ($this->session->flashdata('flash_message')) {
        echo '<div class="alert bg-success"><a class="close" data-dismiss="alert">x</a><strong>' . $this->session->flashdata('flash_message') . '</strong></div>';
    }
    ?>
  
    <div class="row">
        <div class="col-lg-12 clearfix">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid">
                        <div class="table-responsive">
                            <table class="display responsive" id="dataTables-example4">
                                <thead>
                                    <tr>
                                        <th class="sorting_disabled">#</th>
                                        <th>Designation Name</th>
                                        <th>Department</th>
                                        <th class="sorting_disabled">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                //   $departments = array(
                                //       array(
                                //           "id"=>1,
                                //           "depart_id"=>1,
                                //           "designation"=>"new"
                                //           ),
                                //           array(
                                //           "id"=>2,
                                //           "depart_id"=>1,
                                //           "designation"=>"second"
                                //           ),
                                //           array(
                                //           "id"=>3,
                                //           "depart_id"=>1,
                                //           "designation"=>"teacher"
                                //           ),
                                //       );
                                  $i = 1;
                                  foreach ($designations as $k => $r) {
                                    echo '<tr>';
                                    echo '<td>' . $i++ . '</td>';
                                    echo '<td>' . $r['designation'] . '</td>';
                                    echo '<td>' . $r['department'] . '</td>';
                                    echo '<td style="width: 115px;" >';
                                    // echo '  &nbsp;&nbsp;&nbsp; <a  title="View Users Category" alt="View Users Category"  href="' . base_url() . 'admin/team/profile_view/' . $r['id'] . '"><i class="fa fa-user" aria-hidden="true"></i></a>';
                                    echo '  &nbsp;&nbsp;&nbsp; <a class="editrec" title="View/Edit" alt="View/Edit" data-toggle="modal" data-target="#edit_rec_modal" data-recname="'.$r['designation'].'" data-recid="'.$r['id'].'" data-departid="'.$r['depart_id'].'"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                                    // echo '  &nbsp;&nbsp;&nbsp; <a onclick=\'return confirm("Are you sure? you want to delete this user!")\' title="Delete" alt="Delete"  href="' . base_url() . 'admin/department/delete_designation/' . $r['id'] . '"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                                    echo '</td>';
                                    echo '</tr>';
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- col-lg-8  -->
    </div>
    
</div>


<!-- Add Department Modal -->
<div class="modal fade" id="add_rec_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <form accept-charset="UTF-8" action="<?php echo site_url('admin/department/add_designation') ?>" method="post">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Designation</h4>
      </div>
      <div class="modal-body">
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Department</label>
                <span>*</span> </div>
                <div class="col-sm-8 col-xs-12">
                    <select name="department" class="form-control">
                        <?php
                        foreach($departments as $d){
                            ?>
                        <option value="<?= $d["id"]; ?>"><?= $d["department"]; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            </div>
          </div>
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Name</label>
                <span>*</span> </div>
              <div class="col-sm-8 col-xs-12">
                <input type="text" name="designation" class="form-control" id="depart">
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" id="adddepart">Add</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </form>
    </div>
  </div>
</div>

<!-- Edit Department Modal -->
<div class="modal fade" id="edit_rec_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <form accept-charset="UTF-8" action="<?php echo site_url('admin/department/edit_designation') ?>" method="post">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Designation</h4>
      </div>
      <div class="modal-body">
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Department</label>
                <span>*</span> </div>
                <div class="col-sm-8 col-xs-12">
                    <select name="department" class="form-control" id="edepart">
                        <?php
                        foreach($departments as $d){
                            ?>
                        <option value="<?= $d["id"]; ?>"><?= $d["department"]; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
            </div>
          </div>
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label for="recname">Name</label>
                <span>*</span> </div>
                <div class="col-sm-8 col-xs-12">
                    <input type="hidden" name="id" readonly="readonly" class="form-control" id="erecid">
                    <input type="text" name="designation" class="form-control" id="erecname">
                </div>
            </div>
          </div>
          <div class="clearfix"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" id="adddepart">Save</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </form>
    </div>
  </div>
</div>



<!--<br />-->
<!--<br />-->
<!--<br />-->

</body>
<script>
      $(document).ready(function() {
          
        $(".editrec").click(function(){
            var depart_id = $(this).data("departid");
		    var recname = $(this).data("recname");
		    var recid = $(this).data("recid");
		    $("#edepart option[value='"+depart_id+"']").prop("selected",true);
		    $("#erecname").val(recname);
		    $("#erecid").val(recid);
		});
		
		
        dTable = $('#dataTables-example4').dataTable({
          "iDisplayLength": 10,
          "bProcessing": true,
          "bServerSide": false,
          "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
          ],
          "order": [
            [1, "asc"]
          ],
          "aoColumnDefs": [{
              "bSortable": false,
              "aTargets": [0]
            }, {
              "bSortable": false,
              "aTargets": [-1]
            }
    
          ]
        });
        
        // $('select[name="department"]').select2({
        //     placeholder: "Select country",
        //     allowClear: true
        // });
        
      });

</script>
</html>
<?php //$this->load->view('admin/vwFooter'); ?>
<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>