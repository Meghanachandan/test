<?php
if (!empty($postData)) {
    
}
$allcategories = get_blog_categories();
//var_dump($allcategories);
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/news/categories'); ?>">ADDS</a></li>
            <li class="active">MANAGE ADDS</li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">MANAGE ADDS</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <form action="<?php echo base_url('admin/adds/addmanage'); ?>" enctype="multipart/form-data" method="post">
                    <input type="hidden" value=""/>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Select Add <span class="star-color">*</span></label>
                        <select class='form-control' name="position" id="position" required="required">
                            <option value="">Select Add...</option>
                            <?php
                            foreach($addss as $category){
                                ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo $category['title']; ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Select Category <span class="star-color">*</span></label>
                        <select class='form-control' name="manage_category" id="manage_category" required="required">
                            <option value="">Select Category...</option>
                            <?php
                            $s=0;
                            foreach($allcategories as $category){
                                $s++;                        
                                ?>
                                <option value="<?php echo $category['slug']; ?>"><?php echo $category['title']; ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
    <div class="graph-visual tables-main">
        <h3 class="inner-tittle two">ADDS</h3>
        <?php
        if ($this->session->flashdata('success')) {
            ?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php }
        ?>
        <div class="graph">
            <div class="tables">
                <table class="display responsive" id="example-table">
                    <thead> 
                        <tr> 
                         
                            <th style='    font-weight: bold;
                       text-decoration: underline;' width="250px" >Category</th>
                             
                            <th style='    font-weight: bold;
                     text-decoration: underline;' width="250px" >Adds</th> 
                            <th style='    font-weight: bold;
                       text-decoration: underline;' width="250px" >Action</th>  
                        </tr> 
                    </thead>
                    <br/><br/>
                    <?php
                    $i = 0;
                    foreach ($adds as $key => $blog) {
                        //$status = (!empty($blog['position']) && $blog['position'] == '1') ? 'Active' : 'Deactive';
                        $i++;
                        ?>
                        <tr> 
                           
                            <th><?php echo $blog['categoriesid'];
                            //$this->db->select('*');
// $this->db->from('news_categories');
// $this->db->where('id',$blog['categoriesid']);
// $query = $this->db->get();
// $result11 = $query->result_array();  
// foreach($result11 as $result){
//     echo $result[title];
// }
                            ?></th>
                             
                            <th><?php $this->db->select('*');
$this->db->from('adds');
$this->db->where('id',$blog['addsid']);
$quer = $this->db->get();
$result = $quer->result_array();  
foreach($result as $result1){
    echo $result1[title];
} ?></th> 
                            <th>
                                <!--<a href='<?php echo base_url('admin/news/categorie_edit/' . $blog['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp; -->
                                <a onclick='return confirm("Are you sure? you want to delete this Manage Adds!")' href='<?php echo base_url('admin/adds/man_add_delete/' . $blog['id']); ?>'><i class="fa fa-trash-o"></i></a>
                            </th>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script type="text/javascript" > 
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
    
   
</script>