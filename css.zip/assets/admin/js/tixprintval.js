function changesType(d){

	$("#selectType").val(d);
	
	if(d=='v'){
		$("#landscapeLayout").hide();
		$("#portraitLayout").show();
	}
	if(d=='h'){
		$("#portraitLayout").hide();
		$("#landscapeLayout").show();
	}
		
}

function changesTheme(color,id){
	
	var base_url = $("#BaseUrl").val();
		
	$("#portraitLayout").show();
	
	var page_path = base_url+'printing/change_color';
	
	var layout = $("#selectType").val();
	
	if(layout==''){
		alert('Please Select Ticket Design.');
		document.getElementById('portrait').focus();
		return false;	
	}
	
	$("#selectedColor").val(color);
	
	$('#'+id).prop('checked', true);
	
	$.ajax({
            type: "POST",
            data: "color="+color+"&layout="+layout,
            url: page_path,
            success: function(data) {
            	$("#designArea #wrapper").css('background-image', 'url('+ data +')');
				if(layout=='v'){
					$("#designArea").html(data);	
					$(".selectdummyticket").text("Your Ticket");
				}
				if(layout=='h'){
					$("#printing-preview-landscape").html(data);
					$(".selectdummyticket").text("Your Ticket");
				}
			}
        });
	
}


function displayError(div, msg){
	var inputBoxId = div.substring(4);
	$("#"+inputBoxId).addClass('inputerror');
	$("#"+div).addClass('validation_error');
	$("#"+div).show('slow');
	$("#"+div).html(msg);

}
function removeError(div) {
	var inputBoxId = div.substring(4);
	$("#"+inputBoxId).removeClass('inputerror');
	$("#"+div).removeClass('validation_error');
	//$("#"+div).addClass('success');
	$("#"+div).text('');
	$("#"+div).hide();
}

function fieldValidation() {
	var error = 0;
	var getPresented = $("#presented_by").val();
	if(getPresented==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Value of Presented by for Ticket Design";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	var geteventname = $("#event_name").val();
	if(geteventname==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Value of Event Name for Ticket Design";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	var getprintingdate = $("#printing_date").val();
	if(getprintingdate==''){
		$('#client_error').css('display', 'block');
		var error = "Please Select the Date.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	
	var getprintingtime = $("#printing_time").val();
	if(getprintingtime==''){
		$('#client_error').css('display', 'block');
		var error = "Please Select the Time.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	var geteventlocation = $("#event_location").val();
	if(geteventlocation==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter the Location.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	
	var getcontactprinting = $("#contact_printing").val();
	if(getcontactprinting==''){
		
		$('#client_error').css('display', 'block');
		var error = "Please Enter the Contact Number.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	else {
		//var contactprinting = /^\d{10}$/;
		var contactprinting = /^[1-9][0-9]{9,14}$/ ;
		if (!getcontactprinting.match(contactprinting)) {
			
			$('#client_error').css('display', 'block');
		
			var error = "Please Enter Valid contact Number.";
			 $('.error_span').text(error);
			location.hash = '#client_error';
			$('html, body').animate({
			   scrollTop: 0 
			}, 200);
			return false;
		}
	}

	var getotherinfo = $("#other_info").val();
	if(getotherinfo==''){
		$('#client_error').css('display', 'block');
		var error = "Please also add other info.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	/*
	var getTicketPrice = $("#TicketPrice").val();
	if(getTicketPrice==''){
		$('#client_error').css('display', 'block');
		var error = "Please Add Price .";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	
	var getQuantity = $("#Quantity").val();
	if(getQuantity==''){
		$('#client_error').css('display', 'block');
		var error = "Please Add Quantity .";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	var selectType = $("#selectType").val();
	if(selectType==''){
		$('#client_error').css('display', 'block');
		var error = 'Please Select Ticket Design';
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}*/

	
	/*var getColor = $("#selectedColor").val();
	if(getColor==''){
		$('#client_error').css('display', 'block');
		var error = "Please Select Color for Ticket Design";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}*/

	var EventName = $("#event_name").val();
	if(EventName==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Event Name";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	} else if(EventName.length > 40){
		$('#client_error').css('display', 'block');
		var error = "Event Name must be less than 40 characters";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}

	/*var VenueName = $("#VenueName").val();
	if(VenueName==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Venue Name.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	} else if(VenueName.length > 40){
		$('#client_error').css('display', 'block');
		var error = "Venue Name must be less than 40 characters";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	
	var VenueAddress = $("#VenueAddress").val();
	if(VenueAddress==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Venue Address.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	} else if(VenueAddress.length > 30){
		$('#client_error').css('display', 'block');
		var error = "Venue Address must be less than 30 characters";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}*/
	
	/*var EventUrl = $("#EventUrl").val();
	if(EventUrl==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Event URL.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}*//*
	url_validate = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;

	if (!url_validate.test(EventUrl)) {
		$('#client_error').css('display', 'block');
		var error = "Please Enter Valid Event URL.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}*/
	
	var EventDate = $("#EventDate").val();
	if(EventDate==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Event Date.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}
	
	var EventTime = $("#EventTime").val();
	if(EventTime==''){
		$('#client_error').css('display', 'block');
		var error = "Please Enter Event Time.";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}

	var editOrderId = $("#OrderID").val();
	if (editOrderId > 0) {
		var page = "edit";
	} else {
		var page = "add";
	}

	

	var editTaskType = new Array();	
	$('.edittasktype').each(function(){
		if ($(this).val() == "") {
			editTaskType.push(false);
		} else {
			editTaskType.push(true);
		}
	});

	var editTaskPrice = new Array();	
	$('.edittaskprice').each(function(){
		
		var editPriceValue = $(this).val();
		if (editPriceValue == "") {
			editTaskPrice.push("null");
		} else if($.isNumeric(editPriceValue) == false) {
			editTaskPrice.push("num");
		} else {
			editTaskPrice.push("true");
		}
	});

	if (editOrderId > 0 && editOrderId != "") {

		if(jQuery.inArray(false, editTaskType) !== -1) {
			$('#client_error').css('display', 'block');
			var error = "Please Enter Ticket Type (VIP).";
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}

		if(jQuery.inArray("null", editTaskPrice) !== -1) {

			$('#client_error').css('display', 'block');
			var error = "Please Enter Ticket Price (VIP).";
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
        	return false;
        }

        if(jQuery.inArray("num", editTaskPrice) !== -1) {
			$('#client_error').css('display', 'block');
			var error = "Invalid Ticket Price";
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
	}

	
	var TicketType = new Array();	
	$('.tasktype').each(function(){
		if ($(this).val() == "") {
			TicketType.push(false);
		} else {
			TicketType.push(true);
		}
	});

	// Ticket Quentity Empty and Number Validation 
	var quantity = new Array();	
	$('.taskqty').each(function(){
		var qutValue = $(this).val();
		if (qutValue == "") {
			quantity.push("null");
		} else if($.isNumeric(qutValue) == false) {
			quantity.push("num");
		} else {
			quantity.push("true");
		}
	});

	// Ticket Price Empty and Number Validation 
	var TicketPrice = new Array();	
	$('.task').each(function(){
		
		var priceValue = $(this).val();
		if (priceValue == "") {
			TicketPrice.push("null");
		} else if($.isNumeric(priceValue) == false) {
			TicketPrice.push("num");
		} else {
			TicketPrice.push("true");
		}
	});

	var hideValidated = $("#hiddenvalidate").val();

	
	var updateInputValidate = false;
	if (hideValidated == "true" && page == "edit") {
		var updateInputValidate = true;
	}

	if ((TicketPrice == "true" || quantity == "true") || (updateInputValidate == true) || (page == "add" && TicketType.length > 0)) {
		
		if(jQuery.inArray(false, TicketType) !== -1) {
			$('#client_error').css('display', 'block');
			var error = "Please Enter Ticket Type (VIP).";
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
	}
	
	var TicketStartingNumber = $("#TicketStartingNumber").val();
	
	if(jQuery.inArray("null", quantity) !== -1) {
		
		if ((TicketPrice == "true" || TicketType == "true") || (updateInputValidate == true) || (page == "add" && quantity.length > 0)) {

			$('#client_error').css('display', 'block');
			var error = "Please Enter Ticket Quantity.";
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;

	    }

	} else if(jQuery.inArray("num", quantity) !== -1) {
		$('#client_error').css('display', 'block');
		var error = "Invalid Ticket Quantity";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}

	if ((quantity == "true" || TicketType == "true") || (updateInputValidate == true) || (page == "add" && TicketPrice.length > 0)) {
		
		if(jQuery.inArray("null", TicketPrice) !== -1) {

			$('#client_error').css('display', 'block');
			var error = "Please Enter Ticket Price (VIP).";
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
        	return false;
        }
	} else if(jQuery.inArray("num", TicketPrice) !== -1) {
		$('#client_error').css('display', 'block');
		var error = "Invalid Ticket Price";
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	}

	$('#client_error').css('display', 'none');
	return true;
}

function chkproceed(){
	var valdationAction = fieldValidation();
	//alert(valdationAction');
	if (!valdationAction) {
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
		return false;
	}
	
	var orderId_detail = new Array();
	$('.taskorderId').each(function(){
		orderId_detail.push($(this).val());
	});
	
	var TicketTitle = new Array();	
	$('.tasktype').each(function(){
		TicketTitle.push($(this).val());
	});
	
	var quantityv = new Array();	
	$('.taskqty').each(function(){
		quantityv.push($(this).val());
	});
	
	var TicketPricev = new Array();	
	$('.taskpricetix').each(function(){
		TicketPricev.push($(this).val());
	});
	
	var startingNumberv =   new Array();
	$('.tasksn').each(function(){
		startingNumberv.push($(this).val());
	});
	
	var ticketamtCharge =   new Array();
	$('.taskamtcharge').each(function(){
		ticketamtCharge.push($(this).val());
	});
	
	var ticketColorv =   new Array();
	$('.tasktc').each(function(){
		ticketColorv.push($(this).val());
	});
	
	
	
	var OrderID = $("#OrderID").val();

	var tickettext1 = $("#tickettext1").val()
	var tickettext2 = $("#tickettext2").val()
	var tickettext3 = $("#tickettext3").val()
	var tickettext4 = $("#tickettext4").val()
	var ticketFile = $("#ticketFile").val();
	var ticket_type = $("#ticket_type").val();
	var special_instruction = $("#special_instruction").val();
	var presented_by = $("#presented_by").val();
	var event_name = $("#event_name").val();
	var printing_date = $("#printing_date").val();
	var printing_time = $("#printing_time").val();
	var event_location = $("#event_location").val();
	var contact_printing = $("#contact_printing").val();
	var other_info = $("#other_info").val();
	//var sequence = $("#sequence").val();
	
	var norefundchk = $("#norefund").prop('checked');
	if(norefundchk){
		norefund = 1;
	}else{
		norefund = 0;
	}
	condtins = $("#you_will_charged").is(':checked');
	if(condtins==false){
		alert("Please accept You will be Charged to place your order! ");
		return false;
	}
	
	
	var base_url = $("#BaseUrl").val();
	var page_path = base_url+'printing/insertFristStepData'
	$.ajax({
            type: "POST",
			data: "OrderID="+OrderID+"&TicketTitle="+TicketTitle+"&quantity="+quantityv+"&startingNumber="+startingNumberv+"&presented_by="+presented_by+"&event_name="+event_name+"&printing_date="+printing_date+"&printing_time="+printing_time+"&event_location="+event_location+"&contact_printing="+contact_printing+"&other_info="+other_info+"&price_on_tix="+TicketPricev+"&chargedamt="+ticketamtCharge+"&ticketcolor="+ticketColorv+"&tickettext1="+tickettext1+"&tickettext2="+tickettext2+"&tickettext3="+tickettext3+"&tickettext4="+tickettext4+"&fileName="+ticketFile+"&norefund="+norefund+"&ticket_type="+ticket_type+"&special_instruction="+special_instruction+"&order_detail_id="+orderId_detail,
            url: page_path,
            success: function(data) {
				//alert(data);
				
				var res = data.split("#"); 
				if(res[0]=='success'){
					window.location.href = base_url+'printing/StepThree/'+res[1];
					
				}else{
					alert('Data not Proper.');
					return false;
				}
				
			}
        });
}

//for store stape 2
function storeUser(){
	
	var error = 0;
	var focusField = "";	
	
	var FirstName = $("#FirstName").val();
	if(FirstName == ''){
		$('#client_error').css('display', 'block');
		var error = 'Please Enter First Name';
		 $('.error_span').text(error);
		location.hash = '#client_error';
        $('html, body').animate({
           scrollTop: 0 
        }, 200);
        return false;
	} 

	var LastName = $("#LastName").val();
		if(LastName==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Last Name';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
	var signup = document.getElementById('signup');
	

    if (signup.checked){
        var is_newsletter = '1';
    }else{
        var is_newsletter = '0';
    }
	var orderId = $("#orderId").val();
	
	if(error == 1) {
		return false;
	}
	
	var Prefix = $("#Prefix").val();
	var Suffix = $("#Suffix").val();
	var home_phone = $("#home_phone").val();
	var cell_phone = $("#cell_phone").val();
	var gender = $("#gender").val();
	var birth_date = $("#birth_date").val();
	
	var base_url = $("#base_url").val();
	var userId = $("#userId").val();
	
	$.ajax({
		type: "POST",
		data: "FirstName="+FirstName+"&LastName="+LastName+"&is_newsletter="+is_newsletter+"&orderId="+orderId+"&Prefix="+Prefix+"&Suffix="+Suffix+"&home_phone="+home_phone+"&cell_phone="+cell_phone+"&gender="+gender+"&birth_date="+birth_date+"&userId="+userId,
		url: base_url+'printing/insertUser',
		success: function(data) {
			var res = data.split("#"); 
			if(res[0]=='success'){
					window.location.href = base_url+'printing/StepThree/'+res[1];
				}else{
					alert('Data not Proper.');
					return false;
				}
				
		}
	});
	
	
}

function IsEmail(email) {
	var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(!regex.test(email)) {
	   return false;
	}else{
	   return true;
	}
}	

function SubmitThirdStep(){
		var error = 0;
		var focusField = "";	
	
		var Address1 = $("#Address1").val();
		if(Address1==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Address 1';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		/*
		var Address2 = $("#Address2").val();
		if(Address2==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Address 2';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}*/
		
		var CountryId = $("#bill_country").val();
		if(CountryId==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Select Country';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		var StateOrProvinceId = $("#bill_state").val();
		if(StateOrProvinceId==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter State';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		var City = $("#City").val();
		if(City==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter City';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		var PostCode = $("#PostCode").val();
		if(PostCode==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Post Code';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
				
		var ShipAddress1 = $("#ShipAddress1").val();
		if(ShipAddress1==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Shipping Address';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		/*var ShipAddress2 = $("#ShipAddress2").val();
		if(ShipAddress2==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Shipping Address 2';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}*/
		
		var shipCountry = $("#ship_country").val();
		if(shipCountry==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Shipping Country';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		var ShipState = $("#ship_state").val();

		if(ShipState==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Shipping State';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		var ShipCity = $("#ShipCity").val();
		if(ShipCity==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Shipping City';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}
		
		var ShipPostCode = $("#ShipPostCode").val();
		if(ShipPostCode==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Shipping Post Code';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}

		var textEmail = $("#textEmail").val();
		if(textEmail==''){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Email Address';
			 $('.error_span').text(error);
			location.hash = '#client_error';
	        $('html, body').animate({
	           scrollTop: 0 
	        }, 200);
	        return false;
		}

		if(IsEmail(textEmail)==false){
			$('#client_error').css('display', 'block');
			var error = 'Please Enter Valid Email Address';
			$('.error_span').text(error);
			location.hash = '#client_error';
			$('html, body').animate({
			   scrollTop: 0 //$("#client_error").offset().top
			}, 200);
			return false;
		}

		if(error == 1) {
				return false;
		}
		$("form#design-form").submit();
}

