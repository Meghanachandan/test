<?php


if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Upload extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        echo '404';
    }

    public function post($user_id, $id = null)
    {
        $type = $_GET['type'];
        $CKEditor = $_GET['CKEditor'];
        $funcNum = $_GET['CKEditorFuncNum'];
        if (isset($_FILES['upload']) && !empty($_FILES['upload']['name'])) {
            $data['error'] = array();
            $file_name  = time() . $_FILES['upload']['name'];
            $file_size  = $_FILES['upload']['size'];
            $file_tmp   = $_FILES['upload']['tmp_name'];
            $file_type  = $_FILES['upload']['type'];
            $file_ext   = strtolower(end(explode('.', $_FILES['upload']['name'])));
            $expensions = array("jpeg", "jpg", "png", "gif");

            /*
            if (in_array($file_ext, $expensions) === false) {
                $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
            }

            if ($file_size > 2097152) {
                $data['error'] = 'File size must be excately 2 MB';
            }
            */
            //$updateData['image'] = $file_name;

            if (empty($data['error']) == true) {
                move_uploaded_file($file_tmp, "./upload/news/" . $file_name);
                //echo base_url().'upload/news/'.$file_name;
                /*
                    $data = array();
                    $data['fileName'] = $file_name;  
                    $data['uploaded'] = 1;  
                    $data['url'] = base_url().'upload/news/'.$file_name;  
                */
                //echo '<img sytle="min-height:300px" src="'.base_url().'upload/news/'.$file_name.'"/>';
                //echo json_encode($data);
                $url = base_url() . 'upload/news/' . $file_name;
                echo '<script>window.parent.CKEDITOR.tools.callFunction(' . $funcNum . ', "' . $url . '", "' . $message . '")</script>';
                exit;
            }
        }
    }
}
