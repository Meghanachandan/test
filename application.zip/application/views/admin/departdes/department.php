<?php
//$this->load->view('admin/vwHeader');

?>
  <!--<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
  <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
  <!--<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>



<div id="page-wrapper">
    
    <div class="row">
        <div class="col-lg-12">
            <h1>Users <small>Manage Departments</small></h1>
            <ol class="breadcrumb">
                <li class="active"><i class="icon-file-alt"></i> Department</li>
                <a> <button  data-toggle="modal" data-target="#add_rec_modal" class=" btn btn-primary btn-sm" type="button" style="float:right;">Add New Department</button></a>
                <div style="clear: both;"></div>
            </ol>
        </div>
    </div>
    
    <?php
    if (validation_errors() != '') { ?>

        <div class="alert alert-danger" role="alert">
            <!-- <button class="close" data-dismiss="alert">x</button> -->
            <strong><?php echo "ERRORS:"; ?>!</strong> <?php echo validation_errors(); ?>
        </div>
    <?php } ?>
    <?php
    if ($this->session->flashdata('flash_message')) {
        echo '<div class="alert bg-success"><a class="close" data-dismiss="alert">x</a><strong>' . $this->session->flashdata('flash_message') . '</strong></div>';
    }
    ?>
  
    <div class="row">
        <div class="col-lg-12 clearfix">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <div id="dataTables-example_wrapper" class="dataTables_wrapper form-inline" role="grid">
                        <div class="table-responsive">
                            <table class="display responsive" id="dataTables-example4">
                                <thead>
                                    <tr>
                                        <th class="sorting_disabled">#</th>
                                        <th>Department Name</th>
                                        <th class="sorting_disabled">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php
                                //   $departments = array(
                                //       array(
                                //           "id"=>1,
                                //           "department"=>"new"
                                //           ),
                                //           array(
                                //           "id"=>2,
                                //           "department"=>"second"
                                //           ),
                                //           array(
                                //           "id"=>3,
                                //           "department"=>"teacher"
                                //           ),
                                //       );
                                  $i = 1;
                                  foreach ($departments as $k => $r) {
                                    echo '<tr>';
                                    echo '<td>' . $i++ . '</td>';
                                    echo '<td>' . $r['department'] . '</td>';
                                    echo '<td style="width: 115px;" >';
                                    echo '  &nbsp;&nbsp;&nbsp; <a class="editrec" data-toggle="modal" data-target="#edit_rec_modal" title="View/Edit" alt="View/Edit"  data-recname="'.$r['department'].'" data-recid="'.$r['id'].'"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                                    // echo '  &nbsp;&nbsp;&nbsp; <a onclick=\'return confirm("Are you sure? you want to delete this user!")\' title="Delete" alt="Delete"  href="' . base_url() . 'admin/department/delete_record/' . $r['id'] . '"><i class="fa fa-trash-o" aria-hidden="true"></i></a>';
                                    echo '</td>';
                                    echo '</tr>';
                                  }
                                  ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- col-lg-8  -->
    </div>
    





</div>

<!--<br />-->
<!--<br />-->
<!--<br />-->

</body>

<script>
      $(document).ready(function() {
        $(".editrec").click(function(){
		    var recname = $(this).data("recname");
		    var recid = $(this).data("recid");
		    $("#erecname").val(recname);
		    $("#erecid").val(recid);
		});

        dTable = $('#dataTables-example4').dataTable({
          "iDisplayLength": 10,
          "bProcessing": true,
          "bServerSide": false,
          "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
          ],
          "order": [
            [1, "asc"]
          ],
          "aoColumnDefs": [{
              "bSortable": false,
              "aTargets": [0]
            }, {
              "bSortable": false,
              "aTargets": [-1]
            }
    
          ]
        });
      });

</script>
</html>
<?php //$this->load->view('admin/vwFooter'); ?>
<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>


<!-- Add Department Modal -->
<div class="modal fade" id="add_rec_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <form accept-charset="UTF-8" action="<?php echo site_url('admin/department/add_record') ?>" method="post">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Department</h4>
      </div>
      <div class="modal-body">
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label>Name</label>
                <span>*</span> </div>
              <div class="col-sm-8 col-xs-12">
                <input type="text" name="department" class="form-control" id="depart">
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" id="adddepart">Add</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </form>
    </div>
  </div>
</div>

<!-- Edit Department Modal -->
<div class="modal fade" id="edit_rec_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <form accept-charset="UTF-8" action="<?php echo site_url('admin/department/edit_record') ?>" method="post">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Department</h4>
      </div>
      <div class="modal-body">
          <div class="col-sm-12 clearfix mb">
            <div class="form-group clearfix">
              <div class="col-sm-3 col-xs-12 lable-rite">
                <label for="erecname">Name</label>
                <span>*</span> </div>
                <div class="col-sm-8 col-xs-12">
                    <input type="hidden" name="id" readonly="readonly" class="form-control" id="erecid">
                    <input type="text" name="department" class="form-control" id="erecname">
                </div>
            </div>
          </div>
          <div class="clearfix"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" id="adddepart">Save</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </form>
    </div>
  </div>
</div>
