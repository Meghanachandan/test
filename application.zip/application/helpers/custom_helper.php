<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('adminLoadView')) {
    function adminLoadView($filename, $data = array())
    {
        $CI = &get_instance();
        $CI->load->view('admin/vwHeader');
        $CI->load->view('admin/' . $filename, $data);
        $CI->load->view('admin/vwFooter');
    }
}

if (!function_exists('defaultLoadView')) {
    function defaultLoadView($filename, $data = array())
    {
        $CI = &get_instance();
        $CI->load->view('vwHeader', $data);
        $CI->load->view($filename, $data);
        $CI->load->view('vwFooter', $data);
    }
}

if (!function_exists('getMultipleRecord')) {
    function getMultipleRecord($tablename, $status = "")
    {
        if (!empty($tablename)) {

            $CI     = &get_instance();
            if (!empty($status)) {
                $CI->db->where('status', $status);
            }

            $query  = $CI->db->get($tablename);
            $ret    = $query->result_array();
            return $ret;
        }
    }
}

if (!function_exists('addUpdateRecord')) {
    function addUpdateRecord($tablename, $field = '', $value = '', $data = array())
    {
        $CI     = &get_instance();
        if (!empty($field) && !empty($value)) {
            $CI->db->where($field, $value);
            $result = $CI->db->update($tablename, $data);
        } else {
            $result2 = $CI->db->insert($tablename, $data);
            $result = $CI->db->insert_id();
        }

        if ($result) {
            return $result;
        }
        return false;
    }
}

if (!function_exists('getRecordById')) {
    function getRecordById($tablename,  $id = '')
    {
        $CI     = &get_instance();
        $CI->db->where('id', $id);
        $q = $CI->db->get($tablename);
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        return $data;
    }
}

if (!function_exists('getRecordBySlug')) {
    function getRecordBySlug($tablename,  $slug = '', $status)
    {
        $CI     = &get_instance();
        $CI->db->where('slug', $slug);
        if (!empty($status)) {
            $CI->db->where('status', $status);
        }
        $q = $CI->db->get($tablename);
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        return $data;
    }
}

if (!function_exists('getRecordByEmail')) {
    function getRecordByEmail($tablename,  $email = '', $status)
    {
        $CI     = &get_instance();
        $CI->db->where('email', $email);
        if (!empty($status)) {
            $CI->db->where('status', $status);
        }
        $q = $CI->db->get($tablename);
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        return $data;
    }
}

if (!function_exists('deleteRecordById')) {
    function deleteRecordById($tablename,  $id = '')
    {
        $CI     = &get_instance();
        $CI->db->where('id', $id);
        $result = $CI->db->delete($tablename);
        if ($result) {
            return true;
        }
        return false;
    }
}

if (!function_exists('getRecordByFieldName')) {
    function getRecordByFieldName($tablename,  $field = '', $value = '', $order = "asc", $limit = "")
    {
        $CI     = &get_instance();
        $CI->db->where($field, $value);
        if (!empty($limit)) {
            $CI->db->limit($limit);
        }

        if (!empty($order)) {
            $CI->db->order_by("id", $order);
        }

        $q = $CI->db->get($tablename);
        //if id is unique we want just one row to be returned
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('getLimitRecords')) {
    function getLimitRecords($tablename,  $offset = '', $limit = '', $order = 'asc', $status = 1)
    {
        if (!empty($offset)) {
            $offset = $offset . ", ";
        }

        if (!empty($limit)) {
            $limit = "limit " . $offset . $limit;
        }

        if (!empty($tablename)) {
            $CI     = &get_instance();
            $query  = "select * from " . $tablename . " WHERE status = '" . $status . "' Order By id " . $order . " " . $limit;
            $query  = $CI->db->query($query);
            $rows   = $query->result_array();
            return $rows;
        }
    }
}


/*
      Function name :SecurePostData()
      Parameter : string
      Return : secure string
      Use : all input post or get data wil be purify for sql injection and cross scripting
     */

/*   function SecurePostData($string = '') {
        $string = html_purify($string);
        $string = preg_replace('/(\r\n\r\n)$/', '', $string);
        $string = preg_replace("/\n+/", "", $string);
        $string = str_replace("\n", "<br>", $string);
        $string = str_replace("\r", "", $string);
        $string = strip_slashes($string);
        $string = str_replace(PHP_EOL, null, $string);

        return $string;
    }  
*/

/*
  Function name :check_user_authentication()
  Parameter : none
  Return : true or false
  Use : check user login or logout
 */
if (!function_exists('check_user_authentication')) {
    function check_user_authentication($redirect = false, $current_page = '')
    {

        $CI = &get_instance();

        if ($CI->session->userdata('user_id') != '') {
            return $CI->session->userdata('user_id');
        } else {
            if ($redirect == true) {
                $page = '';
                $url = site_url('user/login');
                redirect($url);
            }
            return false;
        }
    }
}

if (!function_exists('send_email_with_template')) {

    function send_email_with_template($email_to = '', $email_from = '', $subject = '', $template = '', $data = '')
    {
        $email_from = "NEWSSYN AUTHOR";
        $msg = $CI->load->view('email_templates/' . $template, $data, TRUE);
        $CI->email->from($email_from);
        $CI->email->to($email_to);
        $CI->email->reply_to($email_from);
        $CI->email->subject($subject);
        $CI->email->message($msg);
        if ($CI->email->send()) {
            return true;
        }
        return false;
    }
}

if (!function_exists('send_email_with_message')) {

    function send_email_with_message($email_to = '', $email_from = '', $subject = '', $data = '')
    
    {
        $CI = &get_instance();

        $config = array();
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.googlemail.com';
        $config['smtp_port'] = '465';
        $config['smtp_user'] = 'newsagcnn@gmail.com';
        $config['smtp_pass'] = 'masscomm';
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
       
        $CI->load->library('email', $config);

        $CI->email->from($email_from);
        $CI->email->to($email_to);
        $CI->email->reply_to($email_from);
        $CI->email->subject($subject);
        $CI->email->message($data);


        if ($CI->email->send()) {
            return true;
        }
        return false;
    }
}

if (!function_exists('getPagination')) {

    function getPagination($count, $page)
    {

        $total      = $count;
        $adjacents  = "2";
        $per_page   = 9;
        $page       = ($page == 0 ? 1 : $page);
        $start      = ($page - 1) * $per_page;

        $prev       = $page - 1;
        $next       = $page + 1;
        $setLastpage = ceil($total / $per_page);
        $lpm1       = $setLastpage - 1;

        if ($count > 0) {

            $setPaginate .= "<ul class='setPaginate'>";
            $setPaginate .= "<li class='setPage hidden-xs'>Page $page of $setLastpage</li>";

            if ($page == '1') {

                $setPaginate .= "<li><a class='current_page'>First</a></li>";
                $setPaginate .= "<li><a class='current_page'>Prev</a></li>";
            } else {
                $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'1\',\'last\')">First</a></li>';
                $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($prev) . '\',\'last\')">Prev</a></li>';
            }

            if ($setLastpage < 7 + ($adjacents * 2)) {
                for ($counter = 1; $counter <= $setLastpage; $counter++) {
                    if ($counter == $page)
                        $setPaginate .= "<li><a class='current_page'>$counter</a></li>";
                    else
                        $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($counter) . '\',\'last\')">' . $counter . '</a></li>';
                }
            } elseif ($setLastpage > 5 + ($adjacents * 2)) {
                if ($page < 1 + ($adjacents * 2)) {
                    for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                        if ($counter == $page)
                            $setPaginate .= "<li><a class='current_page'>$counter</a></li>";
                        else
                            $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($counter) . '\',\'last\')">' . $counter . '</a></li>';
                    }
                    $setPaginate .= "<li class='dot'>...</li>";
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($lpm1) . '\',\'last\')">' . $lpm1 . '</a></li>';
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($setLastpage) . '\',\'last\')">' . $setLastpage . '</a></li>';
                } elseif ($setLastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . (1) . '\',\'last\')">1</a></li>';
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . (2) . '\',\'last\')">2</a></li>';
                    $setPaginate .= "<li class='dot'>...</li>";
                    for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                        if ($counter == $page)
                            $setPaginate .= "<li><a class='current_page'>$counter</a></li>";
                        else
                            $setPaginate .= '<li  href="javascript:void(0)" onclick="changePagination(\'' . ($counter) . '\',\'last\')"><a>' . $counter . '</a></li>';
                    }
                    $setPaginate .= "<li class='dot'>..</li>";
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($lpm1) . '\',\'last\')">' . $lpm1 . '</a></li>';
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($setLastpage) . '\',\'last\')">' . $setLastpage . '</a></li>';
                } else {
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . (1) . '\',\'last\')">1</a></li>';
                    $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . (2) . '\',\'last\')" >2</a></li>';
                    $setPaginate .= "<li class='dot'>..</li>";
                    for ($counter = $setLastpage - (2 + ($adjacents * 2)); $counter <= $setLastpage; $counter++) {
                        if ($counter == $page)
                            $setPaginate .= "<li><a class='current_page'>$counter</a></li>";
                        else
                            $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($counter) . '\',\'last\')">' . $counter . '</a></li>';
                    }
                }
            }
            if ($page < $counter - 1) {
                $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($next) . '\',\'last\')">Next</a></li>';
                $setPaginate .= '<li><a  href="javascript:void(0)" onclick="changePagination(\'' . ($setLastpage) . '\',\'last\')">Last</a></li>';
            } else {
                $setPaginate .= "<li><a class='current_page'>Next</a></li>";
                $setPaginate .= "<li><a class='current_page'>Last</a></li>";
            }

            $setPaginate .= "</ul>\n";
            if ($count > $per_page) {
                $content['pagination']  = $setPaginate;
            } else {
                $content['pagination']  = "";
            }

            $content['per_page']    = $per_page;
            $content['start_from']  = $start;
        } else {
            $content['pagination']  = "";
            $content['per_page']    = $per_page;
            $content['start_from']  = $start;
        }
        return $content;
    }
}

if (!function_exists('getCartCountNTotal')) {

    function getCartCountNTotal()
    {

        $CI = &get_instance();
        $CI->load->library('cart');

        $cartContainers['itemsCount'] = 0;
        $cartContainers['total'] = priceFormate(00);
        $items =  $CI->cart->contents();

        if (!empty($items)) {

            $totalPriceArr = array();
            $totalQtyArr = array();
            foreach ($items as $item) {
                $totalPriceArr[] = $item['subtotal'];
                $totalQtyArr[] = $item['qty'];
            }
            $totalPrice = array_sum($totalPriceArr);
            $totalQty = array_sum($totalQtyArr);
            $cartContainers['total'] = priceFormate($totalPrice);
            $cartContainers['itemsCount'] = $totalQty;
        }

        return $cartContainers;
    }
}

if (!function_exists('priceFormate')) {

    function priceFormate($amount)
    {
        $currency = '$';
        $format = $currency . number_format($amount, 2);
        return $format;
    }
}

if (!function_exists('getCountries')) {
    function getCountries($status = '')
    {
        $CI     = &get_instance();
        if ($status != "") {
            $CI->db->where('active', $status);
        }
        $q = $CI->db->get('countries');
        //if id is unique we want just one row to be returned
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('getStates')) {
    function getStates($status = '')
    {
        $CI     = &get_instance();
        if ($status != "") {
            $CI->db->where('active', $status);
        }
        $q = $CI->db->get('states');
        //if id is unique we want just one row to be returned
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('getStateByCountry')) {
    function getStateByCountry($country_id)
    {

        $CI     = &get_instance();
        if ($country_id != "") {
            $CI->db->where('country_id', $country_id);
        }

        $q = $CI->db->get('states');
        //if id is unique we want just one row to be returned
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('addressCount')) {
    function addressCount()
    {
        $CI     = &get_instance();
        $q = $CI->db->get('user_addresses');
        //if id is unique we want just one row to be returned
        $data = $q->result_array();
        return count($data);
    }
}

if (!function_exists('getLatestAddress')) {
    function getLatestAddress($userid)
    {
        $CI     = &get_instance();
        $CI->db->order_by("id", "desc");
        $CI->db->where('user_id', $userid);
        $q = $CI->db->get('user_addresses');
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        $country = getRecordById('countries', $data['country']);

        if (is_numeric($data['country'])) {
            $state   = getRecordById('states', $data['state']);
            $data['name'] = $state['name'];
        } else {
            $data['name'] = $data['state'];
        }

        $data['name'] = $country['name'];
        return $data;
    }
}

if (!function_exists('getUserAddress')) {
    function getUserAddress($country_id, $state = null)
    {
        $CI     = &get_instance();
        $CI->db->where('country', $country_id);
        $CI->db->where('state', $state);
        $q = $CI->db->get('user_addresses');
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        return $data;
    }
}

if (!function_exists('searchCartItems')) {
    function searchCartItems($postData = array())
    {

        if (!empty($postData)) {
            // Create the result array
            $result = array();
            $CI     = &get_instance();
            $items =  $CI->cart->contents();
            $newItems = array();
            foreach ($items as $key => $item) {
                $newItems[] = array(
                    'id'        => $item['id'],
                    'qty'       => $item['qty'],
                    'size'      => $item['options']['Size'],
                    'color'     => $item['options']['Color'],
                    //'row_id'    => $item['row_id']
                );
            }

            foreach ($items as $key => $value) {
                foreach ($postData as $k => $v) {

                    if (!isset($value[$k]) || $value[$k] != $v) {
                        continue 2;
                    }
                }
            }
            $result['rowid'] = $key;
            $result['qty'] = $value['qty'];
            return $result;
        }

        return null;
    }
}

/*
  Function name :randomNumber()
  Parameter : lenght
  Return : string
  Use : general random number
 */
if (!function_exists('randomNumber')) {
    function randomNumber($length)
    {
        $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        $pass = array();

        for ($i = 0; $i < $length; $i++) {
            $n = rand(0, strlen($alphabet) - 1);

            $pass[$i] = $alphabet[$n];
        }
        return implode($pass);
    }
}

if (!function_exists('getFirstRecord')) {
    function getFirstRecord($tablename)
    {
        $CI     = &get_instance();
        $CI->db->order_by("id", "desc");
        $CI->db->where('status', '1');
        $q = $CI->db->get($tablename);
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        return $data;
    }
}

if (!function_exists('create_slug')) {
    function create_slug($tablename, $name, $id = null)
    {

        if (!empty($name)) {

            if (strlen($name) > 150) {
                $stringCut = substr($name, 0, 150);
                $name = substr($stringCut, 0, strrpos($stringCut, ' '));
            } else {
                $name = $name;
            }

            $slug   = url_title($name, 'dash', true);

            $CI     = &get_instance();
            $CI->db->where('slug', $slug);

            if (!empty($id)) {
                $CI->db->where_not_in('id', $id);
            }

            $q      = $CI->db->get($tablename);
            $data   = $q->result_array();

            if (!empty($data)) {
                return $slug . '-' . rand();
            } else {
                return $slug;
            }
        }
    }
}

if (!function_exists('getSliderData')) {
    function getSliderData($data, $modulas)
    {
        if (!empty($data)) {
            $count = count($data);
            $modulas = $count % $modulas;

            $row_datanew = array();
            if ($count > 6) {
                if ($modulas == '1') {
                    $row_datanew = array_slice($data, 0, 5);
                }

                if ($modulas == '2') {
                    $row_datanew = array_slice($data, 0, 4);
                }

                if ($modulas == '3') {
                    $row_datanew = array_slice($data, 0, 3);
                }

                if ($modulas == '4') {
                    $row_datanew = array_slice($data, 0, 2);
                }

                if ($modulas == '5') {
                    $row_datanew = array_slice($data, 0, 1);
                }

                if ($modulas == '0' && empty($row_datanew)) {
                    $row_data = $data;
                } else {
                    $row_data = array_merge($data, $row_datanew);
                }
            } else {
                $row_data = $data;
            }

            return $row_data;
        }
    }
}

if (!function_exists('getPSliderData')) {
    function getPSliderData($data)
    {
        if (!empty($data)) {
            $count      = count($data);
            $modulas    = $count % 4;

            $row_datanew = array();
            if ($count > 4) {
                if ($modulas == '1') {
                    $row_datanew = array_slice($data, 0, 3);
                }

                if ($modulas == '2') {
                    $row_datanew = array_slice($data, 0, 2);
                }

                if ($modulas == '3') {
                    $row_datanew = array_slice($data, 0, 1);
                }

                if ($modulas == '0' && empty($row_datanew)) {
                    $row_data = $data;
                } else {
                    $row_data = array_merge($data, $row_datanew);
                }
            } else {
                $row_data = $data;
            }
            return $row_data;
        }
    }
}

if (!function_exists('getPSliderData')) {
    function getPSliderData($data)
    {
        if (!empty($data)) {
            $count      = count($data);
            $modulas    = $count % 4;

            $row_datanew = array();
            if ($count > 4) {
                if ($modulas == '1') {
                    $row_datanew = array_slice($data, 0, 3);
                }

                if ($modulas == '2') {
                    $row_datanew = array_slice($data, 0, 2);
                }

                if ($modulas == '3') {
                    $row_datanew = array_slice($data, 0, 1);
                }

                if ($modulas == '0' && empty($row_datanew)) {
                    $row_data = $data;
                } else {
                    $row_data = array_merge($data, $row_datanew);
                }
            } else {
                $row_data = $data;
            }
            return $row_data;
        }
    }
}

if (!function_exists('getAllMenuseRecordBy')) {
    function getAllMenuseRecordBy()
    {
        $CI     = &get_instance();
        $CI->db->where('menu_type', 'mainmenu');
        $CI->db->where('status', '1');
        $CI->db->order_by("id", "ASC");
        $q = $CI->db->get('menus');
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('getAllNotificationActive')) {
    function getAllNotificationActive()
    {
        $CI     = &get_instance();
        $CI->db->where('status', '1');
        $CI->db->order_by("id", "DESC");
        $q = $CI->db->get('notifications');
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('getAllFooterMenuses')) {
    function getAllFooterMenuses()
    {
        $CI     = &get_instance();
        $CI->db->where('menu_type', 'footermenu');
        $CI->db->where('status', '1');
        $CI->db->order_by("id", "ASC");
        $q = $CI->db->get('menus');
        $data = $q->result_array();
        return $data;
    }
}

if (!function_exists('pr')) {
    function pr($data)
    {
        echo '<pre>';
        print_r($data);
        echo '</pre>';
    }
}

function getAllCountry()
{
    $CI     = &get_instance();
    $sql = "SELECT `id`,`name` FROM `countries`;";
    //$this->db->query($sql, array(3, 'live', 'Rick'));
    $query = $CI->db->query($sql);
    $result = $query->result();
    return $result;
}

function getAllCountrystate($Countryid)
{
    $CI     = &get_instance();
    $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
    $query = $CI->db->query($sql, array($Countryid));
    // $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
}


function getAllCountrystateByName($Countryname)
{
    $CI     = &get_instance();
    $countrysql = "SELECT `id`,`name` FROM `countries` WHERE `name` = '" . $Countryname . "' ;";
    $countryquery = $this->db->query($countrysql);
    $countryresult = $countryquery->result_array();

    $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
    $query = $CI->db->query($sql, array($countryresult[0]['id']));
    // $query = $this->db->query($sql);
    $result = $query->result();
    return $result;
}


function getallReporter()
{
    $CI     = &get_instance();
    $sql = "SELECT `id`,`first_name`,`last_name`,`email` FROM `users` WHERE `user_type` = '1';";
    //$query = $this->db->query($sql, array($Countryid));
    $query = $CI->db->query($sql);
    $result = $query->result();
    return $result;
}

function get_blog_categories()
{
    $CI     = &get_instance();
    $query = "SELECT id,title,slug,categorie_type,categorie_colour FROM `news_categories` WHERE `status` = '1' AND categorie_type != '1' AND `order` > 0 ORDER BY `order` ASC";
    $query = $CI->db->query($query);
    $rows = $query->result_array();
    return $rows;
}

function my_news_count($user_id)
{
    $CI     = &get_instance();
    $query = "SELECT count(id) as cnt FROM `latest_news` WHERE `reporter`='" . $user_id . "' ";
    $query = $CI->db->query($query);
    $rows = $query->result_array();
    return $rows[0]['cnt'];
}

function limit_text($content, $chars)
{
    if (strlen($content) > $chars) {
        $content = str_replace('&nbsp;', ' ', $content);
        $content = str_replace("\n", '', $content);
        // use with wordpress    
        //$content = strip_tags(strip_shortcodes(trim($content)));
        $content = strip_tags(trim($content));
        $content = preg_replace('/\s+?(\S+)?$/', '', mb_substr($content, 0, $chars));
        $content = trim($content) . '...';
        return $content;
    } else {
        return $content;
    }
}

function getReporterName($user_id)
{
    $CI     = &get_instance();

    if ($_SESSION['reporter'][$user_id]) {
        $reporter = $_SESSION['reporter'][$user_id];
    } else {
        $query = "SELECT `id`,`first_name`,`last_name`,`email` FROM `users` WHERE id ='" . $user_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['reporter'][$user_id] = $rows[0]['first_name'] . ' ' . $rows[0]['last_name'];
        $reporter = ucwords($rows[0]['first_name'] . ' ' . $rows[0]['last_name']);
    }

    return limit_text($reporter, 15);
}


function getReporterEmail($user_id)
{
    $CI     = &get_instance();

    if ($_SESSION['reporter_email'][$user_id]) {
        $reporter = $_SESSION['reporter_email'][$user_id];
    } else {
        $query = "SELECT `email` FROM `users` WHERE id ='" . $user_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['reporter_email'][$user_id] = $rows[0]['email'];
        $reporter = $rows[0]['email'];
    }
    //return limit_text($reporter, 15);
    return $reporter;
}


function getReporterMobile($user_id)
{
    $CI     = &get_instance();
    if ($_SESSION['reporter_mobile'][$user_id]) {
        $reporter = $_SESSION['reporter_mobile'][$user_id];
    } else {
        $query = "SELECT `phone_mobile` FROM `users` WHERE id ='" . $user_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['reporter_mobile'][$user_id] = $rows[0]['phone_mobile'];
        $reporter =  $rows[0]['phone_mobile'];
    }
    return $reporter;
}

function getReporterImage($user_id)
{
    $CI     = &get_instance();
    if ($_SESSION['reporter_image'][$user_id]) {
        $reporter = $_SESSION['reporter_image'][$user_id];
    } else {
        $query = "SELECT `profile_image` FROM `users` WHERE id ='" . $user_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['reporter_image'][$user_id] = $rows[0]['profile_image'];
        $reporter =  $rows[0]['profile_image'];
    }
    return $reporter;
}

function getNewscategory($cat_id)
{
    $CI     = &get_instance();
    if ($_SESSION['category'][$cat_id]) {
        $reporter = $_SESSION['category'][$cat_id];
    } else {
        $query = "SELECT `title` FROM `news_categories` WHERE id ='" . $cat_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['category'][$cat_id] = $rows[0]['title'];
        $reporter =  $rows[0]['title'];
    }
    return $reporter;
}

function getNewsSubcategory($cat_id)
{
    $CI     = &get_instance();
    if ($_SESSION['category'][$cat_id]) {
        $reporter = $_SESSION['category'][$cat_id];
    } else {
        $query = "SELECT `title` FROM `news_categories` WHERE id ='" . $cat_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['category'][$cat_id] = $rows[0]['title'];
        $reporter =  $rows[0]['title'];
    }
    return $reporter;
}


function addViserRecord()
{
    $CI     = &get_instance();
    $data = array();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip_address = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip_address = $_SERVER['REMOTE_ADDR'];
    }
    $data['ip'] = $ip_address;
    $data['creat_at'] = date('Y-m-d h:i:s');
    $result = $CI->db->insert('site_vister', $data);
    return true;
}

function cleanUrl($string)
{
    $string = trim($string);
    $string = mb_strtolower($string, "UTF-8");

    //$special_character = array();
    //$special_character[] = '\''; 

    $string = str_replace(';', '-', $string);
    $string = str_replace('\'', '-', $string);
    $string = str_replace('"', '-', $string);
    $string = str_replace('/', '-', $string);
    $string = str_replace('@', '-', $string);
    $string = str_replace(':', '-', $string);
    $string = str_replace('=', '-', $string);
    $string = str_replace('*', '-', $string);
    $string = str_replace('&', '-', $string);
    $string = str_replace('<', '-', $string);
    $string = str_replace('>', '-', $string);
    $string = str_replace('#', '-', $string);
    $string = str_replace('%', '-', $string);
    $string = str_replace('{', '-', $string);
    $string = str_replace('}', '-', $string);
    $string = str_replace('|', '-', $string);
    $string = str_replace('^', '-', $string);
    $string = str_replace('~', '-', $string);
    $string = str_replace('`', '-', $string);
    $string = str_replace(']', '-', $string);
    $string = str_replace('[', '-', $string);
    $string = str_replace('(', '-', $string);
    $string = str_replace(')', '-', $string);
    $string = str_replace(',', '-', $string);
    $string = str_replace(array('[\', \']'), '-', $string);
    $string = preg_replace('/\[.*\]/U', '-', $string);
    //$string = preg_replace('/&(amp;)?#?[a-z0-9अ-ज्ञ]+;/i', '-', $string);
    //$string = htmlentities($string, ENT_COMPAT, 'utf-8');
    //$string = preg_replace('/&([a-z0-9अ-ज्ञ])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i', '\\1', $string );
    //$string = preg_replace(array('/[^a-z0-9अ-ज्ञ]/i', '/[-]+/') , '-', $string);
    $string = preg_replace("/[\s-]+/", " ", $string);
    $string = preg_replace("/[\s_]/", "-", $string);
    return rawurldecode($string);
    //return strtolower(trim($string, '-'));
}


function cleanNewsUrl($news)
{
    //$CI     = &get_instance();
    $news_array = array();
    $news_array[] = cleanUrl(getNewscategory($news['categorise']));
    $news_array[] = cleanUrl($news['country']);
    $news_array[] = cleanUrl($news['state']);
    $news_array[] = cleanUrl($news['city']);
    $news_array[] = cleanUrl($news['title']);
    $news_array2 = array_filter($news_array);
    $news_string = implode('/', $news_array2);
    $string =  'home/news_view/' . $news['id'] . '/' . $news_string;
    return $string;
}


function getHomePagesArtical()
{
    $CI     = &get_instance();
    $query = "SELECT * FROM `news_categories` WHERE `status` = '1' AND categorie_type = '1' ORDER BY `order` ASC";
    $query = $CI->db->query($query);
    $rows = $query->result_array();
    return $rows;
}

function getDepartment($d_id)
{
    $CI     = &get_instance();
    if ($_SESSION['department'][$d_id]) {
        $reporter = $_SESSION['department'][$d_id];
    } else {
        $query = "SELECT `department` FROM `departments` WHERE id ='" . $d_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['department'][$d_id] = $rows[0]['department'];
        $reporter =  $rows[0]['department'];
    }
    return $reporter;
}

function getDesignation($d_id)
{
    $CI     = &get_instance();
    if ($_SESSION['designation'][$d_id]) {
        $reporter = $_SESSION['designation'][$d_id];
    } else {
        $query = "SELECT `designation` FROM `designations` WHERE id ='" . $d_id . "' ";
        $query = $CI->db->query($query);
        $rows = $query->result_array();
        $_SESSION['designation'][$d_id] = $rows[0]['designation'];
        $reporter =  $rows[0]['designation'];
    }
    return $reporter;
}


