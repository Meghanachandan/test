<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="initial-scale=1.0"/>
<meta name="format-detection" content="telephone=no">
<title>Welcome</title>  
<style type="text/css">

/* Resets: see reset.css for details */
.ReadMsgBody { width: 100%; background-color: #ffffff;}
.ExternalClass {width: 100%; background-color: #ffffff;}
.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height:100%;}
html{width: 100%;margin:0; padding:0; }
body {-webkit-text-size-adjust:none; -ms-text-size-adjust:none; margin:0; padding:0; -webkit-font-smoothing: antialiased; font:12px Arial, Helvetica, sans-serif;}
table {border-spacing:0;}
img{ outline:none; text-decoration:none; -ms-interpolation-mode: bicubic; border:none; height: auto; line-height: 100%;}
p{padding: 0; margin: 0;}
br { line-height:0 !important; }
div, p, span, strong, b, em, i, a, li, td {
            -webkit-text-size-adjust: none;
        }
.b-letter__body {
  background:#cccccc !important;
}
h4{font:16px calibri, Tahoma, Geneva, sans-serif; text-transform: uppercase; text-align:left;}
table td, table tr { border-collapse: collapse; }
table { border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }

		#no-more-tables1 td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left:0; 
		white-space: normal;
		text-align:left;
		width:16% !important;line-height:18px;
	}
	#no-more-tables1 td a img{ 
		/* Behave  like a "row" */
		margin:0 auto;
	}
	.bdr{border:1px solid #ccc;}
#no-more-tables1 td{border:none;}
@media only screen and (max-width: 640px){
  body{
    width:auto!important;
  }

  table[class="container"], td[class="container"]{
    width: 100%!important;
  }
  table[class="container-inner"]{
    width: 100%!important;
  } 
  table[class="remove-space-width"]{
    display:none!important;
  } 

  table[class="layout-1-col"]{
    margin-right: 20px!important;
    width: 30%!important;
  }

  table[class="layout-1-col-last"]{    
    width: 30%!important;
  }
  table[class="remove"]{
    display:none!important;
  }

  td[class="image-180"] img{
    width:100% !important;
    height:auto !important;
    max-width:100% !important;
  }

  td[class="image-80"] img{
    width:100% !important;
    height:auto !important;
    max-width:100% !important;
  }

  td[class="image-130"] img{
    width:80% !important;
    height:auto !important;
    max-width:100% !important; margin:0 auto !important;
  }

  table[class="gallery-col"]{
    margin-right: 20px!important;
    width: 21%!important;
  }

  table[class="gallery-col-last"]{    
    width: 21%!important;
  }

  table[class="col-3-container"]{    
    width: 250px!important;
  }
  table[class="col-3"]{    
    width: 180px!important;
  }

  table[class="container-price"]{    
    
    float: none!important;
    margin: 0 auto;
  }


}

@media only screen and (max-width: 570px){
  table[class="col-3-container"]{    
    width: 190px!important;
  }
  table[class="col-3"]{    
    width: 120px!important;
  }
}

@media only screen and (max-width: 490px){
h4{font:15px calibri, Tahoma, Geneva, sans-serif; text-transform: uppercase; text-align:center;}
  table[class="gallery-col"]{
    margin-right: 10px!important;
    width: 45%!important;
  }
	.bdr{border:none;}
  table[class="gallery-col-last"]{    
    width: 45%!important;
  }


 table[class="container-social"]{
    width: 100%!important;
  }

  table[class="remove"]{
    display:none!important;
  }

  table[class="remove-ly-3"] img{
    width: 5px !important;
  }

  table[class="container-layout-3"], td[class="container-layout-3"]{
    width: 100%!important;
  }
 


  td[class="add-20"]{
    height: 20px!important
  }
  td[class="add-18"]{
    height: 18px!important
  }

  table[class="layout-1-col"]{
    margin-right: 0px!important;
    width: 100%!important;
  } 

  table[class="layout-1-col-last"]{  
    width: 100%!important;
  }

  td[class="image-180"] {
    text-align: center !important;
  }

  td[class="image-180"] img{
    width:100% !important;
    height:auto !important;
    max-width:180px !important;
    min-width:124px !important;
  }

  td[class="image-80"] {
    text-align: center !important;
  }

  td[class="image-130"] img{
    width:80% !important;
    height:auto !important;
    max-width:100px !important;
    min-width:100px !important;
  }

  td[class="align-center"] {
    text-align: center !important;
  }

  td[class="td-indent"] {
    padding: 0 20px !important;
  }

  table[class="col-3-container"]{    
    width: 100%!important;
  }
  table[class="col-3"]{    
    width: 80%!important;
  }

	/* Hide table headers (but not display: none;, for accessibility) */
	#no-more-tables1 thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
 
	#no-more-tables1 tr { border: 1px solid #ccc; }
 
	#no-more-tables1 td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
		white-space: normal;
		text-align:left;padding:12px 0;
	}
	#no-more-tables1 td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left:0; 
		white-space: normal;
		text-align:left;width:100% !important;
	}
	#no-more-tables1 td a img{ 
		/* Behave  like a "row" */
		margin:0 auto;
	}
 
	#no-more-tables1 td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		text-align:left;
		font-weight: bold;
	}
#no-more-tables1 td:before { content: attr(data-title); 	
				}  
	#no-more-tables1 table, 
	#no-more-tables1 thead, 
	#no-more-tables1 tbody, 
	#no-more-tables1 th, 
	#no-more-tables1 td, 
	#no-more-tables1 tr { 
		display: block; 
	}
 	#no-more-tables table, 
	#no-more-tables thead, 
	#no-more-tables tbody, 
	#no-more-tables th, 
	#no-more-tables td, 
	#no-more-tables tr { 
		display: block; 
	}
 
	/* Hide table headers (but not display: none;, for accessibility) */
	#no-more-tables thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
 
	#no-more-tables tr { border: 1px solid #ccc; }
 
	#no-more-tables td { 
		/* Behave  like a "row" */
		border: none;padding-bottom:5px;padding-top:5px;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 40%; 
		white-space: normal;
		text-align:left;
	}
 
	#no-more-tables td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		text-align:left;
		font-weight: bold;
	}
#no-more-tables td:before { content: attr(data-title); 	
				}
 
}



</style>
  
</head>

<body style="height:100%; background-color:#dde0e2; width:100%; ">
  <div  style="background-color:#eeeeee;margin: 0; -webkit-font-smoothing: antialiased;-ms-text-size-adjust:none; width:100%; padding:10px 0; ">
    <table border="0" cellspacing="0" cellpadding="0" style="width:600px; background-color: #ffffff;border-top:5px solid #171717;" align="center" class="container">
      <tr>
        <td align="center" valign="top" style="padding:10px;">
          <table width="100%" border="0" cellspacing="0" cellpadding="0" style=" background-color: #fff; " >

            <!-- start space -->
            <tr>
              <td valign="top" height="20" class="add-20">
              </td>
            </tr>
            <!-- end space -->

            <tr>
              <td align="center" valign="top" width="580" class="container">

                <!-- start space width --> 
                <table class="remove" width="40" border="0" cellpadding="0" cellspacing="0" align="left" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                  <tr>
                    <td width="40" height="2" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                      <p style="padding-left: 40px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
                <!-- end space width -->
                
                <!-- logo -->
                <table border="0" cellspacing="0" cellpadding="0"  class="container-social" align="left" style="width:178px;">
                  <tr>
                    <td valign="top"  align="center">
                      <a href="<?php echo base_url();?>" style="text-decoration:none;"><img src="<?php echo base_url('images/home/logo.png');?>"  hspace="0" vspace="0" width="200" style="border:none;"/></a>
                    </td>
                  </tr>
                </table>
                <!-- end logo -->

                <!-- end social icons -->         

              </td>
            </tr>

            <!-- start space -->
            <tr>
              <td valign="top" height="20" class="add-20">
              </td>
            </tr>
            <!-- end space -->

          </table>

          
          
          <!-- start layout-1 block -->


            
          <!-- start hor-line -->
          <table width="580" border="0" cellspacing="0" cellpadding="0" align="center" class="container" style="height:1px;background-color:#dbdbdb;">
            <tr>
              <td style="background-color:#dbdbdb; height:1px; padding: 0; margin: 0; vertical-align: top; line-height: 1px; font-size: 1px;" width="580"></td>
            </tr>
          </table>
          <!-- start hor-line -->



          <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">

            <!--start space height --> 
            <tr>
              <td>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                     <td width="580" align="center" style="padding: 0; margin:0px;background-color: #302f37;" valign="top" class="container" >
                      <h4 style="text-align:center; color:#fff;  font-weight:normal; padding:0; margin:6px 15px;">Welcome!</h4>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td height="20"></td>
            </tr>
            <!--end space height -->  

            <tr>
              <td valign="top" height="30">
              	<p style="font-size:16px;margin-left: 16px;">Hi <span> <?php echo ucwords(strtolower($users_name));?> </span>,</p>
              </td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left: 16px;line-height:25px;">Welcome and thanks for signing up ! </p>
              </td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left: 16px; line-height:25px;">You have successfully Registerd with <?php echo $users['email']; ?>.</p>
              </td>
            </tr>
            <tr>
              <td height="10"></td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left: 16px; line-height:25px;"><strong>Important Security Tips : </strong></p>
              </td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left:25px; line-height:25px;">1) Always keep your account Details safe.</p>
              </td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left:25px; line-height:25px;">2) Never disclose your login details to anyone.</p>
              </td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left:25px; line-height:25px;">3) Change your password regularly.</p>
              </td>
            </tr>
            <tr>
              <td height="10"></td>
            </tr>
            <tr>
              <td valign="top" >
              	<p style="margin-left:16px; line-height:25px;"><strong>Note : </strong> this e-mail was sent to you automatically so please do not reply to it.</p>
              </td>
            </tr>
            <tr>
              <td height="40" > </td>
            </tr>
            <tr>
              <td valign="top" style="margin-left: 16px;">
              	<p  style="margin-left: 16px;">Sincerely,</p>
              </td>
            </tr>
            <tr>
              <td height="10" > </td>
            </tr>
            <tr>
              <td valign="top" style="text-align: left;margin-left: 16px;">
              	<p  style="margin-left: 16px;">Pioneer Team.</p>
              </td>
            </tr>
            <!--start space height --> 
            <tr>
              <td height="20" ></td>
            </tr>
            
            <!--end space height -->
          </table>

          <!-- start gallery container -->

          <!-- start hor-line -->
                <!-- start layout title -->
         
                  <!-- start space width  -->                    
                  <table class="remove" width="1" border="0" cellpadding="0" cellspacing="0" align="left" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                    <tr>
                      <td width="0" height="3" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                        <p style="padding-left:5px;mso-table-lspace:0;mso-table-rspace:0; width:15px">&nbsp;</p>
                      </td>
                    </tr>
                  </table>
                  <!-- end space width  -->                    

                  

                </td>
              </tr>
               <!-- end  content -->

               <!--start space height --> 
               <tr>
                 <td height="20"></td>
               </tr>
               <!--end space height -->

           </table>
           <!-- end LAYOUT-1 container  --> 
        </td>
      </tr>
    </table>

      <!-- start hor-line -->
      <table width="580" border="0" cellspacing="0" cellpadding="0" align="center" class="container" style="height:1px;background-color:#dbdbdb;">
        <tr>
          <td style="background-color:#dbdbdb; height:1px; padding: 0; margin: 0; vertical-align: top; line-height: 1px; font-size: 1px;" width="580"></td>
        </tr>
      </table>
      <!-- start hor-line -->


    <!-- start layout-6 container -->
    <table border="0" cellspacing="0" cellpadding="0" style="width:600px; background-color: #333;" align="center" class="container">
      <!--start space height --> 
      <!--end space height -->  
            <tr>
              <td align="center" valign="top" width="580" class="container">
              	<div style="border-top:4px solid #03a5e0;width:100%; padding-top:15px;">

                <!-- start space width --> 
                <table class="remove" width="40" border="0" cellpadding="0" cellspacing="0" align="left" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                  <tr>
                    <td width="40" height="2" style="font-size: 0;line-height: 0;border-collapse: collapse;">
                      <p style="padding-left: 40px;">&nbsp;</p>
                    </td>
                  </tr>
                </table>
                <!-- end space width -->
                </div>
                <!-- logo -->
                <table border="0" cellspacing="0" cellpadding="0"  class="container-social" align="left" style="width:310px;">
                  <tr>
                    <td valign="middle" align="center">
                      <a href="#" style="text-decoration:none; color:#ccc;line-height:23px;">Copyright © AVIS 2020. All rights reserved.</a>
                    </td>
                  </tr>
                </table>
                <!-- end logo -->

                <!-- social icons -->
                <table  border="0" cellspacing="0" cellpadding="0"  class="container-social" align="right" style="width:245px">

                  <!-- start space -->
                  <tr>
                    <td valign="top" height="1" class="add-18">
                    </td>
                  </tr>
                  <!-- end space -->

                  
                </table>
                <!-- end social icons -->         

              </td>
            </tr>
      <!--start space height --> 
      <tr>
        <td height="20"></td>
      </tr>
      <!--end space height -->
    </table>
    <!-- end layout-6 container -->




  </div>
</body>
</html>
            
              