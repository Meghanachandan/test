<?php
class terms_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	public function getRecords()
	{
		$this->db->order_by("id", "ASC");
		$query  = $this->db->get('terms');
		$ret    = $query->result_array();
		return $ret;
	}

	public function getRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('terms');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getMenuType()
	{

		$this->db->where('menu_type', 'mainmenu');
		$q = $this->db->get('terms');
		//if id is unique we want just one row to be returned
		$data = $q->result_array();
		return $data;
	}

	public function getImage($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('terms');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data['image'];
	}

	

	public function gettermsRecords()
	{
		$this->db->order_by("id", "desc");
		$query = $this->db->get('terms');
		$ret = $query->result_array();
		return $ret;
	}

	public function gettermsRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('terms');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getCatImage($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('terms');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data['image'];
	}

	public function formCatValidations($id = null)
	{
		/* $url = $_POST['link'];
			  if (!filter_var($url, FILTER_VALIDATE_URL) == false) {
			  return true;
			  } else {
			  $this->form_validation->set_rules('link', 'Link', 'required');
			  ?>
			  <script>
			  alert('Enter valid Link of Blog');
			  </script>
			  <?php
	
			  return false;
			  } */
		$this->form_validation->set_rules('title', 'Title', 'required');
		//$this->form_validation->set_rules('link', 'Link', 'required');
		/*
		$editImage = $this->getCatImage($id);
		if (empty($editImage)) {
			if (empty($_FILES['image']['name'])) {
				$this->form_validation->set_rules('image', 'Image', 'required');
			}
		}*/

		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}
}























