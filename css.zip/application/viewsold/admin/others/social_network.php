<?php
	if (!empty($postData)) {
		$name 		= $postData['name'];
		$discription= $postData['discription'];
		$link 		= $postData['link'];
		$status 	= $postData['status'];
	}
?>
<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">Social Networking Icons</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">Social Networking Icons</h2>
		<div class="graph-form">
			<?php
				if(!empty($error)){ 
				?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
			} ?>
			<div class="form-body">
				<form action="<?php echo base_url('admin/social_network'); ?>" method="post">
					<input type="hidden" value=""/>
					<?php
							if($this->session->flashdata('success')){ 
							?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
						} ?>
					<div class="form-group">
						<?php foreach ($getIcons as $key => $icon) { ?>
							<div class="row" style="height: 20px;">
								<div class="col-lg-2">
									<input type="checkbox" name="data[checkbox][<?php echo $icon['id']; ?>]" <?php echo ($icon['status'] == '1') ? 'checked' : ''; ?> value="1"> <?php echo $icon['title']; ?>
								</div>
								<div class="col-lg-10">
									<input type="text" name="data[link][<?php echo $icon['id']; ?>]" value="<?php echo $icon['link']; ?>" placeholder="https://" class="form-control">
								</div>
							</div><br>
						<?php } ?>
						
					</div>
					<button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button> 
				</form> 
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( 'discription' );
</script>