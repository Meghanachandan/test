<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script>
<style>
  #imgdiv {
    width: 160px;
    float: left;
    margin-left: 20px
  }

  #reload {
    float: right;
    margin-right: 40px
  }

  section {
    background-color: #FFF;
  }
</style>
<section >
  <!--form-->
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="col-sm-12">
          <br>
          <br>
          <div class="categoryproduct " style="padding-left:0;">
            <div class="content-heading">
              <h2 class="title-head"><?php echo $getPage['name']; ?></h2>
            </div>
          </div>
          <div class="signup-form">
            <?php echo $getPage['discription']; ?>
          </div>
          <!--/sign up form-->
        </div>
      </div>
    </div>
  </div>
</section>
<!--/form-->