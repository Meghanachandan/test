<?php
//error_reporting(E_ALL);
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Allow_signup extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/dashboard_model');
        $this->load->library('image_lib');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index()
    {
        if ($_POST) {

            $sql = "SELECT * FROM `allow_signup`";
            $query = $this->dashboard_model->select($sql)->result();
            if(count($query)==null){

                $data = array(
                    "allow_signup"=>$this->input->post('allowsignup'),
                
                );
                // print_r($data);
                $this->dashboard_model->allow_signup($data);
                // $this->session->set_flashdata('success','Requirement taken successfully');
            }else{
                $data = array(
                    "allow_signup"=>$this->input->post('allowsignup'),
                );
                $this->dashboard_model->update_allow_signup($data);

            }
            redirect('admin/allow_signup');
        }else{
            adminLoadView('signup/allow_signup', $data);
        }
        
    }


}
    