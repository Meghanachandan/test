
        <div class="row bg-primary animate-in-down" >
         
            <div class="col-md-9 " style="    padding: 0px;">
                <div class="carousel slide" data-ride="carousel" id="carousel1">
                    <div class="carousel-inner" role="listbox" style="">
                        <div class="carousel-item active"> 
 <?php

                    if ($latest_news[0]['media_type'] == 'youtube') {
                        /*
                    echo '<div style="width:100%;height:auto">';
                    echo $latest_news[0]['youtube_code'];
                    echo '</div>';
                    */

                        $you_tube = str_replace('height', 'height="400px" res-height', $latest_news[0]['youtube_code']);
                        $you_tube = str_replace('width', 'width="100%" res-width', $you_tube);
                        echo $you_tube;
                    } else {


$imgurl =  'upload/news/orig/' . $latest_news[0]['image'];

                      if ($latest_news[0]['image'] == '' || !file_exists($imgurl)) {
                            $latest_news[0]['image'] = 'http://newssyn.com/upload/adds/no-image.png';
                        } else {
                            $latest_news[0]['image'] = base_url() .'upload/news/orig/' . $latest_news[0]['image'];
                        }
                    ?>
                        <img class="d-block img-fluid w-100" src="<?php echo $latest_news[0]['image']; ?>" alt="<?php echo $latest_news[0]['title'] ?>" style="height:400px;width:100%;" >
                    <?php } ?>

                          


                           
                        </div>
                  
                   <?php 
                   $id =  $latest_news[0]['id']; 
                   $this->db->select('*');
                   $this->db->from('news_gallery');
                   $this->db->where('nid',$id);
                   $query = $this->db->get();
                   $result = $query->result_array();
                 foreach ($result as $key => $value) {
                    $sname =  $value['name'];
                   $imgurl =  'upload/news/orig/' . $value['name'];
if(empty($value['name']) || !file_exists($imgurl))
{
$surl   = 'http://newssyn.com/upload/adds/no-image.png';
}
else
{
$surl   = base_url() . 'upload/news/orig/' . $value['name'];
}
                   ?>
                <div class="carousel-item "> 
                <img class="d-block img-fluid w-100" style="height:400px;width:100%;" src="<?php echo $surl; ?>" data-holder-rendered="true" >
                            
                        </div>
                    <?php } ?>
                         <!--        <div class="carousel-item"> <img class="d-block img-fluid w-100" src="http://res.cloudinary.com/dxfq3iotg/image/upload/v1566825017/work1_2.png" data-holder-rendered="true" style="height:300px;">
                          
                        </div> -->
                    </div>
                    <?php   if ($latest_news[0]['media_type'] != 'youtube') { ?>
                    <style>
                        #show{
                            display: none;
                        }
                        #ss:hover{
                            display: block;
                        }
                    </style>
                    <a id="ss" class="carousel-control-prev" href="#carousel1" role="button" data-slide="prev"> <span id='show' class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carousel1" role="button" data-slide="next"> <span class="carousel-control-next-icon" id='show' aria-hidden="true"></span> <span class="sr-only">Next</span> </a>
                    <?php } ?>                </div>
            </div>
               <div class="col-md-3  text-color" style="">
             
                    <h1 class="db_storybox text-justify" style="text-transform: capitalize;font-weight: 600;color:#004d38;/*height: 135px;*/">
                                <?php echo limit_text(strip_tags($latest_news[0]['title']), 100); ?>
                            </h1>
                            
                            <div class='row'>
                            <div class="col-md-1">
                                <?php
                               
                                    if ($latest_news[0]['hide_image_on_news'] != '1') {
                                        
                                        
                                    $img= getReporterImage($latest_news[0]['reporter']); 
                                    if($img ==''){
                                        $images = 'upload/userss.png';
                                    }else{
                                        $images = 'upload/profile_image/'.getReporterImage($latest_news[0]['reporter']);
                                    }
                                    ?>
                                   <img src="<?php echo base_url().$images; ?>" atl="userImage" style="height: 30px;width: 30px;margin-bottom: 5px;border-radius: 100%;" class="img-circle">
                                   <?php }else{ ?>
                                   <img src="<?php echo base_url().'upload/userss.png'; ?>" atl="userImage" style="height: 30px;width: 30px;margin-bottom: 5px;border-radius: 100%;" class="img-circle">
                                   <?php } ?>
                            </div>
                            <div class="col-md-10">
                                <a style="font-size: 16px;" style="text-transform: capitalize">
                                <?php if ($latest_news[0]['hide_name_on_news'] != '1') { ?>
                                
                                 <?php echo getReporterName($latest_news[0]['reporter']); ?>
                                <?php } ?>
                            <?php if ($latest_news[0]['hide_email_on_news'] != '1') { ?>
                            
                                /<?php echo getReporterEmail($latest_news[0]['reporter']); ?>
                            <?php } ?>
                            <?php if ($latest_news[0]['hide_name_on_news'] == '1' && $latest_news[0]['hide_email_on_news'] == '1') { ?>
                            <a style="font-size: 16px;" style="text-transform: capitalize">
                                /Public Reporter
                            </a><?php } ?>
                            <br>
                            <style>
                                @media(min-width: 1200px){
                                    .dat{
                                        margin-left: -30px;
                                    }
                                }
                            </style>
                            <a class="dat" style="margin-top: 0px; font-size: 10px;text-transform: capitalize">posted :
                                <?php echo date('D/M d, Y, h:i A', strtotime($latest_news[0]['date'])) . ' - ' . date('T'); ?> 
                                <!--<span><i class="fas fa-pencil-alt"></i></span> <?php //echo getReporterName($latest_news[0]['reporter']); ?>-->
                            </a>
                            </div>
                            </div>
                            <p class="mbr-text py-2 mbr-fonts-style display-7 text-info text-justify" style="margin-top: 0px;    font-weight: bold">
                                <?php echo limit_text(strip_tags($latest_news[0]['discription']), 310) ?>
                            </p>
                            <?php
                            if(limit_text(strip_tags($latest_news[0]['discription']), 310 > 309)){
                                ?>
                                <a class="btn btn-secondary btn-sm btn-form m-0" href="<?php echo base_url() . cleanNewsUrl($latest_news[0]); ?>">More..
                    </a>
                                <?php
                            }else{
                                ?>
                                <a class="btn btn-secondary btn-sm btn-form display-4 m-0" href="<?php echo base_url() . cleanNewsUrl($latest_news[0]); ?>">More..
                    </a>
                                <?php
                            }
                            ?>
           

   <!--<a class="btn btn-secondary btn-sm btn-form display-4" style="margin-top: -11px;-->
   <!-- margin-left: 0px;" href="<?php echo base_url() . cleanNewsUrl($latest_news[0]); ?>">-->
   <!--                     More..-->
   <!--                 </a>-->
            </div>
        </div>
 