<?php
class Notice_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}
    
	public function getRecords()
	{
		$this->db->where('status','1');
		$this->db->order_by("id", "desc");
		$query = $this->db->get('notice');
		$ret = $query->result_array();
		return $ret;
	}


}
?>