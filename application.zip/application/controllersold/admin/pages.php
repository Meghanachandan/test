<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pages extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/page_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index() {
        
        $data['pages'] = $this->page_model->getRecords();
        adminLoadView('pages/list', $data);
    }

    public function add() {

        $postData = array();
        if ($_POST) {
            $postData = $_POST;
			$data['error']="";
			$url = $_POST['link'];
			
			/*if (!filter_var($url, FILTER_VALIDATE_URL)) {
			$data['error']='Enter Valid Link of Menu';
			}*/


            $formValidation = $this->page_model->formValidations();
            if ($formValidation && $data['error']=="") {

                $insertData = array(
                    'name'          => $postData['name'],
                    'discription'   => $postData['discription'],
                    'link'          => $postData['link'],
                    'status'        => $postData['status']
                );
				$slug = create_slug('pages', $postData['name']);
				if (!empty($slug)) {
					$insertData['slug'] = $slug;
				}

				if (!empty($postData['status'])) {
					$insertData['status'] = $postData['status'];
				} else {
					$insertData['status'] = 1;
				}   
				$return = addUpdateRecord('pages', '', '', $insertData);
			
				
				
                if ($return) {
                    $this->session->set_flashdata('success', 'Page added successfully.');
                    redirect('admin/pages');
                } 
            } else {

                if(validation_errors()) {
                    if(validation_errors()){
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

       
        $data['postData'] = $postData;
        adminLoadView('pages/create', $data);
    }


    public function edit($id = null) {

        if (empty($id)) {
            redirect('admin/pages');
        }

        $postData = $this->page_model->getRecordById($id);
		$data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
			$data['error']="";
			$url = $_POST['link'];
			/*if (!filter_var($url, FILTER_VALIDATE_URL)) {
				$data['error']='Enter Valid Link of Menu';
			}*/

            $formValidation = $this->page_model->formValidations();
            if ($formValidation && $data['error']=="" ) {
                $updateData = array(
                    'name'          => $postData['name'],
                    'discription'   => $postData['discription'],
                    'link'          => $postData['link'],
                );

                $slug = create_slug('pages', $postData['name'], $id);
                if (!empty($slug)) {
                    $updateData['slug'] = $slug;
                }

                if (!empty($postData['status'])) {
                    $updateData['status'] = $postData['status'];
                } else {
                    $updateData['status'] = 1;
                }   
                
                $return = addUpdateRecord('pages', 'id', $id, $updateData);

                if ($return) {
                    $this->session->set_flashdata('success', 'Page updated successfully.');
                    redirect('admin/pages');
                } 
            } else {

                if(validation_errors()) {
                    if(validation_errors()){
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

       
        
        adminLoadView('pages/edit', $data);
    }

    public function delete($id = null) {

        if (empty($id)) {
            redirect('admin/pages');
        }

        $deleteData = $this->page_model->getRecordById($id);
        $delete = deleteRecordById('pages', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'Page deleted successfully.');
            redirect('admin/pages');
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */