<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Users_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}

	/* 	function getUsers()
	{	
		$users_query = $this->db->query('SELECT * FROM `users`');
		$row_users = $users_query->result_array();
		return $row_users;
	}
	*/

	function getUsers($data = ''){
		$query = "SELECT * ,(SELECT COUNT(latest_news.id) AS cnt FROM `latest_news` WHERE latest_news.`reporter` = users.id ) AS news_count FROM `users` ORDER BY `id` DESC ";
		$users_query = $this->db->query($query);
		$row_users = $users_query->result_array();

		if ($row_users) {
			return $row_users;
		}

		return 0;
	}

	function getAllData(){
		$users_query = $this->db->query('SELECT * FROM `users`');
		$row_users = $users_query->result_array();
		return $row_users;
	}

	//delete Page Data
	public function delete_page($id){
		$this->db->where('id', $id);
		return 	$this->db->delete('users');
	}

	public function getRecordById($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('users');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function check_email($email = "", $status = "", $id='')
	{
		$condition ="";
		if($id>0){
			$condition =" AND id !='".$id."' ";
		}
		$query 			= "SELECT * FROM users WHERE email = '".$email."' ".$condition;		
		$users_query 	= $this->db->query($query);
		$row_users 		= $users_query->result_array();
		if (!empty($row_users) && count($row_users) > 0) {
			if ($status) {
				return array_shift($row_users);
			} else {
				return true;
			}
			
		}
		return false;
	}
}
