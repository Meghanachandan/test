<div onclick="topFunction()" id="myBtn" style="background-color:#232F3E;text-align: center;padding: 5px 0px 0px 0px;">
    <div class="footer-lower">
        <div class="media-container-row mbr-white">
            <div class="col-sm-12 copyright">
                <p class="mbr-text mbr-fonts-style display-7" style="margin-bottom: 5px !important;cursor: pointer;">
                    <span class="mbri-home mbr-iconfont mbr-iconfont-btn" style="font-size: 12px;margin-right: 3px;"></span> Home
                </p>
            </div>
        </div>
    </div>
</div>
<section class="footer1 cid-rUEPFwMA9C mbr-reveal" id="footer1-z">
    <div class="container">
        <div class="media-container-row content mbr-white1" style="padding-bottom: 25px;">
            <!-- <div class="col-md-2 col-sm-12">
                <div class="mb-3 img-logo">
                    <a href="https://Agcnn.com /">
                        <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Agcnn.com">
                    </a>
                </div>
                <p class="mb-3 mbr-fonts-style foot-title display-7">
                    Agcnn.com
                </p>
                <p class="mbr-text mbr-fonts-style mbr-links-column display-7">
                    <a href="#" class="text-white">About Us</a>
                    <br><a href="#" class="text-white">Services</a>
                    <br><a href="#" class="text-white">Selected Work</a>
                    <br><a href="#" class="text-white">Get In Touch</a>
                </p>
            </div> -->
            <div class="col-md-8 col-sm-12">
                <div class="row footer_category_links">
                    <?php
                    $allcategories = get_blog_categories();
                    if ($allcategories) {
                        foreach ($allcategories as $category) {
                            echo '<div class="col-lg-3 col-md-4 col-sm-6 col-xl-3 px-0">';
                            echo '<a href="' . base_url() . 'home/search/' . $category['id'] . '"> ' . $category['title'] . ' </a>';
                            echo '</div>';
                        }
                    }
                    ?>
                    <?php
                    /*
                    $mainMenus = getAllFooterMenuses();
                    foreach ($mainMenus as $key => $resnavmenu) {
                        if (trim($resnavmenu['link']) != '') {
                            $link = trim($resnavmenu['link']);
                        } else {
                            $link = base_url() . 'home/page/' . trim($resnavmenu['slug']);
                        }
                    ?>
                        <div class="col-md-4 col-sm-6">
                            <a href="<?php echo $link; ?>" class="dropdown-toggle">
                                <i class="fa fa-angle-right orange-text footer-icon" aria-hidden="true"></i><?php echo $resnavmenu['title']; ?>
                            </a>
                        </div>
                    <?php
                    }
                    */
                    ?>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <p class="mb-3 foot-title mbr-fonts-style display-7">
                    SUBSCRIBE
                </p>
                <p class="mb-2 mbr-text mbr-fonts-style form-text display-7">
                    Get monthly updates and free resources.
                </p>
                <div class="mb-4 media-container-column" data-form-type="formoid">
                    <!---Formbuilder Form--->
                    <div class="dragArea row form-inline">
                        <div class="col-7" style="padding : 0px;" data-for="email">
                            <input type="email" id="subscribe_email" name="subscribe_email" placeholder="Email" data-form-field="Email" required="required" class="form-control input-sm input-inverse my-2 display-7" id="email-footer4-z">
                        </div>
                        <div class="col-5" style="padding: 0px;">
                            <button type="submit" style="margin-left:5px;padding: 6px 10px;" onclick="actionEmailSub();" class="btn btn-info">Subscribe</button>
                        </div>
                    </div>
                    <div class="row form-inline justify-content-center">
                        <div class="alert alert-success col-12 email_success" style="display: none;"></div>
                        <div class="alert alert-danger col-12 email_error" style="display: none;"></div>
                    </div>
                    <!---Formbuilder Form--->
                </div>
                <p class="mb-3 mbr-fonts-style foot-title display-7">
                    CONNECT WITH US
                </p>
                <div class="social-list pl-0 mb-0">
                    <div class="soc-item">
                        <a href="https://twitter.com/AgcnnNews" target="_blank">
                            <span class="socicon-twitter socicon mbr-iconfont mbr-iconfont-social"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="https://www.facebook.com/pages/agcnn" target="_blank">
                            <span class="socicon-facebook socicon mbr-iconfont mbr-iconfont-social"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="https://www.youtube.com/channel/UCUp6RdKeD74QKu5D-oKhCTQ?view_as=subscriber" target="_blank">
                            <span class="socicon-youtube socicon mbr-iconfont mbr-iconfont-social"></span>
                        </a>
                    </div>
                    <!--
                    <div class="soc-item">
                        <a href="https://instagram.com/mobirise" target="_blank">
                            <span class="socicon-instagram socicon mbr-iconfont mbr-iconfont-social"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="https://plus.google.com/u/0/+Mobirise" target="_blank">
                            <span class="socicon-googleplus socicon mbr-iconfont mbr-iconfont-social"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="https://www.behance.net/Mobirise" target="_blank">
                            <span class="socicon-behance socicon mbr-iconfont mbr-iconfont-social"></span>
                        </a>
                    </div>
                    -->
                </div>
            </div>
        </div>
    </div>
    <div style="background-color:#034882;text-align: center;padding: 0px 0px 0px 0px;">
        <div class="footer-lower">
            <div class="media-container-row mbr-white">
                <div class="col-sm-12 copyright m-0">
                    <ul class="footerMenu p-0" style="display: -webkit-inline-box;">
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>faq"> FAQ </a>
                        <li>
                        <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>home/page/About-Us">About Us</a>
                        <li>
                        <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>contact">Contact Us</a>
                        <li>
                        <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>terms">Terms & Condition</a>
                        <li>
                        <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>home/page/privacy-policy">Privacy Policy</a>
                        <li>
                        <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>home/page/cookie-policy">Cookie Policy</a>
                        <li>    

                        <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>home/page/site-map">Site Map</a>
                        <li>
                             <li> | </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url(); ?>home/page/copyright-policy">Copyright Policy</a>
                        <li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div style="background-color:#37475A;text-align: center;padding: 10px 0px 0px 0px;">
        <div class="footer-lower">
            <div class="media-container-row mbr-white1">
                <div class="col-sm-12 copyright m-0">
                    <p class="mbr-text mbr-fonts-style display-7" style="margin-bottom: 10px !important;">
                        <!-- © Copyright 2020 Agcnn.com - All Rights Reserved -->
                        All Right's Reserved by <span>AVIS</span> © 2020
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>


<div class="center-outer">
</div>


<!-- The Modal -->
<div class="modal fade" id="myModalNewsReadMorePopUp">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <!-- Modal body -->
            <div class="modal-body">
                <div id="myModalNewsReadMorePopUp_detail_box"></div>
                <a id="myModalNewsReadMorePopUp_more_link" href="#">Read More..</a>
                <a type="button" class="close" data-dismiss="modal">Close</a>
            </div>
        </div>
    </div>
</div>




<script src="<?php echo base_url(); ?>assets/popper/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/parallax/jarallax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/dropdown/js/nav-dropdown.js"></script>
<script src="<?php echo base_url(); ?>assets/dropdown/js/navbar-dropdown.js"></script>
<script src="<?php echo base_url(); ?>assets/touchswipe/jquery.touch-swipe.min.js"></script>
<script src="<?php echo base_url(); ?>assets/mbr-tabs/mbr-tabs.js"></script>
<script src="<?php echo base_url(); ?>assets/tether/tether.min.js"></script>
<script src="<?php echo base_url(); ?>assets/smoothscroll/smooth-scroll.js"></script>
<script src="<?php echo base_url(); ?>assets/theme/js/script.js"></script>
<script src="<?php echo base_url(); ?>assets/select2/select2.min.js"></script>
<script>
    //Get the button
    var mybutton = document.getElementById("myBtn");

    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function() {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }
    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>
<a href="#" ID="backToTop"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
</body>

</html>
<script type="text/javascript">
    function loginProcess() {
        var textEmail = $("#email_address").val();
        if (textEmail == "") {
            $('#login_error').css('display', 'block');
            $('#email_address').focus();
            var error = "Please Enter Your Email Address";
            $('.error_span').text(error);
            location.hash = '#login_error';
            return false;
        }
        if (IsEmail(textEmail) == false) {
            $('#login_error').css('display', 'block');
            var error = 'Please Enter Valid Email Address';
            $('#email_address').focus();
            $('.error_span').text(error);
            $('#textEmail').focus();
            location.hash = '#client_error';
            return false;
        }
        var textPassword = $("#textPassword").val();
        if (textPassword == "") {
            $('#login_error').css('display', 'block');
            $('#textPassword').focus();
            var error = "Please Enter Your Password";
            $('.error_span').text(error);
            location.hash = '#login_error';
            return false;
        }

        $('#login_error').css('display', 'none');
        var textloginNewl = $("#textloginNewl").val();
        var path_url = '<?php echo base_url('user/login_ajax'); ?>';
        $(".loaderimg").show();
        $.ajax({
            url: path_url,
            type: "POST",
            data: ({
                loginEmail: textEmail,
                loginPassword: textPassword,
                loginNewl: textloginNewl
            }),
            dataType: 'json',
            success: function(data) {
                if (data.error != '') {
                    $('#login_error').show();
                    $('.error_span').text(data.error);
                    $(".loaderimg").hide();
                } else if (data.success == 'success') {
                    var explode = function() {
                        /*$(".show-logout").show();
                         $(".show-user").show();
                         $(".show-user span").text(data.userString);*/
                        $(".hide-forms").hide();
                        $("#checkout").show();
                        $('#myLoginModal').modal('hide');
                        location.hash = '#checkout';
                        $(".loaderimg").hide();
                        location.reload();
                    };
                    setTimeout(explode, 1000);
                }
                /*$('#login_error').css('display', 'block');
                 $('.error_span').text(error);*/
            },
            error: function(data) {
                designSaved = false;
            }
        })
    }

    function signupProcess(argument) {
        var s_first_name = $("#s_first_name").val();
        if (s_first_name == "") {
            $('#signup_error').css('display', 'block');
            $('#s_first_name').focus();
            var error = "Please Enter Your First Name";
            $('.s_error_span').text(error);
            location.hash = '#signup_error';
            return false;
        }

        var s_last_name = $("#s_last_name").val();
        if (s_last_name == "") {
            $('#signup_error').css('display', 'block');
            $('#s_last_name').focus();
            var error = "Please Enter Your Last Name";
            $('.s_error_span').text(error);
            location.hash = '#signup_error';
            return false;
        }

        var s_email = $("#s_email").val();
        if (s_email == "") {
            $('#signup_error').css('display', 'block');
            $('#s_email').focus();
            var error = "Please Enter Your Email Address";
            $('.s_error_span').text(error);
            location.hash = '#signup_error';
            return false;
        }

        if (IsEmail(s_email) == false) {
            $('#signup_error').css('display', 'block');
            var error = 'Please Enter Valid Email Address';
            $('#s_email').focus();
            $('.s_error_span').text(error);
            $('#textEmail').focus();
            location.hash = '#client_error';
            return false;
        }
        var s_password = $("#s_password").val();
        if (s_password == "") {
            $('#signup_error').css('display', 'block');
            $('#s_password').focus();
            var error = "Please Enter Your Password";
            $('.s_error_span').text(error);
            location.hash = '#signup_error';
            return false;
        }
        var s_confirm_password = $("#s_confirm_password").val();
        if (s_confirm_password == "") {
            $('#signup_error').css('display', 'block');
            $('#s_confirm_password').focus();
            var error = "Please Enter Your Confirm Password";
            $('.s_error_span').text(error);
            location.hash = '#signup_error';
            return false;
        }
        if (s_confirm_password != s_password) {
            $('#signup_error').css('display', 'block');
            $('#s_confirm_password').focus();
            var error = "The Confirm Password field does not match the Password field";
            $('.s_error_span').text(error);
            location.hash = '#signup_error';
            return false;
        }
        $('#signup_error').css('display', 'none');
        var path_url = '<?php echo base_url('user/signup_ajax'); ?>';
        $(".s_loaderimg").show();
        $.ajax({
            url: path_url,
            type: "POST",
            data: ({
                first_name: s_first_name,
                last_name: s_last_name,
                email: s_email,
                password: s_password
            }),
            dataType: 'json',
            success: function(data) {
                console.log(data);
                if (data.success == true) {
                    var path_url = '<?php echo base_url('user/login_ajax'); ?>';
                    /* 
                    $('#signup_success').css('display', 'block');
                    $('.s_success_span').text(data.success);
                    */
                    $.ajax({
                        url: path_url,
                        type: "POST",
                        data: ({
                            loginEmail: s_email,
                            loginPassword: s_password,
                            loginNewl: ""
                        }),
                        dataType: 'json',
                        success: function(data) {
                            if (data.error != '') {
                                $('#signup_success').css('display', 'block');
                                $('.s_success_span').text(data.error);
                                $(".s_loaderimg").hide();
                            } else if (data.success == 'success') {
                                var explode = function() {
                                    /*$(".show-logout").show();
                                     $(".show-user").show();
                                     $(".show-user span").text(data.userString);*/
                                    $(".hide-forms").hide();
                                    $("#checkout").show();
                                    $('#myLoginModal').modal('hide');
                                    location.hash = '#checkout';
                                    $(".s_loaderimg").hide();
                                    location.reload();
                                };
                                setTimeout(explode, 1000);
                            }
                        },
                        error: function(data) {
                            designSaved = false;
                        }
                    })
                } else if (data.emailError != '') {
                    $('#signup_error').css('display', 'block');
                    $('.s_error_span').text(data.emailError);
                    $(".s_loaderimg").hide();
                }
            },
            error: function(data) {
                designSaved = false;
            }
        })
    }

    function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!regex.test(email)) {
            return false;
        } else {
            return true;
        }
    }

    function showSocialButtonBox(id) {
        $('#' + id).show();
    }

    function hideSocialButtonBox() {
        $('.social_share_button').hide();
    }

    function actionEmailSub() {
        var sub_email = $("#subscribe_email").val(),
            path_url = '<?php echo base_url("home/email_subscribes") ?>';
        $.ajax({
            url: path_url,
            type: "POST",
            data: ({
                sub_email: sub_email,
            }),
            dataType: 'json',
            success: function(data) {
                if (data.validation != "") {
                    $(".email_error").show().html(data.validation);
                    $(".email_success").hide();
                } else {
                    $(".email_success").show().html(data.success);
                    $(".email_error").hide()
                    $("#subscribe_email").val('');
                    var explode = function() {
                        $(".email_success").hide();
                    };
                    setTimeout(explode, 3000);
                }
            },
            error: function(data) {
                designSaved = false;
            }
        })
    }


    function open_read_more_popup(news_id) {
        console.log(news_id);
        var html = $("#detail_link_" + news_id).attr('data-original-title');
        var url = $("#detail_link_" + news_id).attr('href');
        $("#myModalNewsReadMorePopUp_detail_box").html(html);
        $("#myModalNewsReadMorePopUp_more_link").attr("href", url);
        $('#myModalNewsReadMorePopUp').modal('show');
    }

    // A $( document ).ready() block.
    <?php if ($this->session->flashdata('msg_exipired')) { ?>
        $(document).ready(function() {
            swal(
                'Verification Link',
                '<?php echo $this->session->flashdata('msg_exipired'); ?>',
                'error'
            )
        });
    <?php } else if ($this->session->flashdata('reset_success')) { ?>
        $(document).ready(function() {
            swal(
                'Reset Password',
                '<?php echo $this->session->flashdata('reset_success'); ?>',
                'success'
            )
        });
    <?php } ?>
    $(document).ready(function() {
        $('.js-example-basic-single').select2({
            placeholder: "Select country for",
            allowClear: true
        });
        $('#state').select2({
            placeholder: "Select state for",
            allowClear: true
        });
        $('#city').select2({
            placeholder: "Select city for",
            allowClear: true
        });
        <?php

        if ($this->input->post('country') != '') {
            echo "getcountrystate('" . $this->input->post('country') . "','load');";
        }

        if ($this->input->post('state') != '') {
            echo "setStateCity('" . $this->input->post('state') . "','load');";
        }

        /*
        if ($this->input->post('state') != '') {
            //echo " setTimeout(function(){ $('#state').val('" . $this->input->post('state') . "'); }, 1000); ";
            echo "$('#state').val('" . $this->input->post('state') . "');";
        }*/
        if ($this->input->post('country') == '' && $this->input->post('state') == '' && $this->input->post('city') == '') {
        ?>
            $.getJSON('https://ipapi.co/json/', function(data) {
                $('#country').val(data.country_name);
                $('.js-example-basic-single').trigger('change');
                getcountrystate(data.country_name, 'load', data.region);
                setStateCity(data.region, 'load', data.city);
                //console.log(data.city);

            });
        <?php } ?>
    });

    jQuery(document).ready(function($) {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 50) {
                $('#backToTop').fadeIn('slow');
            } else {
                $('#backToTop').fadeOut('slow');
            }
        });
        $('#backToTop').click(function() {
            $("html, body").animate({
                scrollTop: 0
            }, 500);
            return false;
        });

        $('#search_laoder').hide();
        $('#search_contaner').show();
    });

    $("#key").keypress(function(event) {
        if (event.which == 13) {
            submitSearchForm();
        }
    });

    $('#city').on('change.select2', function(e) {
        // Do something
        console.log(e);
    });
</script>
<!-- <script src="https://code.jquery.com/jquery-3.3.1.js"></script> -->
<style>
    a#backToTop {
        /* width: 40px;
            height: 40px; */
        opacity: 0.5;
        position: fixed;
        bottom: 5px;
        right: 5px;
        display: none;
        /* text-indent: -10000px; */
        outline: none !important;
        background-repeat: no-repeat;
        background: #000;
        color: #FFF !important;
        padding: 5px 10px;
    }
</style>

<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en',
            //includedLanguages: 'en,fr,es,mk,hi',
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE
        }, 'google_translate_element');

    }
</script>
<!-- 
<link href="<?php echo base_url(); ?>assets/cookies/style.css" rel="stylesheet" />
<script src="<?php echo base_url(); ?>assets/cookies/script.js"></script>
<script src="<?php echo base_url(); ?>assets/cookies/cookieconsent.min.js"></script>
<script>
    const cc = new CookieConsent({
        type: 'info',
        theme: "classic",
        position: 'bottom-right',
        palette: {
            "popup": {
                "background": "#37475A"
            },
            "button": {
                "background": "#ffcb08",
                padding: '5px 50px'
            }
        },
        content: {
            message: "Agcnn.com uses cookies to ensure you get the best experience on our website.",
            dismiss: "Accept",
            //link: '#',
            href: '<?php echo base_url(); ?>home/page/privacy-policy'
        },

    });
    //learn more about cookies
</script>
-->
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<?php addViserRecord(); ?>
<script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>


<script>
    $(document).ready(function() { 

  $('.cookiesnotification').show();    
              $('#close').click(function(){  

                $('.cookiesnotification').hide(); 
                 setCookie("_checkCookie", cookieset, 365);   

              });
  // function checkCookie() {
  //     var cookieset = getCookie("_checkCookie");

  //     if (cookieset!="") {

  //         $('.notification').hide();    

  //     }else{

  //         $('.notification').hide();    

  //         if (cookieset != "" && cookieset != null) {



  //           setCookie("_checkCookie", cookieset, 365);
  //         }
  //     }
  // } 
  // checkCookie();
  
});
</script>



<style type="text/css">
    
.cookiesnotification {
  z-index:99;
  position:fixed;
  bottom:-5px;
  float:none;
  min-width:100%;
  background: #3af;
  padding: 10px 15px;
  margin: 5px auto;

  box-shadow: 0px 0px 5px #999999;
}

.notification-error {
  background: #ff1010;
  color: #ffffff;
}

.notification-alert {
  background: #000000;
  color: #fff;
  text-align: center;
}

.notification-info {
  background: #a4beff;
  color: #000000;
}
#close{
     text-decoration: none;
    background-color: red;
    padding: 0px 8px 0px 8px;
    font-size: 13px;
    color: #fff;
    margin-left: 20px;
 
}
</style>


<div class="cookiesnotification notification-alert">
 By continuing to use this website, you agree to our cookie policy.<a href="<?php echo base_url(); ?>home/page/cookie-policy" target="_blank"> Learn more</a> <a href="#" id="close">Ok</a>
</div>