<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">PAGES</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h3 class="inner-tittle two">PAGES </h3>
		<?php
		if ($this->session->flashdata('success')) {
		?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
																																} ?>
		<div class="graph">
			<div class="tables">
				<table class="display responsive" id="example-table">
					<thead>
						<tr>
							<th class="sorting_disabled"><input type="checkbox" id="selecctall"></th>
							<th>Id</th>
							<th width="200px">Name</th>
							<th>Slug</th>
							<th>Status</th>
							<th>Action</th>
						</tr>
					</thead>
					<?php
					$i = 0;
					foreach ($pages as $key => $page) {
						$status = (!empty($page['status']) && $page['status'] == '1') ? 'Active' : 'Deactive';
						$i++; ?>
						<tr>
							<?php echo '<td><input type="checkbox" class="checkbox1" name="chk[]" value="' . $page['id'] . '" /></td>'; ?>
							<th><?php echo $i; ?></th>
							<th><?php echo $page['name']; ?></th>
							<th><?php echo $page['slug']; ?></th>
							<th><?php echo $status; ?></th>
							<th>
								<a href='<?php echo base_url('admin/pages/edit/' . $page['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp;
								<a onclick='return confirm("Are you sure? you want to delete this page!")' href='<?php echo base_url('admin/pages/delete/' . $page['id']); ?>'><i class="fa fa-trash-o"></i></a>
							</th>
						</tr>
					<?php } ?>
				</table>
			</div>
		</div>
		<!--//graph-visual-->
	</div>
</div>
<script>
	$(document).ready(function() {
		$('#selecctall').click(function(event) { //on click 
			if (this.checked) { // check select status
				$('.checkbox1').each(function() { //loop through each checkbox
					this.checked = true; //select all checkboxes with class "checkbox1"               
				});
			} else {
				$('.checkbox1').each(function() { //loop through each checkbox
					this.checked = false; //deselect all checkboxes with class "checkbox1"           
				});
			}
		});
	});

	function fnCallback() {
		if (this.checked) { // check select status
			$('.checkbox1').each(function() { //loop through each checkbox
				this.checked = true; //select all checkboxes with class "checkbox1"               
			});
		} else {
			$('.checkbox1').each(function() { //loop through each checkbox
				this.checked = false; //deselect all checkboxes with class "checkbox1"               

			});
		}
	}

	$(document).ready(function() {
		$('#example-table').DataTable({
			"pagingType": "full_numbers",
			"lengthMenu": [
				[10, 25, 50, -1],
				[10, 25, 50, "All"]
			]

		});
	});
</script>