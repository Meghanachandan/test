<?php $this->load->view('admin/vwHeader'); ?>
<link href="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<style>
    /*** General styles ***/
    /*
    .panel {
        box-shadow: none;
    }

    .panel-heading {
        border-bottom: 0;
    }

    .panel-title {
        font-size: 17px;
    }

    .panel-title>small {
        font-size: .75em;
        color: #999999;
    }

    .panel-body *:first-child {
        margin-top: 0;
    }

    .panel-footer {
        border-top: 0;
    }

    .panel-default>.panel-heading {
        color: #333333;
        background-color: transparent;
        border-color: rgba(0, 0, 0, 0.07);
    }

    form label {
        color: #999999;
        font-weight: 400;
    }

    .form-group input {
        margin: 0px;
    }

    .form-horizontal .form-group {
        margin-left: 0px;
        margin-right: 15px;
    }

    @media (min-width: 768px) {
        .form-horizontal .control-label {
            text-align: right;
            margin-bottom: 0;
            padding-top: 7px;
        }
    }
*/
    .profile__contact-info-icon {
        float: left;
        font-size: 18px;
        color: #999999;
    }

    .profile__contact-info-body {
        overflow: hidden;
        padding-left: 20px;
        color: #999999;
    }

    .profile-avatar {
        width: 200px;
        position: relative;
        margin: 0px auto;
        margin-top: 196px;
        border: 4px solid #f3f3f3;
    }

    .circle {
        border-radius: 1000px !important;
        overflow: hidden;
        width: 128px;
        height: 128px;
        border: 8px solid rgba(255, 255, 255, 0.7);
        position: absolute;
        top: 72px;
    }

    .border_with_shadow {
        border: 1px solid #f2f2f2;
        box-shadow: 2px 2px 8px #ccc;
    }
</style>
<?php
define("NEW_USER", "Add New User");
define("ERRORS", "Errors");
define("BASIC_INFORMATION", "Basic Information");
define("PREFIX", "Prefix");
define("FIRST_NAME", "First Name");
define("LAST_NAME", "Last Name");
define("SUFFIX", "Suffix");
define("OTHER_INFORMATION", "Account Setting");
define("EMAIL", "Email");
define("PASSWORD", "Password");
define("HOME_PHONE", "Home Phone");
define("CELL_PHONE", "Cell Phone");
define("ALLOW_COSTUME", "Allow Costume");
define("ADD_USER", "Add User");
define("NO", "No");
define("YES", "Yes");
?>
<div id="page-wrapper">

    <div class="row">
        <div class="col-lg-12">
            <h1><?php echo NEW_USER; ?></h1>
            <ol class="breadcrumb">
                <li><a href="Users"><i class="icon-dashboard"></i> Users</a></li>
                <li class="active"><i class="icon-file-alt"></i> <?php echo NEW_USER; ?></li>
                <a href="<?php echo base_url(); ?>admin/users"> <button class="btn btn-primary" type="button" style="float:right;">Back</button></a>
                <div style="clear: both;"></div>
            </ol>
        </div>
    </div><!-- /.row -->

    <?php
    if (validation_errors() != '') { ?>

        <div class="alert alert-danger" role="alert">
            <!-- <button class="close" data-dismiss="alert">x</button> -->
            <strong><?php echo ERRORS; ?>!</strong> <?php echo validation_errors(); ?>
        </div>
    <?php } ?>
    <?php
    if ($this->session->flashdata('flash_message')) {
        echo '<div class="alert bg-success"><a class="close" data-dismiss="alert">x</a><strong>' . $this->session->flashdata('flash_message') . '</strong></div>';
    }
    ?>
    <?php
    $attributes = array('name' => 'frm_listadmin', 'class' => 'site-setting', 'autocomplete' => 'off', 'enctype' => 'multipart/form-data');
    echo form_open('admin/users/add_newuser', $attributes);
    ?>
    <div class="row">
        <div class="col-lg-12 clearfix">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo BASIC_INFORMATION; ?>
                </div>

                <div class="panel-body">

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Photo</label>
                        </div>
                        <div class="col-sm-2">
                            <div class=" d-flex justify-content-center align-items-center rounded" style="height: 140px; background-color: rgb(233, 236, 239);padding: 2px;">
                                <?php if ($user['profile_image'] != '') {
                                    echo '<img class="profile-pic" src="' . base_url() . 'upload/profile_image/' . $user['profile_image'] . '" width="100%" height="100%" />';
                                } else { ?>
                                    <img class="profile-pic" src="<?php echo base_url(); ?>upload/profile-images.png" width="100%" height="100%" />
                                <?php } ?>
                            </div>
                            <input type="hidden" name="old_logo" value="<?= $user['profile_image'] ?>" id="" />
                            <div class="mt-2 p-0">
                                <div style="display: none;">
                                    <input type="file" name="profile_image" id="profile_image" />
                                </div>
                                <button class="btn btn-sm btn-secondary mx-0 upload-button" type="button">
                                    <i class="fa fa-fw fa-camera"></i>
                                    <span>Change Photo</span>
                                </button>
                            </div>


                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label><?php echo FIRST_NAME; ?></label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="first_name" value="<?php echo $user['first_name']; ?>">
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label><?php echo LAST_NAME; ?></label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="last_name" value="<?php echo $user['last_name']; ?>">
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Email</label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="email" value="<?php echo $user['email']; ?>">
                        </div>
                    </div>

                    <div class="form-group col mb-2">
                        <!-- Default unchecked -->
                        <div class="col-sm-3">
                            <label>Gender</label>
                        </div>
                        <div class="col-sm-9">
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="defaultUnchecked" name="gender"  value="Male" <?php if($user['gender']=='Male' || $user['gender']=='' ){ echo 'checked'; }; ?> >
                                        <label class="custom-control-label" for="defaultUnchecked">Male</label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <!-- Default checked -->
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="defaultChecked2" name="gender"  value="Female" <?php if($user['gender']=='Female' ){ echo 'checked'; }; ?> >
                                        <label class="custom-control-label" for="defaultChecked2">Female</label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="defaultChecked3" name="gender"  value="Other" <?php if($user['gender']=='Other' ){ echo 'checked'; }; ?> >
                                        <label class="custom-control-label" for="defaultChecked3">Other</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Address</label>
                        </div>
                        <div class="col-sm-9">
                            <textarea class="form-control" rows="1" name="address_street"><?php echo $user['address_street']; ?></textarea>
                        </div>
                    </div>





                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Country</label>
                        </div>
                        <div class="col-sm-9">
                            <select class="form-control" id="news_country" name="address_country" onchange="news_getcountrystate(this.value);">
                                <?php foreach ($allcountry as $country) {
                                    $selected = '';
                                    if ($country->name == 'India') {
                                        $selected = ' selected="selected" ';
                                    }
                                ?>
                                    <option <?php echo $selected; ?> value="<?php echo $country->name; ?>"><?php echo $country->name; ?></option>
                                <?php } ?>
                            </select>
                            <span class="error_message" id="news_country_error"></span>
                        </div>
                    </div>


                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>State</label>
                        </div>
                        <div class="col-sm-9">
                            <select class="form-control" id="news_state" name="address_state" onchange="news_setStateCity(this.value)">
                                <option value=""></option>
                            </select>
                        </div>
                    </div>


                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>City</label>
                        </div>
                        <div class="col-sm-9">
                            <select class="form-control" id="news_city" name="address_city">
                                <option value=""></option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>Phone No</label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="text" name="phone_mobile" value="<?php echo $user['phone_mobile']; ?>">
                        </div>
                    </div>


                </div>

            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-lg-12 clearfix">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo OTHER_INFORMATION; ?>
                </div>
                <div class="panel-body">

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label><?php echo "Password"; ?></label>
                        </div>
                        <div class="col-sm-9">
                            <input class="form-control" type="password" value="" name="password">
                        </div>
                    </div>

                    <div class="form-group clearfix">
                        <div class="col-sm-3">
                            <label>User Status</label>
                        </div>
                        <div class="col-sm-9">
                            <!-- <input class="form-control" type="text"  value=""  name="phone_mobile"> -->
                            <select name="user_status" class="form-control">
                                <option <?php if ($user['user_status'] == 'A') {
                                            echo ' selected="selected" ';
                                        } else {
                                            echo '';
                                        } ?> value="A">Active</option>
                                <option <?php if ($user['user_status'] == 'B') {
                                            echo ' selected="selected" ';
                                        } else {
                                            echo '';
                                        } ?> value="B">Blocked</option>
                                <option <?php if ($user['user_status'] == 'D') {
                                            echo ' selected="selected" ';
                                        } else {
                                            echo '';
                                        } ?> value="D">Deactive</option>
                                <option <?php if ($user['user_status'] == 'S') {
                                            echo ' selected="selected" ';
                                        } else {
                                            echo '';
                                        } ?> value="S">Suspend</option>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
        </div><!-- col-lg-12  -->

    </div>
    <!-- /row -->
    <div class="text-center">
        <button type="submit" class="btn btn-default btn-lg"><?php echo ADD_USER; ?></button>
    </div>
    </form>
</div>
<!-- /#page-wrapper -->
<br />
<br />
<br />

</body>

</html>
<?php $this->load->view('admin/vwFooter'); ?>
<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        var readURL = function(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('.profile-pic').attr('src', e.target.result);
                    console.log(e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#profile_image").on('change', function() {
            readURL(this);
        });

        $(".upload-button").on('click', function() {
            $("#profile_image").click();
        });
    });

    $(document).ready(function() {
        $('#news_country').select2({
            placeholder: "Select country",
            allowClear: true
        });
        $('#news_state').select2({
            placeholder: "Select state",
            allowClear: true
        });
        $('#news_city').select2({
            placeholder: "Select city",
            allowClear: true
        });
        $('#categorise').select2({
            placeholder: "Select categorise",
            allowClear: true
        });
        $('#news_country').val('<?php echo $user['address_country']; ?>');
        $('#news_country').trigger('change');
        news_getcountrystate('<?php echo $user['address_country']; ?>', 'load', '<?php echo $user['address_state']; ?>', '<?php echo $user['address_city']; ?>');
        //setStateCity('<?php echo $news_state ?>', 'load', '<?php echo $news_city ?>');
    });

    function news_getcountrystate(id, onload = '', set = '', city = '') {
        var postData = {
            country_id: id
        };
        $.ajax({
            url: "<?php echo base_url(); ?>home/getCountrySate",
            data: postData,
            dataType: 'json',
            type: 'POST',
            success: function(result) {
                $('#news_state').html('');
                var output = [];
                output.push('<option value=""></option>');
                $.each(result, function(key, value) {
                    output.push('<option value="' + value.name + '">' + value.name + '</option>');
                });

                if (output.length > 0) {
                    $('#news_state').html(output.join(''));
                } else {
                    $('#news_state').html('<option value="">No state found</option>');
                }
                if (onload == 'load') {

                    if (set != '') {
                        $('#news_state').val(set);
                    }

                    if (city != '') {
                        setTimeout(function() {
                            news_setStateCity(set, 'load', city);
                        }, 1000);
                    }
                }
                $('#news_state').trigger('change');


            }
        });
    }

    function news_setStateCity(id, onload = '', set = '') {
        //alert(id);
        var postData = {
            country_id: id
        };

        $.ajax({
            url: "<?php echo base_url(); ?>home/getSateCity",
            data: postData,
            dataType: 'json',
            type: 'POST',
            success: function(result) {

                $('#news_city').html('');
                var output = [];
                output.push('<option value=""></option>');

                $.each(result, function(key, value) {
                    output.push('<option value="' + value.name + '">' + value.name + '</option>');
                });

                if (output.length > 0) {
                    $('#news_city').html(output.join(''));
                } else {
                    $('#news_city').html('<option value="">No city found</option>');
                }

                if (onload == 'load') {
                    if (set != '') {
                        $('#news_city').val(set);
                    }
                }
                $('#news_city').trigger('change');
            }
        });
    }

    /*
        function validateForm() {
            var error = 0;
            $('.error_message').html('');
            if ($('#title').val() == '') {
                $("#title_error").html('please enter new titel');
                error = 1;
            }
            var desc = CKEDITOR.instances['discription'].getData();
            if (desc == '') {
                $("#discription_error").html('please enter new discription');
                error = 1;
            }

            if ($('#news_country').val() == '') {
                $("#news_country_error").html('please enter country');
                error = 1;
            }

            var data = $('#news_country').select2('data');
            if (data == '') {
                $("#news_country_error").html('please select country');
                error = 1;
            }
            if (error == 1) {
                return false;
            }

        }
        */
</script>