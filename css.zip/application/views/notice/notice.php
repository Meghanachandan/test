<!--<link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet">-->
<!-- <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet"> -->


<style>
	#imgdiv {
		width: 160px;
		float: left;
		margin-left: 20px
	}

	#reload {
		float: right;
		margin-right: 40px
	}

	section {
		background-color: #FFF;
	}

	.table-bordered a {
		color: #000;
	}

	.table-bordered a:hover {
		color: #CCC;
	}
</style>
<section id="form">
	<!--form-->
	<div class="container">
		<div class="row">
			<div class="col-sm-12 mt-4 mb-5">
				<!--
				<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
				<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
                -->
				<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
				<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
				<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
				<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>



				<div class="graph-visual tables-main">
					<h3 class="inner-tittle two">Notice</h3>
					<div class="col-sm-12 text-right" style="margin-top:-30px;margin-bottom:15px;padding: 0;">
						<a style="cursor: pointer;" onclick="loadcategorynrws(0);">All News &nbsp;&nbsp;</a>
						<!--<select name="cate" onchange="loadcategorynrws(this.value);">-->
							<option value="">Select category</option>
							<?php foreach ($category as $cat) { ?>
								<option value="<?php echo $cat['id']; ?>" <?php if ($cat['id'] == $selected_category) {
																				echo ' selected="selected" ';
																			} ?>><?php echo $cat['title']; ?></option>
							<?php } ?>
						<!--</select>-->

					</div>
					<?php
					if ($this->session->flashdata('success')) {
					?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
																																			} ?>
					<div class="graph">
						<div class="tables">
							<table class="display responsive" id="example-table">
								<thead>
									<tr>
										<th>Id</th>
										<th width="180px">Title</th>
										<th>Image</th>
										 <th>Notice</th> 
										<th>Date</th>
										<!--<th>Status</th>-->
										<!--<th style="width: 15%;">Action</th>-->
									</tr>
								</thead>
								<?php
								$i = 0;
								foreach ($notice as $key => $news) {
									$status = (!empty($news['status']) && $news['status'] == '1') ? 'Active' : 'Deactive';
									$i++; ?>
									<tr>
										<td><?php echo $i; ?></td>
										<td width="180px">
													<?php echo $news['title']; ?>
											
										</td>
										<?php
										if (trim($news['image']) == '') {
											$news['image'] = 'no-image.png';
										}
										?>
										<td><?php
										$sdfgh=$news['image'];
										$explode=explode('.',$sdfgh);
										if($explode[1] == 'pdf'){
										?>
										    <a href='<?php echo base_url('upload/notice/thumb/' . $news['image']); ?>'>Download PDF</a>
										    <?php }else{ ?>
										    <a href='<?php echo base_url('upload/notice/thumb/' . $news['image']); ?>'><?php echo "<img src='" . base_url('upload/notice/thumb/' . $news['image']) . "' height='80px' width='90px'/>"; ?></a>
										    <?php } ?>
										    </th>
                                                            
											<!-- <th><?php echo $news['slug']; ?></th> -->
										<!--<td> <?php echo date('D/M d, Y, h:i A', strtotime($news['date'])); ?></td>-->
										<td><a class="btn btn-info" style="padding: 5px;" data-toggle="modal" data-target="#myModal<?php echo $news['id']; ?>">Notice</a></td>
                                        <td><?php echo date('D/M d, Y', strtotime($news['create_date'])); ?></td>
										
										<!--<td>-->
										
										<!--	<a href='<?php echo base_url('news/edit/' . $news['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp;-->
										<!--	<a onclick='return confirm("Are you sure? you want to delete this news!")' href='<?php echo base_url('news/delete/' . $news['id']); ?>'><i class="fa fa-trash-o"></i></a>-->
										<!--	<a href="<?php echo base_url() . cleanNewsUrl($news); ?>"><i class="fa fa-eye"></i></a>-->
										<!--</td>-->
									</tr>
									<!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $news['id']; ?>" style="height: auto;" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Notice - <?php echo $news['title']; ?></h4>
        </div>
        <div class="modal-body">
          <?php echo $news['description']; ?>
        </div>
        <div class="modal-footer" style="padding: 0px;">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
								<?php } ?>
							</table>
						</div>
					</div>
					<!--//graph-visual-->
				</div>
			</div>
			<script>
				$(document).ready(function() {
					$('#example-table').DataTable({
						"pagingType": "full_numbers",
						"lengthMenu": [
							[10, 25, 50, -1],
							[10, 25, 50, "All"]
						]
					});
				});

				function loadcategorynrws(val) {
					location.href = "<?php echo base_url(); ?>news/my_news?cat=" + val;
				}
			</script>
		</div>
	</div>
	</div>
</section>