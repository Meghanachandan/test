<br><?php
$query = $this->db->select('*')
     ->from('news_categories as t1')
     ->where('t1.categorie_type', 1)
     ->join('latest_news as t2', 't1.id = t2.categorise', 'RIGHT')
        ->limit(8,0)
        ->order_by('t2.id', 'desc')
     ->get();

     $result = $query->result_array();
    //  echo $result[0]['categorise'];
    //   echo "<pre>";
    //   print_r($result);
    //   die;


?>


 <style type="text/css">
    

.badgeall
{
   position:absolute;
   font-size:15px;
   color:#fff;
   margin-top:10px;
   margin-left: -85px !important;
}

</style>
<script type="text/javascript">
$(document).ready(function(){

$('.items').slick({
infinite: true,
slidesToShow: 4,
//  autoplay: true,
 dots: false,
    prevArrow: false,
    nextArrow: false,
slidesToScroll: 1,
responsive: [
            {
              breakpoint: 1000,
              settings: {
                slidesToShow: 6,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 800,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 500,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1
              }
            }                
           ]
  

});
}); </script>
<style>
    .slick-arrow.slick-disabled { 
        display: none !important;
    }
</style
 <!--Slick Carousel Slider-->

 <div class="items mbr-text mbr-fonts-style display-7 T2" style="height:250px;overflow:hidden;">
      <!--$key =>-->
    <?php 
    $badge=array("badge-primary","badge-secondary","badge-success","badge-danger","badge-warning","badge-info","badge-primary","badge-secondary","badge-success","badge-danger","badge-warning","badge-info");
    foreach ($result as $key => $news) {
        // var_dump($news);
        
        
        $cname = $news['image'];
           
if(empty($news['image']) || !file_exists( "upload/news/thumb/$cname"))
{
$curlnew  = 'http://newssyn.com/upload/adds/no-image.png';
}
else
{
$curlnew   = base_url() .'upload/news/thumb/'.$cname;
}
// echo $news['categorise'];
$categorise = $news['categorise'];
$this->db->select('title');
$this->db->from('news_categories');
$this->db->where(id,$categorise);
$cat_query=$this->db->get();
$cat_result=$cat_query->result_array();

// var_dump($categorise);
// die;

     ?>
<!-- <div class="card p-3 col-12 col-md-6 my-col"> -->
<div class="card-wrapper">
    <?php
    //var_dump($cat_result);
    ?>
    <div class="card-img">
        <a href="<?php echo base_url() . cleanNewsUrl($news); ?>">
            <?php
            if (trim($news['image']) == '') {
                $news['image'] = 'no-image.png';
            } else {
                $news['image'] = 'thumb/' . $news['image'];
            }
            ?>
         
          


      
          <span class="badge badgeall <?= $badge[$key]; ?>"><?=  $cat_result[0]['title']; ?></span>
         
            <img src="<?= $curlnew; ?>" style="height:120px;" alt="<?php echo $news['short_discription'] ?>">
         
        </a>
        
        
        <style>
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  height: auto;
  position: absolute;
  right: 0px;
  top: 10px;
  background-color: #333;
  min-width: 60px;
  box-shadow: 0px 4px 8px 0px rgba(0,0,0,0.2);
  padding: 0px 16px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
@media(max-width: 600px){
    #dis {
        display: none;
    }
}
</style>
<style>
    @media(min-width: 1200px){
        #mobel{
            display: none;
        }
    }
    @media(max-width: 600px){
        #dest{
            display: none;
        }
    }
    .social_share_button {
        width:96px!important;
    }
</style>

        <div class="date_box">
            <?php //echo date('D, d M Y', strtotime($news['date'])); ?> 
            <!--<span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>-->
            <div style="float: right;" onmouseover="showSocialButtonBox('social_box_<?php echo $list . '_' . $news['id'] ?>');" onmouseout="hideSocialButtonBox()">
                <div class="dropdown">
                  <!--<span class="share_box">...</span>-->
                  <!--<div class="dropdown-content" id="dis">-->
                  <!--<a class="resp-sharing-button__link" href="http://facebook.com/sharer/sharer.php?u=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" aria-label="">-->
                  <!--      <div class="resp-sharing-button resp-sharing-button--facebook resp-sharing-button--small">-->
                  <!--          <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">-->
                  <!--              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">-->
                  <!--                  <path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z" /></svg>-->
                  <!--          </div>-->
                  <!--      </div>-->
                  <!--  </a>-->
                    
                    
                  <!--<a class="resp-sharing-button__link" href="http://twitter.com/intent/tweet/?text=<?php echo urlencode($news['short_discription']); ?>&amp;url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" aria-label="">-->
                  <!--      <div class="resp-sharing-button resp-sharing-button--twitter resp-sharing-button--small">-->
                  <!--          <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">-->
                  <!--              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">-->
                  <!--                  <path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z" /></svg>-->
                  <!--          </div>-->
                  <!--      </div>-->
                  <!--  </a>-->
                    
                  <!--  <a id='mobel' class="resp-sharing-button__link" href="whatsapp://send?text=<?php echo urlencode($news['short_discription'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" rel="noopener" aria-label="">-->
                  <!--      <div class="resp-sharing-button resp-sharing-button--whatsapp resp-sharing-button--small">-->
                  <!--          <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">-->
                  <!--              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">-->
                  <!--                  <path d="M20.1 3.9C17.9 1.7 15 .5 12 .5 5.8.5.7 5.6.7 11.9c0 2 .5 3.9 1.5 5.6L.6 23.4l6-1.6c1.6.9 3.5 1.3 5.4 1.3 6.3 0 11.4-5.1 11.4-11.4-.1-2.8-1.2-5.7-3.3-7.8zM12 21.4c-1.7 0-3.3-.5-4.8-1.3l-.4-.2-3.5 1 1-3.4L4 17c-1-1.5-1.4-3.2-1.4-5.1 0-5.2 4.2-9.4 9.4-9.4 2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7-.1 5.2-4.3 9.4-9.5 9.4zm5.1-7.1c-.3-.1-1.7-.9-1.9-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1s-1.2-.5-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6s.3-.3.4-.5c.2-.1.3-.3.4-.5.1-.2 0-.4 0-.5C10 9 9.3 7.6 9 7c-.1-.4-.4-.3-.5-.3h-.6s-.4.1-.7.3c-.3.3-1 1-1 2.4s1 2.8 1.1 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.3.2-.7.2-1.2.2-1.3-.1-.3-.3-.4-.6-.5z" /></svg>-->
                  <!--          </div>-->
                  <!--      </div>-->
                  <!--  </a>-->
                    
                  <!--  <a id='dest' class="resp-sharing-button__link" href="http://web.whatsapp.com/send?text=<?php echo urlencode($news['short_discription'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" rel="noopener" aria-label="">-->
                  <!--      <div class="resp-sharing-button resp-sharing-button--whatsapp resp-sharing-button--small">-->
                  <!--          <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">-->
                  <!--              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">-->
                  <!--                  <path d="M20.1 3.9C17.9 1.7 15 .5 12 .5 5.8.5.7 5.6.7 11.9c0 2 .5 3.9 1.5 5.6L.6 23.4l6-1.6c1.6.9 3.5 1.3 5.4 1.3 6.3 0 11.4-5.1 11.4-11.4-.1-2.8-1.2-5.7-3.3-7.8zM12 21.4c-1.7 0-3.3-.5-4.8-1.3l-.4-.2-3.5 1 1-3.4L4 17c-1-1.5-1.4-3.2-1.4-5.1 0-5.2 4.2-9.4 9.4-9.4 2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7-.1 5.2-4.3 9.4-9.5 9.4zm5.1-7.1c-.3-.1-1.7-.9-1.9-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1s-1.2-.5-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6s.3-.3.4-.5c.2-.1.3-.3.4-.5.1-.2 0-.4 0-.5C10 9 9.3 7.6 9 7c-.1-.4-.4-.3-.5-.3h-.6s-.4.1-.7.3c-.3.3-1 1-1 2.4s1 2.8 1.1 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.3.2-.7.2-1.2.2-1.3-.1-.3-.3-.4-.6-.5z" /></svg>-->
                  <!--          </div>-->
                  <!--      </div>-->
                  <!--  </a>-->
                    
                  <!--</div>-->
                </div>
                
                
                <!--<span class="share_box">-->
                <!--    ...-->
                <!--</span>-->
                <div class="social_share_button"  id="social_box_<?php echo $list . '_' . $news['id'] ?>">
                     <!--Sharingbutton Facebook -->
                    <a class="resp-sharing-button__link" href="http://facebook.com/sharer/sharer.php?u=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" aria-label="">
                        <div class="resp-sharing-button resp-sharing-button--facebook resp-sharing-button--small">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M18.77 7.46H14.5v-1.9c0-.9.6-1.1 1-1.1h3V.5h-4.33C10.24.5 9.5 3.44 9.5 5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4z" /></svg>
                            </div>
                        </div>
                    </a>

                     <!--Sharingbutton Twitter -->
                    <a class="resp-sharing-button__link" href="http://twitter.com/intent/tweet/?text=<?php echo urlencode($news['title']); ?>&amp;url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" aria-label="">
                        <div class="resp-sharing-button resp-sharing-button--twitter resp-sharing-button--small">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16C5.78 18.1 3.37 18.74 1 18.46c2 1.3 4.4 2.04 6.97 2.04 8.35 0 12.92-6.92 12.92-12.93 0-.2 0-.4-.02-.6.9-.63 1.96-1.22 2.56-2.14z" /></svg>
                            </div>
                        </div>
                    </a>

                     <!--Sharingbutton Tumblr -->
                    <!---
                    <a class="resp-sharing-button__link" href="http://www.tumblr.com/widgets/share/tool?posttype=link&amp;title=Super%20fast%20and%20easy%20Social%20Media%20Sharing%20Buttons.%20No%20JavaScript.%20No%20tracking.&amp;caption=Super%20fast%20and%20easy%20Social%20Media%20Sharing%20Buttons.%20No%20JavaScript.%20No%20tracking.&amp;content=http%3A%2F%2Fsharingbuttons.io&amp;canonicalUrl=http%3A%2F%2Fsharingbuttons.io&amp;shareSource=tumblr_share_button" target="_blank" rel="noopener" aria-label="">
                        <div class="resp-sharing-button resp-sharing-button--tumblr resp-sharing-button--small">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M13.5.5v5h5v4h-5V15c0 5 3.5 4.4 6 2.8v4.4c-6.7 3.2-12 0-12-4.2V9.5h-3V6.7c1-.3 2.2-.7 3-1.3.5-.5 1-1.2 1.4-2 .3-.7.6-1.7.7-3h3.8z" />
                                </svg>
                            </div>
                        </div>
                    </a>
                    -->
                     <!--Sharingbutton WhatsApp -->
                     <style>
                         @media(min-width: 1200px){
                             #mm{
                                 display:none;
                             }
                         }
                         @media(max-width: 600px){
                             #ds{
                                 display:none;
                             }
                         }
                     </style>
                    <a id="mm" class="resp-sharing-button__link" href="whatsapp://send?text=<?php echo urlencode($news['title'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" rel="noopener" aria-label="">
                        <div class="resp-sharing-button resp-sharing-button--whatsapp resp-sharing-button--small">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M20.1 3.9C17.9 1.7 15 .5 12 .5 5.8.5.7 5.6.7 11.9c0 2 .5 3.9 1.5 5.6L.6 23.4l6-1.6c1.6.9 3.5 1.3 5.4 1.3 6.3 0 11.4-5.1 11.4-11.4-.1-2.8-1.2-5.7-3.3-7.8zM12 21.4c-1.7 0-3.3-.5-4.8-1.3l-.4-.2-3.5 1 1-3.4L4 17c-1-1.5-1.4-3.2-1.4-5.1 0-5.2 4.2-9.4 9.4-9.4 2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7-.1 5.2-4.3 9.4-9.5 9.4zm5.1-7.1c-.3-.1-1.7-.9-1.9-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1s-1.2-.5-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6s.3-.3.4-.5c.2-.1.3-.3.4-.5.1-.2 0-.4 0-.5C10 9 9.3 7.6 9 7c-.1-.4-.4-.3-.5-.3h-.6s-.4.1-.7.3c-.3.3-1 1-1 2.4s1 2.8 1.1 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.3.2-.7.2-1.2.2-1.3-.1-.3-.3-.4-.6-.5z" /></svg>
                            </div>
                        </div>
                    </a>
                    <a id="ds" class="resp-sharing-button__link" href="http://web.whatsapp.com/send?text=<?php echo urlencode($news['title'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" rel="noopener" aria-label="">
                        <div class="resp-sharing-button resp-sharing-button--whatsapp resp-sharing-button--small">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M20.1 3.9C17.9 1.7 15 .5 12 .5 5.8.5.7 5.6.7 11.9c0 2 .5 3.9 1.5 5.6L.6 23.4l6-1.6c1.6.9 3.5 1.3 5.4 1.3 6.3 0 11.4-5.1 11.4-11.4-.1-2.8-1.2-5.7-3.3-7.8zM12 21.4c-1.7 0-3.3-.5-4.8-1.3l-.4-.2-3.5 1 1-3.4L4 17c-1-1.5-1.4-3.2-1.4-5.1 0-5.2 4.2-9.4 9.4-9.4 2.5 0 4.9 1 6.7 2.8 1.8 1.8 2.8 4.2 2.8 6.7-.1 5.2-4.3 9.4-9.5 9.4zm5.1-7.1c-.3-.1-1.7-.9-1.9-1-.3-.1-.5-.1-.7.1-.2.3-.8 1-.9 1.1-.2.2-.3.2-.6.1s-1.2-.5-2.3-1.4c-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6s.3-.3.4-.5c.2-.1.3-.3.4-.5.1-.2 0-.4 0-.5C10 9 9.3 7.6 9 7c-.1-.4-.4-.3-.5-.3h-.6s-.4.1-.7.3c-.3.3-1 1-1 2.4s1 2.8 1.1 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.3.2-.7.2-1.2.2-1.3-.1-.3-.3-.4-.6-.5z" /></svg>
                            </div>
                        </div>
                    </a>
                    <style></style>
                    <a class="resp-sharing-button__link" href="http://www.instagram.com/sharer.php?u=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['title']) ?>" target="_blank" rel="noopener" aria-label="">
                        <div class="">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <style>
                        .fa-instagram {
                          background: #125688;
                          color: white;
                          font-size: 25px;
                        }
                    </style><i class='fa fa-instagram'></i>
                            </div>
                        </div>
                    </a>
                    <a class="resp-sharing-button__link" href="http://telegram.me/share/url?url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>&text=<?php echo urlencode($news['title']); ?>" target="_blank" rel="noopener" aria-label="">
                        <div class="">
                            <div aria-hidden="true" class="resp-sharing-button__icon resp-sharing-button__icon--solid">
                                <i class="fa fa-telegram" style="font-size:25px;color:red"></i>
                            </div>
                        </div>
                    </a>
                    
                </div>
                
                
            </div>
        </div>
    </div>
    <div class="card-box">
        <p class="mbr-text mbr-fonts-style display-7 T2" style="margin-top: 0px;">
            <?php
            $full_description = '';
            $full_description .= ' <span class=citycolour ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
            $full_description .= ' <span class=newstitlecolour ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
            $full_description_text = limit_text($news['discription'], 400);
            $full_description .= ' <span class=neswDescription >'.$full_description_text .' </span> ';
            ?>
            <a id="detail_link_<?php echo $list . '_' . $news['id'] ?>" href="<?php echo base_url() . cleanNewsUrl($news); ?>" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
           
                <?php if ($news['city'] != '') { ?>
                    <span class="new_slug citycolour"><?php echo limit_text($news['city'], 20); ?> / </span>
                <?php } ?>
                <span class="new_slug newstitlecolour"><?php echo limit_text($news['title'], 20); ?> / </span>
                <br>
                <span style="color:#000000">
                    <?php #echo strip_tags($news['discription']); ?>

                     <?php echo limit_text(strip_tags($news['discription']), 100) ?>
                </span>
            </a>
        </p>

        <!-- 
        <h4 class="card-title pb-3 mbr-fonts-style display-7"></h4>
        <p class="mbr-text mbr-fonts-style display-7"></p> 
        -->
        <p class="mobile_read_more text-right">
            <a onclick="open_read_more_popup('<?php echo $list . '_' . $news['id'] ?>')" >Read More</a>
        </p>
    </div>
</div>

<!-- </div> -->













 
 <?php } ?>
    
 </div>
 