<?php
$page_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$break = explode('/', $page_url);
$newsid = $break[5];
$sub_cat_id = $break[4];
get_instance()->load->helper('newsview_helper');
$totalipcount = checklikeip($newsid);
$ad="SELECT * FROM `side_img` WHERE page_host ='".$sub_cat_id."' and status='1'  ORDER BY id DESC LIMIT 1";
$q = $this->db->query($ad);
        $data = $q->result_array();
?>
</script>
    <style>
    @media(max-width: 600px){
        #display{
            display: none;
        }
    }
</style>                                
      
        <div class="container-fluid">
            <div class="row">
                <!--main-contaner-for-home-->
 <div class="col-sm-12 col-md-2 col-lg-2 col-xl-2 mb-3 p-1">
     <?php if($sub_cat_id==$data[0]['page_host']){
        if($data[0]['media_type']=='img'){
         ?>
         
             <img id='display' src="<?php echo 'http://newssyn.com/upload/side_img/left_img/orig/'.$data[0]['left_img']; ?>" style="height: 734.5px;width:inherit;">
      <?php  } else{ ?>
                <span id='display' style="height: 734.5px;width:inherit;"><?php echo $data[0]['l_sence_code']; ?></span>
    <?php } }else{ ?>
     <img id='display' src="<?php echo base_url(); ?>images/ads.gif" style="width:100%;">
     <?php } ?>
 </div>
    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 " style="float:left;padding-left:0px !important;padding-right:0px !important;">

                <div  class="col-md-8" style="float:left;" id="single_news_detail">
                            
                            <h1 class="f1-l-3 cl2 p-b-16 p-t-33 respon2 db_storybox">
                                <a href="<?php echo base_url() . 'home/search/' . $getCatInfo['id'] . '/' . $getCatInfo['id']; ?>"><strong style="color: #e6102d;"><?php echo $getCatInfo['title']; ?></strong></a><strong style="color: #000;">/</strong><a href="<?php echo base_url() . 'home/search/' . $getCatInfo['id'] . '/' . $getSubCatInfo['id']; ?>"><strong style="color: #e6102d;"><?php echo $getSubCatInfo['title']; ?></strong></a><strong style="color: #000;">/</strong><a href="<?php echo base_url() . 'home/search?c=' . urlencode($news['country']); ?>"><strong style="color: #e6102d;"><?php echo $news['country']; ?></strong></a><strong style="color: #000;">/</strong><a href="<?php echo base_url() . 'home/search?s=' . urlencode($news['state']); ?>"><strong style="color: #e6102d;"><?php echo $news['state']; ?></strong></a><strong style="color: #000;">/</strong><a href="<?php echo base_url() . 'home/search?ci=' . urlencode($news['city']); ?>"><strong style="color: #e6102d;"><?php echo $news['city']; ?></strong></a><strong style="color: #000;"></strong><br><span style="color:#004d38;font-weight:600;"><?php echo $news['title'] ?></span>
                                <?php if ($preview_action == '1') { ?>
                                    <span class="active_prieview pull-right">
                                        <a href="<?php echo base_url('news/edit/' . $news['id']); ?>"> - Edit </a> | <a href="<?php echo base_url() . 'news/activate_news/' . $news['id']; ?>"> Active </a>
                                    </span>
                                <?php } ?>
                            </h1>

<span class="f1-s-3 cl8 m-r-15">
                            <div class="row">
                                <div class="col-md-1">
                                    <?php
                                    if ($news['hide_image_on_news'] != '1') {
                                        
                                        
                                    $img= getReporterImage($news['reporter']); 
                                    if($img ==''){
                                        $images = 'upload/userss.png';
                                    }else{
                                        $images = 'upload/profile_image/'.getReporterImage($news['reporter']);
                                    }
                                    ?>
                                   <img src="<?php echo base_url().$images; ?>" atl="userImage" style="height: 50px;width: 50px;margin-bottom: 5px;border-radius: 100%;" class="img-circle">
                                   <?php }else{ ?>
                                   <img src="<?php echo base_url().'upload/userss.png'; ?>" atl="userImage" style="height: 50px;width: 50px;margin-bottom: 5px;border-radius: 100%;" class="img-circle">
                                   <?php } ?>
                                        </div>
                                        <div class="col-md-8"><span style="font-size: 16px">By&nbsp;</span>
                                        <?php if ($news['hide_name_on_news'] != '1') { ?>
                                            <a href="#" class="f1-s-4 cl8 hov-cl10 trans-03" style="font-size: 16px;">
                                                <!--<i class="fas fa-pencil-alt"></i>-->
                                                <?php echo getReporterName($news['reporter']); ?>
                                            </a>
                                        <?php } ?>
                                        <?php if ($news['hide_email_on_news'] != '1') { ?>
                                            <a href="#" class="f1-s-4 cl8 hov-cl10 trans-03" style="font-size: 16px;">
                                                /<?php echo getReporterEmail($news['reporter']); ?>
                                            </a>
                                        <?php } ?>
                                        <?php if ($news['hide_name_on_news'] == '1' && $news['hide_email_on_news'] == '1') { ?>
                                        /<a href="#" style="font-size: 16px;">
                                            <!--<i class="fas fa-pencil-alt"></i>&nbsp;-->
                                            Public Reporter</a>
                                        <?php } ?>
                                        <br>
                                        <?php
                                        date_default_timezone_set("Asia/Kolkata");
                                        //echo date_default_timezone_get();
                                        ?>
                                        <span style="font-size: 12px;">
                                        <?php echo date('D/M d, Y, h:i A', strtotime($news['date'])) . ' - ' . date('T'); ?>
                                        <?php if (sizeof($news_count) > 0) {
                                            // . sizeof($news_count)
                                            echo '&nbsp;'  . ' <span class="mbri-preview"></span>';
                                        } ?>
                                         <b><?php echo $countview = countview($newsid); ?></b>
                                        <?php
                                        
                                        if($totalipcount == 1)
                                        { ?>
                                         <span>&nbsp;&nbsp;<i class="far fa-thumbs-up"></i></span>
                                       <?php } else {
                                        ?>
                                        <span style="cursor: pointer;" id="<?php echo $newsid; ?>" onclick="mynewslike(this.id)">&nbsp;&nbsp;<i class="far fa-thumbs-up"></i></span>
                                       <?php  } ?>

                                        <b id="staticcount"><?php echo $countlike = countlike($newsid); ?></b>
                                        </span>
                                        </div>
                                        </div>
                                </span>
                                  <?php if ($show_google_translater == '1') { ?>
                                <div style="margin-right: 0px;float: right;margin-top: -45px;" id="google_translate_element"></div>
                            <?php } ?>

 <div class="carousel slide" data-ride="carousel" id="carousel1">
                    <div class="carousel-inner" role="listbox" >
                        <div class="carousel-item active"> 
 <?php

                    if ($news['media_type'] == 'youtube') {
                        /*
                    echo '<div style="width:100%;height:auto">';
                    echo $latest_news[0]['youtube_code'];
                    echo '</div>';
                    */

                        $you_tube = str_replace('height', 'height="350px" res-height', $news['youtube_code']);
                        $you_tube = str_replace('width', 'width="100%" res-width', $you_tube);
                        echo $you_tube;
                    } else {


// $imgurl =  'upload/news/orig/' . $news['image'];

//                       if ($news['image'] == '' || !file_exists($imgurl)) {
//                             $news['image'] = 'http://newssyn.com/upload/adds/no_image.png';
//                         } else {
//                             $news['image'] = base_url() .'upload/news/orig/' . $news['image'];
//                         }
                    ?>
                        <!--<img class="d-block img-fluid w-100" src="<?php echo $news['image']; ?>" alt="<?php echo $news['title'] ?>" style="height:400px;width:100%;" >-->
                    <?php //} ?>

                           <!--  <img class="d-block img-fluid w-100" src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1566824776/work1.png" alt="first slide" style="height:300px;"> -->



                           
                        <!--</div>-->
                  
                   <?php 
                   $id =  $news['id']; 
                  
                   $this->db->select('*');
                   $this->db->from('news_gallery');
                   $this->db->where('nid',$id);
                   $query = $this->db->get();
                   $result = $query->result_array();
                 foreach ($result as $key => $value) {
                    $sname =  $value['name'];
                   $imgurl =  'upload/news/orig/' . $value['name'];
if(empty($value['name']) || !file_exists($imgurl))
{
$surl   = 'http://newssyn.com/upload/adds/no-image.png';
}
else
{
$surl   = base_url() . 'upload/news/orig/' . $value['name'];
}
                   ?>
                <!--<div class="carousel-item "> -->
                <img style="height:400px;width:100%;" class="d-block img-fluid w-100" src="<?php echo $surl; ?>" data-holder-rendered="true" >
                            
                        </div>
                    <?php }} ?>
                         <!--        <div class="carousel-item"> <img class="d-block img-fluid w-100" src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1566825017/work1_2.png" data-holder-rendered="true" style="height:300px;">
                          
                        </div> -->
                    </div>
                    <?php  if ($news['media_type'] != 'youtube') { ?>
                    <a class="carousel-control-prev" href="#carousel1" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carousel1" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a>
                    <?php } ?>
                </div>
                
                             

<div class="wrap-pic-max-w">

                            <?php if ($news['media_type'] == 'youtube') {

                                $you_tube = str_replace('height', 'height="350px" res-height', $news['youtube_code']);
                                $you_tube = str_replace('width', 'width="100%" res-width', $you_tube);
                             //   echo $you_tube;

                            ?>
                            <?php } else { ?>

                                <?php
                                if (trim($news['image']) == '') {
                                    $news['image'] = 'http://newssyn.com/upload/adds/no-image.png';
                                } else {
                                    $news['image'] = 'orig/' . $news['image'];
                                }
                                ?>
                              

                            <?php } ?>
                        </div>
  <?php if ($news['image_capsion'] != '') { ?>
                            <span class="db_slug"><?php echo $news['image_capsion']; ?></span>
                        <?php } ?>

                        <?php if ($news['highlights'] != '') {
                            $hightLight_point  = explode('#$#', $news['highlights']);
                            echo '<div class="db_storycontent" >';
                            echo '<ul>';
                            foreach ($hightLight_point as $point) {
                                echo '<li>' . $point . '</li> ';
                            }
                            echo '</ul>';
                            echo '</div>';
                        }
                        ?>
<?php if(!empty($news['news_audio']))
{ ?>
<!--                        <audio controls width="200px">-->
<!--  <source src="horse.ogg" type="audio/ogg">-->
<!--  <source src="<?= base_url(); ?>upload/news/audio/<?php echo $news['news_audio']; ?>" type="audio/mpeg">-->
<!--Your browser does not support the audio element.-->
<!--</audio>-->
<?php  }
if(!empty($news['news_video']))
{ 
?>
<!--<video width="100%" style="height:250px;" controls>-->
<!--  <source src="<?= base_url(); ?>upload/news/video/<?php echo $news['news_video']; ?>" type="video/mp4">-->
<!--  <source src="mov_bbb.ogg" type="video/ogg">-->
<!--  Your browser does not support HTML video.-->
<!--</video>-->
<?php } ?>

                        <div class="f1-s-11 cl6 p-b-25 py-3 mt-3 text-justify">
                            <style>
                            .fdgfdgdfg p {
                                    text-align: justify;!important;
                                    font-size: 16px;
                                    color: #333;
                            }
                        </style>
                            <strong style="float: left;color: #e6102d;font-size: 20px;line-height: 23px;"><?php echo $news['city']; ?></strong><strong style="float: left;color: #000;font-size: 20px;line-height: 23px;margin-right: 10px;">/</strong><span class="fdgfdgdfg"><?php echo $news['discription']; ?></span>
                        </div>
                        
                        
                        
                        <div class="row">
                            <div class="col-md-3"></div>
                            <div class="col-md-4.5">
                                <?php
                                        /*
                                        $query = "SELECT * FROM (SELECT * FROM latest_news WHERE categorise LIKE '".$news['categorise']."') latest_news ORDER BY rand() LIMIT 1";
                                      $querya = "SELECT * FROM (SELECT * FROM latest_news WHERE categorise LIKE '".$news['categorise']."') latest_news where created_date < '".$news['created_date']."' ORDER BY created_date DESC LIMIT 1";
                                        $querya = $this->db->query($querya);
                                        $rowsasdasda = $querya->result_array();
                                        $query1a = "SELECT * FROM news_categories where id='".$rowsasdasda[0]['categorise']."'";
                                        $query1a = $this->db->query($query1a);
                                        $row1a = $query1a->result_array();
                                        
                                        */
                                         if($news['previous_news_id']>0){
                                       
                                    ?>
                                    <!--<meta property="og:image" content="<?php echo base_url().'image/logo.png';?>" />-->
                                    <!--<a href="<?php echo base_url().'home/news_view/'.$rowsasdasda[0]['id'] . '/' . $row1a[0]['slug']. '/' . $rowsasdasda[0]['country']. '/' . $rowsasdasda[0]['state']. '/' . $rowsasdasda[0]['city'] . '/' . $rowsasdasda[0]['title']; ?>" style="float: left;" class="dis-block f1-s-13 cl0 bg-pinterest borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">-->
                                    <!--    previous News<i class="fas fa-naxt"></i>-->
                                    <!--</a>-->
                                    <a data-recid="<?= $news['previous_news_id']; ?>"  onclick="ajax_news_view(<?= $news['previous_news_id']; ?>)" style="float: left;" class="ajax_news_view_btn dis-block f1-s-13 cl0 bg-pinterest borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                        Previous News<i class="fas fa-naxt"></i>
                                    </a>
                                <?php } ?>
                                 <?php
                                        
                                       // $query = "SELECT * FROM (SELECT * FROM latest_news WHERE categorise LIKE '".$news['categorise']."') latest_news ORDER BY rand() LIMIT 1";
                                      $query = "SELECT * FROM (SELECT * FROM latest_news WHERE categorise LIKE '".$news['categorise']."') latest_news where created_date > '".$news['created_date']."' ORDER BY created_date ASC LIMIT 1";
                                        $query = $this->db->query($query);
                                        $rowsasdasd = $query->result_array();
                                        $query1 = "SELECT * FROM news_categories where id='".$rowsasdasd[0]['categorise']."'";
                                        $query1 = $this->db->query($query1);
                                        $row1 = $query1->result_array();
                                        
                                        
                                        //  echo $rowsasdasd[0]['id'];
                                        
                                        //echo $ss;
                                        if($news['next_news_id']>0){
                                    ?>
                                    <!--<button onclick="change_state(this.value)" value="<?php echo $rowsasdasd[0]['id']; ?>" type='button' class="btn btn-primary">helo</button>-->
                                    <!--<a href="<?php echo base_url().'home/news_view/'.$rowsasdasd[0]['id'] . '/' . $row1[0]['slug']. '/' . $rowsasdasd[0]['country']. '/' . $rowsasdasd[0]['state']. '/' . $rowsasdasd[0]['city'] . '/' . $rowsasdasd[0]['title']; ?>" style="float: right;" class="dis-block f1-s-13 cl0 bg-pinterest borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">-->
                                    <!--    Next News<i class="fas fa-naxt"></i>-->
                                    <!--</a>-->
                                    <a  data-recid="<?= $news['next_news_id']; ?>" onclick="ajax_news_view(<?= $news['next_news_id']; ?>)" style="float: right;" class="ajax_news_view_btn dis-block f1-s-13 cl0 bg-pinterest borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                        Next News<i class="fas fa-naxt"></i>
                                    </a>
                                    <!--<div id="t6"></div>-->
                                    
                                    <?php } ?>
                            </div>
                            <div class="col-md-3"></div>
                        </div>
                        
                        
                        
                        

<style>
    @media(min-width: 1200px){
        #idsas{
            display: none;
        }
    }
    @media(max-width: 600px){
        #idsss{
            display: none;
        }
    }
    a.ajax_news_view_btn{
        color:white!important;
    }
</style>


  <div class="flex-s-s">
                            <span class="f1-s-12 cl5 p-t-1 m-r-15">
                                Share:
                            </span>
                            <div class="flex-wr-s-s size-w-0">
                                
                                <a href="http://facebook.com/sharer/sharer.php?u=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['title']) ?>" target="_blank" onclick="return fbs_click()" rel="noopener" class="dis-block f1-s-13 cl0 bg-facebook borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                    <i class="fab fa-facebook-f m-r-7"></i>
                                    Facebook
                                </a>
                                <a href="http://twitter.com/intent/tweet/?text=<?php echo urlencode($news['title']); ?>&amp;url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" class="dis-block f1-s-13 cl0 bg-twitter borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                    <i class="fab fa-twitter m-r-7"></i>
                                    Twitter
                                </a>
                                <a id="idsas" href="whatsapp://send?text=<?php echo urlencode($news['title'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" class="dis-block f1-s-13 cl0 bg-whatsapp borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03" data-action="share/whatsapp/share">
                                    <i class="fab fa-whatsapp m-r-7"></i>
                                    Whatsapp
                                </a>
                                 <a id="idsss" href="http://web.whatsapp.com/send?text=<?php echo urlencode($news['title'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>"  target="_blank" class="dis-block f1-s-13 cl0 bg-whatsapp borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03"><i class="fab fa-whatsapp m-r-7"></i>
                                    Whatsapp</a>
                                    <a href="http://telegram.me/share/url?url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>&text=<?php echo urlencode($news['title']); ?>" class="dis-block f1-s-13 cl0 bg-twitter borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                        <i class="fab fa-telegram"></i>
                                        Telegram
                                    </a>
                                <!-- 
                                    <a href="#" class="dis-block f1-s-13 cl0 bg-google borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                        <i class="fab fa-google-plus-g m-r-7"></i>
                                        Google+
                                    </a>
                                    
                                    -->
                                    
                            </div>
                        </div>




                </div>
                
                
                

                
                 <div  class="col-md-4" style="float:left;">
 <div class="content-sidebar">
            <div class="sidebar_inner">

                <?php
                $side_bar_conter = 0;
                if ($populer_news) {
                    // unset($populer_news[0]);

                ?>

                    <div class="widget-item">
                        <div class="w-header">
                                <div class="w-title">Top News</div>
                            <div class="w-seperator"></div>
                        </div>
                        <div class="w-boxed-post">
                            <ul>
                                <?php
                                foreach ($populer_news as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?> </h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php
                    }
                    ?>

                    
                    <?php
                    if ($latest_news) {
                    ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Latest News</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($latest_news as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>

                    <?php if ($recientView) { ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Recent View</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($recientView as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>


                    <!-- <div class="widget-item">
                        <div class="w-header">
                            <div class="w-title">Carousel Posts</div>
                            <div class="w-seperator"></div>
                        </div>
                        <div class="w-carousel-post">
                            <div class="owl-carousel" id="widgetCarousel">
                                <div class="item">
                                    <a href="#">
                                        <div class="w-play-img">
                                            <img src="img/news-test-images/news-img4.jpg" width="300">
                                            <span class="w-video-icon"><i class="material-icons">&#xE038;</i></span>
                                        </div>
                                        <span class="w-post-title">It has roots in a piece of classical Latin literature from</span>

                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img5.jpg" width="300">
                                        <span class="w-post-title">Lorem Ipsum used since</span>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img6.jpg" width="300">
                                        <span class="w-post-title">English versions from the 1914 translation</span>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img7.jpg" width="300">
                                        <span class="w-post-title">The standard chunk of Lorem Ipsum used since</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div> -->

                    <div class="seperator"></div>

                    <!-- <a href="#" class="widget-ad-box">
                        <img src="img/adbox300x250.png" width="300" height="250">
                    </a> -->

                </div>
            </div>
                 </div>


           
            </div>
                <div class="col-sm-12 col-md-2 col-lg-2 col-xl-2 mb-3 p-1">
                        <?php if($sub_cat_id==$data[0]['page_host']){
          if($data[0]['media_type']=='img'){ ?>
             <img id='display' src="<?php echo 'http://newssyn.com/upload/side_img/right_img/orig/'.$data[0]['right_img']; ?>" style="height: 734.5px;width:inherit;">
       <?php  } else{ ?>
                <span id='display' style="height: 734.5px;width:inherit;"><?php echo $data[0]['r_sence_code']; ?></span>
     
    <?php } }else{ ?>
                        <img id='display' src="<?php echo base_url(); ?>images/ads.gif" style="width:100%;">
                        <?php } ?>
 </div>
            </div>
        </div>
        
        
        