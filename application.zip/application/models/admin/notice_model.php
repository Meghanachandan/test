<?php
class Notice_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}
	
	public function formValidations($id = '')
	{
		/*$url = $_POST['link'];
			if (!filter_var($url, FILTER_VALIDATE_URL) == false) {
			return true; 
			} else {
			$this->form_validation->set_rules('link', 'Link', 'required');	
			?>
            <script>
			alert('Enter valid Link of News');
			</script>
            <?php
			
			return false; 
			}*/
		//$this->form_validation->set_rules('link', 'Link', 'required');
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('image', 'File', 'required');
		//$this->form_validation->set_rules('date', 'Date', 'required');
		/*$editImage = $this->getImage($id);
		if (empty($editImage)) {
			if (empty($_FILES['image']['name'])) {
				$this->form_validation->set_rules('image', 'Image', 'required');
			}
		}*/
		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}
	
	public function getNoticeRecords()
	{
		$this->db->order_by("id", "desc");
// 			$this->db->where("categorie_type", '0');
		$query = $this->db->get('notice');
		$ret = $query->result_array();
// 		echo $this->db->last_query();die;
		return $ret;
	}
	
	public function getNoticeRecords11($id)
	{
	$this->db->where('id', $id);
		$q = $this->db->get('notice');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}
	public function getRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('notice');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}
	
}
?>