<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">CHANGE PASSWORD</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">Change Password</h2>
		<div class="graph-form">
			<?php
				if(!empty($error)){ 
				?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
			} elseif(@$this->session->flashdata("flash_msg")) {?>
			<div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata("flash_msg"); ?></div>
			<?php } ?>
			<div class="form-body">
				<form action="<?php echo base_url('admin/home/changepassword'); ?>" method="post">
					<input type="hidden" value=""/>
					<div class="form-group">
						<label for="oldpass">Old Password <span class="star-color">*</span></label>
						<?php //echo $data; ?>
						<input type="password" readonly="readonly" onmouseover="mouseoverPass();" onmouseout="mouseoutPass();" class="form-control" id="oldpass" value="<?php echo $data['password']; ?>" name="oldpass">
						
						<script>
						    function mouseoverPass(obj) {
                          var obj = document.getElementById('oldpass');
                          obj.type = "text";
                        }
                        function mouseoutPass(obj) {
                          var obj = document.getElementById('oldpass');
                          obj.type = "password";
                        }
						</script>
					</div>
					<div class="form-group">
						<label for="newpass">New Password <span class="star-color">*</span></label>
						<input type="password" class="form-control" id="newpass" name="newpass">
					</div>
					<div class="form-group">
						<label for="conpass">Confirm New Password <span class="star-color">*</span></label>
						<input type="password" class="form-control" id="conpass" name="conpass">
					</div>
					<button type="submit" class="btn btn-default" name="submit" value="submit">Update</button> 
				</form> 
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>