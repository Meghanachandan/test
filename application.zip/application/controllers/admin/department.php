<?php

// error_reporting(0);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Department extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->model('admin/department_designation_model');
        $this->load->model('news_model');
    }

    public function index()
    {
        $departments = $this->department_designation_model->get_departments()->result_array();
        $data['departments'] = $departments;
        adminLoadView('departdes/department', $data);
    }
    
    function add_record(){
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('department', 'Department', 'required|trim');

            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'department' => $this->input->post('department'),
                );
                if ($this->department_designation_model->add_department($data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/department');
            }
        }else{
            $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
            redirect('admin/department');
        }
    }
        
    function edit_record(){
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('department', 'Department', 'required|trim');

            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'id' => $this->input->post('id'),
                    'department' => $this->input->post('department'),
                );
                if ($this->department_designation_model->update_department($data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/department');
            }
        }else{
            $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
            redirect('admin/department');
        }
    }
    
    public function designations()
    {
        $designations = $this->department_designation_model->get_designations()->result_array();
        $departments = $this->department_designation_model->get_departments()->result_array();
        $data['departments'] = $departments;
        $data['designations'] = $designations;
        adminLoadView('departdes/designation', $data);
    }
    
    function add_designation(){
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('department', 'Department', 'required|trim');
            $this->form_validation->set_rules('designation', 'designation', 'required|trim');

            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'department' => $this->input->post('department'),
                    'designation' => $this->input->post('designation'),
                );
                if ($this->department_designation_model->add_designation($data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/department/designations');
            }
        }else{
            $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
            redirect('admin/department/designations');
        }
    }

    function edit_designation(){
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('department', 'Department', 'required|trim');
            $this->form_validation->set_rules('designation', 'designation', 'required|trim');

            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'id' => $this->input->post('id'),
                    'department' => $this->input->post('department'),
                    'designation' => $this->input->post('designation'),
                );
                if ($this->department_designation_model->update_designation($data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/department/designations');
            }
        }else{
            $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
            redirect('admin/department/designations');
        }
    }
    
}