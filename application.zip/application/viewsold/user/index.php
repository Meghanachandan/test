<!-- <link href="<?php echo base_url(); ?>assets/css/main.css" rel="stylesheet"> -->
<!-- <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet"> -->


<style>
    #imgdiv {
        width: 160px;
        float: left;
        margin-left: 20px
    }

    #reload {
        float: right;
        margin-right: 40px
    }

    section {
        background-color: #FFF;
    }

    .omb_login .omb_authTitle {
        text-align: center;
        line-height: 300%;
    }

    .error {
        color: #84022e;
    }

   .btn-sm.btn-secondary, .abcRioButton.abcRioButtonBlue {
        min-width: 249px;
        margin: 0 auto;
    }
</style>
<section id="form">
    <!--form-->
    <div class="container">
        <div class="row">

            <div class="col-sm-12">
                <div style="width:95%;max-width: 350px;margin:20px auto;">
                    <?php if (!empty($error)) { ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo $error; ?>
                        </div>
                    <?php } ?>
                    <div style="display: none;" id="alert_error" class="alert alert-danger"></div>
                    <div style="display: none;" id="alert_success" class="alert alert-success"></div>
                    <div class="login-form social-buttons">
                        <!--login form-->
                        <h3 class="omb_authTitle mb-3">Login or <a href="<?php echo base_url('index.php/user/signup' . $page); ?>">Sign up</a></h3>
                        <?php if (!empty($page)) {
                            $page = '?page=' . $page;
                        } ?>
                        <!-- <form action="<?php echo base_url('index.php/user/login' . $page); ?>" autocomplete="off" method="post" novalidate> -->
                        <div class="form-group">
                            <input type="text" class="form-control m-0" name="loginEmail" id="loginEmail" placeholder="Email Address" value="<?php echo $username; ?>" />
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control m-0" name="loginPassword" id="loginPassword" placeholder="Password" />
                            <span toggle="#loginPassword" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                        </div>
                        <div class="row mx-0">
                            <div class="pull-left col-7 p-0">
                                <label><input type="checkbox" class="checkbox" name="loginNewl"> Sign Up for Newsletter</label>
                            </div>
                            <div class="pull-right col-5 p-0">
                                <a href="<?php echo base_url('index.php/user/forgot_password'); ?>" title="Forgot Password">Forgot Password?</a>
                            </div>
                        </div>
                        <div class="col-sm-12 px-0 mb-4 text-center ">
                            <!-- <button type="submit" title="Login" class="btn-sm btn-secondary mt-0">Login</button> -->
                            <button id="submit_button" onclick="return validateSignForm();" title="Create an Account" class="btn-sm btn-secondary">Login</button>
                            <button id="submit_button_loader" style="display: none;" title="Create an Account" class="btn-sm btn-secondary">Login <i class="fa fa-circle-notch fa-spin" style="font-size:24px"></i></button>
                        </div>

                        <div class="form-group text-center">
                            ---- OR ----
                        </div>
                        <div class="col-sm-12 px-0 mb-2 text-center">
                            <script>
                                function statusChangeCallback(response) { // Called with the results from FB.getLoginStatus().
                                    console.log('statusChangeCallback');
                                    console.log(response); // The current login status of the person.
                                    if (response.status === 'connected') { // Logged into your webpage and Facebook.
                                        testAPI();
                                    } else { // Not logged into your webpage or we are unable to tell.
                                        document.getElementById('status').innerHTML = 'Please log ' +
                                            'into this webpage.';
                                    }
                                }


                                function checkLoginState() { // Called when a person is finished with the Login Button.
                                    FB.getLoginStatus(function(response) { // See the onlogin handler
                                        statusChangeCallback(response);
                                    });
                                }


                                window.fbAsyncInit = function() {
                                    FB.init({
                                        appId: '{app-id}',
                                        cookie: true, // Enable cookies to allow the server to access the session.
                                        xfbml: true, // Parse social plugins on this webpage.
                                        version: '{api-version}' // Use this Graph API version for this call.
                                    });


                                    FB.getLoginStatus(function(response) { // Called after the JS SDK has been initialized.
                                        statusChangeCallback(response); // Returns the login status.
                                    });
                                };

                                function testAPI() { // Testing Graph API after login.  See statusChangeCallback() for when this call is made.
                                    console.log('Welcome!  Fetching your information.... ');
                                    FB.api('/me', {
                                        fields: 'first_name,last_name,email'
                                    }, function(response) {
                                        console.log(response);
                                        console.log('Successful login for: ' + response.name);
                                        document.getElementById('status').innerHTML =
                                            'Thanks for logging in, ' + response.name + '!';

                                        var dataString = {
                                            'first_name': response.first_name,
                                            'last_name': response.last_name,
                                            'email': response.email,
                                            'id': response.id,
                                            'social': 'facebook',
                                        };

                                        $.ajax({
                                            type: "POST",
                                            dataType: "json",
                                            url: "<?php echo base_url('index.php/user/social_login'); ?>",
                                            data: dataString,
                                            success: function(html) {
                                                if (html.error != '') {
                                                    $("#alert_error").html(html.error);
                                                    $("#alert_error").show();
                                                } else {
                                                    $("#alert_success").scrollTop(0);
                                                    $("#alert_success").html(html.success);
                                                    $("#alert_success").show();
                                                    setTimeout(location.href = '<?php echo base_url(); ?>', 4000);
                                                }
                                            }
                                        });
                                    });
                                }
                            </script>


                            <!-- The JS SDK Login Button -->
                            <!-- 
                        <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
                        </fb:login-button> -->

                            <div class="fb-login-button" data-size="large" onlogin="checkLoginState();" data-button-type="continue_with" data-layout="default" data-auto-logout-link="false" data-use-continue-as="false" data-width=""></div>

                            <div id="status">
                            </div>

                            <!-- Load the JS SDK asynchronously -->
                            <div id="fb-root"></div>
                            <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v8.0&appId=1004327076697945&autoLogAppEvents=1" nonce="bjtJ3jro"></script>

                            <!-- </form> -->
                        </div>
                        <!-- start google. login -->
                        <div class="col-sm-12 px-0 mb-2 text-center">

                            <!-- <meta name="google-signin-scope" content="profile email">
                            <meta name="google-signin-client_id" content="280836105830-d455tf4hhabi5ura6nni1t47uh76cs51.apps.googleusercontent.com">
                            <script src="https://apis.google.com/js/platform.js" async defer></script> -->

                            <div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark"></div>
                            <script>
                                function onSignIn(googleUser) {
                                    // Useful data for your client-side scripts:
                                    var profile = googleUser.getBasicProfile();

                                    /*
                                    console.log("ID: " + profile.getId()); // Don't send this directly to your server!
                                    console.log('Full Name: ' + profile.getName());
                                    console.log('Given Name: ' + profile.getGivenName());
                                    console.log('Family Name: ' + profile.getFamilyName());
                                    console.log("Image URL: " + profile.getImageUrl());
                                    console.log("Email: " + profile.getEmail());
                                    // The ID token you need to pass to your backend:
                                    var id_token = googleUser.getAuthResponse().id_token;
                                    console.log("ID Token: " + id_token);
                                    */

                                    var dataString = {
                                        'first_name': profile.getGivenName(),
                                        'last_name': profile.getFamilyName(),
                                        'email': profile.getEmail(),
                                        'id': profile.getId(),
                                        'social': 'google',
                                    };

                                    $.ajax({
                                        type: "POST",
                                        dataType: "json",
                                        url: "<?php echo base_url('index.php/user/social_login'); ?>",
                                        data: dataString,
                                        success: function(html) {
                                            if (html.error != '') {
                                                $("#alert_error").html(html.error);
                                                $("#alert_error").show();
                                            } else {
                                                $("#alert_success").scrollTop(0);
                                                $("#alert_success").html(html.success);
                                                $("#alert_success").show();
                                                setTimeout(location.href = '<?php echo base_url(); ?>', 4000);
                                            }
                                        }
                                    });


                                }
                            </script>

                            <!-- end google. login -->




                        </div>
                    </div>
                    <!--/login form-->
                </div>
            </div>
        </div>
    </div>
</section>
<!--/form-->
<!-- <script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script> -->
<script>
    $(document).ready(function() {
        //change CAPTCHA on each click or on refreshing page
        $("#reload").click(function() {
            $("img#img").remove();
            var id = Math.random();
            $('<img id="img" src="<?php echo base_url(); ?>images/captcha/captcha.php?id=' + id + '"/>').appendTo("#imgdiv");
            id = '';
        });
    });
    $('.toggle-password').on('click', function() {
        $(this).toggleClass('fa-eye fa-eye-slash');
        let input = $($(this).attr('toggle'));
        if (input.attr('type') == 'password') {
            input.attr('type', 'text');
        } else {
            input.attr('type', 'password');
        }
    });


    function validateSignForm() {

        var email = $('#loginEmail').val();
        var password = $('#loginPassword').val();

        $('#submit_button').hide();
        $('#submit_button_loader').show();

        $(".error").remove();
        $("#alert_error").hide();
        var error = 0;
        if (email.length < 1) {
            $('#loginEmail').after('<span class="error">This field is required</span>');
            error = 1;
        } else {
            //var regEx = /^[A-Z0-9][A-Z0-9._%+-]{0,63}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/;
            var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            var validEmail = reg.test(email);
            if (validEmail == false) {
                $('#loginEmail').after('<span class="error">Enter a valid email</span>');
                error = 1;
            }
        }

        if (password.length < 8) {
            $('#loginPassword').after('<span class="error">Password must be at least 8 characters long</span>');
            error = 1;
        }

        if (error == 1) {
            //alert("Fill All Fields");
            $('#submit_button').show();
            $('#submit_button_loader').hide();
            return false
        } else {
            //validating CAPTCHA with user input text
            //var dataString = 'captcha=' + captcha;
            var dataString = {
                'loginEmail': email,
                'loginPassword': password,
            };
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "<?php echo base_url('index.php/user/login'); ?>",
                data: dataString,
                success: function(html) {
                    if (html.error != '') {
                        $('#submit_button').show();
                        $('#submit_button_loader').hide();
                        $("#alert_error").html(html.error);
                        $("#alert_error").show();
                    } else {
                        $('#loginEmail').val('');
                        $('#loginPassword').val('');
                        $("#alert_success").scrollTop(0);
                        $("#alert_success").html(html.success);
                        $("#alert_success").show();
                        setTimeout(location.href = '<?php echo base_url(); ?>' + html.url, 4000);
                    }

                }
            });
            return true;
        }
    }

    $('.form-control').keypress(function(e) {
        if (e.which == 13) {
            validateSignForm();
        }
    });
</script>