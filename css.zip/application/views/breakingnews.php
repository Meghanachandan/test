

 <section class="" style="margin: 10px 10px;" >
        <div ></div>
        <div class="container-fluid align-right">
            <div class="row">
                <div class="mbr-white col-lg-8 col-md-7 content-container">
                </div>
                <div class="col-lg-12 col-md-12">
                    <div class="form-container">
                        <div class="media-container-column" data-form-type="formoid">
                            <!---Formbuilder Form--->
                            
                     <div class="d-flex justify-content-between align-items-center breaking-news bg-white" style="border: 1px solid #e0191b;">
                <div class="d-flex flex-row flex-grow-1 flex-fill justify-content-center bg-danger11 py-2 text-white px-1 news"><span class="d-flex align-items-center">&nbsp;Breaking News</span></div>
                <marquee class="news-scroll" behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"> 
<?php 
$this->db->select('*');
$this->db->from('latest_news');
$this->db->limit(5,0);
$this->db->order_by("id", "desc");
$break_query11 = $this->db->get();
$break_result11 = $break_query11->result_array();
foreach ($break_result11 as $key => $bvalue) {
    
    ?>
                &nbsp;&nbsp;  <i class="fas fa-circle" style="color:#535d9d;font-size:13px;"></i> &nbsp; <a href="<?php echo base_url() . cleanNewsUrl($bvalue); ?>" style="color:#e0191b;font-weight:bold;font-size:16px;"><?= $bvalue['title']; ?></a> 
<?php } ?>
                 </marquee>
            </div>
                            <!---Formbuilder Form--->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <style type="text/css">.bg-danger11 {
    background: #e0191b;

    position: relative;
}
.bg-danger11:before {
    content: '';
    position: absolute;
    top: 0; right: 0;
    border-top: 40px solid white;
    border-left: 20px solid red;
    width: 0;
}

.news {
    width: 170px
}

.news-scroll a {
    text-decoration: none
}

.dot {
    height: 6px;
    width: 6px;
    margin-left: 3px;
    margin-right: 3px;
    margin-top: 2px !important;
    background-color: rgb(207, 23, 23);
    border-radius: 50%;
    display: inline-block
}</style>