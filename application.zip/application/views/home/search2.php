<?php //echo "<pre>";print_r($filter_data);die; ?>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Ideabox main theme css file. you have to add all pages -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/search/main-style.css">

<!-- Ideabox responsive css file -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/search/responsive-style.css">



<section class="tabs4 cid-rUEF7euy93" id="tabs4-r" >
        <div class="container-fluid">
            <div class="row">


<!--Main container start -->
<style>
      @media(max-width: 600px){
          #display{
              display: none;
          }
      }
  </style> 
 <div class="col-sm-12 col-md-2 col-lg-2 col-xl-2 mb-3 p-1">
     <img id="display" src="<?php echo base_url(); ?>images/ads.gif" style="width:100%;">
 </div>
    <div class="col-sm-12 col-md-8 col-lg-8 col-xl-8 " style="float:left;padding-left:0px !important;padding-right:0px !important;">
        <div class="col-md-12">
            <div class="row bg-primary animate-in-down" >
<?php if(!empty($latest_news[0]['title']))
{ ?>
                <div  class="col-md-9" style="float:left; padding:0px;">
                    
                <?php

                if ($latest_news[0]['media_type'] == 'youtube') {
                    
                    $you_tube = str_replace('height', 'height="400px" res-height', $latest_news[0]['youtube_code']);
                    $you_tube = str_replace('width', 'width="100%" res-width', $you_tube);
                    echo $you_tube;

                } else {
                    if (trim($latest_news[0]['image']) == '') {
                        $latest_news[0]['image'] = 'no-image.png';
                    }else{
                        $latest_news[0]['image'] = 'orig/'.$latest_news[0]['image'];
                    }
                ?>
                    <img class="main-image-for-home" src="<?php echo base_url() . 'upload/news/' . $latest_news[0]['image']; ?>" alt="<?php echo $latest_news[0]['title'] ?>" style="height:400px;width:100%;">
                <?php } ?>
           
                </div>
                <div  class="col-md-3" style="float:left;">
                          <h1 class="db_storybox text-justify" style="text-transform: capitalize;font-weight: 600;color:#004d38;height: 125px;font: 20px/30px Bhaskar_Web_Head_Test_exp,Arial,Helvetica,sans-serif;">
                            <?php echo limit_text(strip_tags($latest_news[0]['title']), 100); ?>
                        </h1>
                         <div class='row'>
                            <div class="col-md-1">
                                <?php
                               
                                    if ($latest_news[0]['hide_image_on_news'] != '1') {
                                        
                                        
                                    $img= getReporterImage($latest_news[0]['reporter']); 
                                    if($img ==''){
                                        $images = 'upload/userss.png';
                                    }else{
                                        $images = 'upload/profile_image/'.getReporterImage($latest_news[0]['reporter']);
                                    }
                                    ?>
                                   <img src="<?php echo base_url().$images; ?>" atl="userImage" style="height: 30px;width: 30px;margin-bottom: 5px;border-radius: 100%;" class="img-circle">
                                   <?php }else{ ?>
                                   <img src="<?php echo base_url().'upload/userss.png'; ?>" atl="userImage" style="height: 30px;width: 30px;margin-bottom: 5px;border-radius: 100%;" class="img-circle">
                                   <?php } ?>
                            </div>
                            <div class="col-md-10">
                                <a style="font-size: 16px;" style="text-transform: capitalize">
                                <?php if ($latest_news[0]['hide_name_on_news'] != '1') { ?>
                                
                                 <?php echo getReporterName($latest_news[0]['reporter']); ?>
                                <?php } ?>
                            <?php if ($latest_news[0]['hide_email_on_news'] != '1') { ?>
                            
                                /<?php echo getReporterEmail($latest_news[0]['reporter']); ?>
                            <?php } ?>
                            <?php if ($latest_news[0]['hide_name_on_news'] == '1' && $latest_news[0]['hide_email_on_news'] == '1') { ?>
                            <a style="font-size: 16px;" style="text-transform: capitalize">
                                /Public Reporter
                            </a><?php } ?>
                            <br>
                            <a style="margin-top: 0px; font-size: 12px;margin-left: -30px;" style="text-transform: capitalize">
                                <?php echo date('D/M d, Y, h:i A', strtotime($latest_news[0]['date'])) . ' - ' . date('T'); ?> -
                                <!--<span><i class="fas fa-pencil-alt"></i></span> <?php //echo getReporterName($latest_news[0]['reporter']); ?>-->
                            </a>
                            </div>
                            </div>
                        <p class="mbr-text py-2 mbr-fonts-style display-7 text-info text-justify" style="margin-top: -12px; font-weight: bold">
                            <?php echo limit_text(strip_tags($latest_news[0]['discription']), 300) ?>
                        </p>
                        <?php
                            if(limit_text(strip_tags($latest_news[0]['discription']), 300 > 299)){
                                ?>
                                <a class="btn btn-secondary btn-sm btn-form m-0" href="<?php echo base_url() . cleanNewsUrl($latest_news[0]); ?>">More..
                    </a>
                                <?php
                            }else{
                                ?>
                                <a class="btn btn-secondary btn-sm btn-form display-4 m-0" href="<?php echo base_url() . cleanNewsUrl($latest_news[0]); ?>">More..
                    </a>
                                <?php
                            }
                            ?>
                        

                <!--        <a class="btn btn-secondary btn-sm btn-form display-4 m-0" href="<?php echo base_url() . cleanNewsUrl($latest_news[0]); ?>">-->
                <!--    More..-->
                <!--</a>-->
                </div>
            <?php } ?>
            </div>
            </div>
                <div class="col-md-12">
                   <div class="row" >
                <div  class="col-md-8" style="float:left;">
                    <div class="content-sidebar">
            <div class="sidebar_inner">

                <?php
                
                
                ?>

                    <?php if ($filter_data) { ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <br/>
                                <br/>
                                <div class="w-title">
                                    <style>
                                        @media(min-width: 1200px){
                                            #desktops{
                                                margin-left: -360px;
                                            }
                                        }
                                    </style>
                                    <?php
                                    
                                                                            //echo "<span id='desktops'>".$filter_data[0]['title']."</span>"; 
                                                                       
                                    ?>
                                   </div>
                                <div class="w-seperator"></div>
                            </div>
                            <style>
                                @media(min-width: 1200px){
                                    #desktop{
                                        margin-left: -380px;
                                    }
                                }
                            </style>
                            <?php
                                    foreach ($filter_data as $news) {
                                       // echo $side_bar_conter;
                                    ?>
                            <div class="w-boxed-post" id="desktop">
                                <ul>
                                    
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper" style="display: block;">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'http://newssyn.com/upload/adds/no-image.png';
                                                        } else {
                                                            $news['image'] = 'http://newssyn.com/upload/news/thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 100); ?></span>  
                                                           </h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                         <?php echo limit_text(strip_tags($news['discription']), 200); ?>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        
                                    
                                </ul>
                            </div><br/>
                            <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                            
                        </div>

                    <?php

                    }
                    ?>


                    

                </div>
            </div>
                </div>
                <div  class="col-md-4" style="float:left;">
                    <div class="content-sidebar">
            <div class="sidebar_inner">

                <?php
                $side_bar_conter = 0;
                if ($populer_news) {
                    // unset($populer_news[0]);

                ?>

                    <div class="widget-item">
                        <div class="w-header">
                                <div class="w-title">Top News</div>
                            <div class="w-seperator"></div>
                        </div>
                        <div class="w-boxed-post">
                            <ul>
                                <?php
                                foreach ($populer_news as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                      
                                                        if (trim($news['image']) == '') {
                                                            // no-image.png
                                                            $news['image'] = 'http://newssyn.com/upload/adds/no-image.png';
                                                        } else {
                                                            $news['image'] = 'http://newssyn.com/upload/news/thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url(<?= $news['image']; ?>);background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?> </h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php
                    }
                    ?>

                    
                    <?php
                    if ($latest_news) {
                    ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Latest News</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($latest_news as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'http://newssyn.com/upload/adds/no-image.png';
                                                        } else {
                                                            $news['image'] = 'http://newssyn.com/upload/news/thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?=  $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>

                    <?php if ($recientView) { ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Recent View</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($recientView as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'http://newssyn.com/upload/adds/no-image.png';
                                                        } else {
                                                            $news['image'] = 'http://newssyn.com/upload/news/thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>


                    <!-- <div class="widget-item">
                        <div class="w-header">
                            <div class="w-title">Carousel Posts</div>
                            <div class="w-seperator"></div>
                        </div>
                        <div class="w-carousel-post">
                            <div class="owl-carousel" id="widgetCarousel">
                                <div class="item">
                                    <a href="#">
                                        <div class="w-play-img">
                                            <img src="img/news-test-images/news-img4.jpg" width="300">
                                            <span class="w-video-icon"><i class="material-icons">&#xE038;</i></span>
                                        </div>
                                        <span class="w-post-title">It has roots in a piece of classical Latin literature from</span>

                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img5.jpg" width="300">
                                        <span class="w-post-title">Lorem Ipsum used since</span>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img6.jpg" width="300">
                                        <span class="w-post-title">English versions from the 1914 translation</span>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img7.jpg" width="300">
                                        <span class="w-post-title">The standard chunk of Lorem Ipsum used since</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div> -->

                    <div class="seperator"></div>

                    <!-- <a href="#" class="widget-ad-box">
                        <img src="img/adbox300x250.png" width="300" height="250">
                    </a> -->

                </div>
            </div>
                </div>
                </div> 
                </div>
                
    </div>

  <div class="col-sm-12 col-md-2 col-lg-2 col-xl-2 mb-3 p-1">
     <img id="display" src="<?php echo base_url(); ?>images/ads.gif" style="width:100%;margin-bottom: 100pc;">
 </div>   
</div>
</div>
</section>


<!--not equal if condition-->
<?php if ($latest_news == '') { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y" style="margin-top: -50px;">
        <div class="container-fluid">
            <div cl ass="media-container-row">
                <h1 class="classForHeadercategory">
                    Latest News
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php
                unset($latest_news[0]);
                if ($latest_news) {
                    $news = array();
                    foreach ($latest_news as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'ln';
                        $this->load->view('home/home_news_block', $news_data);
                    }
                }
                ?>
            </div>
        </div>
    </section>
<?php } ?>



<!--not equal if condition-->
<?php if ($populer_news == '') { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    papular story
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php if ($populer_news) {
                    $news = array();
                    foreach ($populer_news as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'pn';
                        $this->load->view('home/home_news_block', $news_data);
                    }
                ?>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } ?>



<?php if($adds_banner){ ?>
<section class="features17 cid-rUEHsxB8TC" id="features17-s">
    <div class="container-fluid">
        <div class="">
            <?php 
            //var_dump($adds_banner);
            foreach ($adds_banner as $adds) {
              $ads=$adds['image'];
              $url1 = current_url();
          $url = $url1;
        $parse = parse_url($url);
       $strig = $parse['host'];
       $str_arr = explode('.',$strig);
       $heading= $str_arr[1];
              
            ?>
                    <img src="http://<?php echo $heading. '.com/upload/adds/' . $ads; ?>" alt="FifthNews" style="height:400px;width:100%">
                <?php 
                 ?>
            <?php } ?>
        </div>
    </div>
</section>
<br>
<?php } ?>


<?php
$query = "SELECT child_category FROM category_map where parent_category='".$subcate[0]['id']."' LIMIT 0,3 ";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        
foreach($rows as $rowsa){
        $sco=$rowsa['child_category'];
        
        $querya = "SELECT * FROM news_categories where id='".$sco."'";
        $querya = $this->db->query($querya);
        $rowss = $querya->result_array();
        //var_dump($rowss);
if ($sco) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    
                    <?php foreach ($rowss as $news) { echo $news['title']; } ?>
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php if ($rowss) {
                    $news = array();
                    foreach ($rowss as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'pn';
                        //var_dump($news_data);
                        
                         $this->load->view('home/home_news_block', $news_data);
                    }
                ?>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } }?>

<?php if($adds_banner1){ ?>
<section class="features17 cid-rUEHsxB8TC" id="features17-s">
    <div class="container-fluid">
        <div class="">
            <?php 
            //var_dump($adds_banner);
            foreach ($adds_banner1 as $adds) {
              $ads=$adds['image'];
              $url1 = current_url();
          $url = $url1;
        $parse = parse_url($url);
       $strig = $parse['host'];
       $str_arr = explode('.',$strig);
       $heading= $str_arr[1];
              
            ?>
                    <img src="http://<?php echo $heading. '.com/upload/adds/' . $ads; ?>" alt="FifthNews" style="height:400px;width:100%">
                <?php 
                 ?>
            <?php } ?>
        </div>
    </div>
</section>
<br>
<?php } ?>


<?php
$query = "SELECT child_category FROM category_map where parent_category='".$subcate[0]['id']."' LIMIT 3,6 ";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        
foreach($rows as $rowsa){
        $sco=$rowsa['child_category'];
        
        $querya = "SELECT * FROM news_categories where id='".$sco."'";
        $querya = $this->db->query($querya);
        $rowss = $querya->result_array();
        //var_dump($rowss);
if ($sco) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    
                    <?php foreach ($rowss as $news) { echo $news['title']; } ?>
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php if ($rowss) {
                    $news = array();
                    foreach ($rowss as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'pn';
                        //var_dump($news_data);
                        
                         $this->load->view('home/home_news_block', $news_data);
                    }
                ?>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } }?>


<?php if($adds_banner2){ ?>
<section class="features17 cid-rUEHsxB8TC" id="features17-s">
    <div class="container-fluid">
        <div class="">
            <?php 
            //var_dump($adds_banner);
            foreach ($adds_banner2 as $adds) {
              $ads=$adds['image'];
              $url1 = current_url();
          $url = $url1;
        $parse = parse_url($url);
       $strig = $parse['host'];
       $str_arr = explode('.',$strig);
       $heading= $str_arr[1];
              
            ?>
                    <img src="http://<?php echo $heading. '.com/upload/adds/' . $ads; ?>" alt="FifthNews" style="height:400px;width:100%">
                <?php 
                 ?>
            <?php } ?>
        </div>
    </div>
</section>
<br>
<?php } ?>

<?php
$query = "SELECT child_category FROM category_map where parent_category='".$subcate[0]['id']."' LIMIT 6,9 ";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        
foreach($rows as $rowsa){
        $sco=$rowsa['child_category'];
        
        $querya = "SELECT * FROM news_categories where id='".$sco."'";
        $querya = $this->db->query($querya);
        $rowss = $querya->result_array();
        //var_dump($rowss);
if ($sco) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    
                    <?php foreach ($rowss as $news) { echo $news['title']; } ?>
                </h1>
            </div>
            <div class="media-container-row center slider">
                <?php if ($rowss) {
                    $news = array();
                    foreach ($rowss as $news) {
                        $news_data['news'] = $news;
                        $news_data['list'] = 'pn';
                        //var_dump($news_data);
                        
                         $this->load->view('home/home_news_block', $news_data);
                    }
                ?>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } }?>







<script>
    function gotoViewAllPage() {
        method = "post";

        var form = document.createElement("form");
        form.setAttribute("method", method);
        form.setAttribute("action", "<?php echo base_url() . 'home/news_all_view/' . $cat_id; ?>");

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "country");
        hiddenField.setAttribute("value", '<?php echo $country; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "state");
        hiddenField.setAttribute("value", '<?php echo $state; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "city");
        hiddenField.setAttribute("value", '<?php echo $city; ?>');
        form.appendChild(hiddenField);


        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "key");
        hiddenField.setAttribute("value", '<?php echo $key; ?>');
        form.appendChild(hiddenField);

        document.body.appendChild(form);
        form.submit();
    }


    $(document).ready(function() {
        var hieght = 95 * <?php echo $side_bar_conter; ?>;
        hieght = hieght + 100;
        $('.main-content-wrapper').css('min-height', hieght);
    });
    //href=""
</script>
