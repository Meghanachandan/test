<?php

echo '<pre>';
print_r($badge);die;
// for($s=0;$s<$badge; $s++){
//     var_dump($s);
    
// }
die;
?>
            <div class="card-wrapper">
    <div class="card-img" style="width: 200px;">
                <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" class="fancybox" rel="ligthbox">
                    <?php
            if (trim($news['image']) == '') {
                $news['image'] = 'no-image.png';
            } else {
                $news['image'] = 'thumb/' . $news['image'];
            }
            ?>
            <?php
                    
                    $query1 = "SELECT * FROM `news_categories` WHERE `id` = '".$news['child_categorise']."'";
                    $query1 = $this->db->query($query1);
                    $rows1 = $query1->result_array();
                    
                    if($news[child_categorise]== '0'){
                        $query = "SELECT * FROM `news_categories` WHERE `id` = '".$news['categorise']."'";
                        $query = $this->db->query($query);
                        $rows = $query->result_array();
                    ?>
                    <span class="badge badgeall <?php $badge[$key]; ?>"><?php $rows[0]['title']; ?></span>
                    <?php } ?>
                        <span class="badge badgeall <?php $badge[$key]; ?>"><?php $rows1[0]['title']; ?></span>
                    <?php  ?>
                    <img id='zoom' src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>" style="height:120px;" alt="<?php echo $news['categorise'] ?>">
                   
                </a>
            </div>
            </div>
            
            
            
    