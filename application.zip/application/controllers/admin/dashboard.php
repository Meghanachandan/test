<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/dashboard_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index()
    {
        $data['page'] = 'dash';
        $data['total_users'] = $this->dashboard_model->getTotalUsers();
        $data['total_news'] = $this->dashboard_model->getTotalNews();
        $data['total_visiter'] = $this->dashboard_model->getTotalVister();
        $data['cat_ount'] = $this->dashboard_model->getcategoryNewsCount();
        $data['pending_news'] = $this->dashboard_model->get_all_pending_news();


        adminLoadView('vwDashboard', $data);
    }


    public function social_network()
    {
        $data['getIcons'] = getMultipleRecord("social_icons");
        if ($_POST) {
            foreach ($_POST as $key => $pdata) {
                foreach ($pdata['link'] as $key => $value) {
                    $insert = array(
                        'link' => $value,
                        'status' => $pdata['checkbox'][$key],
                    );
                    addUpdateRecord('social_icons', 'id', $key, $insert);
                }
                $this->session->set_flashdata('success', 'Update record successfully.');
                redirect('admin/social_network');
            }
        }
        adminLoadView('others/social_network', $data);
    }

    public function email_subscribers()
    {
        
        $category = 0;
        if ($_GET['cat'] > 0) {
            $category = $_GET['cat'];
        }
        $arr['msg'] = '';
        
        if ($_POST['chk']) {
            
            if (!empty($_POST['chk'])) {
                
                $arr = array();
                $delete_user = '1';
                
                
              
                foreach ($_POST['chk'] as $id) {
                    
                    if ($delete_user == '1') {
                        
                                $discription=$_POST['discription'];
                                // echo "<pre>";print_r($_POST);die;
                                $image = $_POST["img"];
                                $to= $id;
                                $subject = 'testing';
                                // $MESSAGE_BODY= '<div style="padding: 24px;font-size: 18px;line-height: 37px;width:600px;">
                                //                 <div align="center" style="padding-bottom: 10px;font-size: 30px;">
                                //                 <span style="color:#B32018; font-size:25px; font-weight: bold;">
                                //                 Testing News - Newssyn</span> 
                                //                 </div>';
                                // $MESSAGE_BODY.= '<div>Hello <b>'.$id.'</b><br/>';
                                // $MESSAGE_BODY.= '<br/><center><img src="'.$image.'" alt="image" style="height: 400px;width:100%;></center>.
                                //                  <br/>Thanks! <span style="color:#B32018; font-size:20px; font-weight:
                                //                  bold;"></span> 
                                //                  <br/> <span style="color:#B32018; font-size:20px; font-weight: bold;">
                                //                  Newssyn</span></div></div>';
                                
                                                
                                $MESSAGE_BODY.= '<br/><p>'.$discription.'</p>';
                                $headers  = 'MIME-Version: 1.0' . "\r\n";
                                $headers .= 'From: NEWSSYN ' . "\r\n";
                                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    
                                if(mail($to, $subject, $MESSAGE_BODY, $headers))
                                {
                                  
                                } 
                                    $this->session->set_flashdata('success', 'Send Message.');
                                  redirect('admin/email_subscribers/');     
                            
                    }
                }
            }
        }
        
        
        
        
        $data['email_subscribers'] = getMultipleRecord("email_subscriber");
        // if ($_POST) {
        //     $postData   = $_POST;
        //     if ($postData['status']) {
        //         $inset['status']     = $postData['status'];
        //     } else {
        //         $inset['status']     = 0;
        //     }
        //     $inset['id'] = $postData['id'];
        //     $update = addUpdateRecord('email_subscriber', 'id', $postData['id'], $inset);
        //     if ($update) {
        //         echo $inset['id'];
        //     } else {
        //         echo 'error';
        //     }
        //     exit;
        // }
        adminLoadView('others/email_subscribers', $data);
    }
    
    public function delete($id = null)
    {

        if (empty($id)) {
            redirect('admin/news');
        }

        $deleteData = $this->dashboard_model->getRecordById($id);
        $delete = deleteRecordById('email_subscriber', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'News deleted successfully.');
            redirect('admin/email_subscribers');
        }
    }
    
    
    
    
    
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
