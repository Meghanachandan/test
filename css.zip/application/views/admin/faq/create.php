<?php
if (!empty($postData)) {
    $name = $postData['title'];
    $discription = $postData['discription'];
    $link = $postData['link'];
    $status = $postData['status'];
    $image = $postData['image'];
    $faq_type = $postData['faq_type'];
    $order = $postData['order'];
}
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/faq'); ?>">FAQ</a></li>
            <li class="active">ADD FAQ</li>
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">ADD New FAQ</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <form action="<?php echo base_url('admin/faq/faq_add'); ?>" enctype="multipart/form-data" method="post">
                    <input type="hidden" value=""/>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Question<span class="star-color">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>" required>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-8">
                                <label for="exampleInputPassword1">Answer</label> 
                                <textarea name="discription" rows="10" cols="80" id="discription"  name="discription" required><?php echo $discription; ?></textarea>
                            </div>
                        </div>
                    </div> 
                    <!--     
                    <div class="form-group">
                        <label for="exampleInputPassword1">Link<span class="star-color">*</span></label> 
                        <input type="text" class="form-control" id="link"  name="link"  value="<?php echo $link; ?>" >
                    </div>
                
                    <div class="form-group">
                        <label>Add Image <span class="star-color">*</span></label>
                        <input type="file" id="image" name="image" value="<?php echo $image; ?>" required><small  class="msg-upload">Image Dimension must be Minimum 635px*400px</small>
                    </div> 

                    <div class="form-group">
                        <label>Categorie Type</label>
                        <select class="form-control" id="categorie_type"  name="categorie_type">
                            <option value="0">Main categorise</option>
                            <option value="1">Sub categorise</option>
                        </select>
                    </div>  -->
                    

                    

                    <div class="form-group">
                        <label for="radio" class="col-sm-2 control-label">Status</label>
                        <div class="radio block"><label>
                                <input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked"  />Active</label></div>
                        <div class="radio block">
                            <label><input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive</label></div>
                    </div>

                    <div class="form-group">
                        <label for="radio" class="control-label">Order</label>
                        <input type="text" class="form-control" id="order" name="order" value="<?php echo $order; ?>" required>
                    </div>
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Submit</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script type="text/javascript" > 
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
    
   
</script>