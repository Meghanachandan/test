<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">ADDS SIDE</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h3 class="inner-tittle two">List ADDS SIDE</h3>
			<?php
				if($this->session->flashdata('success')){ 
				?><div class="alert alert-success message" style="display: block;"><?php echo $this->session->flashdata('success'); ?></div><?php
			} ?>

			<?php
			$category_array = array();
			if($adds_categories){
				foreach($adds_categories as $cat){
					//pr($cat);
					$category_array[$cat['id']] = $cat['title'];  
				}
			}
			?>
		<div class="graph">
			<div class="tables">
				<table class="display responsive" id="example-table">
					<thead> 
						<tr> 
							<th>Id</th> 
							<th width="200" >Category/Page</th>
							<th>Link</th> 
							<th>Left Image</th>
							<th>Left Description</th> 
							<th>Right Image</th> 
							<th>Right Description</th> 
							<th>Valid Date</th>  
							<th>create Date</th>  
							<th>Status</th>  
							<th>Action</th>  
						</tr> 
					</thead>
					<?php
					$i=0;
					foreach ($side_img as $key => $blog) {
						
						$status = (!empty($blog['status']) && $blog['status'] == '1') ? 'Active' : 'Deactive';
						$i++; ?>
						<tr> 
							<th><?php echo $i; ?></th> 
							<th><?php if($blog['page_host'] == "newssyn.com") { echo 'Home <br>'; }
							else if($blog['page_host'] == "view_news") { echo 'View News <br>'; }
                            $this->db->select('*');
$this->db->from('news_categories');
$this->db->where('id',$blog['category_id']);
$query = $this->db->get();
$result11 = $query->result_array();  
foreach($result11 as $result){
    echo $result[title];
}
$this->db->select('*');
$this->db->from('news_categories');
$this->db->where('id',$blog['sub_category_id']);
$query = $this->db->get();
$result11 = $query->result_array();  
foreach($result11 as $result){
    echo '/'.$result[title];
}
                            ?></th>
                            <th><?php echo $blog['link']; ?></th>
							<th><?php 
                            if($blog['media_type']=='img'){
                            ?>
                                <img src="<?php echo base_url().'upload/side_img/left_img/orig/'.$blog['left_img']; ?>" style="height: auto; width: 100px">
                            <?php }else{ ?>
                                    <?php echo $blog['l_sence_code']; ?> 
                            <?php } ?></th>
                            <th><?php echo $blog['l_discription']; ?></th> 
							<th><?php 
                            if($blog['media_type']=='img'){
                            ?>
                            <img src="<?php echo base_url().'upload/side_img/right_img/orig/'.$blog['right_img']; ?>" style="height: auto; width: 100px">
                            <?php }else{ ?>
                                <?php echo $blog['r_sence_code']; ?> 
                            <?php } ?></th>
                            <th><?php echo $blog['r_discription']; ?></th>
                            <th><?php echo $blog['valid_date']; ?></th>
                            <th><?php echo $blog['created_date']; ?></th>
                            <th><?php if($blog['status'] =='1'){ echo 'Active';}else{ echo "Inactive"; } ?></th> 
							
							<th>
							<a href='<?php echo base_url('admin/side_img/edit/' . $blog['id']); ?>'><i class="fa fa-edit"></i></a> &nbsp; 
                                <a onclick='return confirm("Are you sure? you want to delete this Manage news categories!")' href='<?php echo base_url('admin/side_img/delete/' . $blog['id']); ?>'><i class="fa fa-trash-o"></i></a>
							</th>
						</tr>
					<?php }?>
				</table>
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>
<script> 
$(document).ready(function() {
	$('#example-table').DataTable( {
		"pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ]

	});
});
</script>