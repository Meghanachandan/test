<style type="text/css">
    @media (max-width: 300px) {
  .carosel-item {
    width: 100%;
  }
}
@media (min-width: 300px) {
  .carosel-item {
    width: 50%;
  }
}
@media (min-width: 500px) {
  .carosel-item {
    width: 33.333%;
  }
}
@media (min-width: 768px) {
  .carosel-item {
    width: 25%;
  }
}
.carosel {
  position: relative;

}
.carosel-inner {
  white-space: nowrap;
  
  font-size: 0;
}
.carosel-item {
  display: inline-block;
}
.carosel-control {
  position: absolute;
  top: 50%;
  padding: 8px;
  box-shadow: 0 0 10px 0px rgba(0, 0, 0, 0.5);
  transform: translateY(-50%);
  border-radius: 50%;
  color: rgba(0, 0, 0, 0.5);
  font-size: 5px;
  display: inline-block;
}
.carosel-control-left {
  left: 15px;
}
.carosel-control-right {
  right: 15px;
}
.carosel-control:active,
.carosel-control:hover {
  text-decoration: none;
  color: rgba(0, 0, 0, 0.8);
}

@media(min-width: 1200px){
.navbar-expand-lg .navbar-collapse
{
    overflow: hidden;
}
}
.menu_title
{

  
  font-size: calc(0.6vw + 0.6em);
  direction: ltr;

  margin:auto;
  text-align:justify;
  word-break: break-word;
  white-space: pre-line;
  overflow-wrap: break-word;
  -ms-word-break: break-word;
  word-break: break-word;
  word-break: break-word;
  -ms-hyphens: auto;
  -moz-hyphens: auto;
  -webkit-hyphens: auto;
  hyphens: auto;
}

</style>












<style type="text/css">
@media(min-width: 1200px){
    #dsjfsdjfljf {
    position: static;
    z-index:1;
}
}

.megamenu {
    position: absolute;
    width: 100%;
    left: 0;
    right: 0;
    padding: 15px;
}
.dropdown-menu
{
    z-index: 99999 !important;
}
.dropdown a
{
    font-size: 14px;
}
.dropdown-toggle::after
{
        margin-bottom: -2px !important;
}
.dropdown:hover .dropdown-menu {display: block;}
</style>
<style>
    <style type="text/css">
    #col a:nth-child(2) {
    border-right: 0px solid white;
    
}
</style>
<style>
    @media(max-width: 600px){
        #carosel1{
            
            padding: 4px;
            
        }
    }
    @media(min-width: 1200px){
        #ids{
            position:absolute;margin-left:0px;margin-top:1px;color:#fff;font-weight: bold; background:#e6102d; height:35.5px;   padding:6px 7px 4px 4px;
        }
        #idss{
            position:absolute;margin-left:76px;margin-top:1px;color:#fff;font-weight: bold; background:#e6102d; height:35.5px;   padding:6px 7px 4px 4px;
        }
    }
    @media(max-width: 600px){
        #ids{
            position: inherit;margin-left: 6px;margin-top: 1px;color:#fff;font-weight: bold;background:#e6102d;height: 20.5px;padding:6px 7px 4px 4px;
        }
        #idss{
            display: none;
        }
    }
</style>

<style>
    .sidenav {
  height: 89%;
  width: 0;
  margin-top: 80px;
  position: fixed;
  z-index: 99999;
  top: 0;
  left: 0;
  background-color: #2f3a4a;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 0px 0px 0px 32px;
  text-decoration: none;
  font-size: 16px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.arrow {
  border: solid #9d9292;
  border-width: 0 3px 3px 0;
  display: inline-block;
  padding: 3px;
}
.down {
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
}
</style>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" ><b style="font-size: 50px;">&times;</b></a>
  <?php if (check_user_authentication() == true) { ?>
 
                                
                                    <?php
                                     $user_id = $this->session->userdata('user_id');
                                    
                                    $query = "SELECT profile_image FROM users WHERE id='".$user_id."'";
                                        $query = $this->db->query($query);
                                        $rowsasdasd = $query->result_array();
                                        $img= $rowsasdasd[0]['profile_image'];
                                        //echo $img;
                                        if($img == ""){
                                            $imgs='upload/userss.png';
                                        }else{
                                            $imgs='upload/profile_image/'.$img;
                                        }
                                       
                                    ?>
                                    <center><img src="<?php echo base_url().$imgs; ?>" alt="userImage" style="height: 60px;width: 60px;border-radius: 100%;" class="img-circle"></center>
                                    <!--<img src"<?php echo base_url().$imgs; ?>" alt="users" style="height: 100px;width: auto;">-->
                            
  <?php } ?>
  <?php if (check_user_authentication() == true) { ?>
  <a href="<?php //echo base_url('user/profile_view'); ?>" style="margin-top: 5px;text-align: center;">
                                <span style="font-size"> Hello
                                    <?php
                                    $fName = $this->session->userdata('user_name');
                                    $lName = $this->session->userdata('last_name');
                                    echo ucfirst($fName) . ' ' . ucfirst($lName);
                                    ?>
                                    </span>
                            </a>
                            <hr style="border: 1px solid;color: antiquewhite;">
  <?php }else{ ?>
  <center><img src="<?php echo base_url().'upload/userss.png'; ?>" alt="userImage" style="height: 60px;width: 60px;border-radius: 100%;" class="img-circle"></center>
  <a href="#" style="margin-left: 28%;margin-top: 5px;">
        <span style="font-size">
            Hello
        </span></a>
        <hr style="border: 1px solid;color: antiquewhite;">
  <?php } ?>
  <a href="<?= base_url(); ?>"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;Home</a><hr style="border: 1px solid;color: antiquewhite;">
  
  <?php if (check_user_authentication() == true) { ?>
  <a href="<?php echo base_url('user/profile_view'); ?>">
                                <span style="font-size"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp; Dashboard
                                    </span>
                            </a>
                            <hr style="border: 1px solid;color: antiquewhite;">
    <a class="" href="<?php echo base_url('news/addNews'); ?>">
                          <i class="fa fa-upload" aria-hidden="true"></i>&nbsp;Add News
                        </a><hr style="border: 1px solid;color: antiquewhite;">
                        <?php //if (my_news_count($this->session->userdata('user_id')) > 0) { ?>
                        <a class="" href="<?php echo base_url('news/my_news'); ?>">
                                    <i class="fa fa-globe" aria-hidden="true"></i>&nbsp;My News (<?php echo my_news_count($this->session->userdata('user_id')); ?>)
                                </a><hr style="border: 1px solid;color: antiquewhite;">
                                
                                <a class="" href="<?php echo base_url('notice'); ?>">
                                    <i class="fa fa-globe" aria-hidden="true"></i>&nbsp;Notice 
                                </a><hr style="border: 1px solid;color: antiquewhite;">
                        <?php //}
                        }else{ ?>
    <a href="<?php echo base_url('user/login?page=' . base64_encode('profile_view')); ?>"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;Dashboard</a><hr style="border: 1px solid;color: antiquewhite;">
  <a href="<?php echo base_url('user/login?page=' . base64_encode('addNews')); ?>"><i class="fa fa-upload" aria-hidden="true"></i>&nbsp;Upload News</a><hr style="border: 1px solid;color: antiquewhite;">
  <a href="<?php echo base_url('user/login?page=' . base64_encode('my_news')); ?>"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;My News</a><hr style="border: 1px solid;color: antiquewhite;">
  <?php } ?>
  <a href="#" data-toggle="collapse" data-target="#service" class="collapsed" aria-expanded="false"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;News Category&nbsp;&nbsp;&nbsp;<i style="font-size:16px" class="arrow down"></i></a><hr style="border: 1px solid;color: antiquewhite;">
  <ul  class="sub-menu collapse" id="service" aria-expanded="false" style="list-style-type: none;">
      <?php 
      $query = "SELECT id,title,slug,categorie_type,categorie_colour FROM `news_categories` WHERE `status` = '1' AND categorie_type='0' AND `order` > 0 ORDER BY `order` ASC";
        $query = $this->db->query($query);
        $rowsasdasd = $query->result_array();
        foreach ($rowsasdasd as $category) {
      ?>
      <li><a href="<?php echo 'http://'.$category['slug'].'.newssyn.com/'; ?> "><i style="font-size:16px" class="fa">&#xf105;</i>&nbsp;&nbsp;<?php echo $category['title'] ?></a></li><hr style="border: 1px solid;color: antiquewhite;">
      <?php } ?>
  </ul>
  
  <a href="<?php echo base_url(); ?>terms"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;News Terms & Condition</a><hr style="border: 1px solid;color: antiquewhite;">
  <a href="<?php echo base_url(); ?>home/page/news-copyright-policy"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;News Copyright Policy</a><hr style="border: 1px solid;color: antiquewhite;">
  <a href="<?php echo base_url(); ?>home/page/privacy-policy"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;Privacy Policy</a><hr style="border: 1px solid;color: antiquewhite;">
  <a href="<?php echo base_url(); ?>home/page/cookie-policy"><i class="fa fa-globe" aria-hidden="true"></i>&nbsp;Cookies Policy</a><hr style="border: 1px solid;color: antiquewhite;">
  
  
  <?php if (check_user_authentication() == true) { ?>
  <a onclick="signOut();" class="btn btn-danger">Logout</a>
  <?php } else { ?>
  <a href="<?php echo base_url(); ?>user/login/"><i class="fa fa-sign-in" aria-hidden="true"></i>&nbsp;Login</a><hr style="border: 1px solid;color: antiquewhite;">
  <a href="<?php echo base_url(); ?>user/signup/"><i class="fa fa-user" aria-hidden="true"></i>&nbsp;Signup</a>
  <a href="#"><br><br></a>
  <?php } ?>
  
</div>
<style>
     @media(max-width: 600px){
         .carosel-inner{
             margin-left: 216px;
    margin-top: -28px;
         }
         #navbar{
             display: block;
         }
         #mob-show{
             display: block;
         }
         #idddsss{
             font-size:20px;cursor:pointer;margin-left: 50px;background-color: #2f3a4a;color: white;padding: 5px;
         }
         #sssss1111{
            max-width: 100%; 
            margin-left: -38px;
         }
         #col{
             display: none;
         }
         #font{
             font-size: 11px;
         }
     }
     
     @media(min-width: 1200px){
         .carosel-inner{
             margin-left:275px;margin-top: -42px;
         }
         #idddsss{
             font-size:30px;cursor:pointer;margin-left: 50px;background-color: #2f3a4a;color: white;padding: 11px;
         }
         #sssss1111{
            max-width: 95%; 
         }
     }
 </style>

<div class="carosel" id="carosel1">
    
  <a class="carosel-control carosel-control-left glyphicon glyphicon-chevron-left" href="#"><i class="fa fa-arrow-left" aria-hidden="true" style="font-size:13px;"></i></a>
  <span id="idddsss" onclick="openNav()">&#9776;</span>
  <a href="<?= base_url(); ?>" style="border-right: 2px solid white;" id='ids'><i class="fa fa-home" aria-hidden="true"></i>&nbsp;Home</a>
  <a href="<?= base_url(); ?>/home/Allcategories" style="border-right: 2px solid white;" id='idss'>All Category</a>
  <div class="carosel-inner" style="">

  <?php 
  $allcategories = get_blog_categories();
//   echo $this->db->last_query();
//   die;
//   echo "<pre>";
//   echo "<br>";
//   var_dump($allcategories);
//   print_r($allcategories);die();
  ?>
<div class="container-fluid">
 <div class="row">
  <div class="col-12" id='sssss1111' style="padding: 0px 0px !important;">
   <nav class="navbar navbar-expand-lg navbar-light bg-light rounded" style="padding: 0px 0px !important;">


    <div class="collapse navbar-collapse" id="navbar" >
     <ul class="navbar-nav mr-auto" id=mob-show>
      <li>Home</li>
      <?php
    //   echo "<pre>";
    //   print_r($allcategories);die;
   foreach ($allcategories as $category) {
       echo $category['slug'];
       ?>
      <li class="nav-item dropdown megamenu-li carosel-item" id='dsjfsdjfljf' style="border-right:2px solid #ccc;">
       <a id='fonts' class="nav-link dropdown-toggle" href="http://<?= $category['slug']; ?>.newssyn.com" id="dropdown01"  aria-haspopup="true" aria-expanded="false"><?= $category['title']; ?></a>|
       <div class="dropdown-menu megamenu" aria-labelledby="dropdown01" style="background-color: #2f3a4a;">
        <div class="row">
         <div class="col-sm-12 col-lg-12" >
       <div style=""><h1>
           <a style="color: #fff;" href="http://<?= $category['slug']; ?>.newssyn.com" style="color:#000;font-size:16px;"><b><?= $category['title']; ?> News</b></a></h1>
           
           </div>
       <div class="text-right" id="col" style="margin-top: -25px;" >
           
          <?php 

       $id =  $category['id']; 
                   $this->db->select('*');
                   $this->db->from('category_map');
                   $this->db->where('parent_category',$id);
                   $query = $this->db->get();
                   $result = $query->result_array();
                   // echo $this->db->last_query();
                   ?>
   
                   <?php
                   foreach ($result as $key => $value) {
                  
$this->db->select('*');
                   $this->db->from('news_categories');
                   $this->db->where('id',$value['child_category']);
                   $query1 = $this->db->get();
                   // echo $this->db->last_query();
                   $result1 = $query1->result_array();
                   // print_r($result1);


          ?>
          
          <a class="" href="http://<?= $category['slug']; ?>.newssyn.com/home/search/<?= $result1[0]['id']; ?>" style="color: #fff;border-right: 0px solid white;">&nbsp;&nbsp;&nbsp;&nbsp;<?= $result1[0]['title']; ?></a>
        <?php } ?>
        
          
        </div>
        <hr class="" style="border: 1px solid;border-block-color: inherit;color: #fff;">
         </div>
         
         <?php 
$mm_url="http://".$category['slug'].".newssyn.com/";
$this->db->select('*');
                   $this->db->from('latest_news');
                   $this->db->where('categorise',$category['id']);
                   $this->db->order_by("id", "desc");
                     $this->db->limit(4,0);
                   $query = $this->db->get();
                   $result = $query->result_array();
                   foreach ($result as $key => $value) {
                       
                       if(trim($value['image']) == ""){
                           $img='http://newssyn.com/upload/news/no-image.png';
                       }else{
                           $img='http://newssyn.com/upload/news/thumb/'.$value['image'];
                       }
                  
         ?>
          <div class="col-sm-12 col-lg-3 mbr-text mbr-fonts-style display-7 T2">
   <a href="<?php echo $mm_url . cleanNewsUrl($value); ?>" id="detail_link_pn_127" style="color:#000;font-size:10px;"> 
          <img src="<?= $img; ?>" alt="..." style="width: 100%;border:1px solid #ccc;padding:3px;height: 200px;">
               <div style="padding:5px;">  <p class="menu_title" style="color: #fff;"><?= $value['title']; ?></p></div>
             </a>
         </div>
       <?php } ?>
       
        </div>
       </div>
      </li>
 <?php } ?>
     <!--  <li class="nav-item dropdown megamenu-li">
       <a class="nav-link dropdown-toggle" href="" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mega Menu 2</a>
       <div class="dropdown-menu megamenu" aria-labelledby="dropdown02">
        <div class="row">
         <div class="col-sm-6 col-lg-4">
          <h5>Image Slider</h5>
          <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
           <div class="carousel-inner">
            <div class="carousel-item active">
             <img class="d-block w-100" src="https://source.unsplash.com/250x150/?sig=1" alt="...">
            </div>
            <div class="carousel-item">
             <img class="d-block w-100" src="https://source.unsplash.com/250x150/?sig=2" alt="...">
            </div>
            <div class="carousel-item">
             <img class="d-block w-100" src="https://source.unsplash.com/250x150/?sig=3" alt="...">
            </div>
           </div>
          </div>
         </div>
         <div class="col-sm-6 col-lg-3">
          <h5>Links</h5>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
         </div>
         <div class="col-sm-6 col-lg-5">
          <h5>Paragraph</h5>
          <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Veniam impedit itaque minus distinctio possimus reiciendis et repellat. Voluptate, temporibus veniam et praesentium alias, maxime repudiandae aliquid, natus omnis animi iste!</p>
         </div>
        </div>
       </div>
      </li> -->
     </ul>
    </div>
   </nav>
  </div>
 </div>
</div>

  </div>
  <style>
      @media(max-width: 600px){
          #fsdfl{
              z-index: 999999;
          }
      }
  </style>
  <a class="carosel-control carosel-control-right glyphicon glyphicon-chevron-right" id='fsdfl' href="#"><i class="fa fa-arrow-right" aria-hidden="true" style="font-size:13px;"></i></a>
</div>


<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<script type="text/javascript">
    $('.carosel-control-right').click(function() {
  $(this).blur();
  $(this).parent().find('.carosel-item').first().insertAfter($(this).parent().find('.carosel-item').last());
});
$('.carosel-control-left').click(function() {
  $(this).blur();
  $(this).parent().find('.carosel-item').last().insertBefore($(this).parent().find('.carosel-item').first());
});
</script>

<script type="text/javascript">
    $(document).ready(function() {
    $(".megamenu").on("click", function(e) {
        e.stopPropagation();
    });
});

</script>
<style type="text/css">
hr.style-three {
border: 0;
height: 1px;
background: #333;
background-image: -webkit-linear-gradient(left, #ccc, #333, #ccc);
background-image: -moz-linear-gradient(left, #ccc, #333, #ccc);
background-image: -ms-linear-gradient(left, #ccc, #333, #ccc);
background-image: -o-linear-gradient(left, #ccc, #333, #ccc);
}
</style>

<!-- <script>
$(document).ready(function(){
    $(".dropdown").hover(function(){
        var dropdownMenu = $(this).children(".dropdown-menu");
        if(dropdownMenu.is(":visible")){
            dropdownMenu.parent().toggleClass("open");
        }
    });
});     
</script> -->