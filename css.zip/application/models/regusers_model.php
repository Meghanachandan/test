<?php
class regusers_model extends CI_Model {
 
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct()
    {
        $this->load->database();
    }

    /**
    * Get users by his is
    * @param int $users_id 
    * @return array
    */
    public function get_users_by_id($id)
    {
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('id', $id);
		$query = $this->db->get();
		return $query->result_array(); 
    }

    public function get_parent_users_by_id($id)
    {
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('parent_id', $id);
		$query = $this->db->get();
		return $query->result_array(); 
    }
    
    /**
    * Fetch users data from the database
    * possibility to mix search, filter and order
    * @param int $manufacuture_id 
    * @param string $search_string 
    * @param strong $order
    * @param string $order_type 
    * @param int $limit_start
    * @param int $limit_end
    * @return array
    */
    public function get_users($education_id=null, $search_string=null, $order=null, $order_type='Asc', $limit_start, $limit_end)
    {
		$this->db->select('users.id');
		$this->db->select('users.first_name');
		$this->db->select('users.last_name');
		$this->db->select('users.email_addres');
		$this->db->select('users.address');
		$this->db->select('users.city');
		$this->db->select('users.state');
		$this->db->select('users.country');
		$this->db->select('users.education');
		$this->db->select('educations.name as education_name');
		$this->db->from('users');
		
        $this->db->where('parent_id', '0');
        
        if($education_id != null && $education_id != 0){
			$this->db->where('education', $education_id);
		}
		if($search_string){
			$this->db->like('email_addres', $search_string);
		}

		$this->db->join('educations', 'users.education = educations.id', 'left');

		$this->db->group_by('users.id');

		if($order){
			$this->db->order_by($order, $order_type);
		}else{
		    $this->db->order_by('id', $order_type);
		}


		//$this->db->limit($limit_start, $limit_end);
		//$this->db->limit('4', '4');


		$query = $this->db->get();
		
		return $query->result_array(); 	
    }

    /**
    * Count the number of rows
    * @param int $manufacture_id
    * @param int $search_string
    * @param int $order
    * @return int
    */
    function count_users($education_id=null, $search_string=null, $order=null)
    {
		$this->db->select('*');
		$this->db->from('users');
		if($education_id != null && $education_id != 0){
			$this->db->where('education', $education_id);
		}
		if($search_string){
			$this->db->like('first_name', $search_string);
		}
        if($search_string){
			$this->db->like('last_name', $search_string);
		}
		if($order){
			$this->db->order_by($order, 'Asc');
		}else{
		    $this->db->order_by('id', 'Asc');
		}
		$query = $this->db->get();
		return $query->num_rows();        
    }

    /**
    * Store the new item into the database
    * @param array $data - associative array with data to store
    * @return boolean 
    */
    function store_users($data)
    {
		$insert = $this->db->insert('users', $data);
	    return $insert;
	}

    /**
    * Update users
    * @param array $data - associative array with data to store
    * @return boolean
    */
    function update_users($id, $data)
    {
		$this->db->where('id', $id);
		$this->db->update('users', $data);
		$report = array();
		
        $report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		
        if($report !== 0){
			return true;
		}else{
			return false;
		}
	}
	
	function insert_users($data)
    {
		$this->db->insert('users', $data);
		$report = array();
		
        $report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		
        if($report !== 0){
			return true;
		}else{
			return false;
		}
	}

    /**
    * Delete users
    * @param int $id - users id
    * @return boolean
    */
	function delete_users($id){
		$this->db->where('id', $id);
		$this->db->delete('users'); 
	}
 
}
?>