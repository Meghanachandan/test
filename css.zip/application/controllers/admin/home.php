<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
    }

    public function index() {
         if ($this->session->userdata('is_admin_login')) {
            redirect('admin/dashboard');
        } else {
        $this->load->view('admin/vwLogin');
        }
    }

     public function do_login() {

        if ($this->session->userdata('is_admin_login')) {
            redirect('admin/home/dashboard');
        } else {
            if (!empty($_POST)) {

                $user       = $_POST['username'];
                $password   = $_POST['password'];

                //print_r($_POST);
                //exit;
                $this->form_validation->set_rules('username', 'Username', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required');

                if ($this->form_validation->run() == FALSE) {

                    if(validation_errors()) {
                        if(validation_errors()){
                            $err['error'] = validation_errors();
                        }
                    }

                } else {
                    $salt = '5&JDDlwz%Rwh!t2Yg-Igae@QxPzFTSId';
                    
                    $enc_pass  = md5($salt.$password);
                    // echo $enc_pass;
                    // die;
                    $sql = "SELECT * FROM admin_users WHERE username = '$user' AND password ='".$password."'";
                    $val = $this->db->query($sql,array($user ,$enc_pass ));
                    //print_r($val);exit;
                    if ($val->num_rows) {
                        foreach ($val->result_array() as $recs => $res) {
                            $this->session->set_userdata(array(
                                'id' => $res['id'],
                                'username' => $res['username'],
                                'email' => $res['email'],                            
                                'is_admin_login' => true,
                                'user_type' => $res['user_type']
                                    )
                            );
                            
                        }
                        redirect('/admin/dashboard');
                    } else {
                        $err['error']   = '<strong>Access Denied</strong> Invalid Username/Password';
                    }
                }

            }
              $this->load->view('admin/vwLogin', $err);
        }
    }
    
    
    function changepassword(){
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home/do_login');
        } else {
            if (!empty($_POST)) {

                $user       = $_POST['username'];
                $password   = $_POST['password'];

                // print_r($_POST);
                //exit;
                $this->form_validation->set_rules('oldpass', 'Old Password', 'required');
                $this->form_validation->set_rules('newpass', 'New Password', 'required');
                $this->form_validation->set_rules('conpass', 'Confirm the Password', 'required|matches[newpass]');

                if ($this->form_validation->run() == FALSE) {

                    if(validation_errors()) {
                        if(validation_errors()){
                            $err['error'] = validation_errors();
                        }
                    }

                } else {
                    $salt = '5&JDDlwz%Rwh!t2Yg-Igae@QxPzFTSId';
                    
                    $userid = $this->session->userdata("id");
                    
                    $oldpass = $this->input->post("oldpass");
                    $enc_oldpass  = md5($salt.$oldpass);
                    
                    $newpass = $this->input->post("newpass");
                    $enc_newpass  = md5($salt.$newpass);
                    
                    $sql = "SELECT * FROM admin_users WHERE id = '$userid' AND password ='".$oldpass."'";
                    $val = $this->db->query($sql,array($userid ,$enc_oldpass ));
                    if ($val->num_rows) {
                        $rs = $val->row();
                        $userid = $rs->id;
                        $sql2 = "UPDATE admin_users set password ='".$newpass."' WHERE id = '$userid' AND password ='".$oldpass."'";
                        $val2 = $this->db->query($sql2,array($enc_newpass, $userid ,$enc_oldpass ));
                        $this->session->set_flashdata("flash_msg","Password Updated Successfully");
                        redirect('admin/home/changepassword');
                    } else {
                        
                        $err['error']   = '<strong>Failed</strong> Incorrect Password'; 
                        adminLoadView('admin_password/vwChangepassword',$err);
                    }
                }

            }
            $userid = $this->session->userdata("id");
                        
                        $this->db->where('id', $userid);
                		$q = $this->db->get('admin_users');
                		//if id is unique we want just one row to be returned
                		$err['data'] = array_shift($q->result_array());
              
            
            adminLoadView('admin_password/vwChangepassword', $err);
            
        }
        
    }

        
    public function logout() {
        $this->session->unset_userdata('id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('user_type');
        $this->session->unset_userdata('is_admin_login');   
        $this->session->sess_destroy();
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        redirect('admin/home/', 'refresh');
    }

    

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */