<?php
if (!empty($postData)) {
	$name 				= $postData['title'];
	$discription 		= $postData['discription'];
	$link 				= $postData['link'];
	$status 			= $postData['status'];
	$image 				= $postData['image'];
	$media_type 		= $postData['media_type'];
	$youtube_code       = $postData['youtube_code'];
	$short_discription 	= $postData['short_discription'];
	$countryname 		= $postData['country'];
	$state 				= $postData['state'];
	$city 				= $postData['city'];
	$reporter 			= $postData['reporter'];
	$categorise 		= $postData['categorise'];
		$child_categorise 		= $postData['child_categorise'];
	$spceial_block 		= $postData['spceial_block'];
	$image_capsion 		= $postData['image_capsion'];
	$highlights_array 	= $postData['highlights'];
	$hide_name_on_news 	= $postData['hide_name_on_news'];
	$hide_email_on_news = $postData['hide_email_on_news'];
	$hide_image_on_news = $postData['hide_image_on_news'];
	$news_audio = $postData['news_audio'];
	$news_video = $postData['news_video'];
	
}
?>
<link href="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<div class="outter-wp">
	<script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<?php if ($user_id > 0) { ?>
				<li><a href="<?php echo base_url('admin/users'); ?>">USERS</a></li>
				<li><a href="<?php echo base_url('admin/users/my_news/' . $user_id); ?>">MY NEWS</a></li>
			<?php } else { ?>
				<li><a href="<?php echo base_url('admin/news'); ?>">NEWS</a></li>
			<?php } ?>
			<li class="active">Edit News</li>
		</ol>
	</div>
	<div class="graph-visual tables-main">
		<h2 class="inner-tittle">Edit News</h2>
		<div class="graph-form">
			<?php
			if (!empty($error)) {
			?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php
																										} ?>
			<div class="form-body">
				<?php
				$editId = "";
				if (!empty($postData['id'])) {
					$editId = $postData['id'];
				} ?>
				<form action="<?php echo base_url('admin/news/edit/' . $editId); ?>" method="post" enctype="multipart/form-data">
					<input type="hidden" value="" />
					<div class="form-group">
						<label for="exampleInputEmail1">News Headline <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>">
					</div>
					<!--<div class="form-group">-->
					<!--	<div class="row">-->
					<!--		<div class="col-lg-8">-->
					<!--			<label for="exampleInputPassword1">Short Description <span class="star-color"></span></label>-->
					<!--			<textarea name="short_discription" style="width: 100%;height: 70px" id="short_discription"><?php echo $short_discription; ?></textarea>-->
					<!--		</div>-->
					<!--	</div>-->
					<!--</div>-->
					<div class="form-group">
						<div class="row">
							<div class="col-lg-12">
								<label for="exampleInputPassword1">Description <span class="star-color">*</span></label>
								<textarea name="discription" rows="3" cols="90" id="discription" name="discription"><?php echo $discription; ?></textarea>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-lg-12">
								<label>News Highlights</label>
								<div id="add_highlights">
									<?php if ($highlights_array) {
										$i = 0;
										foreach ($highlights_array as $highlights) { ?>
											<P class="highlightsClass"><input type="text" class="form-control col-lg-11" name="highlights[]" value="<?php echo $highlights; ?>">&nbsp;&nbsp; <?php if ($i == 0) { ?><a style="cursor: pointer;" onclick="add_highlights_point();">Add New</a><?php } else { ?><a style="cursor: pointer;" onclick="removePoint(this);">Remove</a><?php } ?></p>
										<?php $i++;
										}
									} else { ?>
										<P class="highlightsClass"><input type="text" class="form-control col-lg-11" name="highlights[]" value="">&nbsp;&nbsp; <?php if ($i == 0) { ?><a style="cursor: pointer;" onclick="add_highlights_point();">Add New</a><?php } else { ?><a style="cursor: pointer;" onclick="removePoint(this);">Remove</a><?php } ?></p>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
                    <div class="optionContaner" id="option_to_show_news" style="display:<?php if ($media_type == 'youtube') {
																											echo ' none ';
																										} else {
																											echo ' block ';
																										} ?>">
					<div class="form-group">
						<label>Add Image </label>
						<input type="file" name="image" value="<?php echo $image; ?>">
						<input type="hidden" name="oldimage" value="<?php echo $image; ?>">
						<!-- <small class="msg-upload">Image Dimension must be Minimum 600px*400px</small> -->
						<?php if ($image != '') { ?>
							<br>
							<br>
							<img src="<?php echo base_url('upload/news/thumb/' . $image); ?>" style="width:100px;margin-left:20px;border:1px solid #444;padding:3px;">
						<?php } ?>
					</div>

					<div class="form-group">
						<label>Add Image description</label>
						<input type="text" name="image_capsion" class="form-control" value="<?php echo $image_capsion; ?>">
						
					</div>
					<script type="text/javascript">
						// 	function add_highlights_point11() {
						// 	$('#add_highlights11').append('<p class="highlightsClass"><input type="file" class="form-control col-lg-10" name="mfile[]" value="">&nbsp;&nbsp;<a  style="cursor: pointer;" onclick="removePoint(this);" >Remove</a></p>');
						// }
					</script>
					<div class="form-group">
						<label>Add Multiple Image </label>
						<br>
						<?php

							$nid = $this->uri->segment(4);
							$this->db->select('*');
							$this->db->from('news_gallery');
							$this->db->where('nid',$nid);
							$query = $this->db->get();
							$result = $query->result_array();
							foreach ($result as $key => $value) {

						?>

						<!-- <img src="<?= base_url(); ?>upload/news/orig/<?= $value['name']; ?>" style="width:100px;margin-left:20px;border:1px solid #444;padding:3px;"/> <a href="<?= base_url(); ?>admin/news/ndelete/<?= $nid; ?>/<?= $value['id']; ?>"><span class="glyphicon glyphicon-trash"></span></a> -->
						<?php

							?>

						<?php } ?>

						<!-- <br><br>
						
						<div style="clear: both;"></div>
						<p class="highlightsClass">
						<input type="file" class="form-control col-lg-10" name="mfile[]" value="">&nbsp;&nbsp;<a  style="cursor: pointer;" onclick="add_highlights_point11(this);" >Add New</a></p>
						<span id="add_highlights11"></span><br>
						<div style="clear: both;"></div>
					</div> -->
					</div>
					<!-- <div class="form-group">
						<label for="exampleInputPassword1">Link <span class="star-color">*</span></label>
						<input type="text" class="form-control" id="link" name="link" value="<?php echo $link; ?>">
					</div> -->
					<div class="form-group">
						<label for="exampleInputPassword1">News Type</label>
						<div class="radio block">
							<label>
								<input type="radio" value="news" onclick="showTheUploadOption(this.value);" <?php echo ($media_type == 'news') ? 'checked="checked"' : ''; ?> name="media_type" checked="checked" />News
							</label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label>
								<input type="radio" value="youtube" onclick="showTheUploadOption(this.value);" <?php echo ($media_type == 'youtube') ? 'checked="checked"' : ''; ?> name="media_type" />Youtube
							</label>
						</div>

						<!--<select class="form-control" onclick="showTheUploadOption(this.value);" id="media_type" name="media_type">
							<option <?php if ($media_type != 'youtube' && $media_type != 'video' && $media_type != 'audio') {
										echo ' selected="selected" ';
									} ?> selected="selected" value="news">News</option>
							 <option value="images">Image</option> 
							<option <?php if ($media_type == 'audio') {
										echo ' selected="selected" ';
									} ?> value="audio">Audio</option>
							<option <?php if ($media_type == 'video') {
										echo ' selected="selected" ';
									} ?> value="video">Video</option>
							<option <?php if ($media_type == 'youtube') {
										echo ' selected="selected" ';
									} ?> value="youtube">Youtube</option>
														
							<option value="facebook">FaceBook</option>
							<option value="twitter">Twitter</option>
							<option value="instagram">Instagram</option>
							 
						</select>
						 -->
					</div>
					<!--<div class="form-group optionContaner" id="option_to_show_audio" >-->
					<!--	<label for="exampleInputPassword1">News Audio</label>-->
					<!--	<input type="file" name="news_audio" value="<?php echo $news_audio; ?>"><small class="msg-upload">maximum 5mb File size allowed</small>-->
					<!--	<br>-->
						<?php if(!empty($news_audio))
{ ?>
<!--                        <audio controls width="200px">-->
<!--  <source src="horse.ogg" type="audio/ogg">-->
<!--  <source src="<?= base_url(); ?>upload/news/audio/<?php echo $news_audio; ?>" type="audio/mpeg">-->
<!--Your browser does not support the audio element.-->
<!--</audio>-->
<?php  }
?>
					<!--</div>-->

					<!--<div class="form-group optionContaner" id="option_to_show_video" >-->
					<!--	<label for="exampleInputPassword1">News Video</label>-->
					<!--	<input type="file" name="news_video" value="<?php echo $news_video; ?>"><small class="msg-upload">maximum 5mb File size allowed</small>-->
					<!--	<br>-->
						<?php
						
						if(!empty($news_video))
{ 
?>
<!--<video width="300px" style="height:250px;" controls>-->
<!--  <source src="<?= base_url(); ?>upload/news/video/<?php echo $news_video; ?>" type="video/mp4">-->
<!--  <source src="mov_bbb.ogg" type="video/ogg">-->
<!--  Your browser does not support HTML video.-->
<!--</video>-->
<?php }
						?>
					<!--</div>-->
					
					
					<div class="form-group optionContaner" id="option_to_show_youtube" style="display:<?php if ($media_type == 'youtube') {
																											echo ' block ';
																										} else {
																											echo ' none ';
																										} ?>">
						<div class="row">
							<div class="col-lg-8">
								<label for="exampleInputPassword1">News YouTube Code</label>
								<textarea name="youtube_code" style="width: 100%;height: 70px" id="youtube_code"><?php echo $youtube_code; ?></textarea>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-8">
								<label for="exampleInputPassword1">Note:</label>
						<ol>
							<li>On a computer, go to the YouTube video you want to embed.</li>
							<li>Under the video, click SHARE Share.</li>
							<li>Click Embed.</li>
							<li>From the box that appears, copy the HTML code.</li>
							<li>Paste the code into News YouTube Code.</li>
						</ol>
						</div>
						</div>																										

					</div>

					<div class="form-group">
						<label for="exampleInputPassword1">Location</label>
						<br>
						<select class="form-control" id="country" name="country" onchange="getcountrystate(this.value);">
							<?php foreach ($allcountry as $country) {
								$selected = '';
								if ($country->name == 'India') {
									$selected = ' selected="selected" ';
								}
							?>
								<option <?php echo $selected; ?> value="<?php echo $country->name; ?>"><?php echo $country->name; ?></option>
							<?php } ?>
						</select>
						<br><br>
						<select class="form-control" id="state" name="state" onchange="setStateCity(this.value)">
							<option value=""></option>
						</select>
						<br><br>

						<select class="form-control" id="city" name="city">
							<option value=""></option>
						</select>
					</div>
					
					
					
				<div class="form-group">
						<label for="exampleInputPassword1">News Categorise</label>
						<br>
						<select class="form-control pcategory" id="categorise" name="categorise">
							<option value=""></option>
							<?php foreach ($allcategory as $cat) { ?>
								<option <?php if ($categorise == $cat['id']) {
											echo ' selected="selected" ';
										} ?> value="<?php echo $cat['id']; ?>"><?php echo $cat['title']; ?></option>
							<?php } ?>
						</select>
					</div>

<div class="form-group">
						<label for="exampleInputPassword1">News Child Categorise</label>
						<br>
						<select class="form-control ccategory" id="categorise" name="child_categorise">
							<?php 

$pcategory = $categorise;
// echo $pcategory;
        $this->db->select('*');
        $this->db->from('category_map');
        $this->db->where("parent_category",$pcategory);
        $query = $this->db->get();
        $result = $query->result_array();
        echo "<option value=''>Select Child Category</option>";
        foreach($result as $value)
        {
        $child_category = $value['child_category'];
        $this->db->select('id,title');
        $this->db->from('news_categories');
        $this->db->where("id",$child_category);
        $query11 = $this->db->get();
        // echo $this->db->last_query();die;
        $result11 = $query11->result_array();
      ?>
     <option  <?php if ($child_categorise == $result11[0]['id']) {
											echo ' selected="selected" ';
										} ?> value="<?= $result11[0]['id']; ?>"><?= $result11[0]['title']; ?></option>;
<?php
        }
							?>
							
						</select>
					</div>


<script>
$(document).ready(function(){
    $("select.pcategory").change(function(){
        var pcategory = $(".pcategory option:selected").val();
        // alert(pcategory);
        $.ajax({
            type: "POST",
            url: "http://newssyn.com/pages/pcategory",
            data: { pcategory : pcategory } 
        }).done(function(data){
        	// alert(data);
        	// alert(data);
           $(".ccategory").html(data);
        });
    });
});
</script>
					
					
					
					
					<div class="form-group">
						<label for="exampleInputPassword1">Reporter</label>
						<br>
						<select class="form-control" id="reporter" name="reporter">
							<?php foreach ($allReporter as $reporterrec) { ?>
								<option <?php if ($reporter == $reporterrec->id) {
											echo ' selected="selected" ';
										} ?> value="<?php echo $reporterrec->id ?>"><?php echo $reporterrec->first_name . ' ' . $reporterrec->last_name . '(' . $reporterrec->email . ')'; ?></option>
							<?php } ?>
						</select>
						<br>
						<label>
							<input type="checkbox" name="hide_email_on_news" <?php if ($hide_email_on_news == '1') {
																					echo ' checked="checked" ';
																				} ?> value="1">
							Hide email on news
						</label>
						&nbsp;&nbsp;&nbsp;&nbsp;
						<label>
							<input type="checkbox" name="hide_name_on_news" <?php if ($hide_name_on_news == '1') {
																				echo ' checked="checked" ';
																			} ?> value="1">
							Hide name on news
						</label>
						
						&nbsp;&nbsp;&nbsp;&nbsp;
						<label>
							<input type="checkbox" name="hide_image_on_news" <?php if ($hide_image_on_news == '1') {
																				echo ' checked="checked" ';
																			} ?> value="1">
							Hide image on news
						</label>


					</div>
					<div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Status</label>
						<div class="radio block">
							<label>
								<input type="radio" value="1" <?php echo ($status == '1') ? 'checked="checked"' : ''; ?> name="status" checked="checked" />Active
							</label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label>
								<input type="radio" value="0" <?php echo ($status == '0') ? 'checked="checked"' : ''; ?> name="status" />Inactive
							</label>
						</div>
					</div>
					<!-- <div class="form-group">
						<label for="radio" class="col-sm-2 control-label">Spceial Block</label>
						<div class="radio block">
							<label>
								<input type="radio" value="1" <?php echo ($spceial_block == '1') ? 'checked="checked"' : ''; ?> name="spceial_block" />Yes
							</label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label>
								<input type="radio" value="0" <?php echo ($spceial_block != '1') ? 'checked="checked"' : ''; ?> name="spceial_block" />No
							</label>
						</div>
					</div> -->
					<button type="submit" class="btn btn-default" name="submit" value="submit">Update</button>
					<?php if ($user_id > 0) { ?>
						<a href="<?php echo base_url('admin/users/my_news/' . $user_id); ?>"><button type="button" class="btn btn-default" name="Back" value="Back">Back</button></a>
					<?php } else { ?>
						<a href="<?php echo base_url('admin/news'); ?>"><button type="button" class="btn btn-default" name="Back" value="Back">Back</button></a>
					<?php } ?>
				</form>
			</div>
		</div>
		<!--//graph-visual-->
	</div>
</div>
<br><br>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script src="http://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script>
	$(document).ready(function() {
		$('#datepicker').datepicker();
	});
	//Replace the <textarea id="editor1"> with a CKEditor
	//instance, using default configuration.
	CKEDITOR.replace('discription');

	function showTheUploadOption(val) {
		$('.optionContaner').hide();
		$('#option_to_show_' + val).show();
	}

	function add_highlights_point() {
		$('#add_highlights').append('<p class="highlightsClass"><input type="text" class="form-control col-lg-10" name="highlights[]" value="">&nbsp;&nbsp;<a  style="cursor: pointer;" onclick="removePoint(this);" >Remove</a></p>');
	}

	function removePoint(ele) {
		$(ele).parent('p').remove();
	}

	function getcountrystate(id, onload = '', set = '', city = '') {
		var postData = {
			country_id: id
		};
		$.ajax({
			url: "<?php echo base_url(); ?>home/getCountrySate",
			data: postData,
			dataType: 'json',
			type: 'POST',
			success: function(result) {
				$('#state').html('');
				var output = [];
				output.push('<option value=""></option>');
				$.each(result, function(key, value) {
					output.push('<option value="' + value.name + '">' + value.name + '</option>');
				});

				if (output.length > 0) {
					$('#state').html(output.join(''));
				} else {
					$('#state').html('<option value="">No state found</option>');
				}
				if (onload == 'load') {

					if (set != '') {
						$('#state').val(set);
					}

					if (city != '') {
						setTimeout(function() {
							setStateCity(set, 'load', city);
						}, 1000);
					}
				}
				$('#state').trigger('change');


			}
		});
	}

	function setStateCity(id, onload = '', set = '') {
		//alert(id);
		var postData = {
			country_id: id
		};

		$.ajax({
			url: "<?php echo base_url(); ?>home/getSateCity",
			data: postData,
			dataType: 'json',
			type: 'POST',
			success: function(result) {

				$('#city').html('');
				var output = [];
				output.push('<option value=""></option>');

				$.each(result, function(key, value) {
					output.push('<option value="' + value.name + '">' + value.name + '</option>');
				});

				if (output.length > 0) {
					$('#city').html(output.join(''));
				} else {
					$('#city').html('<option value="">No city found</option>');
				}

				if (onload == 'load') {
					if (set != '') {
						$('#city').val(set);
					}
				}
				$('#city').trigger('change');
			}
		});
	}


	$(document).ready(function() {
		$('#country').select2({
			placeholder: "Select country",
			allowClear: true
		});
		$('#state').select2({
			placeholder: "Select state",
			allowClear: true
		});
		$('#city').select2({
			placeholder: "Select city",
			allowClear: true
		});

		$('#categorise').select2({
			placeholder: "Select categorise",
			allowClear: true
		});

		$('#reporter').select2({
			placeholder: "Select reporter",
			allowClear: true
		});

		$('#country').val('<?php echo $countryname ?>');
		$('#country').trigger('change');

		getcountrystate('<?php echo $countryname ?>', 'load', '<?php echo $state ?>', '<?php echo $city ?>');
		//setStateCity('<?php echo $state ?>', 'load', '<?php echo $city ?>');

	});
</script>