<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Adds extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -  
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/adds_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }
    public function index()
    {
        $data['adds'] = $this->adds_model->getRecords();
        $data['adds_categories'] = $this->adds_model->getCategoriesRecords();
        adminLoadView('adds/list', $data);
    }
    public function add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /*if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->adds_model->formValidations();
            if ($_FILES['image']['name']!="") {
                $data['error'] = array();
                $file_name = time() . $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png", "gif");

                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }
                if ($file_size > 2097152) {
                    //$data['error'] = 'File size must be excately 2 MB';
                }
                //$insertData['image'] = $file_name;
                //var_dump(move_uploaded_file($file_tmp, "_wildcard_/upload/" . $file_name));
                if (empty($data['error']) == true) {
                    $val=move_uploaded_file($file_tmp, "upload/adds/" . $file_name);
                    
                    //var_dump($val);
                    if ($val) {
                      // die;
                        $thumb = array();
                        // Create thumnail or resize image
                        $thumb['image_library']     = 'gd2';
                        $thumb['source_image']      = './upload/adds/' . $file_name;
                        $thumb['new_image']         = './upload/adds/thumb/';
                        $thumb['create_thumb']      = false;
                        $thumb['maintain_ratio']    = false;
                        $thumb['width']             = 300;
                        $thumb['height']            = 200;
                        $this->load->library('image_lib', $thumb);
                        $this->image_lib->resize();
                        unlink($file_tmp, "./upload/adds/" . $file_name);
                    }
                }
                
            }
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'title' => $postData['title'],
                    'discription' => $postData['discription'],
                    'link' => $postData['link'],
                    'image' => $postData['image'],
                    'page_path' => $postData['home'],
                    'status' => $postData['status'],
                    // 'categorie' => $postData['categorie'],
                    'news_cate' => $postData['news_categories'],
                    'news_sub_cateid' => $postData['news_sub_cateid'],
                    'addscode' => $postData['addscode']
                );
                $insertData['image'] = $file_name ? $file_name : "";
                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }
                
                if (!empty($postData['news_categories'])) {
                    $insertData['news_cate'] = $postData['news_categories'];
                } else {
                    $insertData['news_cate'] = '';
                }
                
                if (!empty($postData['news_sub_cateid'])) {
                    $insertData['news_sub_cateid'] = $postData['news_sub_cateid'];
                } else {
                    $insertData['news_sub_cateid'] = '';
                }
                
                $slug = create_slug('adds', $postData['title']);
                if (!empty($slug)) {
                    $insertData['slug'] = $slug;
                }
                $return = addUpdateRecord('adds', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'adds added successfully.');
                    redirect('admin/adds');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['adds_categories'] = $this->adds_model->getCategoriesRecords();
        $data['postData'] = $postData;
        adminLoadView('adds/create', $data);
    }
    public function edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/adds');
        }
        $postData = $this->adds_model->getRecordById($id);
        $data['adds_categories'] = $this->adds_model->getCategoriesRecords();
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            }*/
            $formValidation = $this->adds_model->formValidations($id);
            $slug = create_slug('adds', $postData['title'], $id);
            if (!empty($slug)) {
                $updateData['slug'] = $slug;
            }
            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            if (isset($_FILES['image']) && $_FILES['image']['name']!="") {

                $data['error'] = array();
                $file_name = time() . $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png", "gif");
                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }
                if ($file_size > 2097152) {
                    // $data['error'] = 'File size must be excately 2 MB';
                }
                $updateData['image'] = $file_name;
                if (empty($data['error']) == true) {

                    if (move_uploaded_file($file_tmp, "./upload/adds/" . $file_name)) {
                        $thumb = array();
                        // Create thumnail or resize image
                        $thumb['image_library']     = 'gd2';
                        $thumb['source_image']      = './upload/adds/' . $file_name;
                        $thumb['new_image']         = './upload/adds/thumb/';
                        $thumb['create_thumb']      = false;
                        $thumb['maintain_ratio']    = false;
                        $thumb['width']             = 300;
                        $thumb['height']            = 200;
                        $this->load->library('image_lib', $thumb);
                        $this->image_lib->resize();
                        unlink($file_tmp, "./upload/adds/" . $file_name);
                    }
                }

                /*
                $testsize = getimagesize("/var/www/html/public_html/v2/agcnnnews/upload/adds/" . $file_name);
                $width = $testsize[0];
                $height = $testsize[1];
                if ($width < 450 || $height < 280) {
                    $data['error'] = 'Image Size is Small';
                    unlink("./upload/adds/" . $file_name);
                }
                */

                $updateData['image'] = $file_name;
            }
            if ($formValidation && empty($data['error'])) {
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                $updateData['link'] = $postData['link'];
                $updateData['page_path'] = $postData['home'];
                $updateData['status'] = $postData['status'];
                // $updateData['categorie'] = $postData['categorie'];
                $updateData['addscode'] = $postData['addscode'];
                $updateData['news_cate'] = $postData['news_categories'];
                $updateData['news_sub_cateid'] = $postData['news_sub_cateid'];
                
                $return = addUpdateRecord('adds', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'adds updated successfully.');
                    redirect('admin/adds');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

        adminLoadView('adds/edit', $data);
    }
    public function delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/adds');
        }
        $deleteData = $this->adds_model->getRecordById($id);
        $delete = deleteRecordById('adds', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'adds deleted successfully.');
            redirect('admin/adds');
        }
    }



    public function categories()
    {
        $data['adds'] = $this->adds_model->getCategoriesRecords();
        adminLoadView('adds/list_category', $data);
    }
    public function categorie_add()
    {
        $postData = array();
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /* if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            } else {*/
            $formValidation = $this->adds_model->formCatValidations();
            if (!empty($_FILES['image'])) {
                $data['error'] = array();
                $file_name = $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png", "gif");
                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }
                if ($file_size > 2097152) {
                    $data['error'] = 'File size must be excately 2 MB';
                }
                $insertData['image'] = $file_name;
                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/adds_categorie/" . $file_name);
                    $testsize = getimagesize("./upload/adds_categorie/" . $file_name);
                    $width = $testsize[0];
                    $height = $testsize[1];
                    /*
                        if ($width < 450 || $height < 280) {
                            $data['error'] = 'Image Size is Small';
                            unlink("./upload/adds/" . $file_name);
                        }
                         
                         */
                }
            }
            //}
            if ($formValidation && empty($data['error'])) {
                $insertData = array(
                    'title' => $postData['title'],
                    'discription' => $postData['discription'],
                    'link' => $postData['link'],
                    'image' => $postData['image'],
                    'categorie_type' => $postData['categorie_type'],
                    'categorie_colour' => $postData['categorie_colour'],
                    'order' => $postData['order'],
                    'status' => $postData['status']
                );
                $insertData['image'] = $file_name;
                if (!empty($postData['status'])) {
                    $insertData['status'] = $postData['status'];
                } else {
                    $insertData['status'] = 1;
                }
                $slug = create_slug('adds_categories', $postData['title']);
                if (!empty($slug)) {
                    $insertData['slug'] = $slug;
                }
                $return = addUpdateRecord('adds_categories', '', '', $insertData);
                if ($return) {
                    $this->session->set_flashdata('success', 'adds added successfully.');
                    redirect('admin/adds/categories');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        $data['postData'] = $postData;
        adminLoadView('adds/create_category', $data);
    }
    public function categorie_edit($id = null)
    {
        if (empty($id)) {
            redirect('admin/adds');
        }
        $postData = $this->adds_model->getCategorieRecordById($id);
        $data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
            $data['error'] = "";
            $url = $_POST['link'];
            /*if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $data['error'] = 'Enter Valid Link of Menu';
            }*/
            $formValidation = $this->adds_model->formCatValidations($id);
            $slug = create_slug('adds_categories', $postData['title'], $id);
            if (!empty($slug)) {
                $updateData['slug'] = $slug;
            }

            if (empty($postData['status'])) {
                $updateData['status'] = 1;
            } else {
                $updateData['status'] = $postData['status'];
            }
            if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
                $data['error'] = array();
                $file_name = $_FILES['image']['name'];
                $file_size = $_FILES['image']['size'];
                $file_tmp = $_FILES['image']['tmp_name'];
                $file_type = $_FILES['image']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));
                $expensions = array("jpeg", "jpg", "png", "gif");
                if (in_array($file_ext, $expensions) === false) {
                    $data['error'] = "extension not allowed, please choose a JPEG or PNG file.";
                }
                if ($file_size > 2097152) {
                    $data['error'] = 'File size must be excately 2 MB';
                }
                $updateData['image'] = $file_name;
                if (empty($data['error']) == true) {
                    move_uploaded_file($file_tmp, "./upload/adds_categorie/" . $file_name);
                }
                $testsize = getimagesize("./upload/adds_categorie/" . $file_name);
                $width = $testsize[0];
                $height = $testsize[1];
                /*
                if ($width < 450 || $height < 280) {
                    $data['error'] = 'Image Size is Small';
                    unlink("./upload/adds_categorie/" . $file_name);
                }*/
                $updateData['image'] = $file_name;
            }
            if ($formValidation && empty($data['error'])) {
                $updateData['title'] = $postData['title'];
                $updateData['discription'] = $postData['discription'];
                $updateData['link'] = $postData['link'];
                $updateData['categorie_type'] = $postData['categorie_type'];
                $updateData['status'] = $postData['status'];
                $updateData['categorie_colour'] = $postData['categorie_colour'];
                $updateData['order'] = $postData['order'];

                $return = addUpdateRecord('adds_categories', 'id', $id, $updateData);
                if ($return) {
                    $this->session->set_flashdata('success', 'adds updated successfully.');
                    redirect('admin/adds/categories');
                }
            } else {
                if (validation_errors()) {
                    if (validation_errors()) {
                        $data['error'] = validation_errors();
                    }
                }
            }
        }
        adminLoadView('adds/edit_category', $data);
    }
    public function categorie_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/adds/categories');
        }
        $deleteData = $this->adds_model->getCategorieRecordById($id);
        $delete = deleteRecordById('adds_categories', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'adds Categorie deleted successfully.');
            redirect('admin/adds/categories');
        }
    }
    
    public function add_manage()
    {
        
        
        
        $data['adds'] = $this->adds_model->getaddRecords();
        $data['addss'] = $this->adds_model->getRecords();
        
        adminLoadView('adds/manage_adds', $data);
    }
    
    public function addmanage(){
        
        
     $catid =    $_POST['manage_category'];
     $position = $_POST['position'];
   
    $sql = "SELECT * FROM `manage_adds` where addsid = $position OR categoriesid = $catid";
    	$query = $this->db->query($sql);
        $result = $query->result();
        if($result){
          for($i=0;count($result)>$i;$i++){
              $sql1 = "DELETE FROM `manage_adds` where addsid = $position OR categoriesid = $catid";
              $this->db->query($sql1);
          }
           $insertData = array(
                    'categoriesid' => $_POST['manage_category'],
                    'addsid' => $_POST['position']
                );
                
                $return = addUpdateRecord('manage_category', '', '', $insertData);
                $this->session->set_flashdata('success', 'Manage Add Update successfully.');
                    redirect('admin/adds/add_manage');
        }
        else{
           $insertData = array(
                    'categoriesid' => $_POST['manage_category'],
                    'addsid' => $_POST['position']
                );
                
                $return = addUpdateRecord('manage_adds', '', '', $insertData);
                

                    $this->session->set_flashdata('success', 'Manage Add added successfully.');
                    redirect('admin/adds/add_manage');
        }
     
    }
    public function man_add_delete($id = null)
    {
        if (empty($id)) {
            redirect('admin/adds/add_manage');
        }
        $deleteData = $this->adds_model->getmanAddRecordById($id);
        $delete = deleteRecordById('manage_adds', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'Manage Adds deleted successfully.');
            redirect('admin/adds/add_manage');
        }
    }
    
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */