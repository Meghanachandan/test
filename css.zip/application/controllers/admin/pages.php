<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pages extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {

        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/page_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index() {
        
        $data['pages'] = $this->page_model->getRecords();
        adminLoadView('pages/list', $data);
    }

    public function add() {

        $postData = array();
        if ($_POST) {
            $postData = $_POST;
			$data['error']="";
			$url = $_POST['link'];
			
			/*if (!filter_var($url, FILTER_VALIDATE_URL)) {
			$data['error']='Enter Valid Link of Menu';
			}*/


            $formValidation = $this->page_model->formValidations();
            if ($formValidation && $data['error']=="") {

                $insertData = array(
                    'name'          => $postData['name'],
                    'discription'   => $postData['discription'],
                    'link'          => $postData['link'],
                    'status'        => $postData['status']
                );
				$slug = create_slug('pages', $postData['name']);
				if (!empty($slug)) {
					$insertData['slug'] = $slug;
				}

				if (!empty($postData['status'])) {
					$insertData['status'] = $postData['status'];
				} else {
					$insertData['status'] = 1;
				}   
				$return = addUpdateRecord('pages', '', '', $insertData);
			
				
				
                if ($return) {
                    $this->session->set_flashdata('success', 'Page added successfully.');
                    redirect('admin/pages');
                } 
            } else {

                if(validation_errors()) {
                    if(validation_errors()){
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

       
        $data['postData'] = $postData;
        adminLoadView('pages/create', $data);
    }


    public function edit($id = null) {

        if (empty($id)) {
            redirect('admin/pages');
        }

        $postData = $this->page_model->getRecordById($id);
		$data['postData'] = $postData;
        if ($_POST) {
            $postData = $_POST;
			$data['error']="";
			$url = $_POST['link'];
			/*if (!filter_var($url, FILTER_VALIDATE_URL)) {
				$data['error']='Enter Valid Link of Menu';
			}*/

            $formValidation = $this->page_model->formValidations();
            if ($formValidation && $data['error']=="" ) {
                $updateData = array(
                    'name'          => $postData['name'],
                    'discription'   => $postData['discription'],
                    'link'          => $postData['link'],
                );

                $slug = create_slug('pages', $postData['name'], $id);
                if (!empty($slug)) {
                    $updateData['slug'] = $slug;
                }

                if (!empty($postData['status'])) {
                    $updateData['status'] = $postData['status'];
                } else {
                    $updateData['status'] = 1;
                }   
                
                $return = addUpdateRecord('pages', 'id', $id, $updateData);

                if ($return) {
                    $this->session->set_flashdata('success', 'Page updated successfully.');
                    redirect('admin/pages');
                } 
            } else {

                if(validation_errors()) {
                    if(validation_errors()){
                        $data['error'] = validation_errors();
                    }
                }
            }
        }

       
        
        adminLoadView('pages/edit', $data);
    }

    public function delete($id = null) {

        if (empty($id)) {
            redirect('admin/pages');
        }

        $deleteData = $this->page_model->getRecordById($id);
        $delete = deleteRecordById('pages', $deleteData['id']);
        if ($delete) {
            $this->session->set_flashdata('success', 'Page deleted successfully.');
            redirect('admin/pages');
        }
    }
    public function pcategory()
    {
        $pcategory = $_POST['pcategory'];
        $this->db->select('*');
        $this->db->from('category_map');
        $this->db->where("parent_category",$pcategory);
        $query = $this->db->get();
        $result = $query->result_array();
        // echo $this->db->last_query();die;
        echo "<option value=''>Select Child Category</option>";
        foreach($result as $value)
        {
        $child_category = $value['child_category'];
        $this->db->select('id,title');
        $this->db->from('news_categories');
        $this->db->where("id",$child_category);
        $query11 = $this->db->get();
        // echo $this->db->last_query();die;
        $result11 = $query11->result_array();
      
        echo "<option value='".$result11[0]['id']."'>".$result11[0]['title']."</option>";

        }


    }
    public function topstatus()
    {
      $id = $_POST['id'];   
        $status = $_POST['status']; 
        if($status==1)
        {
            $status = 0;
        }
        else
        {
          $status = 1;  
        }
        $this->db->where("id",$id);
        $this->db->update("news_categories",["top"=>$status]);
    }
    
    public function desgination()
    {
        $pcategory = $_POST['pcategory'];
        $this->db->select('*');
        $this->db->from('designations');
        $this->db->where("depart_id",$pcategory);
        $query = $this->db->get();
        $result = $query->result_array();
        // echo $this->db->last_query();die;
        echo "<option value=''>Select Desgination</option>";
        // foreach($result as $value)
        // {
        $child_category = $value['depart_id'];
        //echo $child_category;print_r($child_category);
        $this->db->select('id,designation');
        $this->db->from('designations');
        $this->db->where("depart_id",$pcategory);
        $query11 = $this->db->get();
        // echo $this->db->last_query();die;
        $result11 = $query11->result_array();
            foreach($result11 as $value1){
        echo "<option value='".$value1['id']."'>".$value1['designation']."</option>";
       // }
        }


    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */