<?php
if ($getCatInfo) {
?>
    <section class="tabs4 cid-rUEF7euy93" id="tabs4-r">
        <div class="container">
            <h1>News In <?php echo $getCatInfo['title']; ?></h1>
        </div>
    </section>
<?php
}
?>
<section class="features17 cid-rUEOBxXWse" id="features17-y">
    <div class="container-fluid">
        <div cl ass="media-container-row">
            <h1 class="classForHeadercategory">
                Latest News
            </h1>
        </div>
        <div class="media-container-row">

            <?php if ($latest_news) { ?>
                <?php foreach ($latest_news as $news) { ?>
                    <?php //pr(); 
                    ?>
                    <div class="card p-3 col-12 col-md-6 my-col">
                        <a href="<?php echo base_url() . 'home/news_view/' . $news['id'].'/'.str_replace(' ','-',$news['title']); ?>">
                            <div class="card-wrapper">
                                <div class="card-img">
                                    <?php
                                        if(trim($news['image'])==''){
                                            $news['image'] = 'no-image.png';
                                        }                
                                    ?>
                                    <img src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>" style="height:120px;" alt="<?php echo $news['title'] ?>">
                                    <div class="date_box">
                                        <?php echo $news['date'] ?> - &nbsp;&nbsp;&nbsp;
                                        <span><i class="fas fa-pencil-alt"></i></span> Nilima Pathak
                                    </div>
                                </div>
                                <div class="card-box">
                                    <h4 class="card-title pb-3 mbr-fonts-style display-7">
                                        <?php echo $news['title'] ?>
                                    </h4>
                                    <p class="mbr-text mbr-fonts-style display-7">
                                        <?php echo strip_tags($news['discription']) ?>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
</section>


<section class="features17 cid-rUEOBxXWse" id="features17-y">
    <div class="container-fluid">
        <div class="media-container-row">
            <h1 class="classForHeadercategory">
                papular story
            </h1>
        </div>
        <div class="media-container-row">


            <?php if ($populer_news) { ?>
                <?php foreach ($populer_news as $news_p) { ?>
                    <div class="card p-3 col-12 col-md-6 my-col">
                        <a href="<?php echo base_url() . 'home/news_view/' . $news_p['id'].'/'.str_replace(' ','-',$news_p['title']); ?>">
                            <div class="card-wrapper">
                                <div class="card-img">
                                    <?php
                                        if(trim($news_p['image'])==''){
                                            $news_p['image'] = 'no-image.png';
                                        }                
                                    ?>
                                    <img src="<?php echo base_url() . 'upload/news/' . $news_p['image']; ?>" style="height:120px;" alt="<?php echo $news_p['title'] ?>">
                                    <div class="date_box">
                                        <?php echo $news_p['date'] ?> - &nbsp;&nbsp;&nbsp;
                                        <span><i class="fas fa-pencil-alt"></i></span> Nilima Pathak
                                    </div>
                                </div>
                                <div class="card-box">
                                    <h4 class="card-title pb-3 mbr-fonts-style display-7">
                                        <?php echo $news_p['title'] ?>
                                    </h4>
                                    <p class="mbr-text mbr-fonts-style display-7">
                                        <?php echo strip_tags($news_p['discription']) ?>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
</section>



<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script>
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>

<section class="features17 cid-rUEOBxXWse" id="features17-y">
    <div class="container">
        <div class="row">
            <h1 class="classForHeadercategory">
                All Result
            </h1>
        </div>
        <div class="row">
            <div class="tables">
                <table class="display responsive" id="example-table">
                    <!-- <thead> 
                    <tr>
                        <td>ll</td>
                    </tr>
                </thead> -->
                    <?php
                    foreach ($filter_data as $news) {
                        //pr($news);
                        echo '<tr><td><a href="'. base_url() . 'home/news_view/' . $news['id'].'/'.str_replace(' ','-',$news['title']).'">' . $news['title'] . '</a></td></tr>';
                    }
                    ?>
                </table>
            </div>

        </div>
    </div>
</section>

<?php if ($recientView) { ?>
    <section class="features17 cid-rUEOBxXWse" id="features17-y">
        <div class="container-fluid">
            <div class="media-container-row">
                <h1 class="classForHeadercategory">
                    Recent View
                </h1>
            </div>
            <div class="media-container-row">
                <?php foreach ($recientView as $news_p) { ?>
                    <div class="card p-3 col-12 col-md-6 my-col">
                        <a href="<?php echo base_url() . 'home/news_view/' . $news_p['id'].'/'.str_replace(' ','-',$news_p['title']); ?>">
                            <div class="card-wrapper">
                                <div class="card-img">
                                    <?php
                                        if(trim($news_p['image'])==''){
                                            $news_p['image'] = 'no-image.png';
                                        }                
                                    ?>
                                    <img src="<?php echo base_url() . 'upload/news/' . $news_p['image']; ?>" style="height:120px;" alt="<?php echo $news_p['title'] ?>">
                                    <div class="date_box">
                                        <?php echo $news_p['date'] ?> - &nbsp;&nbsp;&nbsp;
                                        <span><i class="fas fa-pencil-alt"></i></span> Nilima Pathak
                                    </div>
                                </div>
                                <div class="card-box">
                                    <h4 class="card-title pb-3 mbr-fonts-style display-7">
                                        <?php echo $news_p['title'] ?>
                                    </h4>
                                    <p class="mbr-text mbr-fonts-style display-7">
                                        <?php echo strip_tags($news_p['discription']) ?>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
<?php } ?>

<script>
    $(document).ready(function() {
        $('#example-table').DataTable({
            "pagingType": "full_numbers"
        });
    });
</script>