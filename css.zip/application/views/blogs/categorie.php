<?php

print_r($getBlogs);

?>

<section>
	<div class="container">
		<div class="row">
            <div class="page-title-wrapper product">
            	<div class="col-md-12 col-sm-12 col-xs-12">
                    <h1 class="page-title">
                        <span class="base" data-ui-id="page-title-wrapper" itemprop="name"><?php echo $getCat['title'];?></span>
                    </h1>
                 </div>
            	<div class="clearfix"></div>
            </div>    
        </div>
    </div>
</section>
<section>
	<div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-9">
				<div class="blog-post-area" id="blog-post-area">
					<?php if(!empty($getBlogs)) { ?>
						<?php 
							$i=1;
							foreach ($getBlogs as $blog) {
								$css = "";
								if ($i > 1) {
									$css = "mt20";
								}
						?>
							<div class="single-blog-post <?php echo $css; ?> ">
								<a title="<?php echo $blog->title; ?>" href="<?php echo base_url('blogs/post/'.$blog->slug); ?>">
									<img src="<?php echo base_url("upload/blogs/".$blog->image) ?>" alt="" class="img-responsive">
								</a>
								<h3><?php echo $blog->title; ?> </h3>
								<div class="post-meta">
									<ul>
										<li><i class="fa fa-calendar"> &nbsp; Posted </i> <?php echo  date('M d, Y', strtotime($blog->created_date)); ?></li>
									</ul>
								</div>
								<p class="blog-para">
									<?php 
										if (strlen($blog->discription) > 100) {
					                        $stringCut = substr($blog->discription, 0, 100);
					                        $string = substr($stringCut, 0, strrpos($stringCut, ' ')).'...'; 
					                    } else {
					                        $string = $blog->discription;
					                    } 
					                    echo $string;
									?>
								</p>
								<a title="<?php echo $blog->title; ?>"  class="btn btn-primary" href="<?php echo base_url('blogs/post/'.$blog->slug); ?>">Read More</a>
							</div>
							<?php 
								if($i != count($getBlogs)){
									echo '<hr>';
								}
							?>
                    <?php 	
                    			$i++;
                    		}
                    	} ?>
                    	<br>
					<?php echo $paginationCount; ?>
				</div>
			</div>
			<div class="col-sm-4 col-md-3">
				<div class="left-sidebar">
                        <div class="clearfix"></div>
                        <!--Search Post-->
                        <div class="mt10 blog-search blog-search-cust">
                        	<div class="blog-input">
                        	<input  placeholder="Search posts here..." class="input-text" maxlength="128" type="text" id="searchText">
                        	<i class="fa " id="searchLoader" style="color: #000;font-size:18px;position: relative;top:-28px;margin-left:10px"></i>
                        	<span><button type="submit" title="Search" class="action search-btn" id="searchbutton" onclick="searchPost()" style="margin-top: -3px;margin-right: 10px;"><i class="fa fa-search"></i> </button></span></div>
                        </div>
                        <!--/ Search Post-->
					<div class="mb100"><!--shipping-->
						<?php if (!empty($latest_post)) { ?>
							 <h2>Recent Posts</h2>
                        	<p><?php echo  date('F Y', strtotime($latest_post['created_date'])); ?></p>
							<a title="<?php echo $latest_post['title']; ?>" href="<?php echo base_url("blogs/post/".$latest_post['slug']); ?>"><img src="<?php echo base_url("upload/blogs/".$latest_post['image']); ?>" alt="" class="img-responsive"/></a>
						<?php } ?>
					</div><!--/shipping-->
				</div>
			</div>
		</div>
	</div>
	<input type="hidden" id="hiddenSearchText" value="">
</section>
	<script type="text/javascript">
		function changePagination(pageId, liId) {
			var page_path  = "<?php echo base_url(); ?>blogs/filter";
		    var searchText = $("#hiddenSearchText").val();
		    $("#blog-post-area").addClass('overlay-bg-blog');
		   	$.ajax({
	           type: "POST",
	           url: page_path,
	           data: ({
                    pageId 			: pageId,
                    searchText 		: searchText
                }),
	           cache: false,
	           success: function(result){
	                $("#blog-post-area").html(result).removeClass('overlay-bg-blog');
           			$(".link").removeClass("active") ;
             		$("#"+liId).addClass( "active" );
	           }
	      	});
		}
		function searchPost() {
			var searchText 	= $("#searchText").val();
			$("#hiddenSearchText").val(searchText);			
			var search 		= "";
			if (searchText != "") {
				var search 	= searchText;
				//$("#blog-post-area").addClass('blogpostdata');
				$("#searchLoader").addClass('fa-spinner').addClass('fa-spin');
			}
			var page_path  = "<?php echo base_url(); ?>blogs/search";
		   	$.ajax({
	           type: "POST",
	           url: page_path,
	           data: ({
                    searchText 	: search
                }),
	           cache: false,
	           success: function(result){
					var explode = function(){
						$("#blog-post-area").html(result);
					  	//$("#blog-post-area").removeClass('blogpostdata');<i class="fa fa-search"></i>
					  	$("#searchLoader").removeClass('fa-spinner').removeClass('fa-spin');
						//$("#searchbutton i").addClass('fa-search').removeClass('fa-spinner fa-spin');
					};
					setTimeout(explode, 500);
	           }
	      	});
		}
	</script>