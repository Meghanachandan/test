<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends CI_Controller
{

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        //$this->load->model('product_model');
        $this->load->model('home_model');
        //$this->load->model('our_partner_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['page_active'] = 'Home';
        //$data['getBanners'] = $this->home_model->getBanners();
        //$data['allcategories'] = $this->home_model->get_blog_categories();
        $data['latest_news'] = $this->home_model->get_latest_news();
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews();
        //$this->load->model('admin/news_model');
        //$allcountry = $this->news_model->getAllCountry();
        //$allcountryState = $this->news_model->getAllCountrystate(101);
        //$data['allcountryState'] = $allcountryState;
        //$data['allcountry'] = $allcountry;

        $data['addOnPage'] = $this->home_model->getHomeAdds();
        $data['recientView'] =  $this->home_model->getRecientView();
        $sql = "SELECT * FROM `allow_signup`";
        $data['signup'] = $this->home_model->select($sql);

        defaultLoadView('vwHome', $data);
    }

    public function latest_news_popular_story()
    {
        $data['page_active'] = 'Home';
        //$data['getBanners'] = $this->home_model->getBanners();
        //$data['allcategories'] = $this->home_model->get_blog_categories();
        $data['latest_news'] = $this->home_model->get_latest_news();
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews();
        //$this->load->model('admin/news_model');
        //$allcountry = $this->news_model->getAllCountry();
        //$allcountryState = $this->news_model->getAllCountrystate(101);
        //$data['allcountryState'] = $allcountryState;
        //$data['allcountry'] = $allcountry;

        $data['addOnPage'] = $this->home_model->getHomeAdds();
        $data['recientView'] =  $this->home_model->getRecientView();

        defaultLoadView('latest_news_popular_story', $data);
    }

    public function do_login()
    {
        if ($this->session->userdata('is_client_login')) {
            redirect('home/loggedin');
        } else {
            $user = $_POST['username'];
            $password = $_POST['password'];
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
            if ($this->form_validation->run() == FALSE) {
                /*
                 * Code By Abhishek R. Kaushik
                 * Sr. Software Developer 
                 */
                $this->load->view('login');
            } else {
                $sql = "SELECT * FROM users WHERE user_name = '" . $user . "' AND user_hash = '" . md5($password) . "'";
                $val = $this->db->query($sql);

                if ($val->num_rows) {
                    foreach ($val->result_array() as $recs => $res) {
                        $this->session->set_userdata(
                            array(
                                'user_id' => $res['id'],
                                'users_name' => $res['user_name'],
                                'fname' => $res['first_name'],
                                'lname' => $res['last_name'],
                                'email' => $res['email'],
                                'is_client_login' => true
                            )
                        );
                    }
                    redirect('calls/call');
                } else {
                    $err['error'] = 'Username or Password incorrect';
                    $this->load->view('login', $err);
                }
            }
        }
    }

    public function like()
    {
        if ($this->session->userdata('user_id')) 
        {
            $news_ids = $this->input->post('news_id');
            $user_id = $this->session->userdata('user_id');
            $data = array(
                'user_id' => $user_id,
                'newsid' => $news_ids,
                'like' => 1
            );
            $this->db->insert('news_like',$data);
            echo 1;
        }
        else echo 0;
        // echo $this->session->userdata('users_name');
    }

    public function unlike()
    {
        if ($this->session->userdata('user_id')) 
        {
            $news_ids = $this->input->post('news_id');
            $user_id = $this->session->userdata('user_id');
            $this->db->where(array("newsid"=>$news_ids,"user_id"=>$user_id));
            $this->db->delete('news_like');
            echo 1;
        }
        else echo 0;
    }

    public function logout()
    {
        $this->session->unset_userdata('id');
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('title');
        $this->session->unset_userdata('ag_country');
        $this->session->unset_userdata('is_client_login');
        $this->session->sess_destroy();
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        redirect('home', 'refresh');
    }

    public function deleteimage()
    {
        unlink($_POST['img']);
    }

    public function page($slug)
    {
        $data['getPage'] = getRecordBySlug('pages', urldecode($slug), '1');
        // echo $this->db->last_query();die;
        defaultLoadView('page', $data);
    }

    public function email_subscribes()
    {

        $data["success"] = "";
        if ($_POST) {
            
            $this->form_validation->set_rules('sub_email', 'Email', 'required|valid_email');
            $email = $_POST['sub_email'];

            $data["validation"] = "";
            if ($this->form_validation->run() == FALSE) {
                if (validation_errors()) {
                    $data["validation"] = validation_errors();
                }
            } else {
                $newsdate =  date('Y-m-d h:i:s');
                $ins = array(
                    'email' => $email,
                    'created'           => $newsdate,
                    'status' => '1'
                );
                // var_dump($ins);
                // $checkEMail = getRecordByEmail('email_subscriber', $email);
    // var_dump($checkEMail);
                // if (empty($checkEMail)) {
                   $return= addUpdateRecord('email_subscriber', '', '', $ins);
                // }
                if ($return) {
                $data["success"] = "Your email subscribed successfully.";
                }
            }
            echo json_encode($data);
        }
    }

    function search($cat_id = 0)
    {
        $i = 0;
        if ($cat_id > 0) {
            $data['getCatInfo'] = $this->home_model->getcategoryInfo($cat_id);
             //$data['getSubCatInfo'] = $this->home_model->getsubcategoryInfo($sub_id);
            $data['breadcrumb_data'][$i]['url'] = '';
            $data['breadcrumb_data'][$i]['titel'] = $data['getCatInfo']['title'];
           // $data['breadcrumb_data'][$i]['titel'] = $data['getCatInfo']['getSubCatInfo']['title'];
            $i++;
            //  echo "<pre>";print_r($data);die;
        }

        $country = '';
        $state = '';
        $city = '';
        $key = '';

        if ($_POST) {

            if ($_POST['country'] != '') {
                $country = $_POST['country'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_POST['state'] != '') {
                $state = $_POST['state'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_POST['city'] != '') {
                $city = $_POST['city'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }

            if ($_POST['key'] != '') {
                $key = $_POST['key'];
            }
        }


        if ($_GET) {

            if ($_GET['c'] != '') {
                $country = $_POST['c'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_GET['s'] != '') {
                $state = $_GET['s'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_GET['ci'] != '') {
                $city = $_GET['ci'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }
        }


        $this->load->library("pagination");

        $data['country'] = $country;
        $data['state'] = $state;
        $data['city'] = $city;
        $data['key'] = $key;
        $data['cat_id'] = $cat_id;

        $data['filter_data'] = $this->home_model->get_latest_news_by_id_with_filter($cat_id, $country, $state, $city, $key, 0);
        $data['latest_news'] = $this->home_model->get_latest_news_with_filter($cat_id, $country, $state, $city, $key);
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews_with_filter($cat_id, $country, $state, $city, $key);
        $data['recientView'] = $this->home_model->getRecientView();
        
        
         // var_dump($data[0]['id']);
    //  echo $this->db->last_query(); 
    // die;
    //     $data['adds_banner'] =  $this->home_model->getAddsBanner($heading);
    //  $data['adds_banner1'] =  $this->home_model->getAddsBanner1($heading);
    //  $data['adds_banner2'] =  $this->home_model->getAddsBanner2($heading);
    //  $data['subcate'] =  $this->home_model->getNewsSubcate($heading);

        defaultLoadView('home/search2', $data);
    }

    function getCountrySate()
    {
        $this->load->model('admin/news_model');
        $allcountryState = array();
        if ($_POST['country_id']) {
            $allcountryState = $this->news_model->getAllCountrystateByName($_POST['country_id']);
            // echo $this->db->last_query();die;
        }
        echo json_encode($allcountryState);
    }
    
    function getSateCity()
    {
        $this->load->model('admin/news_model');
        $allcountryState = array();
        if ($_POST['country_id']) {
            $allcountryState = $this->news_model->getAllStateCityByName($_POST['country_id']);
        }
        echo json_encode($allcountryState);
    }

    function news_all_view($cat_id)
    {
        if ($cat_id > 0) {
            $data['getCatInfo'] = $this->home_model->getcategoryInfo($cat_id);
        }
        $country = '';
        $state = '';
        $city = '';
        $key = '';
        $i = 0;
        if ($_POST) {

            if ($_POST['country'] != '') {
                $country = $_POST['country'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_POST['state'] != '') {
                $state = $_POST['state'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_POST['city'] != '') {
                $city = $_POST['city'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }

            if ($_POST['key'] != '') {
                $country = $_POST['key'];
            }
        }

        $data['breadcrumb_data'][$i]['url'] = '';
        $data['breadcrumb_data'][$i]['titel'] = $data['getCatInfo']['title'];
        $i++;


        $data['country'] = $country;
        $data['state'] = $state;
        $data['city'] = $city;
        $data['key'] = $key;
        $data['cat_id'] = $cat_id;
        $data['getCatInfo'] = $this->home_model->getcategoryInfo($cat_id);
        $data['filter_data'] = $this->home_model->get_latest_news_by_id_with_filter($cat_id, $country, $state, $city, $key, 25);
        $data['latest_news'] = $this->home_model->get_latest_news_with_filter($cat_id, $country, $state, $city, $key);
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews_with_filter($cat_id, $country, $state, $city, $key);
        $data['recientView'] = $this->home_model->getRecientView();

        defaultLoadView('home/search2_all', $data);
    }


    function news_view($id,$url='')
    {
        $data['preview_action'] = '0';
        $data['show_google_translater'] = '1';
        if($_GET['preview']){
            $preview_user_id = base64_decode($_GET['preview']);
            if($preview_user_id==$this->session->userdata('user_id')){
                $data['preview_action'] = '1';
                $data['news'] = $news = $this->home_model->getNewsInfo($id,'preview');
            }
        }else{
            $data['news'] = $news = $this->home_model->getNewsInfo($id);
        }
        
        $country = '';
        $state = '';
        $city = '';
        $key = '';
        $i = 0;

        if(!$news){
            redirect('home');
        }

        if ($_GET) {
            if ($_GET['c'] != '') {
                $country = $_POST['c'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_GET['s'] != '') {
                $state = $_GET['s'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_GET['ci'] != '') {
                $city = $_GET['ci'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }
        }

        if ($news['categorise'] > 0) {
            $data['getCatInfo'] = $getCatInfo = $this->home_model->getcategoryInfo($news['categorise']);
            $data['getSubCatInfo'] = $getSubCatInfo = $this->home_model->getsubcategoryInfo($news['child_categorise']);
            $data['breadcrumb_data'][$i]['url'] = base_url().'home/search/'.$news['id'];
            $data['breadcrumb_data'][$i]['titel'] = $getCatInfo['title'];
            $i++;
        }

        if ($news) {
            if ($news['country'] != '') {
                $country = $news['country'];
                $data['breadcrumb_data'][$i]['url'] = base_url().'home/search?c='.urlencode($country);
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($news['state'] != '') {
                $state = $news['state'];
                $data['breadcrumb_data'][$i]['url'] = base_url().'home/search?s='.urlencode($state);
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($news['city'] != '') {
                $city = $news['city'];
                $data['breadcrumb_data'][$i]['url'] = base_url().'home/search?ci='.urlencode($city);
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }
        }

        $data['breadcrumb_data'][$i]['url'] = '';
        $data['breadcrumb_data'][$i]['titel'] = $news['title'];
        $i++;


        if ($news) {

            $insertData = array();
            $insertData['date'] = date('Y-m-d h:i:s');
            $insertData['news_id'] = $news['id'];
            $insertData['country'] = $news['country'];
            $insertData['state'] = $news['state'];
            $insertData['city'] = $news['city'];
            $insertData['user_id'] = $this->session->userdata('user_id');
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip_address = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip_address = $_SERVER['REMOTE_ADDR'];
            }
            $insertData['ip'] = $ip_address;
            $return = addUpdateRecord('populer_news', '', '', $insertData);
        }

        $data['news_count']  = $this->home_model->getNewsViewById($news['id']);
        $data['recientView'] = $this->home_model->getRecientView();
        $_SESSION['recient_view'][] = $news['id'];

        $data['latest_news'] = $this->home_model->get_latest_news_with_filter($news['categorise'], $country, $state, $city, '');
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews_with_filter($news['categorise'], $country, $state, $city, '');
        defaultLoadView('home/news_view', $data);
    }
    
    
    function ajax_news_view($id,$url='')
    {
        $data['preview_action'] = '0';
        $data['show_google_translater'] = '1';
        if($_GET['preview']){
            $preview_user_id = base64_decode($_GET['preview']);
            if($preview_user_id==$this->session->userdata('user_id')){
                $data['preview_action'] = '1';
                $data['news'] = $news = $this->home_model->getNewsInfo($id,'preview');
            }
        }else{
            $data['news'] = $news = $this->home_model->getNewsInfo($id);
        }
        
        $country = '';
        $state = '';
        $city = '';
        $key = '';
        $i = 0;

        if(!$news){
            redirect('home');
        }

        if ($_GET) {
            if ($_GET['c'] != '') {
                $country = $_POST['c'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_GET['s'] != '') {
                $state = $_GET['s'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_GET['ci'] != '') {
                $city = $_GET['ci'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }
        }

        if ($news['categorise'] > 0) {
            $data['getCatInfo'] = $getCatInfo = $this->home_model->getcategoryInfo($news['categorise']);
            $data['getSubCatInfo'] = $getSubCatInfo = $this->home_model->getsubcategoryInfo($news['child_categorise']);
            $data['breadcrumb_data'][$i]['url'] = base_url().'home/search/'.$news['id'];
            $data['breadcrumb_data'][$i]['titel'] = $getCatInfo['title'];
            $i++;
        }

        if ($news) {
            if ($news['country'] != '') {
                $country = $news['country'];
                $data['breadcrumb_data'][$i]['url'] = base_url().'home/search?c='.urlencode($country);
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($news['state'] != '') {
                $state = $news['state'];
                $data['breadcrumb_data'][$i]['url'] = base_url().'home/search?s='.urlencode($state);
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($news['city'] != '') {
                $city = $news['city'];
                $data['breadcrumb_data'][$i]['url'] = base_url().'home/search?ci='.urlencode($city);
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }
        }

        $data['breadcrumb_data'][$i]['url'] = '';
        $data['breadcrumb_data'][$i]['titel'] = $news['title'];
        $i++;


        if ($news) {

            $insertData = array();
            $insertData['date'] = date('Y-m-d h:i:s');
            $insertData['news_id'] = $news['id'];
            $insertData['country'] = $news['country'];
            $insertData['state'] = $news['state'];
            $insertData['city'] = $news['city'];
            $insertData['user_id'] = $this->session->userdata('user_id');
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip_address = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip_address = $_SERVER['REMOTE_ADDR'];
            }
            $insertData['ip'] = $ip_address;
            $return = addUpdateRecord('populer_news', '', '', $insertData);
        }

        $data['news_count']  = $this->home_model->getNewsViewById($news['id']);
        $data['recientView'] = $this->home_model->getRecientView();
        $_SESSION['recient_view'][] = $news['id'];

        $data['latest_news'] = $this->home_model->get_latest_news_with_filter($news['categorise'], $country, $state, $city, '');
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews_with_filter($news['categorise'], $country, $state, $city, '');
        $this->load->view('home/ajax_news_view', $data);
    }
    
    
    public function newslike()
    {
        $like = $this->input->post('likeid');
        $ip = $this->input->post('ip');
        $data = array(
         'newsid' => $like,
         'ip' => $ip,
         'like' => 1
        );
        //print_r($data);die;
        $this->db->select('*');
        $this->db->from('news_like');
        $this->db->where('ip', $ip);
        $this->db->where('newsid', $like);
        $getdata = $this->db->get();
        $coutrow = $getdata->num_rows();
        if($coutrow  > 0)
        {

        } else
        {
            $this->db->insert('news_like', $data);

        }
    }
    function allnews($cat_id = 0)
    {
       
        $i = 0;
        if ($cat_id > 0) {
            $data['getCatInfo'] = $this->home_model->getcategoryInfo($cat_id);
            $data['breadcrumb_data'][$i]['url'] = '';
            $data['breadcrumb_data'][$i]['titel'] = $data['getCatInfo']['title'];
            $i++;
        }

        $country = '';
        $state = '';
        $city = '';
        $key = '';

        if ($_POST) {
            

            if ($_POST['country'] != '') {
                $country = $_POST['country'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_POST['state'] != '') {
                $state = $_POST['state'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_POST['city'] != '') {
                $city = $_POST['city'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }

            if ($_POST['key'] != '') {
                $key = $_POST['key'];
            }
        }


        if ($_GET) {

            if ($_GET['c'] != '') {
                $country = $_POST['c'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $country;
                $i++;
            }

            if ($_GET['s'] != '') {
                $state = $_GET['s'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $state;
                $i++;
            }

            if ($_GET['ci'] != '') {
                $city = $_GET['ci'];
                $data['breadcrumb_data'][$i]['url'] = '';
                $data['breadcrumb_data'][$i]['titel'] = $city;
                $i++;
            }
        }
         

        $this->load->library("pagination");

        $data['country'] = $country;
        $data['state'] = $state;
        $data['city'] = $city;
        $data['key'] = $key;
        $data['cat_id'] = $cat_id;

$country=$_GET['country'];
$state=$_GET['state'];
$city=$_GET['city'];
$key=$_GET['key'];



$q1="select * from latest_news where";  

if(!empty($country) && $country!='null') 
{
    $q2 = " country = '$country'";
    if($state!='' && $state!='null' || !empty($city) || !empty($key))
    {
        $q3= " and";
    }
} 
if(!empty($state) && $state!='null') 
{
    $q4 = " state = '$state'";
    if(!empty($city) || !empty($key))
    {
        $q5 = " and";
    }
} 
if(!empty($city) && $city!='null') 
{
    $q6 = " city = '$city'";
    if(!empty($key))
    {
        $q7 = " and";
    }
} 
if(!empty($key)) 
{
    $q8 = " title LIKE '%$key%'";
} 


$qq = $q1.$q2.$q3.$q4.$q5.$q6.$q7.$q8;
 //  echo $qq;die;
   if($qq == "select * from latest_news where"){
       
          echo "<script>alert('please search something')</script>";
          echo "<script>window.location.href = 'http://newssyn.com'</script>";
             
       
   }else{
       $query = $this->db->query($qq);
    $data['filter_data'] = $query->result_array();
    // echo "<pre>";
    // print_r($data['filter_data']);die;
       

       //  echo "bdfgfdg";die;
        // $data['filter_data'] = $this->home_model->get_latest_news_by_id_with_filter($cat_id, $country, $state, $city, $key, 0);
        $data['latest_news'] = $this->home_model->get_latest_news_with_filter($cat_id, $country, $state, $city, $key);
        $data['populer_news'] = $this->home_model->getHomePagesPopulerNews_with_filter($cat_id, $country, $state, $city, $key);
        $data['recientView'] = $this->home_model->getRecientView();
        
      

        defaultLoadView('home/search', $data);
      
         
        
   }
    
    }
    
    
    
    public function Allcategories()
    {
        defaultLoadView('all_category');
    }
    
    function getCountrySate1()
    {
        // echo "<pre>";print_r($_POST);die;
        $this->load->model('admin/news_model');
        $allcountryState = array();
        if ($_POST['country_id']) {
            $allcountryState = $this->news_model->getAllCountrystateByName1($_POST['country_id']);
            // echo $this->db->last_query();die;
        }
        echo json_encode($allcountryState);
    }
    
    
    
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
