<?php

//error_reporting(0);

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Team extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
        $this->load->helper('custom_helper');
        $this->load->model('admin/team_model');
        $this->load->model('news_model');
    }

    public function index()
    {
        $arr['page'] = 'user';
        $arr['msg'] = '';
        if ($_POST) {
            if (!empty($_POST['chk'])) {
                $arr = array();
                $delete_user = '0';
                if ($_POST['action'] == 'active') {
                    $arr = array('status' => 1);
                    $data['msg'] = 'active';
                } else if ($_POST['action'] == 'deactive') {
                    $arr = array('status' => 0);
                    $data['msg'] = 'deactive';
                }else if ($_POST['action'] == 'delete') {
                    $data['msg'] = 'delete';    
                    $delete_user = '1';
                }else if ($_POST['action'] == 'sendmail') {
                    $data['msg'] = 'sendmail';
                    $send_mail = 'sendmail';
                }
                
                foreach ($_POST['chk'] as $id) {
                    if($send_mail=='sendmail'){
                        //echo '****';
                    }else if($delete_user == '1'){
                        $delete = deleteRecordById('users', $id);
                        if ($delete) {
                            $this->session->set_flashdata('success', 'Users deleted successfully.');
                        }
                    }else{
                        if(!empty($arr)){
                            $this->db->where('id', $id);
                            $this->db->update('team', $arr);
                        }
                    }
                }
            }
        }
        
        $users = $this->team_model->getUsers();
        $data['users'] = $users;
        $this->load->view('admin/team/vwManageUser', $data);
    }

    /*
    public function add_newuser() {
        $arr['page'] = 'user';
        $this->load->view('admin/users/vwAddNewUser',$arr);
    }
	*/


    function add_newmember()
    {

        $this->load->model('regusers_model');
        $this->load->model('user_model');
        $user = array();
        
        date_default_timezone_set('Asia/Kolkata');
        $dates= date('d-m-Y');
        
        

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('name', 'Name', 'required|trim');
            $this->form_validation->set_rules('phone', 'Mobile no', 'required|trim|numeric');
            $this->form_validation->set_rules('email', 'email address', 'trim|required|valid_email');
            $this->form_validation->set_rules('designation', 'Designation', 'required|trim');

            if ($this->form_validation->run()) {

                $data_to_store = array(
                    'name' => $this->input->post('name'),
                    'email' => filter_var(trim($this->input->post('email')),FILTER_SANITIZE_EMAIL),
                    'phone' => $this->input->post('phone'),
                    'designation' => $this->input->post('designation'),
                    'department_id' => $this->input->post('department'),
                    'description' => $this->input->post('description'),
                    'status' => 1
                );
                
                if($_FILES["profile_image"]["name"]!="" && in_array(pathinfo($_FILES["profile_image"]["name"],PATHINFO_EXTENSION), array("jpg", "jpeg", "png", "wevp"))){
                    $img_name = substr($_FILES["profile_image"]["name"], 0, -6).date("YmdHis").mt_rand(10000,99999).".".pathinfo($_FILES["profile_image"]["name"],PATHINFO_EXTENSION);
                    $imgfile = "upload/team_pic/".$img_name;
                    if(move_uploaded_file($_FILES["profile_image"]["tmp_name"],$imgfile)){
                        $data_to_store["profile_image"] = $imgfile;
                    }
                }
                // echo "<pre>";print_r($data_to_store);die;
                if ($this->team_model->insert_member($data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/team');
            } else {
                $data["user"] = $_POST;
            }
        }

        $alldepartments = $this->db->select("id,department")->from('departments')->get()->result();
        // echo $this->db->last_query();die;
        $data['id'] = $id;
        $data['alldepartments'] = $alldepartments;
        $this->load->view('admin/team/vwAddNewUser', $data);
    }

    public function edit_member($id)
    {
        $this->load->model('team_model');
        $user = $this->team_model->getRecordById($id);

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->load->library('form_validation');

            
            $this->form_validation->set_rules('name', 'Name', 'required|trim');
            $this->form_validation->set_rules('phone', 'Mobile no', 'required|trim|numeric');
            $this->form_validation->set_rules('email', 'email address', 'trim|required|valid_email');
            $this->form_validation->set_rules('designation', 'Designation', 'required|trim');

            if ($this->form_validation->run()) {

                $data_to_store = array(
                    'name' => $this->input->post('name'),
                    'email' => filter_var(trim($this->input->post('email')),FILTER_SANITIZE_EMAIL),
                    'phone' => $this->input->post('phone'),
                    'designation' => $this->input->post('designation'),
                    'department_id' => $this->input->post('department'),
                    'uploaded_file' => $this->input->post('old_dp_pic'),
                    'description' => $this->input->post('description'),
                );
                //   echo "<pre>";print_r($data_to_store);die;
                if($_FILES["dp_pic"]["name"]!="" && in_array(pathinfo($_FILES["dp_pic"]["name"],PATHINFO_EXTENSION), array("jpg", "jpeg", "png", "wevp"))){
                    $img_name = substr($_FILES["dp_pic"]["name"], 0, -6).date("YmdHis").mt_rand(10000,99999).".".pathinfo($_FILES["dp_pic"]["name"],PATHINFO_EXTENSION);
                    $imgfile = "upload/team_pic/".$img_name;
                    if(move_uploaded_file($_FILES["dp_pic"]["tmp_name"],$imgfile)){
                        $data_to_store["dp_pic"] = $imgfile;
                    }
                    unlink(trim($_POST["old_dp_pic"]));
                }

                if ($this->team_model->update_member($id, $data_to_store) == TRUE) {
                    $this->session->set_flashdata('flash_message', 'Details successfully submitted.');
                } else {
                    $this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
                }
                redirect('admin/team');
            } else {
                $user = $_POST;
            }
        }

        $alldepartments = $this->db->select("id,department")->from('departments')->get()->result();
// echo $this->db->last_query();die;
        $data['id'] = $id;
        $data['alldepartments'] = $alldepartments;
        $data['user']  = $user;
        $this->load->view('admin/team/vwEditUser.php', $data);
    }

    public function delete_member($user_id)
    {
        if (empty($user_id)) {
            redirect('team');
        }
        $image = $this->db->select("picture")->from("team")->where("id",$user_id)->get();
        $delete = deleteRecordById('team', $user_id);
        if ($delete) {
            $this->session->set_flashdata('success', 'Users deleted successfully.');
        }
        redirect('admin/team');
    }

    function list_users_ajax($msg = '') {
        
        $sort = array('id', 'first_name', 'last_name', 'email', 'user_ip');
        if ($_POST['sSearch']) {
            $search = " WHERE first_name LIKE '%" . $_POST['sSearch'] . "%' OR last_name LIKE '%" . $_POST['sSearch'] . "%' OR email LIKE '%" . $_POST['sSearch'] . "%' OR user_ip LIKE '%" . $_POST['sSearch'] . "%'";
        } else {
            $search = '';
        }
        if ($sort[$_POST['iSortCol_0']]) {
            $order = " ORDER BY " . $sort[$_POST['iSortCol_0']] . " " . $_POST['sSortDir_0'];
        }
        $get['limit'] = $_POST['iDisplayLength'];
        $get['fields'] = '*';
        $get['offset'] = $_POST['iDisplayStart'];
        $get['search'] = $search;
        $get['order'] = $order;
        $row = $this->users_model->getUsers($get);
        $res = array();

        foreach ($row as $k => $r) {
            $res[$k]['checkbox'] = '<input type="checkbox" class="checkbox1" name="chk[]" value="' . $r['id'] . '" />';
            $res[$k]['first_name'] = $r['first_name'] .' '.$r['last_name'];
            
            /* $res[$k]['email'] =
              '<a href="' .base_url() .'admin/admin_user/event_user/?id='.$r['id'].'' . $r['id'] . '" onclick="fillModel(this)">'.$r['email'].'</a>'; */

            $res[$k]['email'] = $r['email'];

            /* $res[$k]['email'] = '<a href="#" onclick="setEmail(this);" email="' . $r['email'] . '"  id="m_window"  data-toggle="modal" data-target="#myModal">' . $r['email'] . '</a>'; */
            //$res[$k]['first_name'] = $r['first_name'];
            //$res[$k]['user_ip'] = $r['user_ip'];
            //$res[$k]['events'] = '<a href="' . base_url() . 'admin/users/event_user/' . $r['id'] . '"><img width=" " height=" " alt=" " src="' . base_url() . 'admin_images/event.png"></img></a>';
            //$res[$k]['purchase'] = '<a href="' . base_url() . 'admin/users/purchase_user/' . $r['id'] . ' "><img width=" " height=" " alt=" " src="' . base_url() . 'admin_images/ticketimg.png"></img></a>';
            //$res[$k]['multi_users'] = '<a href="' . base_url() . 'admin/users/list_multi_users/' . $r['id'] . '"><img width=" " height=" " alt=" " src="' . base_url() . 'admin_images/accountimg.png"></img></a>';
            
            if ($r['user_status'] == 'A')
                $res[$k]['user_status'] = '<div style="text-align:center"><img title="Active User" alt="Active User" src="' . base_url() . 'admin_images/active.jpg"></img></div>';
            else
                $res[$k]['user_status'] = '<div style="text-align:center"><img title="Disabled User" alt="Disabled User" src="' . base_url() . 'admin_images/deactive.jpg"></img></div>';
            
            //$res[$k]['active'] = ($r['active']==1)?'Active':'Inactive';

            /*
            $res[$k]['action'] = '<a href="' . base_url() . 'admin/users/earning/0/' . $r['id'] . '">Earnings</a> /
            <a href="' . base_url() . 'admin/users/view_user/' . $r['id'] . '">View</a> /
            <a href="' . base_url() . 'admin/users/edit_user/' . $r['id'] . '">Edit</a> /
            <a href="' . base_url() . 'admin/users/refferal_user/' . $r['id'] . '">User Referral</a>';
            */
            
            $res[$k]['action'] = '<a href="' . base_url() . 'admin/users/my_news/' . $r['id'] . '">News</a> / <a href="' . base_url() . 'admin/users/edit_user/' . $r['id'] . '">Edit</a>';
        }
        $data['data'] = $res;
        //$data['draw'] = 1;
        $data['recordsTotal'] = count($data['data']);
        $data['recordsFiltered'] = count($this->users_model->getAllData());
        echo json_encode($data);
    }


}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
