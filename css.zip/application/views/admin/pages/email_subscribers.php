<!--
<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
-->
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
<script type="text/javascript" src="http://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>

<?php
	if (!empty($postData)) {
		$name 		= $postData['name'];
		$discription= $postData['discription'];
		$link 		= $postData['link'];
		$status 	= $postData['status'];
	}
	
?>

<div class="outter-wp">
	<!--/sub-heard-part-->
	<div class="sub-heard-part">
		<ol class="breadcrumb m-b-0">
			<li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
			<li class="active">Emails</li>
		</ol>
		<button type="button" class="btn btn-danger btn-sm" onclick="setaction('chk[]','email', '<?php echo 'Are you sure you want to Email selected Subscriber'; ?>', 'frm_listpage')"><?php echo 'Email'; ?></button>
	</div>
	<div class="graph-visual tables-main">
		<h3 class="inner-tittle two">Emails </h3>
		<?php if(!empty($this->session->flashdata('success')))
                        { ?>
                        <div class="alert alert-success" role="alert">
                        <?php echo $this->session->flashdata('success'); ?>
                        </div>
                        <?php } ?>
                        <?php if(!empty($this->session->flashdata('invalid')))
                        { ?>
                        <div class="alert alert-danger" role="alert">
                        <?php echo $this->session->flashdata('invalid'); ?>
                        </div>
                        <?php } ?>
			<div class="alert alert-success message-success" style="display: none;"></div>
			<?php
//   $attributes = array('name' => 'frm_listpage', 'id' => 'frm_listpage');
//   echo form_open('admin/email_subscribers/', $attributes);
  ?>
  <input type="hidden" name="action" id="action" />
		<div class="graph">
			<div class="tables">
           
				<table class="display responsive" id="example-table">
				<thead> 
					<tr> 
						<th>Id <input type="checkbox" id="selecctall"></th> 
						<th width="200px" >Email</th>
						<th>Date</th>
						<th>Status</th>
						<th>Change Status</th>  
					</tr> 
				</thead>
					<?php
						$i=0;
						foreach ($email_subscribers as $key => $sub) {
							$status = (!empty($sub['status']) && $sub['status'] == '1') ? 'Active' : 'Deactive';
						$i++; ?>
						<tr> 
						
							<th><?php echo $i; ?> <input type="checkbox" class="checkbox1" name="chk[]" value="<?php echo $sub['email']; ?>" /></th> 
							<th><?php echo $sub['email']; ?></th>
							<th><?php echo date('M d, Y h:i a', strtotime($sub['created'])); ?></th>
							<th id="status_<?php echo $sub['id']; ?>"><?php echo $status; ?></th> 
							<th>
							<select  class="chagne_status" data-id="<?php echo $sub['id']; ?>" style="width:45%">
								<option value="1" <?php echo ($status == 'Active')? 'selected' : ''; ?>>Active</option>
								<option value="0" <?php echo ($status == 'Deactive')? 'selected' : ''; ?>>Dactive</option>
							</select>
							</th>
						</tr>
					<?php }?>
				</table>
			</div>
		</div>
	<!--//graph-visual-->
	</div>
</div>

<script>
	$(".chagne_status").on('change', function() {

		var thisValue 	= $(this).val();
		var dataid 		= $(this).data('id');
		var postUrl 	= "<?php echo base_url(); ?>admin/email_subscribers";
		$.ajax({
			type: "POST",
			url : postUrl,
			data: ({
			    status 	: thisValue,
			    id    	: dataid
	        }),
	       	cache   : false,
	       	dataType: 'json',
	       	success : function(data) {
	       		if (data == 'error') {

	       		} else {
	       			if (thisValue == "1") {
	       				$("#status_"+data).text('Active');
	       			} else {
	       				$("#status_"+data).text('Deactive');
	       			}
	       			$('.message-success').show().text('Status Update Successfully.');
	       		}
	       	}
      	});
	});
   
</script>
<script> 
$(document).ready(function() {
	$('#example-table').DataTable( {
		"pagingType": "full_numbers",
            "lengthMenu": [
              [10, 25, 50, -1],
              [10, 25, 50, "All"]
            ]

	});
});

$(document).ready(function() {

$('#selecctall').click(function(event) { //on click 
  if (this.checked) { // check select status
	$('.checkbox1').each(function() { //loop through each checkbox
	  this.checked = true; //select all checkboxes with class "checkbox1"               
	});
  } else {
	$('.checkbox1').each(function() { //loop through each checkbox
	  this.checked = false; //deselect all checkboxes with class "checkbox1"           
	});
  }
});



});



function setaction(elename, actionval, actionmsg, formname) {

		vchkcnt = 0;
		elem = document.getElementsByName(elename);

		for (i = 0; i < elem.length; i++) {

			if (elem[i].checked) vchkcnt++;

		}

		if (vchkcnt == 0) {

			alert('<?php echo PLEASE_SELECT_A_RECORD; ?>')

		} else {

			if (confirm(actionmsg))

			{
				document.getElementById('action').value = actionval;

				document.getElementById(formname).submit();
			}

		}


	}
</script>