<!DOCTYPE html>
<html>

<head>
    <!-- Site made with Newssyn.com Website Builder v4.12.3, # -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, user-scalable=no">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>images/logo.jpg" type="image/x-icon">
    <meta name="description" content="">
    <title>The News Synthesis: New Way of Journalism</title>
    <link href="<?php echo base_url(); ?>assets/select2/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/mobirise-icons/mobirise-icons.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/mobirise-icons-bold/mobirise-icons-bold.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/mobirise-icons2/mobirise2.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap-reboot.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dropdown/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/tether/tether.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/socicon/css/styles.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/theme/css/style.css">
    <link rel="preload" as="style" href="<?php echo base_url(); ?>assets/mobirise/css/mbr-additional.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/mobirise/css/mbr-additional.css" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css" type="text/css">
    <script src="<?php echo base_url(); ?>assets/web/assets/jquery/jquery.min.js"></script>
</head>
<?php
$allcategories = get_blog_categories();
$allcountry = getAllCountry();
//$allcountryState = getAllCountrystate(101);
?>
<style>
    div#navbarSupportedContent {
        padding: 10px 0px;
        opacity: 1;
        float: left;
        text-align: left;
        width: 100%;
    }

    .cid-qTkzRZLJNu .nav-item a {
        justify-content: left;
    }

    #google_translate_element {
        padding: 10px;
    }

    .cid-qTkzRZLJNu .btn {
        display: table;
    }

    section {
        overflow: hidden;
    }



    :focus {
        outline: -webkit-focus-ring-color auto 0px;
        outline-color: -webkit-focus-ring-color;
        outline-style: auto;
        outline-width: 0px;
    }
</style>

<body>
    <section class="menu cid-qTkzRZLJNu" once="menu" id="menu1-0">
        <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>
            <div class="menu-logo">
                <div class="navbar-brand">
                    <span class="navbar-logo">
                        <a href="<?php echo base_url(); ?>">
                            <img src="<?php echo base_url(); ?>images/logo.jpg" alt="Agcnn.com" title="Agcnn.com" style="height:50px">
                        </a>
                    </span>
                    <span class="navbar-caption-wrap">
                        <a class="navbar-caption text-black display-5" href="<?php echo base_url(); ?>"><strong style="font-size: 43px;">A</strong>GCNN NEWS</a>
                        <!-- <a href="<?php echo base_url(); ?>">
                            <img src="<?php echo base_url(); ?>assets/images/logo-name.png" alt="Agcnn.com" title="Agcnn.com" style="height:50px">
                        </a> -->

                    </span>
                    <span class="subheadingText">
                        The Voice of People
                    </span>
                </div>
            </div>
            <div class="col-sm-12 headerMobilecontaner m-0">
                <ul class="headerMobileMenu p-0">
                    <!-- <li>
                        <div style="margin-right: 10px;" id="google_translate_element2xx"></div>
                    </li> -->

                    <!-- <li >
                            <a href="<?php echo base_url(); ?>terms">Terms & Condition</a>
                        <li>
                        <li> | </li>
                    <li> -->
                    <?php if (check_user_authentication() == true) { ?>
                        <a class="" href="<?php echo base_url('news/addNews'); ?>">
                            Add News
                        </a>
                    <?php } else { ?>
                        <a class="" href="<?php echo base_url('user/login?page=' . base64_encode('addNews')); ?>">
                            Upload News
                        </a>
                    <?php } ?>
                    </li>
                    <li> | </li>

                    <?php if (check_user_authentication() == true) { ?>
                        <?php if (my_news_count($this->session->userdata('user_id')) > 0) { ?>
                            <li>
                                <a class="" href="<?php echo base_url('news/my_news'); ?>">
                                    My News
                                </a>
                            </li>
                            <li> | </li>
                        <?php } ?>

                        <li>
                            <a href="<?php echo base_url('user/profile_view'); ?>">
                                <span> Hello
                                    <?php
                                    $fName = $this->session->userdata('user_name');
                                    $lName = $this->session->userdata('last_name');
                                    echo ucfirst($fName) . ' ' . ucfirst($lName);
                                    ?>
                            </a>
                        </li>
                        <li> | </li>
                        <li>
                            <a onclick="signOut();">
                                <span> Logout
                            </a>
                        </li>
                    <?php } else { ?>
                        <li>
                            <a href="<?php echo base_url('user/login'); ?>">
                                <span></span> Login
                            </a>
                        </li>
                        <li> | </li>
                        <li>
                            <a href="<?php echo base_url('user/signup') ?>">
                                <span></span> Signup
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <?php if ($show_google_translater != '1') { ?>
                    <div style="margin-right: 10px;" id="google_translate_element"></div>
                <?php } ?>
                <div class="navbar-buttons mbr-section-btn">
                    <?php if (check_user_authentication() == true) { ?>
                        <a class="btn btn-sm btn-secondary display-4" href="<?php echo base_url('news/addNews'); ?>">
                            Add News
                        </a>
                    <?php } else { ?>
                        <a class="btn btn-sm btn-secondary display-4" href="<?php echo base_url('user/login?page=' . base64_encode('addNews')); ?>">
                            Upload News
                        </a>
                    <?php } ?>
                </div>
                <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
                    <!-- <li class="nav-item">
                        <a class="nav-link link text-black display-4" href="#">
                            <span class="mbri-home mbr-iconfont mbr-iconfont-btn"></span>
                            Services
                        </a>
                    </li> -->
                    <!-- <li class="nav-item" >
                            <a class="nav-link link text-black display-4" href="<?php echo base_url(); ?>terms"><span class="mbri-file"></span> Terms & Condition</a>
                        <li>
                        <li class="nav-item">
                            <a class="nav-link link text-black display-4" href="<?php echo base_url(); ?>home/page/privacy-policy"><span class="mbri-setting"></span> Privacy Policy</a>
                        <li> -->

                    <?php if (check_user_authentication() == true) { ?>

                        <?php if (my_news_count($this->session->userdata('user_id')) > 0) { ?>
                            <li class="nav-item">
                                <a class="nav-link link text-black display-4" href="<?php echo base_url('news/my_news'); ?>">
                                    <span class="mbri-file mbr-iconfont mbr-iconfont-btn"></span>
                                    My News
                                </a>
                            </li>
                        <?php } ?>

                        <li class="nav-item <?php echo ($page_active == 'order') ? "active-tab" : ""; ?>">
                            <a href="<?php echo base_url('user/profile_view'); ?>" class="nav-link link text-black display-4">
                                <span class="mbri-user"> Hello
                                    <?php
                                    $fName = $this->session->userdata('user_name');
                                    $lName = $this->session->userdata('last_name');
                                    echo ucfirst($fName) . ' ' . ucfirst($lName);
                                    ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link link text-black display-4" onclick="signOut();">
                                <span class="mbri-logout"> Logout
                            </a>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item <?php echo ($page_active == 'login') ? "active-tab" : ""; ?>">
                            <a class="nav-link link text-black display-4" href="<?php echo base_url('user/login'); ?>">
                                <span class="mbri-lock"></span> Login
                            </a>
                        </li>
                        <li class="nav-item <?php echo ($page_active == 'new_account') ? "active-tab" : ""; ?>">
                            <a class="nav-link link text-black display-4" href="<?php echo base_url('user/signup') ?>">
                                <span class="mbri-user"></span> Signup
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </nav>

    </section>

    <section class="header15 cid-rUENmQmr8c mbr-parallax-background" id="header15-x">
        <div class="mbr-overlay" style="opacity:1; background-color: rgb(25, 35, 46);"></div>
        <div class="container align-right">
            <div class="row">
                <div class="mbr-white col-lg-8 col-md-7 content-container">
                </div>
                <div class="col-lg-12 col-md-12">
                    <div class="form-container">
                        <div class="media-container-column" data-form-type="formoid">
                            <!---Formbuilder Form--->
                            <div class="row">
                                <div hidden="hidden" data-form-alert="" class="alert alert-success col-12">Thanks for filling out the form!</div>
                                <div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">
                                </div>
                            </div>
                            <div class="dragArea row">
                                <div id="search_contaner" class="col-md-12 col-lg-12 col-sm-12" style="display: none;">
                                    <div class="row">
                                        <div class="col-md-3 form-group has-search" data-for="name">
                                            <!-- <input type="text" name="name" placeholder="Country" data-form-field="Name" required="required" class="form-control px-3 display-7" id="name-header15-x">
                                        <button class="fa fa-search form-control-feedback"></button> -->
                                            <!-- <div class="col-md-12 pull-left"> -->
                                            <select class="form-control px-3 display-7 js-example-basic-single" style="width: 86%" id="country" name="country" onchange="getcountrystate(this.value);">
                                                <option value=""></option>
                                                <?php foreach ($allcountry as $country) {
                                                    $selected = '';
                                                    if ($this->input->post('country') != '') {
                                                        if ($this->input->post('country') == $country->name) {
                                                            $selected = ' selected="selected" ';
                                                        }
                                                    }
                                                ?>
                                                    <option <?php echo $selected; ?> value="<?php echo $country->name; ?>"><?php echo $country->name; ?></option>
                                                <?php } ?>
                                            </select>
                                            <a onclick="submitSearchForm();" style="float:left">
                                                <i class="fa fa-search" style="font-size:20px;color:#FFF;margin-top: 10px;"></i>
                                            </a>
                                            <!-- </div> -->
                                        </div>
                                        <div class="col-md-3 form-group has-search" data-for="email">
                                            <!-- <input type="email" name="email" placeholder="State" data-form-field="Email" required="required" class="form-control px-3 display-7" id="email-header15-x">
                                        <span class="fa fa-search form-control-feedback"></span> -->
                                            <select class="form-control px-3 display-7" onchange="setStateCity(this.value)" style="width: 86%;float:left" id="state" name="state">
                                                <?php foreach ($allcountryState as $state) { ?>
                                                    <option value="<?php echo $state->name; ?>"><?php echo $state->name; ?></option>
                                                <?php } ?>
                                            </select>
                                            <a onclick="submitSearchForm();" style="float:left">
                                                <i class="fa fa-search" style="font-size:20px;color:#FFF;margin-top: 10px;"></i>
                                            </a>
                                        </div>
                                        <div data-for="phone" class="col-md-3 form-group has-search">
                                            <!--<input type="tel" name="city" placeholder="City" style="width: 80%;float:left;min-height: 28px;height: 28px;" data-form-field="Phone" value="" class="form-control px-3 display-7" id="city"> -->
                                            <select class="form-control px-3 display-7" style="width: 86%;float:left" id="city" name="city">
                                                <option value=""></option>
                                            </select>
                                            <!-- <a onclick="submitSearchForm();" style="float:left">
                                        <i class="fa fa-arrow-circle-right" style="font-size:28px;color:green;margin-top: 6px;"></i>
                                    </a> -->
                                            <a onclick="submitSearchForm();" style="float:left">
                                                <i class="fa fa-search" style="font-size:20px;color:#FFF;margin-top: 10px;"></i>
                                            </a>
                                        </div>
                                        <div class="col-md-3 form-group has-search">
                                            <input type="tel" name="key" placeholder="Search News" style="width:86%;float:left;min-height:28px;height:28px;border-radius:5px;margin:4px 10px 8px 0px;" data-form-field="Phone" value="<?php if ($this->input->post('key') != '') {
                                                                                                                                                                                                                                            echo $this->input->post('key');
                                                                                                                                                                                                                                        } ?>" class="form-control px-3 display-7" id="key">
                                            <a onclick="submitSearchForm();" style="float:left">
                                                <i class="fa fa-search" style="font-size:20px;color:#FFF;margin-top: 10px;"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div id="search_laoder" class="col-md-12 col-lg-12 col-sm-12" style="margin: 0 auto;text-align: center;">
                                    <div class="spinner-border text-light" role="status">
                                        <span class="sr-only">Loading...</span>
                                    </div>
                                </div>
                            </div>
                            <!---Formbuilder Form--->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="cid-rUENmQmr8c mbr-parallax-background main-category_menus">
        <div class="mbr-overlay" style="opacity: 0.8; background-color: rgb(3, 72, 130);"></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col div-for-sub-menu p-1">
                    <?php $homePageArtical = getHomePagesArtical(); ?>
                    <?php foreach ($homePageArtical as $artical) {  ?>

                        <a href="<?php echo base_url() . 'home/search/' . $artical['id'] . '/' . str_replace(' ', '-', $artical['title']); ?>">
                            <?php echo $artical['title']; ?>
                        </a>

                    <?php } ?>
                </div>
            </div>
        </div>
    </section>
    <?php if ($notShowCategory != '1') { ?>
        <section class="features3 cid-rUEHwsmxWt" id="features3-t">
            <div class="container">
                <div class="media-container-row">
                    <div class="card p-1 col-12  col-lg-12 pull-left" style="overflow: auto;">
                        <table class="headerMenuTab">
                            <?php
                            if ($allcategories) {
                                $divider = round((sizeof($allcategories) + 1) / 2);
                                $i = 1;
                                echo '<tr>';
                                echo '<td><a href="' . base_url() . '"><span class="mbri-home mbr-iconfont mbr-iconfont-btn" style="font-size: 12px;margin-right: 3px;"></span>Home</a></td>';
                                foreach ($allcategories as $category) {
                                    if ($i % $divider == 0) {
                                        echo '</tr><tr>';
                                    }
                                    echo '<td><a href="' . base_url() . 'home/search/' . $category['id'] . '">' . $category['title'] . '</a></td>';
                                    $i++;
                                }
                                echo '</tr>';
                            }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    <?php } ?>

    <?php if ($breadcrumb_data) { ?>
        <section class="features13 cid-rUEEK5VpT4" id="features13-q">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                    <?php
                    if ($breadcrumb_data) {
                        foreach ($breadcrumb_data as $link) {
                            if ($link['url'] != '') {
                                echo '<li><a href="' . $link['url'] . '">' . $link['titel'] . '</a></li>';
                            } else {
                                echo '<li>' . $link['titel'] . '</li>';
                            }
                        }
                    }
                    ?>
                    <!-- 
                    <li><a href="#">Pictures</a></li>
                    <li><a href="#">Summer 15</a></li>
                    <li>Italy</li> 
                    -->
                </ul>
            </div>
        </section>
    <?php } ?>
    <style>
        .headerMenuTab a,
        .headerMenuTab a:hover {
            color: #000 !important;
            font-size: 11px;
        }
    </style>
    <script>
        function getcountrystate(id, onload = '', set = '') {

            var postData = {
                country_id: id
            };

            $.ajax({
                url: "<?php echo base_url(); ?>home/getCountrySate",
                data: postData,
                dataType: 'json',
                type: 'POST',
                success: function(result) {

                    $('#state').html('');
                    var output = [];
                    output.push('<option value=""></option>');
                    $.each(result, function(key, value) {
                        output.push('<option value="' + value.name + '">' + value.name + '</option>');
                    });

                    if (output.length > 0) {
                        $('#state').html(output.join(''));
                    } else {
                        $('#state').html('<option value="">No state found</option>');
                    }

                    if (onload == 'load') {
                        <?php
                        if ($this->input->post('state') != '') {
                            echo "$('#state').removeAttr('onchange');";
                            echo "$('#state').val('" . $this->input->post('state') . "');";
                        }
                        if ($this->input->post('city') != '') {
                            echo "$('#city').val('" . $this->input->post('city') . "');";
                        }
                        ?>
                        if (set != '') {
                            $('#state').val(set);
                        }
                    }
                    $('#state').trigger('change');
                }
            });
        }

        function setStateCity(id, onload = '', set = '') {
            //alert(id);
            var postData = {
                country_id: id
            };

            $.ajax({
                url: "<?php echo base_url(); ?>home/getSateCity",
                data: postData,
                dataType: 'json',
                type: 'POST',
                success: function(result) {
                    $('#city').html('');
                    var output = [];
                    output.push('<option value=""></option>');
                    $.each(result, function(key, value) {
                        output.push('<option value="' + value.name + '">' + value.name + '</option>');
                    });
                    if (output.length > 0) {
                        $('#city').html(output.join(''));
                    } else {
                        $('#city').html('<option value="">No city found</option>');
                    }
                    if (onload == 'load') {
                        <?php
                        if ($this->input->post('state') != '') {
                            echo "$('#state').attr('onchange','setStateCity(this.value)');";
                        }
                        if ($this->input->post('city') != '') {
                            //echo 'alert("' . $this->input->post('city') . '");';
                            //echo 'alert("' . $this->input->post('city') . '");';
                            echo "$('#city').val('" . $this->input->post('city') . "');";
                            //echo "$('#state').attr('onchange','setStateCity(this.value)');";
                        }
                        ?>
                        if (set != '') {
                            $('#city').val(set);
                        }
                    }
                    $('#city').trigger('change');
                }
            });
        }

        function submitSearchForm() {
            var method = "post";
            var form = document.createElement("form");
            form.setAttribute("method", method);
            form.setAttribute("action", "<?php echo base_url(); ?>home/search/0/");

            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "country");
            hiddenField.setAttribute("value", $("#country").val());
            form.appendChild(hiddenField);

            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "state");
            hiddenField.setAttribute("value", $("#state").val());
            form.appendChild(hiddenField);

            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "city");
            hiddenField.setAttribute("value", $("#city").val());
            form.appendChild(hiddenField);

            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "key");
            hiddenField.setAttribute("value", $("#key").val());
            form.appendChild(hiddenField);

            document.body.appendChild(form);
            form.submit();
        }


        $('#search_laoder').hide();
        $('#search_contaner').show();
    </script>
    <meta name="google-signin-scope" content="profile email">
    <meta name="google-signin-client_id" content="280836105830-d455tf4hhabi5ura6nni1t47uh76cs51.apps.googleusercontent.com">
    <script src="https://apis.google.com/js/platform.js?onload=onLoad" async defer></script>
    <script>
        function signOut() {
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function() {
                console.log('User signed out.');
            });
            location.href = '<?php echo base_url('user/logout'); ?>';
        }

        function onLoad() {
            gapi.load('auth2', function() {
                gapi.auth2.init();
            });
        }
    </script>