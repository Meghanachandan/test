<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -  
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in 
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('custom_helper');
        $this->load->library('form_validation');
        $this->load->model('admin/dashboard_model');
        if (!$this->session->userdata('is_admin_login')) {
            redirect('admin/home');
        }
    }

    public function index()
    {
        $data['page'] = 'dash';
        $data['total_users'] = $this->dashboard_model->getTotalUsers();
        $data['total_news'] = $this->dashboard_model->getTotalNews();
        $data['total_visiter'] = $this->dashboard_model->getTotalVister();
        $data['cat_ount'] = $this->dashboard_model->getcategoryNewsCount();
        $data['pending_news'] = $this->dashboard_model->get_all_pending_news();


        adminLoadView('vwDashboard', $data);
    }


    public function social_network()
    {
        $data['getIcons'] = getMultipleRecord("social_icons");
        if ($_POST) {
            foreach ($_POST as $key => $pdata) {
                foreach ($pdata['link'] as $key => $value) {
                    $insert = array(
                        'link' => $value,
                        'status' => $pdata['checkbox'][$key],
                    );
                    addUpdateRecord('social_icons', 'id', $key, $insert);
                }
                $this->session->set_flashdata('success', 'Update record successfully.');
                redirect('admin/social_network');
            }
        }
        adminLoadView('others/social_network', $data);
    }

    public function email_subscribers()
    {
        $data['email_subscribers'] = getMultipleRecord("email_subscriber");
        if ($_POST) {
            $postData   = $_POST;
            if ($postData['status']) {
                $inset['status']     = $postData['status'];
            } else {
                $inset['status']     = 0;
            }
            $inset['id'] = $postData['id'];
            $update = addUpdateRecord('email_subscriber', 'id', $postData['id'], $inset);
            if ($update) {
                echo $inset['id'];
            } else {
                echo 'error';
            }
            exit;
        }
        adminLoadView('others/email_subscribers', $data);
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
