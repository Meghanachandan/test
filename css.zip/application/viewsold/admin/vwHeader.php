<!DOCTYPE HTML>
<html>

<head>
    <title>
    Agcnn.com:The Voice of People
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link rel="shortcut icon" href="<?php echo HTTP_CSS_PATH; ?>favicon.png">
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo HTTP_CSS_PATH; ?>admin/bootstrap.min.css" rel='stylesheet' type='text/css' />
    <!-- Custom CSS -->
    <link href="<?php echo HTTP_CSS_PATH; ?>admin/style.css" rel='stylesheet' type='text/css' />
    <link href="<?php echo HTTP_CSS_PATH; ?>admin/custom.css" rel="stylesheet">
    <!-- Graph CSS -->
    <link href="<?php echo HTTP_CSS_PATH; ?>admin/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
    <!-- lined-icons -->
    <link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/icon-font.min.css" type='text/css' />
    <!-- //lined-icons -->

    <!-- <script src="<?php echo HTTP_JS_PATH; ?>admin/jquery-1.10.2.min.js"></script> -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>admin/amcharts.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>admin/serial.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>admin/light.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>admin/radar.js"></script>
    <!-- <link href="<?php echo HTTP_CSS_PATH; ?>barChart.css" rel='stylesheet' type='text/css' /> -->
    <link href="<?php echo HTTP_CSS_PATH; ?>admin/fabochart.css" rel='stylesheet' type='text/css' />
    <!--clock init-->
    <script src="<?php echo HTTP_JS_PATH; ?>admin/css3clock.js"></script>
    <!--Easy Pie Chart-->
    <!--skycons-icons-->
    <!-- <script src="<?php echo HTTP_JS_PATH; ?>skycons.js"></script> -->
    <!-- <script src="<?php echo HTTP_JS_PATH; ?>jquery.easydropdown.js"></script> -->
    <!--//skycons-icons-->
    
</head>

<body>
    <div class="page-container">
        <div class="left-content">
            <div class="inner-content">
                <div class="header-section">
                    <div class="top_menu">
                        <div class="main-search">
                        </div>
                        <script type="text/javascript">
                            $('.main-search').hide();
                            $('button').click(function() {
                                $('.main-search').show();
                                $('.main-search text').focus();
                            });
                            $('.close').click(function() {
                                $('.main-search').hide();
                            });
                        </script>
                        <!--/profile_details-->
                        <div class="profile_details_left">
                            <ul class="nofitications-dropdown">

                                <!--<li class="dropdown note pull-right">
                                            <a href="<?php //echo base_url('admin/users/logout')  
                                                        ?>" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" title="Logout"><i class="fa fa-sign-out"></i></a>
                                    </li>
                                    <li class="dropdown note pull-right">
                                    <?php //if ($this->session->userdata('username')) { 
                                    ?>
                                            <a href="" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" style="color: #fff"><i class="fa fa-user"></i> &nbsp;Hello <?php //echo ucwords($this->session->userdata('username'));  
                                                                                                                                                                                        ?></a>
                                    <?php //} 
                                    ?>
                                    </li>-->
                                <script type="text/javascript">
                                    function DropDown(el) {
                                        this.dd = el;
                                        this.placeholder = this.dd.children('span');
                                        this.opts = this.dd.find('ul.dropdown > li');
                                        this.val = '';
                                        this.index = -1;
                                        this.initEvents();
                                    }
                                    DropDown.prototype = {
                                        initEvents: function() {
                                            var obj = this;

                                            obj.dd.on('click', function(event) {
                                                $(this).toggleClass('active');
                                                return false;
                                            });
                                            obj.opts.on('click', function() {
                                                var opt = $(this);
                                                obj.val = opt.text();
                                                obj.index = opt.index();
                                                obj.placeholder.text(obj.val);
                                            });
                                        },
                                        getValue: function() {
                                            return this.val;
                                        },
                                        getIndex: function() {
                                            return this.index;
                                        }
                                    }
                                    $(function() {
                                        var dd = new DropDown($('#dd'));
                                        $(document).click(function() {
                                            // all dropdowns
                                            $('.wrapper-dropdown-3').removeClass('active');
                                        });
                                    });
                                </script>
                                </li>
                                <div class="clearfix"></div>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                        <!--//profile_details-->
                    </div>
                    <!--//menu-right-->
                    <div class="clearfix"></div>
                </div>