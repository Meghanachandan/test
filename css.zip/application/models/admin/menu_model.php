<?php
	class Menu_model extends CI_Model {
 
	    function __construct()
	    {
	        parent::__construct();
	    }

	    public function getRecords()
	    {

			$query = "SELECT e.*, m.`title` as parent FROM menus e left join menus m on e.parent_id = m.id ORDER BY id DESC";		
			$users_query = $this->db->query($query);
			$row_users = $users_query->result_array();
			return $row_users;
	    }

	    public function getRecordById($id)
	    {
			$this->db->where('id', $id);
			$q = $this->db->get('menus');
			//if id is unique we want just one row to be returned
			$data = array_shift($q->result_array());
			return $data;
	    }

	     public function getMenuType()
	    {
	    	$menus = array('mainmenu', 'footermenu');
			$this->db->where_in('menu_type', $menus);
			$q = $this->db->get('menus');
			//if id is unique we want just one row to be returned
			$data = $q->result_array();
			return $data;
	    }
		
		
		public function formValidations()
		{
			
			$this->form_validation->set_rules('link', 'Link', 'required');
			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('menu_type', 'Menu Type', 'required');
			if ($this->form_validation->run() == FALSE) {
			return false; 
			} else {
			return TRUE; 
			}
			
	    }
		
		

	    
	}
?>
