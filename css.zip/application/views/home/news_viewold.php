<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Ideabox main theme css file. you have to add all pages -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/search/main-style.css">
<!-- Ideabox responsive css file -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/search/responsive-style.css">
<!--Main container start -->
<main class="container">
    <section class="main-content">
        <div class="main-content-wrapper">
            <div class="content-body">
                <div class="content-timeline">
                    <div class="p-r-10 p-r-0-sr991">
                        <!-- Blog Detail -->
                        <div class="p-b-70">
                            <h1 class="f1-l-3 cl2 p-b-16 p-t-33 respon2 db_storybox">
                                <a href="<?php echo base_url() . 'home/search/' . $getCatInfo['id'] . '/' . $getCatInfo['id']; ?>"><strong style="color: #e6102d;"><?php echo $getCatInfo['title']; ?></strong></a><strong style="color: #000;">/</strong><a href="<?php echo base_url() . 'home/search?ci=' . urlencode($news['city']); ?>"><strong style="color: #e6102d;"><?php echo $news['city']; ?></strong></a><strong style="color: #000;">/</strong>&nbsp;&nbsp;<?php echo $news['title'] ?>
                                <?php if ($preview_action == '1') { ?>
                                    <span class="active_prieview pull-right">
                                        <a href="<?php echo base_url('news/edit/' . $news['id']); ?>"> - Edit </a> | <a href="<?php echo base_url() . 'news/activate_news/' . $news['id']; ?>"> Active </a>
                                    </span>
                                <?php } ?>
                            </h1>
                            <div class="flex-wr-s-s" style="clear: both;height: 40px;">
                                <span class="f1-s-3 cl8 m-r-15">
                                    <div style="float: left;">
                                        <?php if ($news['hide_name_on_news'] != '1') { ?>
                                            <a href="#" class="f1-s-4 cl8 hov-cl10 trans-03">
                                                <i class="fas fa-pencil-alt"></i>&nbsp;<?php echo getReporterName($news['reporter']); ?>
                                            </a>/
                                        <?php } ?>
                                        <?php if ($news['hide_email_on_news'] != '1') { ?>
                                            <a href="#" class="f1-s-4 cl8 hov-cl10 trans-03">
                                                <?php echo getReporterEmail($news['reporter']); ?>
                                            </a>/
                                        <?php } ?>
                                        <?php if ($news['hide_name_on_news'] == '1' && $news['hide_email_on_news'] == '1') { ?>
                                            <i class="fas fa-pencil-alt"></i>&nbsp;Public Reporter/
                                        <?php } ?>
                                        <?php
                                        date_default_timezone_set("Asia/Kolkata");
                                        //echo date_default_timezone_get();
                                        ?>
                                        <?php echo date('D/M d, Y, h:i A', strtotime($news['date'])) . ' - ' . date('T'); ?>
                                        <?php if (sizeof($news_count) > 0) {
                                            echo '-' . sizeof($news_count) . ' <span class="mbri-preview"></span>';
                                        } ?>

                                </span>
                            </div>
                            <?php if ($show_google_translater == '1') { ?>
                                <div style="margin-right: 0px;float: right;margin-top: -10px;" id="google_translate_element"></div>
                            <?php } ?>

                        </div>
                        <div class="wrap-pic-max-w">

                            <?php if ($news['media_type'] == 'youtube') {

                                $you_tube = str_replace('height', 'height="350px" res-height', $news['youtube_code']);
                                $you_tube = str_replace('width', 'width="100%" res-width', $you_tube);
                                echo $you_tube;

                            ?>
                            <?php } else { ?>

                                <?php
                                if (trim($news['image']) == '') {
                                    $news['image'] = 'no-image.png';
                                } else {
                                    $news['image'] = 'orig/' . $news['image'];
                                }
                                ?>
                                <img src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>" alt="<?php echo $news['title'] ?>">

                            <?php } ?>
                        </div>

                        <?php if ($news['image_capsion'] != '') { ?>
                            <span class="db_slug"><?php echo $news['image_capsion']; ?></span>
                        <?php } ?>

                        <?php if ($news['highlights'] != '') {
                            $hightLight_point  = explode('#$#', $news['highlights']);
                            echo '<div class="db_storycontent" >';
                            echo '<ul>';
                            foreach ($hightLight_point as $point) {
                                echo '<li>' . $point . '</li> ';
                            }
                            echo '</ul>';
                            echo '</div>';
                        }
                        ?>

                        <div class="f1-s-11 cl6 p-b-25 py-3 mt-3 text-justify">
                            <strong style="float: left;color: #e6102d;font-size: 20px;line-height: 23px;"><?php echo $news['city']; ?></strong><strong style="float: left;color: #000;font-size: 20px;line-height: 23px;margin-right: 10px;">/</strong><?php echo $news['discription']; ?>
                        </div>
                        <!-- <div class="flex-s-s p-t-12 p-b-15">
                            </div> -->

                        <!-- Tag -->
                        <!-- <div class="flex-s-s p-t-12 p-b-15">
                                <span class="f1-s-12 cl5 m-r-8">
                                    Tags:
                                </span>

                                <div class="flex-wr-s-s size-w-0">
                                    <a href="#" class="f1-s-12 cl8 hov-link1 m-r-15">
                                        Streetstyle
                                    </a>

                                    <a href="#" class="f1-s-12 cl8 hov-link1 m-r-15">
                                        Crafts
                                    </a>
                                </div>
                            </div> -->

                        <!-- Share -->
                        <div class="flex-s-s">
                            <span class="f1-s-12 cl5 p-t-1 m-r-15">
                                Share:
                            </span>
                            <div class="flex-wr-s-s size-w-0">
                                <a href="https://facebook.com/sharer/sharer.php?u=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" rel="noopener" class="dis-block f1-s-13 cl0 bg-facebook borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                    <i class="fab fa-facebook-f m-r-7"></i>
                                    Facebook
                                </a>
                                <a href="https://twitter.com/intent/tweet/?text=<?php echo urlencode($news['short_discription']); ?>&amp;url=<?php echo urlencode(base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']) ?>" target="_blank" class="dis-block f1-s-13 cl0 bg-twitter borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                    <i class="fab fa-twitter m-r-7"></i>
                                    Twitter
                                </a>
                                <a href="whatsapp://send?text=<?php echo urlencode($news['short_discription'] . ' ' . base_url() . 'home/news_view/' . $news['id'] . '/' . $news['slug']); ?>" target="_blank" class="dis-block f1-s-13 cl0 bg-whatsapp borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                    <i class="fab fa-whatsapp m-r-7"></i>
                                    Whatsapp
                                </a>
                                <!-- 
                                    <a href="#" class="dis-block f1-s-13 cl0 bg-google borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                        <i class="fab fa-google-plus-g m-r-7"></i>
                                        Google+
                                    </a>
                                    <a href="#" class="dis-block f1-s-13 cl0 bg-pinterest borad-3 p-tb-4 p-rl-18 hov-btn1 m-r-3 m-b-3 trans-03">
                                        <i class="fab fa-pinterest-p m-r-7"></i>
                                        Pinterest
                                    </a>
                                    -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-sidebar">
            <div class="sidebar_inner">

                <?php
                $side_bar_conter = 0;
                if ($populer_news) {
                    // unset($populer_news[0]);

                ?>

                    <div class="widget-item">
                        <div class="w-header">
                                <div class="w-title">Top News</div>
                            <div class="w-seperator"></div>
                        </div>
                        <div class="w-boxed-post">
                            <ul>
                                <?php
                                foreach ($populer_news as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?> </h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                    <?php
                    if ($latest_news) {
                    ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Latest News</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($latest_news as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>

                    <?php if ($recientView) { ?>
                        <div class="widget-item">
                            <div class="w-header">
                                <div class="w-title">Recent View</div>
                                <div class="w-seperator"></div>
                            </div>
                            <div class="w-boxed-post">
                                <ul>
                                    <?php
                                    foreach ($recientView as $news) {
                                    ?>
                                        <li>
                                            <?php
                                            $full_description = '';
                                            $full_description .= ' <span class=\'citycolour\' ><strong> ' . strip_tags($news['city']) . ' </strong> / ';
                                            $full_description .= ' <span class=\'newstitlecolour\' ><strong> ' . strip_tags($news['title']) . ' </strong> <br>';
                                            $full_description_text = limit_text($news['discription'], 400);
                                            $full_description .= ' <span class=neswDescription >' . $full_description_text . ' </span> ';
                                            ?>
                                            <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" style="background-image: url(img/news-test-images/news-img7.jpg);" data-html="true" data-placement="top" data-toggle="tooltip" title="<?php echo $full_description; ?>">
                                                <div class="box-wrapper">
                                                    <div class="box-left">
                                                        <?php
                                                        if (trim($news['image']) == '') {
                                                            $news['image'] = 'no-image.png';
                                                        } else {
                                                            $news['image'] = 'thumb/' . $news['image'];
                                                        }
                                                        ?>
                                                        <span style="background-image: url('<?php echo base_url() . 'upload/news/' . $news['image']; ?>');background-position: center;background-size: cover;">
                                                        </span>
                                                    </div>
                                                    <div class="box-right">
                                                        <h3 class="p-title"><span style="color: #004d38;" ><?php echo limit_text($news['title'], 15); ?></span> / 
                                                            <?php echo limit_text(strip_tags($news['discription']), 50); ?></h3>
                                                        <div class="p-icons">
                                                            <?php echo date('D, d M Y', strtotime($news['date'])); ?>
                                                            <span><i class="fas fa-pencil-alt"></i></span> <?php echo getReporterName($news['reporter']); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                    <?php
                                        $side_bar_conter++;
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>

                    <?php

                    }
                    ?>


                    <!-- <div class="widget-item">
                        <div class="w-header">
                            <div class="w-title">Carousel Posts</div>
                            <div class="w-seperator"></div>
                        </div>
                        <div class="w-carousel-post">
                            <div class="owl-carousel" id="widgetCarousel">
                                <div class="item">
                                    <a href="#">
                                        <div class="w-play-img">
                                            <img src="img/news-test-images/news-img4.jpg" width="300">
                                            <span class="w-video-icon"><i class="material-icons">&#xE038;</i></span>
                                        </div>
                                        <span class="w-post-title">It has roots in a piece of classical Latin literature from</span>

                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img5.jpg" width="300">
                                        <span class="w-post-title">Lorem Ipsum used since</span>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img6.jpg" width="300">
                                        <span class="w-post-title">English versions from the 1914 translation</span>
                                    </a>
                                </div>
                                <div class="item">
                                    <a href="#">
                                        <img src="img/news-test-images/news-img7.jpg" width="300">
                                        <span class="w-post-title">The standard chunk of Lorem Ipsum used since</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div> -->

                    <div class="seperator"></div>

                    <!-- <a href="#" class="widget-ad-box">
                        <img src="img/adbox300x250.png" width="300" height="250">
                    </a> -->

                </div>
            </div>
        <div style="clear: both;"></div>
        </div>
    </section>

</main>

<script>
    function gotoViewAllPage() {
        method = "post";

        var form = document.createElement("form");
        form.setAttribute("method", method);
        form.setAttribute("action", "<?php echo base_url() . 'home/news_all_view/' . $cat_id; ?>");

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "country");
        hiddenField.setAttribute("value", '<?php echo $country; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "state");
        hiddenField.setAttribute("value", '<?php echo $state; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "city");
        hiddenField.setAttribute("value", '<?php echo $city; ?>');
        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", "key");
        hiddenField.setAttribute("value", '<?php echo $key; ?>');
        form.appendChild(hiddenField);

        document.body.appendChild(form);
        form.submit();
    }

    $(document).ready(function() {
        var hieght = 100 * <?php echo $side_bar_conter; ?>;
        hieght = hieght + 100;
        $('.main-content-wrapper').css('min-height', hieght);
    });
</script>
<style>
    span.active_prieview.pull-right {
        float: right;
        position: absolute;
        right: 0;
        font-size: 15px;
    }
</style>