<?php
if (!empty($postData)) {
    $name = $postData['title'];
    $discription = $postData['discription'];
    $status = $postData['status'];
    $order = $postData['order'];
    
}
?>
<div class="outter-wp">
    <script type="text/javascript" src="<?php echo base_url(); ?>ckeditor/ckeditor.js"></script>
    <!--/sub-heard-part-->
    <div class="sub-heard-part">
        <ol class="breadcrumb m-b-0">
            <li><a href="<?php echo base_url('admin/dashboard'); ?>">DASHBOARD</a></li>
            <li><a href="<?php echo base_url('admin/terms/categories'); ?>">TERMS AND CONDITIONS</a></li>
           <!--<li class="active">EDIT FAQ</li>-->
        </ol>
    </div>
    <div class="graph-visual tables-main">
        <h2 class="inner-tittle">Edit Terms And Conditions</h2>
        <div class="graph-form">
            <?php
            if (!empty($error)) {
                ?><div class="alert alert-danger message" style="display: block;"><?php echo $error; ?></div><?php }
            ?>
            <div class="form-body">
                <?php
                $editId = "";
                if (!empty($postData['id'])) {
                    $editId = $postData['id'];
                }
                ?>
                <form action="<?php echo base_url('admin/terms/terms_edit/' . $editId); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" value=""/>
                    <div class="form-group">
                        <label for="exampleInputEmail1">TERMS AND CONDITIONS <span class="star-color">*</span></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $name; ?>" required>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="exampleInputPassword1">Descrption</label> 
                                <textarea name="discription" rows="10" cols="80" id="discription"  name="discription" required><?php echo $discription; ?></textarea>
                            </div>
                        </div>
                    </div> 
     								
                    <button type="submit" class="btn btn-default" name="submit" value="submit">Update</button> 
                </form> 
            </div>
        </div>
        <!--//graph-visual-->
    </div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('discription');
	
</script>