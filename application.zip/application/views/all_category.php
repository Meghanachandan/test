<!--<meta name="viewport" content="width=device-width, initial-scale=1">-->

<!--<script src="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>-->
 



<section style="border-top: 2px solid #fff;">
    <div class='container-fluid'>
        <div class='row'>
        <div class="col-md-12" style="background-color:#2f3a4a;color: #fff">
          <h1 style="margin-top: 50px;margin-bottom: 50px;font-size: 20px;
">ALL Categories</h1>  
        </div>
    </div>
    </div>
</section>

<style type="text/css">
    

.badgeall
{
   position:absolute;
   font-size:15px;
   color:#fff;
   margin-top:10px;
   //background-color: darkblue;
   margin-left: -85px !important;
}

</style>
<script type="text/javascript">
$(document).ready(function(){

$('.items').slick({
infinite: true,
slidesToShow: 6,
 autoplay: true,
 dots: false,
    prevArrow: false,
    nextArrow: false,
slidesToScroll: 3

});
}); </script>
<style>
    .slick-arrow.slick-disabled { 
        display: none !important;
    }
</style>
<style>
/*    #zoom:hover {*/
  /*transform: scale(1.2); */
/*}*/
</style>
<?php
$badge=array("badge-primary","badge-secondary","badge-success","badge-danger","badge-warning","badge-info","badge-primary","badge-secondary","badge-success","badge-danger","badge-warning","badge-info");
$cat_count = 0;
$adds_counter_count = 1;

     
          $query = "SELECT news_categories.id,news_categories.title,news_categories.slug,news_categories.categorie_type,news_categories.categorie_colour,manage_category.position,manage_category.categoriesid FROM `news_categories` INNER JOIN manage_category ON news_categories.id = manage_category.categoriesid where news_categories.status = '1' AND news_categories.order > 0 ORDER BY manage_category.position ASC";
        $query = $this->db->query($query);
        $rowsasdasd = $query->result_array();
  


   
      //  echo "<pre>";print_r($rowsasdasd);die;
$allcategories = $rowsasdasd;
//echo "<pre>";print_r($allcategories);die;
if ($allcategories) {
    foreach ($allcategories as $category) {
       
        $query1 = "SELECT parent_category,child_category FROM `category_map` where parent_category='".$category['id']."'";
        $query1 = $this->db->query($query1);
        $rowsasdasd1 = $query1->result_array();
    
        $categories_news = $this->home_model->get_latest_news_by_ids($category['id']);
        
        if ($categories_news) { ?>
            <section class="tabs4 cid-rUEF7euy93" id="tabs4-r" style="background-color: #232c37;">
                <div class="container-fluid">
                    <div class="media-container-row">
                        <h1 class="classForHeadercategory" style="background-color:#2f3a4a;padding: 10px;">
                            <div style="width: calc(100% - 55px);"><?php echo '<a style="color: #fff ! important;" href="http://' . $category['slug']. '.newssyn.com"> ' . $category['title'] . ' </a>'; ?></div>
                            <div><?php echo '<a style="font-size: 15px;color: #fff ! important;" href="http://' . $category['slug']. '.newssyn.com"> More... </a>'; ?></div>
                        </h1>
                    </div>
                    



        <div class="row">
            <div class="col-md-12">
                <div class="items mbr-text mbr-fonts-style display-7 T2" style="height:120px;overflow:hidden;">
                        <?php
                        $news = array();
                        
                        foreach ($categories_news as $key=> $news) {
                           
                            // $news_data['news'] = $news;
                            // $news_data['list'] = 'cat';
                            // $news_data['badge'] = $badge;
                            // $this->load->view('home/all_cate_news_block', $news_data);
                            ?>
                            
                            <div class="card-wrapper">
    <div class="card-img" style="width: 200px;">
                <a href="<?php echo base_url() . cleanNewsUrl($news); ?>" class="fancybox" rel="ligthbox">
                    <?php
            if (trim($news['image']) == '') {
                $news['image'] = 'no-image.png';
            } else {
                $news['image'] = 'thumb/' . $news['image'];
            }
            ?>
            <?php
                    // var_dump($badge);
                    // die;
                    $q = "SELECT * FROM `news_categories` WHERE `id` = '".$news['child_categorise']."'";
                    $q = $this->db->query($q);
                    $r = $q->result_array();
                    
                    if($news[child_categorise]== '0'){
                        $qu = "SELECT * FROM `news_categories` WHERE `id` = '".$news['categorise']."'";
                        $qu = $this->db->query($qu);
                        $ro = $qu->result_array();
                    ?>
                    <span class="badge badgeall <?php echo $badge[$key]; ?>"><?php echo $ro[0]['title']; ?></span>
                    <?php } ?>
                        <span class="badge badgeall <?php echo $badge[$key]; ?>"><?php echo $r[0]['title']; ?></span>
                    <?php  ?>
                    <img id='zoom' src="<?php echo base_url() . 'upload/news/' . $news['image']; ?>" style="height:120px;" alt="<?php echo $news['title'] ?>">
                   
                </a>
            </div>
            </div>
                            
                            
                            <?php
                        
                        }
                        ?>
                        </div>
                    </div>
                   </div>
                </div>
            </section>
        <?php } ?>
        <?php
        
        $cat_count++;
    }
}
?>

 <script>
         $(document).ready(function(){
  $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
    
    $(".zoom").hover(function(){
		
		$(this).addClass('transition');
	}, function(){
        
		$(this).removeClass('transition');
	});
});
    
     </script>       
           
           
       


<script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/slick/slick.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
    $(document).on('ready', function() {
        $(".center").slick({
            dots: false,
            infinite: true,
            slidesToShow: 6,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 6,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        $(".center2").slick({
            dots: false,
            infinite: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });

        $(".center3").slick({
            dots: false,
            infinite: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        centerMode: false
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: true
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]
        });
    });
</script>