<?php
function viewcounter($data)
{
    
	$ci =& get_instance();
    $ci->load->database();
	$data1 = $data;
// 	print_r($data);die;
	/* check ip addaress*/
	$ci->db->select('*');
	$ci->db->from('news_view');
	$ci->db->where('ip', $data1['ip']);
	$ci->db->where('newsid', $data1['newsid']);
	$getdata = $ci->db->get();
	$result = $getdata->result_array();
	//print_r($result);die;
	$countrow = $getdata->num_rows();
	if($countrow > 0)
	{ } else
    { 
    // insert data
    $ci->db->insert('news_view', $data1);
    }
}
 
 function countview($newsid)
 {
   $ci1 =& get_instance();
   $ci1->load->database();
   $getnewsid = $newsid;
   $ci1->db->select('*');
   $ci1->db->from('news_view');
   $ci1->db->where('newsid', $getnewsid);
   $getresult = $ci1->db->get();
   echo $countrow = $getresult->num_rows();
 }

  function countlike($likeid)
 {
   $ci2 =& get_instance();
   $ci2->load->database();
   $getlikeid = $likeid;
   $ci2->db->select('*');
   $ci2->db->from('news_like');
   $ci2->db->where('newsid', $getlikeid);
   $getresult = $ci2->db->get();
   echo $countrow = $getresult->num_rows();
 }

 function checklikeip($newsid) 
 {
 	$checklikeip = $newsid; 
 	$checkip = $_SERVER['SERVER_ADDR'];
 	$ci3 =& get_instance();
   $ci3->load->database();
   $ci3->db->select('*');
   $ci3->db->from('news_like');
   $ci3->db->where('ip', $checkip);
   $ci3->db->where('newsid', $checklikeip);
   $getresult = $ci3->db->get();
   return $rowcount = $getresult->num_rows();

 }
?>