<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/style.css">
        <style>
           
        </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <!-- <div class="panel panel-default">
                    <div class="panel-body"> -->
                        <div class="row"  style="padding: 26px 50px;">
                       
                            <div class="col-md-4 col-md-offset-4 login_form_grid">
                                <p class="login_name">
                                        Login 
                                </p>
                                <?php if($this->session->flashdata('error')){?>
                                    <p style="color: white;background: red;text-align: center;padding: 5px;"><?php echo $this->session->flashdata('error'); ?></p>
                                <?php } ?>
                                <div class="col-md-12 login_form">
                                    <?php echo form_open('AdminAuthenticate/login'); ?>
                                       
                                        <div class="form-group">
                                            <label class="login_form_label">Email </label>
                                            <input type="text" class="form-control login_form_input" name="email">
                                        </div>
                                      
                                        <div class="form-group">
                                            <label class="login_form_label">Password</label>
                                            <input type="password" class="form-control login_form_input" name="password">
                                        </div>

                                        <button type="submit" class="btn btn-default login_button_login">Login</button>
                                      
                                        <div class="form-group">
                                            <p style="text-align: center;
                                            ">Don't have account? <a href="<?php echo base_url('AdminLogin/register'); ?>" style="color: #92A3DA;">Sign Up</a></p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                       
                    <!-- </div>
                </div> -->
            </div>
        </div>
    </div>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"
        integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa"
        crossorigin="anonymous"></script>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

</body>
</html>