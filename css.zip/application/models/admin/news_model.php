<?php
class News_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	public function getRecords($cate=0)
	{
		if($cate>0){
			$this->db->where('categorise', $cate);
		}
		
		$this->db->order_by("id", "desc");
		$query  = $this->db->get('latest_news');
		$ret    = $query->result_array();
		return $ret;
	}

	public function getRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getMenuType()
	{

		$this->db->where('menu_type', 'mainmenu');
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = $q->result_array();
		return $data;
	}

	public function getImage($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('latest_news');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data['image'];
	}

	public function formValidations($id = null)
	{
		/*$url = $_POST['link'];
			if (!filter_var($url, FILTER_VALIDATE_URL) == false) {
			return true; 
			} else {
			$this->form_validation->set_rules('link', 'Link', 'required');	
			?>
            <script>
			alert('Enter valid Link of News');
			</script>
            <?php
			
			return false; 
			}*/
		//$this->form_validation->set_rules('link', 'Link', 'required');
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('country', 'country', 'required');
		//$this->form_validation->set_rules('date', 'Date', 'required');
		/*$editImage = $this->getImage($id);
		if (empty($editImage)) {
			if (empty($_FILES['image']['name'])) {
				$this->form_validation->set_rules('image', 'Image', 'required');
			}
		}*/
		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}

	public function getCategoriesRecords()
	{
		$this->db->order_by("id", "desc");
// 			$this->db->where("categorie_type", '0');
		$query = $this->db->get('news_categories');
		$ret = $query->result_array();
// 		echo $this->db->last_query();die;
		return $ret;
	}
		public function getCategoriesRecords11()
	{
		$this->db->order_by("id", "desc");
			$this->db->where("categorie_type", '0');
		$query = $this->db->get('news_categories');
		$ret = $query->result_array();
// 		echo $this->db->last_query();die;
		return $ret;
	}

	public function getCategorieRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('news_categories');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}

	public function getCatImage($id)
	{
		$this->db->where('id', $id);
		$q = $this->db->get('news_categories');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data['image'];
	}

	public function formCatValidations($id = null)
	{
		/* $url = $_POST['link'];
			  if (!filter_var($url, FILTER_VALIDATE_URL) == false) {
			  return true;
			  } else {
			  $this->form_validation->set_rules('link', 'Link', 'required');
			  ?>
			  <script>
			  alert('Enter valid Link of Blog');
			  </script>
			  <?php
	
			  return false;
			  } */
		$this->form_validation->set_rules('title', 'Title', 'required');
		//$this->form_validation->set_rules('link', 'Link', 'required');
		$editImage = $this->getCatImage($id);
// 		if (empty($editImage)) {
// 			if (empty($_FILES['image']['name'])) {
// 				$this->form_validation->set_rules('image', 'Image', 'required');
// 			}
// 		}

		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}
    
    function getAllCountry(){
        
        $sql = "SELECT `id`,`name` FROM `countries`;";
        //$this->db->query($sql, array(3, 'live', 'Rick'));
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
    }
    
    
    
    function getAllCountrystate($Countryid){
        
        $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
        $query = $this->db->query($sql, array($Countryid));
       // $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
	}


	function getAllCountrystateByName($Countryname){

		$countrysql = "SELECT `id`,`name` FROM `countries` WHERE `name` = '".$Countryname."' ;";
        $countryquery = $this->db->query($countrysql);
		$countryresult = $countryquery->result_array();
		
        $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
        $query = $this->db->query($sql, array($countryresult[0]['id']));
       // $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
	}
    
    function getAllStateCityByName($Countryname){

		$countrysql = "SELECT `id`,`name` FROM `states` WHERE `name` = '".$Countryname."' ;";
        $countryquery = $this->db->query($countrysql);
		$countryresult = $countryquery->result_array();
		
        $sql = "SELECT `id`,`name` FROM `cities` WHERE `state_id` = ? ;";
        $query = $this->db->query($sql, array($countryresult[0]['id']));
       // $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
	}


	function getallReporter(){
        //$sql = "SELECT `id`,`first_name`,`last_name`,`email` FROM `users` WHERE `user_type` = '1';";
        $sql = "SELECT `id`,`first_name`,`last_name`,`email` FROM `users`";
        //$query = $this->db->query($sql, array($Countryid));
    	$query = $this->db->query($sql);
        $result = $query->result();
        return $result;
	}
	
		public function formCatValidation($id = null)
	{
		
		$this->form_validation->set_rules('manage_category', 'manage_category', 'required');
		$this->form_validation->set_rules('position', 'position', 'required');
		

		if ($this->form_validation->run() == FALSE) {
			return false;
		} else {
			return TRUE;
		}
	}
	
	public function getManCategoriesRecords()
	{
		$this->db->order_by("position", "ASC");
	    //$this->db->where("categorie_type", '0');
		$query = $this->db->get('manage_category');
		$ret = $query->result_array();
// 		echo $this->db->last_query();die;
		return $ret;
	}
	
	public function getmanCategorieRecordById($id)
	{

		$this->db->where('id', $id);
		$q = $this->db->get('manage_category');
		//if id is unique we want just one row to be returned
		$data = array_shift($q->result_array());
		return $data;
	}
	
	
	
	function getAllCountrystateByName1($id){
//echo '<pre>';print_r($id);die;
		$countrysql = "SELECT `id`,`name` FROM `countries` WHERE `id` = '".$id."' ;";
        $countryquery = $this->db->query($countrysql);
		$countryresult = $countryquery->result_array();
		
        $sql = "SELECT `id`,`name` FROM `states` WHERE `country_id` = ? ;";
        $query = $this->db->query($sql, array($countryresult[0]['id']));
       // $query = $this->db->query($sql);
        $result = $query->result();
        return $result;
	}
	
	
	

	

}























