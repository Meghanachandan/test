<?php 

class Printing_model extends CI_Model {

	function __construct()
	{
		// Call the Model constructor
		parent::__construct();
	}
   
   function getOrderDetails($id=0){
	
		$query_eto = $this->db->query('SELECT * FROM event_ticket_order WHERE id='.$id);
		$row_eto = $query_eto->row();
		
		return $row_eto;
	}
	
	function getOrderId($id){
	 
		$getVar = base64_decode($id);
		
		$getOrderId = explode('^!^',$getVar);
		
		return $getOrderId[0];
	 
	}
	
	function getUserDetails($id){
	
		$query_eto = $this->db->query('SELECT UserId FROM event_ticket_order WHERE id='.$id);
		$row_eto = $query_eto->row();
		
		//print_r($row_eto->UserId); exit;
		$row_user ='';
		
		if($row_eto->UserId!=''){
			$query_user = $this->db->query('SELECT * FROM users WHERE id='.$row_eto->UserId);
			$row_user = $query_user->row();
		}
		
		return $row_user;
	}
	
	function insertCCdetails($arr,$userId){
		
		$data['cc_type'] = $arr['Type'];
		$data['cc_number']= $arr['CreditCardNumber'];
		$data['cc_expiryMonth']= $arr['ExpiryMonth'];
		$data['cc_expiryYear']= $arr['ExpiryYear']; 
		$data['cc_cvv']= $arr['CVV'];
		$data['userId']= $userId;
		
		$this->db->insert('credit_card', $data);
	}
	
	function insertBillingdetails($arr,$userId){
		
		$data['userId']= $userId;
		$data['FirstName'] = $arr['FirstName'];
		$data['LastName']= $arr['LastName'];
		$data['CompanyName']= $arr['CompanyName'];
		$data['Address1']= $arr['Address1']; 
		$data['Address2']= $arr['Address2'];
		$data['City']= $arr['City'];
		$data['Country']= $arr['CountryId'];
		$data['StateOrProvince']= $arr['StateOrProvinceId'];
		$data['PostCode']= $arr['PostCode'];
		$data['Phone']= $arr['Phone'];
		
		$this->db->insert('billing_details', $data);
	}
	
	function insertShippingdetails($arr,$userId){
		
		$data['userId']= $userId;
		$data['Name'] = $arr['FirstName'].' '.$arr['LastName'];;
		
		$data['CompanyName']= $arr['CompanyName'];
		$data['Address1']= $arr['Address1']; 
		$data['Address2']= $arr['Address2'];
		$data['City']= $arr['City'];
		$data['Country']= $arr['CountryId'];
		$data['StateOrProvince']= $arr['StateOrProvinceId'];
		$data['PostCode']= $arr['PostCode'];
		$data['Phone']= $arr['Phone'];
		
		$this->db->insert('shipping_details', $data);
	}
	
	//Gett Billing Details
	function getBillingDetails($id){
		
		$query_bill = $this->db->query('SELECT * FROM billing_details WHERE userId='.$id);
		$row_bill = $query_bill->row();
		
		return $row_bill;
	}
	
	//Gett Shipping Details
	function getShippingDetails($id){
		
		$query_ship = $this->db->query('SELECT * FROM shipping_details WHERE userId='.$id);
		$row_ship = $query_ship->row();
		
		return $row_ship;
	}
	
	//Gett Shipping Details
	function getCCDetails($id){
		
		$query_cc = $this->db->query('SELECT * FROM credit_card WHERE userId='.$id);
		$row_cc = $query_cc->row();
		
		return $row_cc;
	}

}


?>