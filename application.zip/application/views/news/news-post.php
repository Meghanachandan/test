<section>
	<div class="container">
		<div class="row">
            <div class="page-title-wrapper product">
            	<div class="col-md-6 col-sm-6 col-xs-12"><h1 class="page-title">
                    <span class="base" data-ui-id="page-title-wrapper" itemprop="name"><?php echo $getNews['title']; ?> </span></h1>
                 </div>
            	<div class="col-sm-6 hidden-xs"><div class="pull-right mt-5">
                    <ul class="page-list">
                        <li class="item home"><a href="<?php echo base_url('/'); ?>" title="Go to Home Page"> Home </a>  </li>
                        <li> > </li>
                        <li class="item home"><a href="<?php echo base_url('news'); ?>" title="Go to Latest News"> Latest News </a>  </li>
                        <li> > </li>
                        <li class="item product"><?php echo $getNews['title']; ?></li>
	                </ul>
                </div>
                </div>

                <div class="clearfix"></div>
            </div>    
        </div>
    </div>
</section>
<section>
	<div class="container">
		<div class="row">
        
			<div class="col-sm-8 col-md-9">
				<div class="blog-post-area">
					<div class="single-blog-post">
                        <div class="">
                        <?php
                            if(trim($getNews['image'])==''){
                                $getNews['image'] = 'no-image.png';
                            }                
                        ?>
                        <img src="<?php echo base_url('upload/news/'.$getNews['image']); ?>" alt="" class="img-responsive">
                       
                        </div>    
                        <div class="col-sm-12 col-md-12 mt25" >
                        <div class="col-sm-1 col-md-1">
                         <a href="<?php echo base_url('upload/news/'.$getNews['image']); ?>" download="" class="btn" > <i class="fa fa-download" aria-hidden="true"></i></a>
                        </div>
                        <div class="col-sm-11 col-md-11 ">
                            <script type='text/javascript' src='http://platform-api.sharethis.com/js/sharethis.js#property=5e6a9840d6eae300128211f0&product=inline-share-buttons&cms=website' async='async'></script>
                <div class="sharethis-inline-share-buttons"></div>
                <style>#st-1{text-align: left;}</style>
                        </div>    
                        </div>    
                        <div class="col-sm-12 col-md-12 mt25" >
						<h3><?php echo $getNews['title']; ?></h3>
                        </div> 
 <div class="col-sm-12 col-md-12" >                        
						<div class="post-meta">
							<ul>
								<li><i class="fa fa-calendar"> &nbsp; Posted </i> <?php echo  date('M d, Y', strtotime($getNews['created_date'])); ?></li>
							</ul>
						</div>
						</div>
                         <div class="col-sm-12 col-md-12" >
						<p class="blog-para"><?php echo $getNews['discription']; ?></p>
					</div>
					</div>
				</div>
			</div>
            
			<div class="col-sm-4 col-md-3">
				<div class="left-sidebar">
					<div class="mt20 mb100"><!--shipping-->
                       <?php if (!empty($latest_post)) { ?>
							 <h2>Recent News</h2>
	                    	<p><?php echo  date('F Y', strtotime($latest_post['created_date'])); ?></p>
                            <?php
                                if(trim($latest_post['image'])==''){
                                    $latest_post['image'] = 'no-image.png';
                                }                
                            ?>
							<a title="<?php echo $latest_post['title']; ?>" href="<?php echo base_url("news/post/".$latest_post['slug']); ?>"><img src="<?php echo base_url("upload/news/".$latest_post['image']); ?>" alt="" class="img-responsive"/></a>
						<?php } ?>
					</div><!--/shipping-->
                        
				</div>
			</div>
		</div>
	</div>
</section>