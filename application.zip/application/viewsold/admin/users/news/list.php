<style>
	#imgdiv {
		width: 160px;
		float: left;
		margin-left: 20px
	}

	#reload {
		float: right;
		margin-right: 40px
	}

	section {
		background-color: #FFF;
	}

	.table-bordered a {
		color: #000;
	}

	.table-bordered a:hover {
		color: #CCC;
	}
</style>
<div class="row">
	<div class="col-sm-12">
		<!--
		<link rel="stylesheet" href="<?php echo HTTP_CSS_PATH; ?>admin/jquery.dataTables.min.css">
		<script src="<?php echo HTTP_JS_PATH; ?>admin/jquery.dataTables.min.js"></script>
        -->
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css" />
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.dataTables.min.css" />
		<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>

		<div class="outter-wp">
			<!--/sub-heard-part-->
			<div class="sub-heard-part">
				<ol class="breadcrumb m-b-0">
					<li><a href="<?php echo base_url('admin/users'); ?>">Users</a></li>
					<li><?php echo getReporterName($user_id); ?></li>
					<li class="active">USER NEWS</li>
				</ol>
				<select name="cate" class="pull-right" onchange="loadcategorynrws(this.value);">
					<option value="">Select category</option>
					<?php foreach ($category as $cat) { ?>
						<option value="<?php echo $cat['id']; ?>" <?php if ($cat['id'] == $selected_category) {
																		echo ' selected="selected" ';
																	} ?>><?php echo $cat['title']; ?></option>
					<?php } ?>
				</select> <a class="pull-right" style="cursor: pointer;" onclick="loadcategorynrws(0);">All News &nbsp;&nbsp;</a>
			</div>
			<div class="graph-visual tables-main">
				<h3 class="inner-tittle two"><?php echo getReporterName($user_id); ?> / USER NEWS</h3>
				<?php
				if ($this->session->flashdata('success')) {
				?>
					<div class="alert alert-success message" style="display: block;">
						<?php echo $this->session->flashdata('success'); ?>
					</div>
				<?php
				} ?>
				<div class="graph">
					<div class="tables">
						<table class="display responsive" id="example-table">
							<thead>
								<tr>
									<th>Id</th>
									<th width="200px">Title</th>
									<th>Image</th>
									<!-- <th>Slug</th> -->
									<th>Date</th>
									<th>Status</th>
									<th style="width: 15%;">Action</th>
								</tr>
							</thead>
							<?php
							$i = 0;
							foreach ($news_list as $key => $news) {
								$status = (!empty($news['status']) && $news['status'] == '1') ? 'Active' : 'Deactive';
								$i++; ?>
								<tr>
									<td><?php echo $i; ?></td>
									<td>
										<a href="<?php echo base_url('home/news_view/' . $news['id'] . '/' . str_replace(' ', '-', $news['title'])); ?>" target="_blank"><?php echo $news['title']; ?></a>
										<br>
										<i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo $news['city']; ?>, <?php echo $news['state']; ?>, <?php echo $news['country']; ?>
										<br>
										<i class="fa fa-list" aria-hidden="true"></i> <?php echo getNewscategory($news['categorise']); ?>
									</td>
									<?php
									if (trim($news['image']) == '') {
										$news['image'] = 'no-image.png';
									}else{
										$news['image'] = 'thumb/'.$news['image'] ;
									} 
									?>
									<td><?php echo "<img src='" . base_url('upload/news/' . $news['image']) . "' height='80px' width='90px'/>"; ?></th>

										<!-- <th><?php echo $news['slug']; ?></th> -->
									<td><?php echo date('D, d M Y', strtotime($news['date'])); ?></td>
									<td><?php echo $status; ?></td>
									<td>
										<a href='<?php echo base_url('admin/news/edit/' . $news['id'] . '/' . $news['reporter']); ?>'><i class="fa fa-edit"></i></a> &nbsp;
										<a onclick='return confirm("Are you sure? you want to delete this news!")' href='<?php echo base_url('admin/news/delete/' . $news['id'] . '/' . $news['reporter']); ?>'><i class="fa fa-trash-o"></i></a>
									</td>
								</tr>
							<?php } ?>
						</table>
					</div>
				</div>
				<!--//graph-visual-->
			</div>
		</div>
		<script>
			$(document).ready(function() {
				$('#example-table').DataTable({
					"pagingType": "full_numbers",
					"lengthMenu": [
						[10, 25, 50, -1],
						[10, 25, 50, "All"]
					]
				});
			});

			function loadcategorynrws(val) {
				location.href = "<?php echo base_url(); ?>admin/users/my_news/<?php echo $user_id; ?>?cat=" + val;
			}
		</script>
	</div>
</div>