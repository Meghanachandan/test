<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin_Model extends CI_Model {
   
    public function register($data){
        $this->db->set('cdate','NOW()',FALSE);
       return $this->db->insert('register',$data);
    }

    public function select($db)
    {
        return $this->db->query($db);
    }
   
    public function get_user($criteria){
        return $this->db->get_where('register',$criteria);
    }


}