  <?php

class Home_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function getRecords($limit = null)
    {
        $qLimit = "";
        if (!empty($limit)) {
            $qLimit = "LIMIT $limit";
        }
        $query = "SELECT * FROM  `our_partner` WHERE status = '1' ORDER BY  `our_partner`.`order` ASC " . $qLimit;
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }

    public function getRecordById($id)
    {

        $this->db->where('id', $id);
        $q = $this->db->get('our_partner');
        //if id is unique we want just one row to be returned
        $data = array_shift($q->result_array());
        return $data;
    }

    public function getForHomeRecords()
    {

        $qLimit = "";
        if (!empty($limit)) {
            $qLimit = "LIMIT '18'";
        }
        $query = "SELECT * FROM  `our_partner` WHERE status = '1' ORDER BY  `our_partner`.`order` ASC " . $qLimit;
        $query = $this->db->query($query);
        $rows = $query->result_array();
        $getData = getSliderData($rows, 6);
        return $getData;
    }

    public function getBanners()
    {
        $query = "SELECT * FROM `banner_images` WHERE `status` = '1' ORDER BY `banner_order` ASC";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        $getData = getSliderData($rows, 6);
        return $getData;
    }


    function get_blog_categories()
    {

        // $query = "SELECT id,title,slug,categorie_type,categorie_colour FROM `news_categories` WHERE `status` = '1' AND `order` > 0 ORDER BY `order` ASC";
        // $query = $this->db->query($query);
        // $rows = $query->result_array();
        // return $rows;
        
        //   $query = "SELECT news_categories.id,news_categories.title,news_categories.slug,news_categories.categorie_type,news_categories.categorie_colour FROM `news_categories` INNER JOIN manage_category ON news_categories.id = manage_category.categoriesid WHERE `news_categories.status` = '1' AND `news_categories.order` > 0 ORDER BY `manage_category.position` ASC";
        // $query = $this->db->query($query);
        // $rows = $query->result_array();
        // return $rows;
    }

    public function get_latest_news_by_id($id)
    {
        $query = "SELECT * FROM `latest_news`  WHERE `latest_news`.`status` = '1' AND `latest_news`.home_artical != '1' AND `latest_news`.`categorise` ='" . $id . "' ORDER BY `latest_news`.`id` DESC limit 7";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }
    
    
    public function get_latest_news_by_ids($id)
    {
        $query = "SELECT * FROM `latest_news`  WHERE `latest_news`.`status` = '1' AND `latest_news`.home_artical != '1' AND `latest_news`.`categorise` ='" . $id . "' ORDER BY `latest_news`.`id` DESC limit 10";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }


    public function get_latest_news_by_id_with_filter($id = 0, $country = '', $state = '', $city = '', $keyword = '', $date_load = 0)
    {

        $condition = "";

        if ($id > 0) {
            $condition .= " AND categorise = '" . $id . "' ";
        }

        if (trim($country) != '') {
            $condition .= " AND country = '" . $country . "' ";
        }

        if (trim($state) != '') {
            $condition .= " AND state = '" . $state . "' ";
        }

        if (trim($city) != '') {
            $condition .= " AND city = '" . $city . "' ";
        }

        if (trim($keyword) != '') {
            $condition .= " AND ( title like '%" . $keyword . "%' OR discription like '%" . $keyword . "%') ";
        }

        if ($date_load > 0) {
            //$limit_condition = "  limit 25, 1000 ";
            $limit_condition = "  limit 10, 500 ";
        } else {
            $limit_condition = " limit 15";
        }

        $query = "SELECT * FROM `latest_news` WHERE `latest_news`.`status` = '1' AND `latest_news`.home_artical != '1' " . $condition . " ORDER BY `latest_news`.`id` DESC  " . $limit_condition;
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }


    public function get_latest_news()
    {
        $query = "SELECT * FROM `latest_news` WHERE `latest_news`.`status` = '1' AND `latest_news`.home_artical != '1' ORDER BY `latest_news`.`id` DESC  LIMIT 0,8";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }

    function getHomePagesArtical()
    {
        $query = "SELECT * FROM `news_categories` WHERE `status` = '1' AND categorie_type = '1' ORDER BY `created_date` DESC limit 3";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }

    function getHomeAdds()
    {
        $query = "SELECT * FROM `adds` WHERE `status` = '1' AND news_cate='' AND news_sub_cateid='' ORDER BY id DESC LIMIT 0,1";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        $allAdds = array();

        foreach ($rows as $add) {
            $allAdds[$add['categorie']][] = $add;
        }
        return $allAdds;
    }

    function getHomePagesPopulerNews()
    {
        $query = "SELECT news_id,COUNT(id) AS cnt FROM `populer_news` WHERE news_id IS NOT NULL AND `populer_news`.`date`  BETWEEN NOW() - INTERVAL 10 DAY AND NOW() GROUP BY news_id ORDER BY cnt DESC LIMIT 0,7";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        $allids = array();

        foreach ($rows as $pid) {
            if ($pid['news_id'] > 0) {
                $allids[] = $pid['news_id'];
            }
        }

        if (!empty($allids)) {
            $all_id_string = implode(',', $allids);
            
            $query = "SELECT * FROM `latest_news` WHERE `status` = '1' AND home_artical != '1' AND id in (" . $all_id_string . ")  LIMIT 10";
            $query = $this->db->query($query);
            $rows = $query->result_array();
            return $rows;
        }
    }

    public function getcategoryInfo($id)
    {
        $this->db->where('id', $id);
        $q = $this->db->get('news_categories');
        $data = array_shift($q->result_array());
        return $data;
    }

    public function get_latest_news_with_filter($id = 0, $country = '', $state = '', $city = '', $keyword = '')
    {

        $condition = "";

        if ($id > 0) {
            $condition .= " AND categorise = '" . $id . "' ";
        }

        if ($country != '') {
            $condition .= " AND country = '" . $country . "' ";
        }

        if ($state != '') {
            $condition .= " AND state = '" . $state . "' ";
        }

        if ($city != '') {
            $condition .= " AND city = '" . $city . "' ";
        }

        if ($keyword != '') {
            $condition .= " AND ( title like '%" . $keyword . "%' OR discription like '%" . $keyword . "%') ";
        }

        $query = "SELECT * FROM `latest_news` WHERE `latest_news`.`status` = '1' AND `latest_news`.home_artical != '1'  " . $condition . "  ORDER BY `latest_news`.`id` DESC limit 5";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }

    function getHomePagesPopulerNews_with_filter($id = 0, $country = '', $state = '', $city = '', $keyword = '')
    {
        $query = "SELECT news_id,COUNT(id) AS cnt FROM `populer_news` WHERE news_id IS NOT NULL AND `populer_news`.`date`  BETWEEN NOW() - INTERVAL 10 DAY AND NOW() GROUP BY news_id ORDER BY cnt DESC";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        $allids = array();

        foreach ($rows as $pid) {
            if ($pid['news_id'] > 0) {
                $allids[] = $pid['news_id'];
            }
        }


        $condition = "";

        if ($id > 0) {
            $condition .= " AND categorise = '" . $id . "' ";
        }

        if ($country != '') {
            $condition .= " AND country = '" . $country . "' ";
        }

        if ($state != '') {
            $condition .= " AND state = '" . $state . "' ";
        }

        if ($city != '') {
            $condition .= " AND city = '" . $city . "' ";
        }

        if ($keyword != '') {
            $condition .= " AND ( title like '%" . $keyword . "%' OR discription like '%" . $keyword . "%') ";
        }
        if(!empty($allids)){
            $all_id_string = implode(',', $allids);
            $id_condition = " AND id in (" . $all_id_string . ") ";
        }else{
            $id_condition = "";
        }
        
        $query = "SELECT * FROM `latest_news` WHERE `status` = '1' AND home_artical != '1' ".$id_condition." " . $condition . "  LIMIT 5";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }


    function getRecientView()
    {

        $allids = array();
        if (!empty($_SESSION['recient_view'])) {
            foreach ($_SESSION['recient_view'] as $id) {
                if ($id > 0) {
                    $allids[] = $id;
                }
            }

            //$all_id_string = implode(',', $allids);

            if(!empty($allids)){
                $all_id_string = implode(',', $allids);
                $id_condition = " AND id in (" . $all_id_string . ") ";
            }else{
                $id_condition = "";
            }

            $query = "SELECT * FROM `latest_news` WHERE `status` = '1' AND home_artical != '1' ".$id_condition." limit 5 ";
            $query = $this->db->query($query);
            $rows = $query->result_array();
            return $rows;
        } else {
            return false;
        }
    }

    function getfaqs(){
        $query = "SELECT * FROM `faqs` order by id asc";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }

    function getTerms(){
        $query = "SELECT * FROM `terms` where id ='1'";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows[0];
    }

    

    function getNewsInfo($id,$preview='')
    {
        $condition ='';
        if($preview==''){
            $condition = " AND `l`.`status` = '1' ";
        }

        $query = "SELECT *,
        ifnull((SELECT id FROM latest_news as l2 WHERE l2.categorise=l.categorise AND l2.created_date>l.created_date AND l2.status=l.status ORDER BY l2.created_date ASC LIMIT 1),0) as next_news_id,  
        ifnull((SELECT id FROM latest_news as l3 WHERE l3.categorise=l.categorise AND  l3.created_date<l.created_date AND l3.status=l.status ORDER BY l3.created_date DESC LIMIT 1),0) as previous_news_id  
        FROM `latest_news`as l  WHERE `l`.`id`='" . $id . "' ".$condition;

        // $query = "SELECT * FROM `latest_news`  WHERE `latest_news`.`id`='" . $id . "' ".$condition;
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows[0];
    }

    function getNewsViewById($id){
        $query = "SELECT `news_id` FROM `populer_news` WHERE news_id='".$id."' GROUP BY ip,`user_id` ";
        $query = $this->db->query($query);
        $rows = $query->result_array();
        return $rows;
    }
    
public function getsubcategoryInfo($id)
    {
        $this->db->where('id', $id);
        $q = $this->db->get('news_categories');
        $data = array_shift($q->result_array());
        return $data;
    }
}
